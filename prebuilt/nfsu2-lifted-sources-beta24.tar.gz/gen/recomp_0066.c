/* AUTO-GENERATED from SPEED2.analysis.exe by run_lift.py (pcrecomp lift32). DO NOT EDIT, DO NOT COMMIT. */
#define RECOMP_GENERATED_CODE
#include "recomp_types.h"
#include "recomp_funcs.h"
#include "guest_render_probe.h"
#include <math.h>
#include <string.h>

void sub_00779300(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779300u);

L_00779300:
    eax = MEM32(ebp + (-0x60)); /* 0x00779300: mov eax, dword ptr [ebp - 0x60] */
    PUSH32(esp, eax); /* 0x00779303: push eax */
    RECOMP_CALL(sub_00486E80); /* 0x00779304: call 0x486e80 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00779309: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077930A: ret  */

}

void sub_0077930B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077930Bu);

    goto L_0077930B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077930B:
    eax = 0x007E4B9Cu; /* 0x0077930B: mov eax, 0x7e4b9c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779310: jmp 0x75bf0e */

}

void sub_00779320(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779320u);

L_00779320:
    PUSH32(esp, 0x00436820u); /* 0x00779320: push 0x436820 */
    PUSH32(esp, 0xCBu); /* 0x00779325: push 0xcb */
    PUSH32(esp, 8); /* 0x0077932A: push 8 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077932C: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077932F: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x00779330: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779335: ret  */

}

void sub_00779336(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779336u);

    goto L_00779336;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779336:
    eax = 0x007E4BC0u; /* 0x00779336: mov eax, 0x7e4bc0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077933B: jmp 0x75bf0e */

}

void sub_00779340(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779340u);

L_00779340:
    PUSH32(esp, 0); /* 0x00779340: push 0 */
    PUSH32(esp, 0x007A52C0u); /* 0x00779342: push 0x7a52c0 */
    eax = MEM32(ebp + (-0x10)); /* 0x00779347: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077934A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077934B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779350: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779353: ret  */

}

void sub_00779354(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779354u);

    goto L_00779354;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779354:
    eax = 0x007E4BE4u; /* 0x00779354: mov eax, 0x7e4be4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779359: jmp 0x75bf0e */

}

void sub_00779360(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779360u);

L_00779360:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779360: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4A0u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4A0u; /* 0x00779363: add ecx, 0x4a0 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005E07F0u); RECOMP_RETURN(); /* 0x00779369: jmp 0x5e07f0 */

}

void sub_0077936E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077936Eu);

    goto L_0077936E;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077936E:
    eax = 0x007E4C08u; /* 0x0077936E: mov eax, 0x7e4c08 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779373: jmp 0x75bf0e */

}

void sub_00779380(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779380u);

L_00779380:
    ecx = MEM32(ebp + (-0x14)); /* 0x00779380: mov ecx, dword ptr [ebp - 0x14] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(8);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 8; /* 0x00779383: add ecx, 8 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x00779386: jmp 0x5ce0f0 */

}

void sub_0077938B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077938Bu);

    goto L_0077938B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077938B:
    eax = 0x007E4C2Cu; /* 0x0077938B: mov eax, 0x7e4c2c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779390: jmp 0x75bf0e */

}

void sub_007793A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007793A0u);

L_007793A0:
    eax = MEM32(ebp + 0x4); /* 0x007793A0: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x007793A3: push eax */
    RECOMP_CALL(sub_005D7D10); /* 0x007793A4: call 0x5d7d10 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x007793A9: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007793AA: ret  */

}

void sub_007793AB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007793ABu);

    goto L_007793AB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007793AB:
    eax = 0x007E4C50u; /* 0x007793AB: mov eax, 0x7e4c50 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007793B0: jmp 0x75bf0e */

}

void sub_007793C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007793C0u);

L_007793C0:
    ecx = MEM32(ebp + (-0x40)); /* 0x007793C0: mov ecx, dword ptr [ebp - 0x40] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0xCu; /* 0x007793C3: add ecx, 0xc */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x007793C6: jmp 0x5cde60 */

}

void sub_007793CB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007793CBu);

L_007793CB:
    ecx = MEM32(ebp + (-0x40)); /* 0x007793CB: mov ecx, dword ptr [ebp - 0x40] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x14u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x14u; /* 0x007793CE: add ecx, 0x14 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x007793D1: jmp 0x5cde60 */

}

void sub_007793D6(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007793D6u);

L_007793D6:
    PUSH32(esp, 0x004022D0u); /* 0x007793D6: push 0x4022d0 */
    PUSH32(esp, 0xC0u); /* 0x007793DB: push 0xc0 */
    PUSH32(esp, 0x14u); /* 0x007793E0: push 0x14 */
    eax = MEM32(ebp + (-0x40)); /* 0x007793E2: mov eax, dword ptr [ebp - 0x40] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x1Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x1Cu; /* 0x007793E5: add eax, 0x1c */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x007793E8: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x007793E9: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007793EE: ret  */

}

void sub_007793EF(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007793EFu);

    goto L_007793EF;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007793EF:
    eax = 0x007E4C84u; /* 0x007793EF: mov eax, 0x7e4c84 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007793F4: jmp 0x75bf0e */

}

void sub_00779400(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779400u);

L_00779400:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779400: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0xCu; /* 0x00779403: add ecx, 0xc */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00779406: jmp 0x5cde60 */

}

void sub_0077940B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077940Bu);

L_0077940B:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077940B: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x14u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x14u; /* 0x0077940E: add ecx, 0x14 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00779411: jmp 0x5cde60 */

}

void sub_00779416(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779416u);

L_00779416:
    PUSH32(esp, 0x004022D0u); /* 0x00779416: push 0x4022d0 */
    PUSH32(esp, 0xC0u); /* 0x0077941B: push 0xc0 */
    PUSH32(esp, 0x14u); /* 0x00779420: push 0x14 */
    eax = MEM32(ebp + (-0x10)); /* 0x00779422: mov eax, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x1Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x1Cu; /* 0x00779425: add eax, 0x1c */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x00779428: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x00779429: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077942E: ret  */

}

void sub_0077942F(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077942Fu);

    goto L_0077942F;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077942F:
    eax = 0x007E4CB8u; /* 0x0077942F: mov eax, 0x7e4cb8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779434: jmp 0x75bf0e */

}

void sub_00779440(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779440u);

L_00779440:
    PUSH32(esp, 0); /* 0x00779440: push 0 */
    PUSH32(esp, 0x007A52DCu); /* 0x00779442: push 0x7a52dc */
    eax = MEM32(ebp + 0x4); /* 0x00779447: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x0077944A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077944B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779450: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779453: ret  */

}

void sub_00779454(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779454u);

    goto L_00779454;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779454:
    eax = 0x007E4CDCu; /* 0x00779454: mov eax, 0x7e4cdc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779459: jmp 0x75bf0e */

}

void sub_00779460(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779460u);

L_00779460:
    ecx = ebp + (-0x18); /* 0x00779460: lea ecx, [ebp - 0x18] */
    RECOMP_ITAIL(0x005E0860u); RECOMP_RETURN(); /* 0x00779463: jmp 0x5e0860 */

}

void sub_00779468(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779468u);

L_00779468:
    ecx = ebp + (-0x20); /* 0x00779468: lea ecx, [ebp - 0x20] */
    RECOMP_ITAIL(0x005E0860u); RECOMP_RETURN(); /* 0x0077946B: jmp 0x5e0860 */

}

void sub_00779470(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779470u);

    goto L_00779470;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779470:
    eax = 0x007E4D08u; /* 0x00779470: mov eax, 0x7e4d08 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779475: jmp 0x75bf0e */

}

void sub_00779480(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779480u);

L_00779480:
    PUSH32(esp, 0); /* 0x00779480: push 0 */
    PUSH32(esp, 0x007A5300u); /* 0x00779482: push 0x7a5300 */
    eax = MEM32(ebp + (-0x10)); /* 0x00779487: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077948A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077948B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779490: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779493: ret  */

}

void sub_00779494(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779494u);

    goto L_00779494;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779494:
    eax = 0x007E4D2Cu; /* 0x00779494: mov eax, 0x7e4d2c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779499: jmp 0x75bf0e */

}

void sub_007794A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007794A0u);

L_007794A0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007794A0: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(8);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 8; /* 0x007794A3: add ecx, 8 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x007794A6: jmp 0x5ce0f0 */

}

void sub_007794AB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007794ABu);

    goto L_007794AB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007794AB:
    eax = 0x007E4D50u; /* 0x007794AB: mov eax, 0x7e4d50 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007794B0: jmp 0x75bf0e */

}

void sub_007794C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007794C0u);

L_007794C0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007794C0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x007794C3: jmp 0x5cde60 */

}

void sub_007794C8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007794C8u);

L_007794C8:
    ecx = MEM32(ebp + (-0x10)); /* 0x007794C8: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(8);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 8; /* 0x007794CB: add ecx, 8 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x007794CE: jmp 0x5cde60 */

}

void sub_007794D3(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007794D3u);

    goto L_007794D3;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007794D3:
    eax = 0x007E4D7Cu; /* 0x007794D3: mov eax, 0x7e4d7c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007794D8: jmp 0x75bf0e */

}

void sub_007794E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007794E0u);

L_007794E0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007794E0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x007794E3: jmp 0x5cde60 */

}

void sub_007794E8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007794E8u);

L_007794E8:
    ecx = MEM32(ebp + (-0x10)); /* 0x007794E8: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(8);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 8; /* 0x007794EB: add ecx, 8 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x007794EE: jmp 0x5cde60 */

}

void sub_007794F3(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007794F3u);

L_007794F3:
    ecx = MEM32(ebp + (-0x10)); /* 0x007794F3: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x10u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x10u; /* 0x007794F6: add ecx, 0x10 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x007794F9: jmp 0x5cde60 */

}

void sub_007794FE(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007794FEu);

L_007794FE:
    ecx = MEM32(ebp + (-0x10)); /* 0x007794FE: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x18u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x18u; /* 0x00779501: add ecx, 0x18 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00779504: jmp 0x5cde60 */

}

void sub_00779509(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779509u);

L_00779509:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779509: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x20u; /* 0x0077950C: add ecx, 0x20 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x0077950F: jmp 0x5cde60 */

}

void sub_00779514(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779514u);

L_00779514:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779514: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x28u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x28u; /* 0x00779517: add ecx, 0x28 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x0077951A: jmp 0x5cde60 */

}

void sub_0077951F(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077951Fu);

L_0077951F:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077951F: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x30u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x30u; /* 0x00779522: add ecx, 0x30 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00779525: jmp 0x5cde60 */

}

void sub_0077952A(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077952Au);

L_0077952A:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077952A: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x38u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x38u; /* 0x0077952D: add ecx, 0x38 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00779530: jmp 0x5cde60 */

}

void sub_00779535(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779535u);

L_00779535:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779535: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x40u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x40u; /* 0x00779538: add ecx, 0x40 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x0077953B: jmp 0x5cde60 */

}

void sub_00779540(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779540u);

    goto L_00779540;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779540:
    eax = 0x007E4DE0u; /* 0x00779540: mov eax, 0x7e4de0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779545: jmp 0x75bf0e */

}

void sub_00779550(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779550u);

L_00779550:
    eax = MEM32(ebp + 0x4); /* 0x00779550: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00779553: push eax */
    RECOMP_CALL(sub_005D2DF0); /* 0x00779554: call 0x5d2df0 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00779559: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077955A: ret  */

}

void sub_0077955B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077955Bu);

    goto L_0077955B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077955B:
    eax = 0x007E4E04u; /* 0x0077955B: mov eax, 0x7e4e04 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779560: jmp 0x75bf0e */

}

void sub_00779570(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779570u);

L_00779570:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779570: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x60u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x60u; /* 0x00779573: add ecx, 0x60 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005DC580u); RECOMP_RETURN(); /* 0x00779576: jmp 0x5dc580 */

}

void sub_0077957B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077957Bu);

    goto L_0077957B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077957B:
    eax = 0x007E4E28u; /* 0x0077957B: mov eax, 0x7e4e28 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779580: jmp 0x75bf0e */

}

void sub_00779590(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779590u);

L_00779590:
    eax = MEM32(ebp + (-0x14)); /* 0x00779590: mov eax, dword ptr [ebp - 0x14] */
    PUSH32(esp, eax); /* 0x00779593: push eax */
    RECOMP_CALL(sub_005D2E10); /* 0x00779594: call 0x5d2e10 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00779599: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077959A: ret  */

}

void sub_0077959B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077959Bu);

    goto L_0077959B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077959B:
    eax = 0x007E4E4Cu; /* 0x0077959B: mov eax, 0x7e4e4c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007795A0: jmp 0x75bf0e */

}

void sub_007795B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007795B0u);

L_007795B0:
    ecx = ebp + (-0x320); /* 0x007795B0: lea ecx, [ebp - 0x320] */
    RECOMP_ITAIL(0x005E0BE0u); RECOMP_RETURN(); /* 0x007795B6: jmp 0x5e0be0 */

}

void sub_007795BB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007795BBu);

    goto L_007795BB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007795BB:
    eax = 0x007E4E70u; /* 0x007795BB: mov eax, 0x7e4e70 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007795C0: jmp 0x75bf0e */

}

void sub_007795D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007795D0u);

L_007795D0:
    ecx = ebp + (-0x35C); /* 0x007795D0: lea ecx, [ebp - 0x35c] */
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x007795D6: jmp 0x4022d0 */

}

void sub_007795DB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007795DBu);

L_007795DB:
    ecx = ebp + (-0x320); /* 0x007795DB: lea ecx, [ebp - 0x320] */
    RECOMP_ITAIL(0x005E0BE0u); RECOMP_RETURN(); /* 0x007795E1: jmp 0x5e0be0 */

}

void sub_007795E6(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007795E6u);

    goto L_007795E6;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007795E6:
    eax = 0x007E4EA4u; /* 0x007795E6: mov eax, 0x7e4ea4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007795EB: jmp 0x75bf0e */

}

void sub_007795F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007795F0u);

L_007795F0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007795F0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x0040A120u); RECOMP_RETURN(); /* 0x007795F3: jmp 0x40a120 */

}

void sub_007795F8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007795F8u);

L_007795F8:
    PUSH32(esp, 0); /* 0x007795F8: push 0 */
    PUSH32(esp, 0x00785B54u); /* 0x007795FA: push 0x785b54 */
    eax = MEM32(ebp + 0x4); /* 0x007795FF: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00779602: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779603: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779608: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077960B: ret  */

}

void sub_0077960C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077960Cu);

    goto L_0077960C;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077960C:
    eax = 0x007E4ED0u; /* 0x0077960C: mov eax, 0x7e4ed0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779611: jmp 0x75bf0e */

}

void sub_00779620(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779620u);

L_00779620:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779620: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x0040A120u); RECOMP_RETURN(); /* 0x00779623: jmp 0x40a120 */

}

void sub_00779628(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779628u);

    goto L_00779628;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779628:
    eax = 0x007E4EF4u; /* 0x00779628: mov eax, 0x7e4ef4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077962D: jmp 0x75bf0e */

}

void sub_00779640(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779640u);

L_00779640:
    PUSH32(esp, 0); /* 0x00779640: push 0 */
    PUSH32(esp, 0x007A5D2Cu); /* 0x00779642: push 0x7a5d2c */
    eax = MEM32(ebp + 0x4); /* 0x00779647: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x0077964A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077964B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779650: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779653: ret  */

}

void sub_00779654(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779654u);

L_00779654:
    PUSH32(esp, 0); /* 0x00779654: push 0 */
    PUSH32(esp, 0x00785298u); /* 0x00779656: push 0x785298 */
    eax = MEM32(ebp + 0x4); /* 0x0077965B: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x0077965E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077965F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779664: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779667: ret  */

}

void sub_00779668(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779668u);

L_00779668:
    PUSH32(esp, 0); /* 0x00779668: push 0 */
    PUSH32(esp, 0x00785BB0u); /* 0x0077966A: push 0x785bb0 */
    eax = MEM32(ebp + 0x4); /* 0x0077966F: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00779672: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779673: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779678: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077967B: ret  */

}

void sub_0077967C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077967Cu);

L_0077967C:
    PUSH32(esp, 0); /* 0x0077967C: push 0 */
    PUSH32(esp, 0x00785B84u); /* 0x0077967E: push 0x785b84 */
    eax = MEM32(ebp + 0x4); /* 0x00779683: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00779686: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779687: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077968C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077968F: ret  */

}

void sub_00779690(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779690u);

L_00779690:
    PUSH32(esp, 0); /* 0x00779690: push 0 */
    PUSH32(esp, 0x00785B98u); /* 0x00779692: push 0x785b98 */
    eax = MEM32(ebp + 0x4); /* 0x00779697: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x0077969A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077969B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007796A0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007796A3: ret  */

}

void sub_007796A4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007796A4u);

L_007796A4:
    PUSH32(esp, 0); /* 0x007796A4: push 0 */
    PUSH32(esp, 0x007A5D18u); /* 0x007796A6: push 0x7a5d18 */
    eax = MEM32(ebp + 0x4); /* 0x007796AB: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x007796AE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007796AF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007796B4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007796B7: ret  */

}

void sub_007796B8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007796B8u);

    goto L_007796B8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007796B8:
    eax = 0x007E4F40u; /* 0x007796B8: mov eax, 0x7e4f40 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007796BD: jmp 0x75bf0e */

}

void sub_007796D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007796D0u);

L_007796D0:
    PUSH32(esp, 0); /* 0x007796D0: push 0 */
    PUSH32(esp, 0x007A5EA8u); /* 0x007796D2: push 0x7a5ea8 */
    eax = MEM32(ebp + (-0x10)); /* 0x007796D7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007796DA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007796DB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007796E0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007796E3: ret  */

}

void sub_007796E4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007796E4u);

    goto L_007796E4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007796E4:
    eax = 0x007E4F64u; /* 0x007796E4: mov eax, 0x7e4f64 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007796E9: jmp 0x75bf0e */

}

void sub_007796F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007796F0u);

L_007796F0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007796F0: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x11Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x11Cu; /* 0x007796F3: add ecx, 0x11c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x007796F9: jmp 0x4022d0 */

}

void sub_007796FE(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007796FEu);

L_007796FE:
    ecx = MEM32(ebp + (-0x10)); /* 0x007796FE: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x260u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x260u; /* 0x00779701: add ecx, 0x260 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x00779707: jmp 0x4022d0 */

}

void sub_0077970C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077970Cu);

L_0077970C:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077970C: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x3A4u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x3A4u; /* 0x0077970F: add ecx, 0x3a4 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x00779715: jmp 0x4022d0 */

}

void sub_0077971A(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077971Au);

L_0077971A:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077971A: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4E8u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4E8u; /* 0x0077971D: add ecx, 0x4e8 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x00779723: jmp 0x4022d0 */

}

void sub_00779728(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779728u);

L_00779728:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779728: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x62Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x62Cu; /* 0x0077972B: add ecx, 0x62c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x00779731: jmp 0x4022d0 */

}

void sub_00779736(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779736u);

L_00779736:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779736: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x770u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x770u; /* 0x00779739: add ecx, 0x770 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x0077973F: jmp 0x4022d0 */

}

void sub_00779744(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779744u);

L_00779744:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779744: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x8BCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x8BCu; /* 0x00779747: add ecx, 0x8bc */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x0077974D: jmp 0x4022d0 */

}

void sub_00779752(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779752u);

L_00779752:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779752: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0xA08u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0xA08u; /* 0x00779755: add ecx, 0xa08 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x0077975B: jmp 0x4022d0 */

}

void sub_00779760(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779760u);

L_00779760:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779760: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0xB54u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0xB54u; /* 0x00779763: add ecx, 0xb54 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x00779769: jmp 0x4022d0 */

}

void sub_0077976E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077976Eu);

L_0077976E:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077976E: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0xCA0u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0xCA0u; /* 0x00779771: add ecx, 0xca0 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x00779777: jmp 0x4022d0 */

}

void sub_0077977C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077977Cu);

L_0077977C:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077977C: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0xDECu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0xDECu; /* 0x0077977F: add ecx, 0xdec */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x00779785: jmp 0x4022d0 */

}

void sub_0077978A(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077978Au);

L_0077978A:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077978A: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0xF38u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0xF38u; /* 0x0077978D: add ecx, 0xf38 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x00779793: jmp 0x4022d0 */

}

void sub_00779798(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779798u);

L_00779798:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779798: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x1084u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x1084u; /* 0x0077979B: add ecx, 0x1084 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x007797A1: jmp 0x4022d0 */

}

void sub_007797A6(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007797A6u);

L_007797A6:
    ecx = MEM32(ebp + (-0x10)); /* 0x007797A6: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x11D0u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x11D0u; /* 0x007797A9: add ecx, 0x11d0 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x007797AF: jmp 0x4022d0 */

}

void sub_007797B4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007797B4u);

L_007797B4:
    ecx = MEM32(ebp + (-0x10)); /* 0x007797B4: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x131Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x131Cu; /* 0x007797B7: add ecx, 0x131c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x007797BD: jmp 0x4022d0 */

}

void sub_007797C2(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007797C2u);

L_007797C2:
    ecx = MEM32(ebp + (-0x10)); /* 0x007797C2: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x1468u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x1468u; /* 0x007797C5: add ecx, 0x1468 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x007797CB: jmp 0x4022d0 */

}

void sub_007797D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007797D0u);

L_007797D0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007797D0: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x15B4u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x15B4u; /* 0x007797D3: add ecx, 0x15b4 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x007797D9: jmp 0x4022d0 */

}

void sub_007797DE(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007797DEu);

L_007797DE:
    ecx = MEM32(ebp + (-0x10)); /* 0x007797DE: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x1700u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x1700u; /* 0x007797E1: add ecx, 0x1700 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x007797E7: jmp 0x4022d0 */

}

void sub_007797EC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007797ECu);

    goto L_007797EC;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007797EC:
    eax = 0x007E5258u; /* 0x007797EC: mov eax, 0x7e5258 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007797F1: jmp 0x75bf0e */

}

void sub_00779800(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779800u);

L_00779800:
    ecx = ebp + (-0x274); /* 0x00779800: lea ecx, [ebp - 0x274] */
    RECOMP_ITAIL(0x0043E0D0u); RECOMP_RETURN(); /* 0x00779806: jmp 0x43e0d0 */

}

void sub_0077980B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077980Bu);

L_0077980B:
    ecx = ebp + (-0x4DC); /* 0x0077980B: lea ecx, [ebp - 0x4dc] */
    RECOMP_ITAIL(0x0043E0D0u); RECOMP_RETURN(); /* 0x00779811: jmp 0x43e0d0 */

}

void sub_00779816(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779816u);

    goto L_00779816;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779816:
    eax = 0x007E4F90u; /* 0x00779816: mov eax, 0x7e4f90 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077981B: jmp 0x75bf0e */

}

void sub_00779820(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779820u);

L_00779820:
    ecx = MEM32(ebp + (-0x18)); /* 0x00779820: mov ecx, dword ptr [ebp - 0x18] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x2D4u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x2D4u; /* 0x00779823: add ecx, 0x2d4 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00411770u); RECOMP_RETURN(); /* 0x00779829: jmp 0x411770 */

}

void sub_0077982E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077982Eu);

L_0077982E:
    ecx = MEM32(ebp + (-0x18)); /* 0x0077982E: mov ecx, dword ptr [ebp - 0x18] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x64Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x64Cu; /* 0x00779831: add ecx, 0x64c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005E0BE0u); RECOMP_RETURN(); /* 0x00779837: jmp 0x5e0be0 */

}

void sub_0077983C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077983Cu);

L_0077983C:
    PUSH32(esp, 0); /* 0x0077983C: push 0 */
    PUSH32(esp, 0x007A6114u); /* 0x0077983E: push 0x7a6114 */
    eax = MEM32(ebp + (-0x14)); /* 0x00779843: mov eax, dword ptr [ebp - 0x14] */
    PUSH32(esp, eax); /* 0x00779846: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779847: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077984C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077984F: ret  */

}

void sub_00779850(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779850u);

L_00779850:
    eax = MEM32(ebp + (-0x14)); /* 0x00779850: mov eax, dword ptr [ebp - 0x14] */
    PUSH32(esp, eax); /* 0x00779853: push eax */
    RECOMP_CALL(sub_00575590); /* 0x00779854: call 0x575590 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00779859: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077985A: ret  */

}

void sub_0077985B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077985Bu);

    goto L_0077985B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077985B:
    eax = 0x007E4FCCu; /* 0x0077985B: mov eax, 0x7e4fcc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779860: jmp 0x75bf0e */

}

void sub_00779870(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779870u);

L_00779870:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779870: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x2D4u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x2D4u; /* 0x00779873: add ecx, 0x2d4 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00411770u); RECOMP_RETURN(); /* 0x00779879: jmp 0x411770 */

}

void sub_0077987E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077987Eu);

L_0077987E:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077987E: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x64Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x64Cu; /* 0x00779881: add ecx, 0x64c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005E0BE0u); RECOMP_RETURN(); /* 0x00779887: jmp 0x5e0be0 */

}

void sub_0077988C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077988Cu);

    goto L_0077988C;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077988C:
    eax = 0x007E4FF8u; /* 0x0077988C: mov eax, 0x7e4ff8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779891: jmp 0x75bf0e */

}

void sub_007798A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007798A0u);

L_007798A0:
    PUSH32(esp, 0); /* 0x007798A0: push 0 */
    PUSH32(esp, 0x007A61C8u); /* 0x007798A2: push 0x7a61c8 */
    eax = MEM32(ebp + 0x4); /* 0x007798A7: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x007798AA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007798AB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007798B0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007798B3: ret  */

}

void sub_007798B4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007798B4u);

    goto L_007798B4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007798B4:
    eax = 0x007E501Cu; /* 0x007798B4: mov eax, 0x7e501c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007798B9: jmp 0x75bf0e */

}

void sub_007798C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007798C0u);

L_007798C0:
    PUSH32(esp, 0); /* 0x007798C0: push 0 */
    PUSH32(esp, 0x007A62A4u); /* 0x007798C2: push 0x7a62a4 */
    eax = MEM32(ebp + (-0xB84)); /* 0x007798C7: mov eax, dword ptr [ebp - 0xb84] */
    PUSH32(esp, eax); /* 0x007798CD: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007798CE: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007798D3: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007798D6: ret  */

}

void sub_007798D7(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007798D7u);

L_007798D7:
    PUSH32(esp, 0); /* 0x007798D7: push 0 */
    PUSH32(esp, 0x007A6288u); /* 0x007798D9: push 0x7a6288 */
    eax = MEM32(ebp + (-0xB84)); /* 0x007798DE: mov eax, dword ptr [ebp - 0xb84] */
    PUSH32(esp, eax); /* 0x007798E4: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007798E5: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007798EA: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007798ED: ret  */

}

void sub_007798EE(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007798EEu);

L_007798EE:
    PUSH32(esp, 0); /* 0x007798EE: push 0 */
    PUSH32(esp, 0x007A6278u); /* 0x007798F0: push 0x7a6278 */
    eax = MEM32(ebp + (-0xB84)); /* 0x007798F5: mov eax, dword ptr [ebp - 0xb84] */
    PUSH32(esp, eax); /* 0x007798FB: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007798FC: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779901: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779904: ret  */

}

void sub_00779905(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779905u);

L_00779905:
    PUSH32(esp, 0); /* 0x00779905: push 0 */
    PUSH32(esp, 0x007A6260u); /* 0x00779907: push 0x7a6260 */
    eax = MEM32(ebp + (-0xB84)); /* 0x0077990C: mov eax, dword ptr [ebp - 0xb84] */
    PUSH32(esp, eax); /* 0x00779912: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779913: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779918: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077991B: ret  */

}

void sub_0077991C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077991Cu);

L_0077991C:
    PUSH32(esp, 0); /* 0x0077991C: push 0 */
    PUSH32(esp, 0x007A624Cu); /* 0x0077991E: push 0x7a624c */
    eax = MEM32(ebp + (-0xB7C)); /* 0x00779923: mov eax, dword ptr [ebp - 0xb7c] */
    PUSH32(esp, eax); /* 0x00779929: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077992A: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077992F: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779932: ret  */

}

void sub_00779933(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779933u);

L_00779933:
    PUSH32(esp, 0); /* 0x00779933: push 0 */
    PUSH32(esp, 0x007A6238u); /* 0x00779935: push 0x7a6238 */
    eax = MEM32(ebp + (-0xB84)); /* 0x0077993A: mov eax, dword ptr [ebp - 0xb84] */
    PUSH32(esp, eax); /* 0x00779940: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779941: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779946: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779949: ret  */

}

void sub_0077994A(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077994Au);

L_0077994A:
    PUSH32(esp, 0); /* 0x0077994A: push 0 */
    PUSH32(esp, 0x007A6224u); /* 0x0077994C: push 0x7a6224 */
    eax = MEM32(ebp + (-0xB84)); /* 0x00779951: mov eax, dword ptr [ebp - 0xb84] */
    PUSH32(esp, eax); /* 0x00779957: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779958: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077995D: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779960: ret  */

}

void sub_00779961(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779961u);

L_00779961:
    ecx = ebp + (-0xAEC); /* 0x00779961: lea ecx, [ebp - 0xaec] */
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x00779967: jmp 0x4022d0 */

}

void sub_0077996C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077996Cu);

L_0077996C:
    ecx = ebp + (-0x878); /* 0x0077996C: lea ecx, [ebp - 0x878] */
    RECOMP_ITAIL(0x005E0BE0u); RECOMP_RETURN(); /* 0x00779972: jmp 0x5e0be0 */

}

void sub_00779977(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779977u);

L_00779977:
    PUSH32(esp, 0); /* 0x00779977: push 0 */
    PUSH32(esp, 0x007A624Cu); /* 0x00779979: push 0x7a624c */
    eax = MEM32(ebp + (-0xB54)); /* 0x0077997E: mov eax, dword ptr [ebp - 0xb54] */
    PUSH32(esp, eax); /* 0x00779984: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779985: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077998A: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077998D: ret  */

}

void sub_0077998E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077998Eu);

L_0077998E:
    PUSH32(esp, 0); /* 0x0077998E: push 0 */
    PUSH32(esp, 0x007A6210u); /* 0x00779990: push 0x7a6210 */
    eax = MEM32(ebp + (-0xB84)); /* 0x00779995: mov eax, dword ptr [ebp - 0xb84] */
    PUSH32(esp, eax); /* 0x0077999B: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077999C: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007799A1: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007799A4: ret  */

}

void sub_007799A5(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007799A5u);

L_007799A5:
    ecx = ebp + (-0x328); /* 0x007799A5: lea ecx, [ebp - 0x328] */
    RECOMP_ITAIL(0x005E0BE0u); RECOMP_RETURN(); /* 0x007799AB: jmp 0x5e0be0 */

}

void sub_007799B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007799B0u);

L_007799B0:
    PUSH32(esp, 0); /* 0x007799B0: push 0 */
    PUSH32(esp, 0x007A624Cu); /* 0x007799B2: push 0x7a624c */
    eax = MEM32(ebp + (-0xB54)); /* 0x007799B7: mov eax, dword ptr [ebp - 0xb54] */
    PUSH32(esp, eax); /* 0x007799BD: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007799BE: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007799C3: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007799C6: ret  */

}

void sub_007799C7(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007799C7u);

L_007799C7:
    PUSH32(esp, 0); /* 0x007799C7: push 0 */
    PUSH32(esp, 0x007A6210u); /* 0x007799C9: push 0x7a6210 */
    eax = MEM32(ebp + (-0xB84)); /* 0x007799CE: mov eax, dword ptr [ebp - 0xb84] */
    PUSH32(esp, eax); /* 0x007799D4: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007799D5: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007799DA: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007799DD: ret  */

}

void sub_007799DE(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007799DEu);

L_007799DE:
    PUSH32(esp, 0); /* 0x007799DE: push 0 */
    PUSH32(esp, 0x007A61FCu); /* 0x007799E0: push 0x7a61fc */
    eax = MEM32(ebp + (-0xB84)); /* 0x007799E5: mov eax, dword ptr [ebp - 0xb84] */
    PUSH32(esp, eax); /* 0x007799EB: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007799EC: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007799F1: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007799F4: ret  */

}

void sub_007799F5(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007799F5u);

L_007799F5:
    PUSH32(esp, 0); /* 0x007799F5: push 0 */
    PUSH32(esp, 0x007A61E8u); /* 0x007799F7: push 0x7a61e8 */
    eax = MEM32(ebp + (-0xB84)); /* 0x007799FC: mov eax, dword ptr [ebp - 0xb84] */
    PUSH32(esp, eax); /* 0x00779A02: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779A03: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779A08: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779A0B: ret  */

}

void sub_00779A0C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779A0Cu);

    goto L_00779A0C;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779A0C:
    eax = 0x007E50B8u; /* 0x00779A0C: mov eax, 0x7e50b8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779A11: jmp 0x75bf0e */

}

void sub_00779A20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779A20u);

L_00779A20:
    PUSH32(esp, 0); /* 0x00779A20: push 0 */
    PUSH32(esp, 0x007A62ECu); /* 0x00779A22: push 0x7a62ec */
    eax = MEM32(ebp + (-0x10)); /* 0x00779A27: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00779A2A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779A2B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779A30: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779A33: ret  */

}

void sub_00779A34(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779A34u);

L_00779A34:
    PUSH32(esp, 0); /* 0x00779A34: push 0 */
    PUSH32(esp, 0x007A62E4u); /* 0x00779A36: push 0x7a62e4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00779A3B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00779A3E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779A3F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779A44: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779A47: ret  */

}

void sub_00779A48(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779A48u);

    goto L_00779A48;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779A48:
    eax = 0x007E50E4u; /* 0x00779A48: mov eax, 0x7e50e4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779A4D: jmp 0x75bf0e */

}

void sub_00779A60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779A60u);

L_00779A60:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779A60: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x5C4u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x5C4u; /* 0x00779A63: add ecx, 0x5c4 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005E0BE0u); RECOMP_RETURN(); /* 0x00779A69: jmp 0x5e0be0 */

}

void sub_00779A6E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779A6Eu);

L_00779A6E:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779A6E: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x8D8u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x8D8u; /* 0x00779A71: add ecx, 0x8d8 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x00779A77: jmp 0x4022d0 */

}

void sub_00779A7C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779A7Cu);

    goto L_00779A7C;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779A7C:
    eax = 0x007E5110u; /* 0x00779A7C: mov eax, 0x7e5110 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779A81: jmp 0x75bf0e */

}

void sub_00779A90(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779A90u);

L_00779A90:
    PUSH32(esp, 0); /* 0x00779A90: push 0 */
    PUSH32(esp, 0x007A209Cu); /* 0x00779A92: push 0x7a209c */
    eax = MEM32(ebp + (-0x10)); /* 0x00779A97: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00779A9A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779A9B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779AA0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779AA3: ret  */

}

void sub_00779AA4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779AA4u);

L_00779AA4:
    PUSH32(esp, 0); /* 0x00779AA4: push 0 */
    PUSH32(esp, 0x0078458Cu); /* 0x00779AA6: push 0x78458c */
    eax = MEM32(ebp + 0x4); /* 0x00779AAB: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00779AAE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779AAF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779AB4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779AB7: ret  */

}

void sub_00779AB8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779AB8u);

L_00779AB8:
    eax = MEM32(ebp + 0x4); /* 0x00779AB8: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00779ABB: push eax */
    RECOMP_CALL(sub_005EB840); /* 0x00779ABC: call 0x5eb840 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00779AC1: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779AC2: ret  */

}

void sub_00779AC3(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779AC3u);

L_00779AC3:
    PUSH32(esp, 0); /* 0x00779AC3: push 0 */
    PUSH32(esp, 0x007A1F24u); /* 0x00779AC5: push 0x7a1f24 */
    eax = MEM32(ebp + 0x4); /* 0x00779ACA: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00779ACD: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779ACE: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779AD3: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779AD6: ret  */

}

void sub_00779AD7(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779AD7u);

L_00779AD7:
    eax = MEM32(ebp + 0x4); /* 0x00779AD7: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00779ADA: push eax */
    RECOMP_CALL(sub_00583260); /* 0x00779ADB: call 0x583260 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00779AE0: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779AE1: ret  */

}

void sub_00779AE2(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779AE2u);

    goto L_00779AE2;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779AE2:
    eax = 0x007E5154u; /* 0x00779AE2: mov eax, 0x7e5154 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779AE7: jmp 0x75bf0e */

}

void sub_00779AF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779AF0u);

L_00779AF0:
    ecx = ebp + (-0x84C); /* 0x00779AF0: lea ecx, [ebp - 0x84c] */
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x00779AF6: jmp 0x4022d0 */

}

void sub_00779AFB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779AFBu);

    goto L_00779AFB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779AFB:
    eax = 0x007E5178u; /* 0x00779AFB: mov eax, 0x7e5178 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779B00: jmp 0x75bf0e */

}

void sub_00779B10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779B10u);

L_00779B10:
    PUSH32(esp, 0); /* 0x00779B10: push 0 */
    PUSH32(esp, 0x007A632Cu); /* 0x00779B12: push 0x7a632c */
    eax = MEM32(ebp + (-0x10)); /* 0x00779B17: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00779B1A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779B1B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779B20: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779B23: ret  */

}

void sub_00779B24(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779B24u);

L_00779B24:
    PUSH32(esp, 0); /* 0x00779B24: push 0 */
    PUSH32(esp, 0x0079DC04u); /* 0x00779B26: push 0x79dc04 */
    eax = MEM32(ebp + (-0x10)); /* 0x00779B2B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00779B2E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779B2F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779B34: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779B37: ret  */

}

void sub_00779B38(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779B38u);

L_00779B38:
    PUSH32(esp, 0); /* 0x00779B38: push 0 */
    PUSH32(esp, 0x007A631Cu); /* 0x00779B3A: push 0x7a631c */
    eax = MEM32(ebp + (-0x10)); /* 0x00779B3F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00779B42: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779B43: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779B48: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779B4B: ret  */

}

void sub_00779B4C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779B4Cu);

    goto L_00779B4C;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779B4C:
    eax = 0x007E51ACu; /* 0x00779B4C: mov eax, 0x7e51ac */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779B51: jmp 0x75bf0e */

}

void sub_00779B60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779B60u);

L_00779B60:
    PUSH32(esp, 0); /* 0x00779B60: push 0 */
    PUSH32(esp, 0x007A5D2Cu); /* 0x00779B62: push 0x7a5d2c */
    eax = MEM32(ebp + (-0x20)); /* 0x00779B67: mov eax, dword ptr [ebp - 0x20] */
    PUSH32(esp, eax); /* 0x00779B6A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779B6B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779B70: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779B73: ret  */

}

void sub_00779B74(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779B74u);

L_00779B74:
    eax = MEM32(ebp + (-0x20)); /* 0x00779B74: mov eax, dword ptr [ebp - 0x20] */
    PUSH32(esp, eax); /* 0x00779B77: push eax */
    RECOMP_CALL(sub_005EA1A0); /* 0x00779B78: call 0x5ea1a0 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00779B7D: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779B7E: ret  */

}

void sub_00779B7F(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779B7Fu);

    goto L_00779B7F;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779B7F:
    eax = 0x007E52ACu; /* 0x00779B7F: mov eax, 0x7e52ac */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779B84: jmp 0x75bf0e */

}

void sub_00779B90(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779B90u);

L_00779B90:
    PUSH32(esp, 0); /* 0x00779B90: push 0 */
    PUSH32(esp, 0x007A632Cu); /* 0x00779B92: push 0x7a632c */
    eax = MEM32(ebp + (-0x10)); /* 0x00779B97: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00779B9A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779B9B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779BA0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779BA3: ret  */

}

void sub_00779BA4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779BA4u);

L_00779BA4:
    PUSH32(esp, 0); /* 0x00779BA4: push 0 */
    PUSH32(esp, 0x0079DC04u); /* 0x00779BA6: push 0x79dc04 */
    eax = MEM32(ebp + (-0x10)); /* 0x00779BAB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00779BAE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779BAF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779BB4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779BB7: ret  */

}

void sub_00779BB8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779BB8u);

L_00779BB8:
    PUSH32(esp, 0); /* 0x00779BB8: push 0 */
    PUSH32(esp, 0x007A631Cu); /* 0x00779BBA: push 0x7a631c */
    eax = MEM32(ebp + (-0x10)); /* 0x00779BBF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00779BC2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779BC3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779BC8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779BCB: ret  */

}

void sub_00779BCC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779BCCu);

L_00779BCC:
    PUSH32(esp, 0); /* 0x00779BCC: push 0 */
    PUSH32(esp, 0x007A63C0u); /* 0x00779BCE: push 0x7a63c0 */
    eax = MEM32(ebp + (-0x10)); /* 0x00779BD3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00779BD6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779BD7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779BDC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779BDF: ret  */

}

void sub_00779BE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779BE0u);

    goto L_00779BE0;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779BE0:
    eax = 0x007E52E8u; /* 0x00779BE0: mov eax, 0x7e52e8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779BE5: jmp 0x75bf0e */

}

void sub_00779BF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779BF0u);

L_00779BF0:
    PUSH32(esp, 0x005FC290u); /* 0x00779BF0: push 0x5fc290 */
    PUSH32(esp, 6); /* 0x00779BF5: push 6 */
    PUSH32(esp, 0x1F0u); /* 0x00779BF7: push 0x1f0 */
    eax = MEM32(ebp + (-0x10)); /* 0x00779BFC: mov eax, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x30u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x30u; /* 0x00779BFF: add eax, 0x30 */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x00779C02: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x00779C03: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779C08: ret  */

}

void sub_00779C09(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779C09u);

L_00779C09:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779C09: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0xC40u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0xC40u; /* 0x00779C0C: add ecx, 0xc40 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0040BE30u); RECOMP_RETURN(); /* 0x00779C12: jmp 0x40be30 */

}

void sub_00779C17(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779C17u);

    goto L_00779C17;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779C17:
    eax = 0x007E5314u; /* 0x00779C17: mov eax, 0x7e5314 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779C1C: jmp 0x75bf0e */

}

void sub_00779C30(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779C30u);

L_00779C30:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779C30: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x005EF5B0u); RECOMP_RETURN(); /* 0x00779C33: jmp 0x5ef5b0 */

}

void sub_00779C38(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779C38u);

L_00779C38:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779C38: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 4; /* 0x00779C3B: add ecx, 4 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005FA730u); RECOMP_RETURN(); /* 0x00779C3E: jmp 0x5fa730 */

}

void sub_00779C43(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779C43u);

L_00779C43:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779C43: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x190u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x190u; /* 0x00779C46: add ecx, 0x190 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00576850u); RECOMP_RETURN(); /* 0x00779C4C: jmp 0x576850 */

}

void sub_00779C51(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779C51u);

L_00779C51:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779C51: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x1D0u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x1D0u; /* 0x00779C54: add ecx, 0x1d0 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00576850u); RECOMP_RETURN(); /* 0x00779C5A: jmp 0x576850 */

}

void sub_00779C5F(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779C5Fu);

L_00779C5F:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779C5F: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x1F8u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x1F8u; /* 0x00779C62: add ecx, 0x1f8 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00576850u); RECOMP_RETURN(); /* 0x00779C68: jmp 0x576850 */

}

void sub_00779C6D(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779C6Du);

    goto L_00779C6D;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779C6D:
    eax = 0x007E5358u; /* 0x00779C6D: mov eax, 0x7e5358 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779C72: jmp 0x75bf0e */

}

void sub_00779C80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779C80u);

L_00779C80:
    ecx = MEM32(ebp + (-0x14)); /* 0x00779C80: mov ecx, dword ptr [ebp - 0x14] */
    RECOMP_ITAIL(0x005FF3B0u); RECOMP_RETURN(); /* 0x00779C83: jmp 0x5ff3b0 */

}

void sub_00779C88(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779C88u);

L_00779C88:
    ecx = MEM32(ebp + (-0x14)); /* 0x00779C88: mov ecx, dword ptr [ebp - 0x14] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(8);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 8; /* 0x00779C8B: add ecx, 8 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005FA6F0u); RECOMP_RETURN(); /* 0x00779C8E: jmp 0x5fa6f0 */

}

void sub_00779C93(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779C93u);

L_00779C93:
    PUSH32(esp, 0x00405340u); /* 0x00779C93: push 0x405340 */
    PUSH32(esp, 0x14u); /* 0x00779C98: push 0x14 */
    PUSH32(esp, 0x50u); /* 0x00779C9A: push 0x50 */
    eax = MEM32(ebp + (-0x14)); /* 0x00779C9C: mov eax, dword ptr [ebp - 0x14] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x130u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x130u; /* 0x00779C9F: add eax, 0x130 */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x00779CA4: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x00779CA5: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779CAA: ret  */

}

void sub_00779CAB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779CABu);

L_00779CAB:
    PUSH32(esp, 0x00405340u); /* 0x00779CAB: push 0x405340 */
    PUSH32(esp, 0x14u); /* 0x00779CB0: push 0x14 */
    PUSH32(esp, 0x50u); /* 0x00779CB2: push 0x50 */
    eax = MEM32(ebp + (-0x14)); /* 0x00779CB4: mov eax, dword ptr [ebp - 0x14] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x770u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x770u; /* 0x00779CB7: add eax, 0x770 */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x00779CBC: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x00779CBD: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779CC2: ret  */

}

void sub_00779CC3(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779CC3u);

L_00779CC3:
    ecx = MEM32(ebp + (-0x14)); /* 0x00779CC3: mov ecx, dword ptr [ebp - 0x14] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x1080u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x1080u; /* 0x00779CC6: add ecx, 0x1080 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x00779CCC: jmp 0x4022d0 */

}

void sub_00779CD1(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779CD1u);

L_00779CD1:
    ecx = MEM32(ebp + (-0x14)); /* 0x00779CD1: mov ecx, dword ptr [ebp - 0x14] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x1250u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x1250u; /* 0x00779CD4: add ecx, 0x1250 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x00779CDA: jmp 0x4022d0 */

}

void sub_00779CDF(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779CDFu);

L_00779CDF:
    ecx = MEM32(ebp + (-0x14)); /* 0x00779CDF: mov ecx, dword ptr [ebp - 0x14] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x1420u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x1420u; /* 0x00779CE2: add ecx, 0x1420 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x00779CE8: jmp 0x4022d0 */

}

void sub_00779CED(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779CEDu);

L_00779CED:
    PUSH32(esp, 0); /* 0x00779CED: push 0 */
    PUSH32(esp, 0x007851ACu); /* 0x00779CEF: push 0x7851ac */
    eax = MEM32(ebp + (-0x10)); /* 0x00779CF4: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00779CF7: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779CF8: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779CFD: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779D00: ret  */

}

void sub_00779D01(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779D01u);

L_00779D01:
    PUSH32(esp, 0); /* 0x00779D01: push 0 */
    PUSH32(esp, 0x007A63F0u); /* 0x00779D03: push 0x7a63f0 */
    eax = MEM32(ebp + (-0x10)); /* 0x00779D08: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00779D0B: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779D0C: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779D11: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779D14: ret  */

}

void sub_00779D15(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779D15u);

    goto L_00779D15;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779D15:
    eax = 0x007E53BCu; /* 0x00779D15: mov eax, 0x7e53bc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779D1A: jmp 0x75bf0e */

}

void sub_00779D20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779D20u);

L_00779D20:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779D20: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x005FF3B0u); RECOMP_RETURN(); /* 0x00779D23: jmp 0x5ff3b0 */

}

void sub_00779D28(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779D28u);

L_00779D28:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779D28: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(8);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 8; /* 0x00779D2B: add ecx, 8 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005FA6F0u); RECOMP_RETURN(); /* 0x00779D2E: jmp 0x5fa6f0 */

}

void sub_00779D33(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779D33u);

L_00779D33:
    PUSH32(esp, 0x00405340u); /* 0x00779D33: push 0x405340 */
    PUSH32(esp, 0x14u); /* 0x00779D38: push 0x14 */
    PUSH32(esp, 0x50u); /* 0x00779D3A: push 0x50 */
    eax = MEM32(ebp + (-0x10)); /* 0x00779D3C: mov eax, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x130u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x130u; /* 0x00779D3F: add eax, 0x130 */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x00779D44: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x00779D45: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779D4A: ret  */

}

void sub_00779D4B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779D4Bu);

L_00779D4B:
    PUSH32(esp, 0x00405340u); /* 0x00779D4B: push 0x405340 */
    PUSH32(esp, 0x14u); /* 0x00779D50: push 0x14 */
    PUSH32(esp, 0x50u); /* 0x00779D52: push 0x50 */
    eax = MEM32(ebp + (-0x10)); /* 0x00779D54: mov eax, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x770u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x770u; /* 0x00779D57: add eax, 0x770 */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x00779D5C: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x00779D5D: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779D62: ret  */

}

void sub_00779D63(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779D63u);

L_00779D63:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779D63: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x1080u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x1080u; /* 0x00779D66: add ecx, 0x1080 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x00779D6C: jmp 0x4022d0 */

}

void sub_00779D71(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779D71u);

L_00779D71:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779D71: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x1250u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x1250u; /* 0x00779D74: add ecx, 0x1250 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x00779D7A: jmp 0x4022d0 */

}

void sub_00779D7F(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779D7Fu);

L_00779D7F:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779D7F: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x1420u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x1420u; /* 0x00779D82: add ecx, 0x1420 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x00779D88: jmp 0x4022d0 */

}

void sub_00779D8D(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779D8Du);

    goto L_00779D8D;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779D8D:
    eax = 0x007E5410u; /* 0x00779D8D: mov eax, 0x7e5410 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779D92: jmp 0x75bf0e */

}

void sub_00779DA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779DA0u);

L_00779DA0:
    ecx = ebp + (-0x38); /* 0x00779DA0: lea ecx, [ebp - 0x38] */
    RECOMP_ITAIL(0x005FF430u); RECOMP_RETURN(); /* 0x00779DA3: jmp 0x5ff430 */

}

void sub_00779DA8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779DA8u);

    goto L_00779DA8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779DA8:
    eax = 0x007E5434u; /* 0x00779DA8: mov eax, 0x7e5434 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779DAD: jmp 0x75bf0e */

}

void sub_00779DC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779DC0u);

L_00779DC0:
    ecx = ebp + (-0x278); /* 0x00779DC0: lea ecx, [ebp - 0x278] */
    RECOMP_ITAIL(0x0043E0D0u); RECOMP_RETURN(); /* 0x00779DC6: jmp 0x43e0d0 */

}

void sub_00779DCB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779DCBu);

    goto L_00779DCB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779DCB:
    eax = 0x007E5458u; /* 0x00779DCB: mov eax, 0x7e5458 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779DD0: jmp 0x75bf0e */

}

void sub_00779DE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779DE0u);

L_00779DE0:
    eax = MEM32(ebp + 0x4); /* 0x00779DE0: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00779DE3: push eax */
    RECOMP_CALL(sub_005EA1A0); /* 0x00779DE4: call 0x5ea1a0 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00779DE9: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779DEA: ret  */

}

void sub_00779DEB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779DEBu);

L_00779DEB:
    PUSH32(esp, 0); /* 0x00779DEB: push 0 */
    PUSH32(esp, 0x007A6430u); /* 0x00779DED: push 0x7a6430 */
    eax = MEM32(ebp + 0x4); /* 0x00779DF2: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00779DF5: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779DF6: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779DFB: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779DFE: ret  */

}

void sub_00779DFF(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779DFFu);

    goto L_00779DFF;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779DFF:
    eax = 0x007E5484u; /* 0x00779DFF: mov eax, 0x7e5484 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779E04: jmp 0x75bf0e */

}

void sub_00779E10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779E10u);

L_00779E10:
    ecx = ebp + (-0x950); /* 0x00779E10: lea ecx, [ebp - 0x950] */
    RECOMP_ITAIL(0x0050F700u); RECOMP_RETURN(); /* 0x00779E16: jmp 0x50f700 */

}

void sub_00779E1B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779E1Bu);

    goto L_00779E1B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779E1B:
    eax = 0x007E54A8u; /* 0x00779E1B: mov eax, 0x7e54a8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779E20: jmp 0x75bf0e */

}

void sub_00779E30(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779E30u);

L_00779E30:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779E30: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0xCu; /* 0x00779E33: add ecx, 0xc */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005FF3F0u); RECOMP_RETURN(); /* 0x00779E36: jmp 0x5ff3f0 */

}

void sub_00779E3B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779E3Bu);

    goto L_00779E3B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779E3B:
    eax = 0x007E54CCu; /* 0x00779E3B: mov eax, 0x7e54cc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779E40: jmp 0x75bf0e */

}

void sub_00779E50(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779E50u);

L_00779E50:
    ecx = MEM32(ebp + (-0x24)); /* 0x00779E50: mov ecx, dword ptr [ebp - 0x24] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x5C4u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x5C4u; /* 0x00779E53: add ecx, 0x5c4 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005E0BE0u); RECOMP_RETURN(); /* 0x00779E59: jmp 0x5e0be0 */

}

void sub_00779E5E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779E5Eu);

L_00779E5E:
    ecx = MEM32(ebp + (-0x24)); /* 0x00779E5E: mov ecx, dword ptr [ebp - 0x24] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x8D8u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x8D8u; /* 0x00779E61: add ecx, 0x8d8 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x00779E67: jmp 0x4022d0 */

}

void sub_00779E6C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779E6Cu);

L_00779E6C:
    PUSH32(esp, 0); /* 0x00779E6C: push 0 */
    PUSH32(esp, 0x007A5D2Cu); /* 0x00779E6E: push 0x7a5d2c */
    eax = MEM32(ebp + (-0x28)); /* 0x00779E73: mov eax, dword ptr [ebp - 0x28] */
    PUSH32(esp, eax); /* 0x00779E76: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779E77: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779E7C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779E7F: ret  */

}

void sub_00779E80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779E80u);

L_00779E80:
    PUSH32(esp, 0); /* 0x00779E80: push 0 */
    PUSH32(esp, 0x007A64A0u); /* 0x00779E82: push 0x7a64a0 */
    eax = MEM32(ebp + (-0x28)); /* 0x00779E87: mov eax, dword ptr [ebp - 0x28] */
    PUSH32(esp, eax); /* 0x00779E8A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779E8B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779E90: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779E93: ret  */

}

void sub_00779E94(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779E94u);

L_00779E94:
    PUSH32(esp, 0); /* 0x00779E94: push 0 */
    PUSH32(esp, 0x007A6494u); /* 0x00779E96: push 0x7a6494 */
    eax = MEM32(ebp + (-0x28)); /* 0x00779E9B: mov eax, dword ptr [ebp - 0x28] */
    PUSH32(esp, eax); /* 0x00779E9E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779E9F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779EA4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779EA7: ret  */

}

void sub_00779EA8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779EA8u);

    goto L_00779EA8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779EA8:
    eax = 0x007E5510u; /* 0x00779EA8: mov eax, 0x7e5510 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779EAD: jmp 0x75bf0e */

}

void sub_00779EC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779EC0u);

L_00779EC0:
    PUSH32(esp, 0); /* 0x00779EC0: push 0 */
    PUSH32(esp, 0x007A6510u); /* 0x00779EC2: push 0x7a6510 */
    eax = MEM32(ebp + 0x4); /* 0x00779EC7: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00779ECA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779ECB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779ED0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779ED3: ret  */

}

void sub_00779ED4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779ED4u);

    goto L_00779ED4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779ED4:
    eax = 0x007E5534u; /* 0x00779ED4: mov eax, 0x7e5534 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779ED9: jmp 0x75bf0e */

}

void sub_00779EE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779EE0u);

L_00779EE0:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779EE0: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x20u; /* 0x00779EE3: add ecx, 0x20 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00436820u); RECOMP_RETURN(); /* 0x00779EE6: jmp 0x436820 */

}

void sub_00779EEB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779EEBu);

L_00779EEB:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779EEB: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x28u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x28u; /* 0x00779EEE: add ecx, 0x28 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x00779EF1: jmp 0x5ce0f0 */

}

void sub_00779EF6(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779EF6u);

    goto L_00779EF6;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779EF6:
    eax = 0x007E5560u; /* 0x00779EF6: mov eax, 0x7e5560 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779EFB: jmp 0x75bf0e */

}

void sub_00779F00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779F00u);

L_00779F00:
    ecx = ebp + (-0x328); /* 0x00779F00: lea ecx, [ebp - 0x328] */
    RECOMP_ITAIL(0x005E0BE0u); RECOMP_RETURN(); /* 0x00779F06: jmp 0x5e0be0 */

}

void sub_00779F0B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779F0Bu);

    goto L_00779F0B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779F0B:
    eax = 0x007E5584u; /* 0x00779F0B: mov eax, 0x7e5584 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779F10: jmp 0x75bf0e */

}

void sub_00779F20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779F20u);

L_00779F20:
    PUSH32(esp, 0); /* 0x00779F20: push 0 */
    PUSH32(esp, 0x007A6560u); /* 0x00779F22: push 0x7a6560 */
    eax = MEM32(ebp + (-0x10)); /* 0x00779F27: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00779F2A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779F2B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779F30: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779F33: ret  */

}

void sub_00779F34(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779F34u);

    goto L_00779F34;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779F34:
    eax = 0x007E55A8u; /* 0x00779F34: mov eax, 0x7e55a8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779F39: jmp 0x75bf0e */

}

void sub_00779F40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779F40u);

L_00779F40:
    ecx = ebp + (-0x48); /* 0x00779F40: lea ecx, [ebp - 0x48] */
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x00779F43: jmp 0x4022d0 */

}

void sub_00779F48(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779F48u);

L_00779F48:
    PUSH32(esp, 0); /* 0x00779F48: push 0 */
    PUSH32(esp, 0x00785BC0u); /* 0x00779F4A: push 0x785bc0 */
    eax = MEM32(ebp + 0x8); /* 0x00779F4F: mov eax, dword ptr [ebp + 8] */
    PUSH32(esp, eax); /* 0x00779F52: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779F53: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779F58: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779F5B: ret  */

}

void sub_00779F5C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779F5Cu);

L_00779F5C:
    PUSH32(esp, 0); /* 0x00779F5C: push 0 */
    PUSH32(esp, 0x00785BC0u); /* 0x00779F5E: push 0x785bc0 */
    eax = MEM32(ebp + 0x8); /* 0x00779F63: mov eax, dword ptr [ebp + 8] */
    PUSH32(esp, eax); /* 0x00779F66: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779F67: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779F6C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779F6F: ret  */

}

void sub_00779F70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779F70u);

    goto L_00779F70;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779F70:
    eax = 0x007E55DCu; /* 0x00779F70: mov eax, 0x7e55dc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779F75: jmp 0x75bf0e */

}

void sub_00779F80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779F80u);

L_00779F80:
    PUSH32(esp, 0); /* 0x00779F80: push 0 */
    PUSH32(esp, 0x00785B84u); /* 0x00779F82: push 0x785b84 */
    eax = MEM32(ebp + (-0x14)); /* 0x00779F87: mov eax, dword ptr [ebp - 0x14] */
    PUSH32(esp, eax); /* 0x00779F8A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779F8B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779F90: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779F93: ret  */

}

void sub_00779F94(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779F94u);

L_00779F94:
    PUSH32(esp, 0); /* 0x00779F94: push 0 */
    PUSH32(esp, 0x00785B84u); /* 0x00779F96: push 0x785b84 */
    eax = MEM32(ebp + (-0x14)); /* 0x00779F9B: mov eax, dword ptr [ebp - 0x14] */
    PUSH32(esp, eax); /* 0x00779F9E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779F9F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779FA4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779FA7: ret  */

}

void sub_00779FA8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779FA8u);

L_00779FA8:
    PUSH32(esp, 0); /* 0x00779FA8: push 0 */
    PUSH32(esp, 0x00785B84u); /* 0x00779FAA: push 0x785b84 */
    eax = MEM32(ebp + (-0x14)); /* 0x00779FAF: mov eax, dword ptr [ebp - 0x14] */
    PUSH32(esp, eax); /* 0x00779FB2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779FB3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779FB8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779FBB: ret  */

}

void sub_00779FBC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779FBCu);

L_00779FBC:
    ecx = ebp + (-0x1C); /* 0x00779FBC: lea ecx, [ebp - 0x1c] */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00779FBF: jmp 0x5cde60 */

}

void sub_00779FC4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779FC4u);

    goto L_00779FC4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779FC4:
    eax = 0x007E5690u; /* 0x00779FC4: mov eax, 0x7e5690 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779FC9: jmp 0x75bf0e */

}

void sub_00779FD0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779FD0u);

L_00779FD0:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779FD0: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x20u; /* 0x00779FD3: add ecx, 0x20 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00490340u); RECOMP_RETURN(); /* 0x00779FD6: jmp 0x490340 */

}

void sub_00779FDB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779FDBu);

    goto L_00779FDB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779FDB:
    eax = 0x007E56B4u; /* 0x00779FDB: mov eax, 0x7e56b4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779FE0: jmp 0x75bf0e */

}

void sub_00779FF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779FF0u);

L_00779FF0:
    PUSH32(esp, 0); /* 0x00779FF0: push 0 */
    PUSH32(esp, 0x007A08B4u); /* 0x00779FF2: push 0x7a08b4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00779FF7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00779FFA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00779FFB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077A000: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A003: ret  */

}

void sub_0077A004(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A004u);

L_0077A004:
    PUSH32(esp, 0); /* 0x0077A004: push 0 */
    PUSH32(esp, 0x007A5ED0u); /* 0x0077A006: push 0x7a5ed0 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077A00B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077A00E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077A00F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077A014: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A017: ret  */

}

void sub_0077A018(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A018u);

L_0077A018:
    PUSH32(esp, 0); /* 0x0077A018: push 0 */
    PUSH32(esp, 0x007873E8u); /* 0x0077A01A: push 0x7873e8 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077A01F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077A022: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077A023: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077A028: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A02B: ret  */

}

void sub_0077A02C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A02Cu);

    goto L_0077A02C;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077A02C:
    eax = 0x007E56E8u; /* 0x0077A02C: mov eax, 0x7e56e8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077A031: jmp 0x75bf0e */

}

void sub_0077A040(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A040u);

L_0077A040:
    eax = MEM32(ebp + (-0x10)); /* 0x0077A040: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077A043: push eax */
    RECOMP_CALL(sub_00575590); /* 0x0077A044: call 0x575590 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077A049: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A04A: ret  */

}

void sub_0077A04B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A04Bu);

L_0077A04B:
    PUSH32(esp, 0); /* 0x0077A04B: push 0 */
    PUSH32(esp, 0x007A6598u); /* 0x0077A04D: push 0x7a6598 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077A052: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077A055: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077A056: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077A05B: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A05E: ret  */

}

void sub_0077A05F(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A05Fu);

    goto L_0077A05F;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077A05F:
    eax = 0x007E5714u; /* 0x0077A05F: mov eax, 0x7e5714 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077A064: jmp 0x75bf0e */

}

void sub_0077A070(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A070u);

L_0077A070:
    ecx = MEM32(ebp + (-0x14)); /* 0x0077A070: mov ecx, dword ptr [ebp - 0x14] */
    RECOMP_ITAIL(0x00609CA0u); RECOMP_RETURN(); /* 0x0077A073: jmp 0x609ca0 */

}

void sub_0077A078(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A078u);

L_0077A078:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077A078: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x20u; /* 0x0077A07B: add ecx, 0x20 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00490340u); RECOMP_RETURN(); /* 0x0077A07E: jmp 0x490340 */

}

void sub_0077A083(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A083u);

    goto L_0077A083;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077A083:
    eax = 0x007E5740u; /* 0x0077A083: mov eax, 0x7e5740 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077A088: jmp 0x75bf0e */

}

void sub_0077A090(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A090u);

L_0077A090:
    PUSH32(esp, 0); /* 0x0077A090: push 0 */
    PUSH32(esp, 0x007A51D0u); /* 0x0077A092: push 0x7a51d0 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077A097: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077A09A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077A09B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077A0A0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A0A3: ret  */

}

void sub_0077A0A4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A0A4u);

    goto L_0077A0A4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077A0A4:
    eax = 0x007E5764u; /* 0x0077A0A4: mov eax, 0x7e5764 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077A0A9: jmp 0x75bf0e */

}

void sub_0077A0B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A0B0u);

L_0077A0B0:
    PUSH32(esp, 0x004022D0u); /* 0x0077A0B0: push 0x4022d0 */
    PUSH32(esp, 0x10u); /* 0x0077A0B5: push 0x10 */
    PUSH32(esp, 0x30u); /* 0x0077A0B7: push 0x30 */
    eax = ebp + (-0x310); /* 0x0077A0B9: lea eax, [ebp - 0x310] */
    PUSH32(esp, eax); /* 0x0077A0BF: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x0077A0C0: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A0C5: ret  */

}

void sub_0077A0C6(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A0C6u);

    goto L_0077A0C6;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077A0C6:
    eax = 0x007E5788u; /* 0x0077A0C6: mov eax, 0x7e5788 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077A0CB: jmp 0x75bf0e */

}

void sub_0077A0D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A0D0u);

L_0077A0D0:
    eax = MEM32(ebp + (-0x10)); /* 0x0077A0D0: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077A0D3: push eax */
    RECOMP_CALL(sub_00486E80); /* 0x0077A0D4: call 0x486e80 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077A0D9: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A0DA: ret  */

}

void sub_0077A0DB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A0DBu);

L_0077A0DB:
    eax = MEM32(ebp + 0x8); /* 0x0077A0DB: mov eax, dword ptr [ebp + 8] */
    PUSH32(esp, eax); /* 0x0077A0DE: push eax */
    RECOMP_CALL(sub_00486E80); /* 0x0077A0DF: call 0x486e80 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077A0E4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A0E5: ret  */

}

void sub_0077A0E6(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A0E6u);

    goto L_0077A0E6;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077A0E6:
    eax = 0x007E57B4u; /* 0x0077A0E6: mov eax, 0x7e57b4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077A0EB: jmp 0x75bf0e */

}

void sub_0077A0F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A0F0u);

L_0077A0F0:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077A0F0: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x374u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x374u; /* 0x0077A0F3: add ecx, 0x374 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x0077A0F9: jmp 0x4022d0 */

}

void sub_0077A0FE(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A0FEu);

    goto L_0077A0FE;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077A0FE:
    eax = 0x007E57D8u; /* 0x0077A0FE: mov eax, 0x7e57d8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077A103: jmp 0x75bf0e */

}

void sub_0077A110(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A110u);

L_0077A110:
    eax = MEM32(ebp + 0x4); /* 0x0077A110: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x0077A113: push eax */
    RECOMP_CALL(sub_00610660); /* 0x0077A114: call 0x610660 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077A119: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A11A: ret  */

}

void sub_0077A11B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A11Bu);

    goto L_0077A11B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077A11B:
    eax = 0x007E57FCu; /* 0x0077A11B: mov eax, 0x7e57fc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077A120: jmp 0x75bf0e */

}

void sub_0077A130(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A130u);

L_0077A130:
    eax = MEM32(ebp + 0x4); /* 0x0077A130: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x0077A133: push eax */
    RECOMP_CALL(sub_00610640); /* 0x0077A134: call 0x610640 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077A139: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A13A: ret  */

}

void sub_0077A13B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A13Bu);

    goto L_0077A13B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077A13B:
    eax = 0x007E5820u; /* 0x0077A13B: mov eax, 0x7e5820 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077A140: jmp 0x75bf0e */

}

void sub_0077A150(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A150u);

L_0077A150:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077A150: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(8);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 8; /* 0x0077A153: add ecx, 8 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00637ED0u); RECOMP_RETURN(); /* 0x0077A156: jmp 0x637ed0 */

}

void sub_0077A15B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A15Bu);

    goto L_0077A15B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077A15B:
    eax = 0x007E5844u; /* 0x0077A15B: mov eax, 0x7e5844 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077A160: jmp 0x75bf0e */

}

void sub_0077A170(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A170u);

L_0077A170:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077A170: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x3F0u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x3F0u; /* 0x0077A173: add ecx, 0x3f0 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x0077A179: jmp 0x5cde60 */

}

void sub_0077A17E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A17Eu);

L_0077A17E:
    PUSH32(esp, 0x00436820u); /* 0x0077A17E: push 0x436820 */
    PUSH32(esp, 0x1Eu); /* 0x0077A183: push 0x1e */
    PUSH32(esp, 8); /* 0x0077A185: push 8 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077A187: mov eax, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x458u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x458u; /* 0x0077A18A: add eax, 0x458 */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x0077A18F: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x0077A190: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A195: ret  */

}

void sub_0077A196(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A196u);

L_0077A196:
    PUSH32(esp, 0x0061F470u); /* 0x0077A196: push 0x61f470 */
    PUSH32(esp, 0x1Eu); /* 0x0077A19B: push 0x1e */
    PUSH32(esp, 8); /* 0x0077A19D: push 8 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077A19F: mov eax, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x548u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x548u; /* 0x0077A1A2: add eax, 0x548 */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x0077A1A7: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x0077A1A8: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A1AD: ret  */

}

void sub_0077A1AE(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A1AEu);

L_0077A1AE:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077A1AE: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x1F88u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x1F88u; /* 0x0077A1B1: add ecx, 0x1f88 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00437B30u); RECOMP_RETURN(); /* 0x0077A1B7: jmp 0x437b30 */

}

void sub_0077A1BC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A1BCu);

L_0077A1BC:
    PUSH32(esp, 0x004022D0u); /* 0x0077A1BC: push 0x4022d0 */
    PUSH32(esp, 2); /* 0x0077A1C1: push 2 */
    PUSH32(esp, 0x68u); /* 0x0077A1C3: push 0x68 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077A1C5: mov eax, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x1FBCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x1FBCu; /* 0x0077A1C8: add eax, 0x1fbc */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x0077A1CD: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x0077A1CE: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A1D3: ret  */

}

void sub_0077A1D4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A1D4u);

L_0077A1D4:
    PUSH32(esp, 0x00490370u); /* 0x0077A1D4: push 0x490370 */
    PUSH32(esp, 8); /* 0x0077A1D9: push 8 */
    PUSH32(esp, 0x18u); /* 0x0077A1DB: push 0x18 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077A1DD: mov eax, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x21B4u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x21B4u; /* 0x0077A1E0: add eax, 0x21b4 */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x0077A1E5: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x0077A1E6: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A1EB: ret  */

}

void sub_0077A1EC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A1ECu);

L_0077A1EC:
    PUSH32(esp, 0x00490370u); /* 0x0077A1EC: push 0x490370 */
    PUSH32(esp, 0x60u); /* 0x0077A1F1: push 0x60 */
    PUSH32(esp, 0x18u); /* 0x0077A1F3: push 0x18 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077A1F5: mov eax, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x2274u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x2274u; /* 0x0077A1F8: add eax, 0x2274 */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x0077A1FD: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x0077A1FE: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A203: ret  */

}

void sub_0077A204(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A204u);

L_0077A204:
    PUSH32(esp, 0x00490370u); /* 0x0077A204: push 0x490370 */
    PUSH32(esp, 6); /* 0x0077A209: push 6 */
    PUSH32(esp, 0x18u); /* 0x0077A20B: push 0x18 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077A20D: mov eax, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x2B74u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x2B74u; /* 0x0077A210: add eax, 0x2b74 */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x0077A215: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x0077A216: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A21B: ret  */

}

void sub_0077A21C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A21Cu);

    goto L_0077A21C;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077A21C:
    eax = 0x007E58A0u; /* 0x0077A21C: mov eax, 0x7e58a0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077A221: jmp 0x75bf0e */

}

void sub_0077A230(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A230u);

L_0077A230:
    eax = MEM32(0x8A4514); /* 0x0077A230: mov eax, dword ptr [0x8a4514] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0xFFFFFFFEu);
    eax = eax & 0xFFFFFFFEu; /* 0x0077A235: and eax, 0xfffffffe */
    _cf = 0;
    _flag_k = FK_TEST;
    MEM32(0x8A4514) = eax; /* 0x0077A238: mov dword ptr [0x8a4514], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A23D: ret  */

}

void sub_0077A23E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A23Eu);

    goto L_0077A23E;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077A23E:
    eax = 0x007E58C4u; /* 0x0077A23E: mov eax, 0x7e58c4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077A243: jmp 0x75bf0e */

}

void sub_0077A250(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A250u);

L_0077A250:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077A250: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x20u; /* 0x0077A253: add ecx, 0x20 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0040BE20u); RECOMP_RETURN(); /* 0x0077A256: jmp 0x40be20 */

}

void sub_0077A25B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A25Bu);

    goto L_0077A25B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077A25B:
    eax = 0x007E58E8u; /* 0x0077A25B: mov eax, 0x7e58e8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077A260: jmp 0x75bf0e */

}

void sub_0077A270(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A270u);

L_0077A270:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077A270: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x28u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x28u; /* 0x0077A273: add ecx, 0x28 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00634420u); RECOMP_RETURN(); /* 0x0077A276: jmp 0x634420 */

}

void sub_0077A27B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A27Bu);

L_0077A27B:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077A27B: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x30u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x30u; /* 0x0077A27E: add ecx, 0x30 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00634460u); RECOMP_RETURN(); /* 0x0077A281: jmp 0x634460 */

}

void sub_0077A286(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A286u);

L_0077A286:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077A286: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x38u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x38u; /* 0x0077A289: add ecx, 0x38 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x006344A0u); RECOMP_RETURN(); /* 0x0077A28C: jmp 0x6344a0 */

}

void sub_0077A291(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A291u);

L_0077A291:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077A291: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x40u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x40u; /* 0x0077A294: add ecx, 0x40 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x0077A297: jmp 0x5cde60 */

}

void sub_0077A29C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A29Cu);

L_0077A29C:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077A29C: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x48u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x48u; /* 0x0077A29F: add ecx, 0x48 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x0077A2A2: jmp 0x5cde60 */

}

void sub_0077A2A7(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A2A7u);

L_0077A2A7:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077A2A7: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x50u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x50u; /* 0x0077A2AA: add ecx, 0x50 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x0077A2AD: jmp 0x5cde60 */

}

void sub_0077A2B2(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A2B2u);

L_0077A2B2:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077A2B2: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x58u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x58u; /* 0x0077A2B5: add ecx, 0x58 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x006344E0u); RECOMP_RETURN(); /* 0x0077A2B8: jmp 0x6344e0 */

}

void sub_0077A2BD(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A2BDu);

    goto L_0077A2BD;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077A2BD:
    eax = 0x007E593Cu; /* 0x0077A2BD: mov eax, 0x7e593c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077A2C2: jmp 0x75bf0e */

}

void sub_0077A2D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A2D0u);

L_0077A2D0:
    eax = MEM32(ebp + (-0x10)); /* 0x0077A2D0: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077A2D3: push eax */
    RECOMP_CALL(sub_00486E80); /* 0x0077A2D4: call 0x486e80 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077A2D9: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A2DA: ret  */

}

void sub_0077A2DB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A2DBu);

    goto L_0077A2DB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077A2DB:
    eax = 0x007E5960u; /* 0x0077A2DB: mov eax, 0x7e5960 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077A2E0: jmp 0x75bf0e */

}

void sub_0077A2F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A2F0u);

L_0077A2F0:
    ecx = MEM32(ebp + (-0x14)); /* 0x0077A2F0: mov ecx, dword ptr [ebp - 0x14] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(8);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 8; /* 0x0077A2F3: add ecx, 8 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00637ED0u); RECOMP_RETURN(); /* 0x0077A2F6: jmp 0x637ed0 */

}

void sub_0077A2FB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A2FBu);

    goto L_0077A2FB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077A2FB:
    eax = 0x007E5984u; /* 0x0077A2FB: mov eax, 0x7e5984 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077A300: jmp 0x75bf0e */

}

void sub_0077A310(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A310u);

L_0077A310:
    eax = MEM32(ebp + (-0x10)); /* 0x0077A310: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077A313: push eax */
    RECOMP_CALL(sub_0060BAF0); /* 0x0077A314: call 0x60baf0 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077A319: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A31A: ret  */

}

void sub_0077A31B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A31Bu);

    goto L_0077A31B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077A31B:
    eax = 0x007E59A8u; /* 0x0077A31B: mov eax, 0x7e59a8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077A320: jmp 0x75bf0e */

}

void sub_0077A330(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A330u);

L_0077A330:
    ecx = MEM32(ebp + (-0x24C)); /* 0x0077A330: mov ecx, dword ptr [ebp - 0x24c] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x3F0u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x3F0u; /* 0x0077A336: add ecx, 0x3f0 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x0077A33C: jmp 0x5cde60 */

}

void sub_0077A341(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A341u);

L_0077A341:
    PUSH32(esp, 0x00436820u); /* 0x0077A341: push 0x436820 */
    PUSH32(esp, 0x1Eu); /* 0x0077A346: push 0x1e */
    PUSH32(esp, 8); /* 0x0077A348: push 8 */
    eax = MEM32(ebp + (-0x24C)); /* 0x0077A34A: mov eax, dword ptr [ebp - 0x24c] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x458u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x458u; /* 0x0077A350: add eax, 0x458 */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x0077A355: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x0077A356: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A35B: ret  */

}

void sub_0077A35C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A35Cu);

L_0077A35C:
    PUSH32(esp, 0x0061F470u); /* 0x0077A35C: push 0x61f470 */
    PUSH32(esp, 0x1Eu); /* 0x0077A361: push 0x1e */
    PUSH32(esp, 8); /* 0x0077A363: push 8 */
    eax = MEM32(ebp + (-0x24C)); /* 0x0077A365: mov eax, dword ptr [ebp - 0x24c] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x548u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x548u; /* 0x0077A36B: add eax, 0x548 */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x0077A370: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x0077A371: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A376: ret  */

}

void sub_0077A377(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A377u);

L_0077A377:
    ecx = MEM32(ebp + (-0x24C)); /* 0x0077A377: mov ecx, dword ptr [ebp - 0x24c] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x1F88u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x1F88u; /* 0x0077A37D: add ecx, 0x1f88 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00437B30u); RECOMP_RETURN(); /* 0x0077A383: jmp 0x437b30 */

}

void sub_0077A388(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A388u);

L_0077A388:
    PUSH32(esp, 0x004022D0u); /* 0x0077A388: push 0x4022d0 */
    PUSH32(esp, 2); /* 0x0077A38D: push 2 */
    PUSH32(esp, 0x68u); /* 0x0077A38F: push 0x68 */
    eax = MEM32(ebp + (-0x24C)); /* 0x0077A391: mov eax, dword ptr [ebp - 0x24c] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x1FBCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x1FBCu; /* 0x0077A397: add eax, 0x1fbc */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x0077A39C: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x0077A39D: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A3A2: ret  */

}

void sub_0077A3A3(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A3A3u);

L_0077A3A3:
    PUSH32(esp, 0x00490370u); /* 0x0077A3A3: push 0x490370 */
    PUSH32(esp, 8); /* 0x0077A3A8: push 8 */
    PUSH32(esp, 0x18u); /* 0x0077A3AA: push 0x18 */
    eax = MEM32(ebp + (-0x24C)); /* 0x0077A3AC: mov eax, dword ptr [ebp - 0x24c] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x21B4u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x21B4u; /* 0x0077A3B2: add eax, 0x21b4 */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x0077A3B7: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x0077A3B8: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A3BD: ret  */

}

void sub_0077A3BE(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A3BEu);

L_0077A3BE:
    PUSH32(esp, 0x00490370u); /* 0x0077A3BE: push 0x490370 */
    PUSH32(esp, 0x60u); /* 0x0077A3C3: push 0x60 */
    PUSH32(esp, 0x18u); /* 0x0077A3C5: push 0x18 */
    eax = MEM32(ebp + (-0x24C)); /* 0x0077A3C7: mov eax, dword ptr [ebp - 0x24c] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x2274u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x2274u; /* 0x0077A3CD: add eax, 0x2274 */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x0077A3D2: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x0077A3D3: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A3D8: ret  */

}

void sub_0077A3D9(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A3D9u);

L_0077A3D9:
    PUSH32(esp, 0x00490370u); /* 0x0077A3D9: push 0x490370 */
    PUSH32(esp, 6); /* 0x0077A3DE: push 6 */
    PUSH32(esp, 0x18u); /* 0x0077A3E0: push 0x18 */
    eax = MEM32(ebp + (-0x24C)); /* 0x0077A3E2: mov eax, dword ptr [ebp - 0x24c] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x2B74u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x2B74u; /* 0x0077A3E8: add eax, 0x2b74 */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x0077A3ED: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x0077A3EE: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A3F3: ret  */

}

void sub_0077A3F4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A3F4u);

    goto L_0077A3F4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077A3F4:
    eax = 0x007E5A04u; /* 0x0077A3F4: mov eax, 0x7e5a04 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077A3F9: jmp 0x75bf0e */

}

void sub_0077A400(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A400u);

L_0077A400:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077A400: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0xCu; /* 0x0077A403: add ecx, 0xc */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0063A320u); RECOMP_RETURN(); /* 0x0077A406: jmp 0x63a320 */

}

void sub_0077A40B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A40Bu);

L_0077A40B:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077A40B: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x100u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x100u; /* 0x0077A40E: add ecx, 0x100 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00610C40u); RECOMP_RETURN(); /* 0x0077A414: jmp 0x610c40 */

}

void sub_0077A419(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A419u);

    goto L_0077A419;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077A419:
    eax = 0x007E5A30u; /* 0x0077A419: mov eax, 0x7e5a30 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077A41E: jmp 0x75bf0e */

}

void sub_0077A430(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A430u);

L_0077A430:
    ecx = MEM32(ebp + (-0x20)); /* 0x0077A430: mov ecx, dword ptr [ebp - 0x20] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x24u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x24u; /* 0x0077A433: add ecx, 0x24 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0063A510u); RECOMP_RETURN(); /* 0x0077A436: jmp 0x63a510 */

}

void sub_0077A43B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A43Bu);

    goto L_0077A43B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077A43B:
    eax = 0x007E5A54u; /* 0x0077A43B: mov eax, 0x7e5a54 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077A440: jmp 0x75bf0e */

}

void sub_0077A450(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A450u);

L_0077A450:
    PUSH32(esp, 0); /* 0x0077A450: push 0 */
    PUSH32(esp, 0x007A8D5Cu); /* 0x0077A452: push 0x7a8d5c */
    eax = MEM32(ebp + (-0x10)); /* 0x0077A457: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077A45A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077A45B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077A460: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A463: ret  */

}

void sub_0077A464(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A464u);

    goto L_0077A464;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077A464:
    eax = 0x007E5A78u; /* 0x0077A464: mov eax, 0x7e5a78 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077A469: jmp 0x75bf0e */

}

void sub_0077A470(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A470u);

L_0077A470:
    eax = MEM32(ebp + 0x4); /* 0x0077A470: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x0077A473: push eax */
    RECOMP_CALL(sub_00575590); /* 0x0077A474: call 0x575590 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077A479: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A47A: ret  */

}

void sub_0077A47B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A47Bu);

    goto L_0077A47B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077A47B:
    eax = 0x007E5A9Cu; /* 0x0077A47B: mov eax, 0x7e5a9c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077A480: jmp 0x75bf0e */

}

void sub_0077A490(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A490u);

L_0077A490:
    eax = MEM32(ebp + (-0xA0)); /* 0x0077A490: mov eax, dword ptr [ebp - 0xa0] */
    PUSH32(esp, eax); /* 0x0077A496: push eax */
    RECOMP_CALL(sub_006106B0); /* 0x0077A497: call 0x6106b0 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077A49C: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A49D: ret  */

}

void sub_0077A49E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A49Eu);

    goto L_0077A49E;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077A49E:
    eax = 0x007E5AC0u; /* 0x0077A49E: mov eax, 0x7e5ac0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077A4A3: jmp 0x75bf0e */

}

void sub_0077A4B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A4B0u);

L_0077A4B0:
    ecx = MEM32(ebp + (-0x34)); /* 0x0077A4B0: mov ecx, dword ptr [ebp - 0x34] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x24u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x24u; /* 0x0077A4B3: add ecx, 0x24 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0063A510u); RECOMP_RETURN(); /* 0x0077A4B6: jmp 0x63a510 */

}

void sub_0077A4BB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A4BBu);

    goto L_0077A4BB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077A4BB:
    eax = 0x007E5AECu; /* 0x0077A4BB: mov eax, 0x7e5aec */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077A4C0: jmp 0x75bf0e */

}

void sub_0077A4D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A4D0u);

L_0077A4D0:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077A4D0: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x24u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x24u; /* 0x0077A4D3: add ecx, 0x24 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0063A510u); RECOMP_RETURN(); /* 0x0077A4D6: jmp 0x63a510 */

}

void sub_0077A4DB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A4DBu);

    goto L_0077A4DB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077A4DB:
    eax = 0x007E5B10u; /* 0x0077A4DB: mov eax, 0x7e5b10 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077A4E0: jmp 0x75bf0e */

}

void sub_0077A4F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A4F0u);

L_0077A4F0:
    ecx = MEM32(ebp + (-0x1C)); /* 0x0077A4F0: mov ecx, dword ptr [ebp - 0x1c] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x24u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x24u; /* 0x0077A4F3: add ecx, 0x24 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0063A510u); RECOMP_RETURN(); /* 0x0077A4F6: jmp 0x63a510 */

}

void sub_0077A4FB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A4FBu);

L_0077A4FB:
    PUSH32(esp, 0); /* 0x0077A4FB: push 0 */
    PUSH32(esp, 0x007A64A0u); /* 0x0077A4FD: push 0x7a64a0 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077A502: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077A505: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077A506: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077A50B: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A50E: ret  */

}

void sub_0077A50F(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A50Fu);

    goto L_0077A50F;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077A50F:
    eax = 0x007E5B3Cu; /* 0x0077A50F: mov eax, 0x7e5b3c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077A514: jmp 0x75bf0e */

}

void sub_0077A520(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A520u);

L_0077A520:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077A520: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x10u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x10u; /* 0x0077A523: add ecx, 0x10 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0040BE20u); RECOMP_RETURN(); /* 0x0077A526: jmp 0x40be20 */

}

void sub_0077A52B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A52Bu);

    goto L_0077A52B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077A52B:
    eax = 0x007E5B60u; /* 0x0077A52B: mov eax, 0x7e5b60 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077A530: jmp 0x75bf0e */

}

void sub_0077A535(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A535u);

    goto L_0077A535;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077A535:
    eax = 0x007E5BB0u; /* 0x0077A535: mov eax, 0x7e5bb0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077A53A: jmp 0x75bf0e */

}

void sub_0077A53F(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A53Fu);

L_0077A53F:
    ecx = ebp + (-0x28); /* 0x0077A53F: lea ecx, [ebp - 0x28] */
    RECOMP_ITAIL(0x005CEFB0u); RECOMP_RETURN(); /* 0x0077A542: jmp 0x5cefb0 */

}

void sub_0077A547(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A547u);

    goto L_0077A547;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077A547:
    eax = 0x007E5C10u; /* 0x0077A547: mov eax, 0x7e5c10 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077A54C: jmp 0x75bf0e */

}

void sub_0077A560(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A560u);

L_0077A560:
    fp_push(*(float*)&MEM32(0x784250)); /* 0x0077A560: fld dword ptr [0x784250] */
    _st[0] /= (double)*(float*)ADDR(0x783490); /* 0x0077A566: fdiv dword ptr [0x783490] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x81E7FC) = _v; } /* 0x0077A56C: fstp dword ptr [0x81e7fc] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A572: ret  */

}

void sub_0077A580(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A580u);

L_0077A580:
    PUSH32(esp, 5); /* 0x0077A580: push 5 */
    PUSH32(esp, 0x007E9BC8u); /* 0x0077A582: push 0x7e9bc8 */
    ecx = 0x0081E378u; /* 0x0077A587: mov ecx, 0x81e378 */
    RECOMP_CALL(sub_005766E0); /* 0x0077A58C: call 0x5766e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A591: ret  */

}

void sub_0077A5A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A5A0u);

L_0077A5A0:
    PUSH32(esp, 2); /* 0x0077A5A0: push 2 */
    PUSH32(esp, 0x007E9BF0u); /* 0x0077A5A2: push 0x7e9bf0 */
    ecx = 0x0081E7DCu; /* 0x0077A5A7: mov ecx, 0x81e7dc */
    RECOMP_CALL(sub_005766E0); /* 0x0077A5AC: call 0x5766e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A5B1: ret  */

}

void sub_0077A5C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A5C0u);

L_0077A5C0:
    PUSH32(esp, 2); /* 0x0077A5C0: push 2 */
    PUSH32(esp, 0x007E9C00u); /* 0x0077A5C2: push 0x7e9c00 */
    ecx = 0x00827A10u; /* 0x0077A5C7: mov ecx, 0x827a10 */
    RECOMP_CALL(sub_005766E0); /* 0x0077A5CC: call 0x5766e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A5D1: ret  */

}

void sub_0077A5E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A5E0u);

L_0077A5E0:
    ecx = 0x0081E5B8u; /* 0x0077A5E0: mov ecx, 0x81e5b8 */
    RECOMP_CALL(sub_00414D20); /* 0x0077A5E5: call 0x414d20 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007818C0u); /* 0x0077A5EA: push 0x7818c0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077A5EF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077A5F4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A5F5: ret  */

}

void sub_0077A600(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A600u);

L_0077A600:
    ecx = 0x0081E388u; /* 0x0077A600: mov ecx, 0x81e388 */
    RECOMP_CALL(sub_00414D20); /* 0x0077A605: call 0x414d20 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007818D0u); /* 0x0077A60A: push 0x7818d0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077A60F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077A614: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A615: ret  */

}

void sub_0077A620(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A620u);

L_0077A620:
    PUSH32(esp, 0x00781880u); /* 0x0077A620: push 0x781880 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077A625: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077A62A: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A62B: ret  */

}

void sub_0077A630(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A630u);

L_0077A630:
    fp_push(*(float*)&MEM32(0x81CB84)); /* 0x0077A630: fld dword ptr [0x81cb84] */
    _st[0] *= (double)*(float*)ADDR(0x81CB84); /* 0x0077A636: fmul dword ptr [0x81cb84] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x827A20) = _v; } /* 0x0077A63C: fstp dword ptr [0x827a20] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A642: ret  */

}

void sub_0077A650(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A650u);

L_0077A650:
    PUSH32(esp, 0xBu); /* 0x0077A650: push 0xb */
    PUSH32(esp, 0x007E9C10u); /* 0x0077A652: push 0x7e9c10 */
    ecx = 0x0081E380u; /* 0x0077A657: mov ecx, 0x81e380 */
    RECOMP_CALL(sub_005766E0); /* 0x0077A65C: call 0x5766e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A661: ret  */

}

void sub_0077A670(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A670u);

L_0077A670:
    PUSH32(esp, 2); /* 0x0077A670: push 2 */
    PUSH32(esp, 0x007E9C68u); /* 0x0077A672: push 0x7e9c68 */
    ecx = 0x0081E370u; /* 0x0077A677: mov ecx, 0x81e370 */
    RECOMP_CALL(sub_005766E0); /* 0x0077A67C: call 0x5766e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A681: ret  */

}

void sub_0077A690(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A690u);

L_0077A690:
    PUSH32(esp, 0xAu); /* 0x0077A690: push 0xa */
    PUSH32(esp, 0x007E9C78u); /* 0x0077A692: push 0x7e9c78 */
    ecx = 0x00827A18u; /* 0x0077A697: mov ecx, 0x827a18 */
    RECOMP_CALL(sub_005766E0); /* 0x0077A69C: call 0x5766e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A6A1: ret  */

}

void sub_0077A6B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A6B0u);

L_0077A6B0:
    PUSH32(esp, 9); /* 0x0077A6B0: push 9 */
    PUSH32(esp, 0x007E9CC8u); /* 0x0077A6B2: push 0x7e9cc8 */
    ecx = 0x0081E7F4u; /* 0x0077A6B7: mov ecx, 0x81e7f4 */
    RECOMP_CALL(sub_005766E0); /* 0x0077A6BC: call 0x5766e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A6C1: ret  */

}

void sub_0077A6D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A6D0u);

L_0077A6D0:
    PUSH32(esp, 2); /* 0x0077A6D0: push 2 */
    PUSH32(esp, 0x007E9D24u); /* 0x0077A6D2: push 0x7e9d24 */
    ecx = 0x0081E800u; /* 0x0077A6D7: mov ecx, 0x81e800 */
    RECOMP_CALL(sub_005766E0); /* 0x0077A6DC: call 0x5766e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A6E1: ret  */

}

void sub_0077A6F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A6F0u);

L_0077A6F0:
    PUSH32(esp, 2); /* 0x0077A6F0: push 2 */
    PUSH32(esp, 0x007E9D34u); /* 0x0077A6F2: push 0x7e9d34 */
    ecx = 0x0081E7E4u; /* 0x0077A6F7: mov ecx, 0x81e7e4 */
    RECOMP_CALL(sub_005766E0); /* 0x0077A6FC: call 0x5766e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A701: ret  */

}

void sub_0077A710(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A710u);

L_0077A710:
    MEM32(0x81E5AC) = 0x3DD67750u; /* 0x0077A710: mov dword ptr [0x81e5ac], 0x3dd67750 */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A71A: ret  */

}

void sub_0077A720(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A720u);

L_0077A720:
    PUSH32(esp, 4); /* 0x0077A720: push 4 */
    PUSH32(esp, 0x007E9F58u); /* 0x0077A722: push 0x7e9f58 */
    ecx = 0x0081E5B0u; /* 0x0077A727: mov ecx, 0x81e5b0 */
    RECOMP_CALL(sub_005766E0); /* 0x0077A72C: call 0x5766e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A731: ret  */

}

void sub_0077A740(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A740u);

L_0077A740:
    ecx = 0x0081E7ECu; /* 0x0077A740: mov ecx, 0x81e7ec */
    RECOMP_CALL(sub_00570FA0); /* 0x0077A745: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007818A0u); /* 0x0077A74A: push 0x7818a0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077A74F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077A754: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A755: ret  */

}

void sub_0077A760(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A760u);

L_0077A760:
    eax = MEM32(0x783C30); /* 0x0077A760: mov eax, dword ptr [0x783c30] */
    edx = MEM32(0x783C28); /* 0x0077A765: mov edx, dword ptr [0x783c28] */
    ecx = eax; /* 0x0077A76B: mov ecx, eax */
    MEM32(0x7EA088) = eax; /* 0x0077A76D: mov dword ptr [0x7ea088], eax */
    MEM32(0x7EA08C) = ecx; /* 0x0077A772: mov dword ptr [0x7ea08c], ecx */
    ecx = MEM32(0x783C2C); /* 0x0077A778: mov ecx, dword ptr [0x783c2c] */
    eax = edx; /* 0x0077A77E: mov eax, edx */
    MEM32(0x7EA0C0) = edx; /* 0x0077A780: mov dword ptr [0x7ea0c0], edx */
    edx = ecx; /* 0x0077A786: mov edx, ecx */
    MEM32(0x7EA0C4) = eax; /* 0x0077A788: mov dword ptr [0x7ea0c4], eax */
    MEM32(0x7EA0C8) = ecx; /* 0x0077A78D: mov dword ptr [0x7ea0c8], ecx */
    SET_LO8(ecx, 0x80u); /* 0x0077A793: mov cl, 0x80 */
    SET_LO8(eax, 0x25u); /* 0x0077A795: mov al, 0x25 */
    MEM8(0x7EA0E8) = (uint8_t)(LO8(eax)); /* 0x0077A797: mov byte ptr [0x7ea0e8], al */
    MEM8(0x7EA0E9) = (uint8_t)(LO8(eax)); /* 0x0077A79C: mov byte ptr [0x7ea0e9], al */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0077A7A1: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    MEM8(0x7EA0EE) = (uint8_t)(LO8(ecx)); /* 0x0077A7A3: mov byte ptr [0x7ea0ee], cl */
    MEM8(0x7EA0EF) = (uint8_t)(LO8(ecx)); /* 0x0077A7A9: mov byte ptr [0x7ea0ef], cl */
    MEM8(0x7EA0F0) = (uint8_t)(LO8(ecx)); /* 0x0077A7AF: mov byte ptr [0x7ea0f0], cl */
    MEM8(0x7EA0F1) = (uint8_t)(LO8(ecx)); /* 0x0077A7B5: mov byte ptr [0x7ea0f1], cl */
    MEM8(0x7EA0F2) = (uint8_t)(LO8(ecx)); /* 0x0077A7BB: mov byte ptr [0x7ea0f2], cl */
    MEM8(0x7EA0F3) = (uint8_t)(LO8(ecx)); /* 0x0077A7C1: mov byte ptr [0x7ea0f3], cl */
    SET_LO8(ecx, 0x32u); /* 0x0077A7C7: mov cl, 0x32 */
    MEM32(0x7EA090) = 0; /* 0x0077A7C9: mov dword ptr [0x7ea090], 0 */
    MEM32(0x7EA094) = 0x41200000u; /* 0x0077A7D3: mov dword ptr [0x7ea094], 0x41200000 */
    MEM32(0x7EA098) = 0x40000000u; /* 0x0077A7DD: mov dword ptr [0x7ea098], 0x40000000 */
    MEM32(0x7EA09C) = 0; /* 0x0077A7E7: mov dword ptr [0x7ea09c], 0 */
    MEM32(0x7EA0A0) = 0x41200000u; /* 0x0077A7F1: mov dword ptr [0x7ea0a0], 0x41200000 */
    MEM32(0x7EA0A4) = 0x40000000u; /* 0x0077A7FB: mov dword ptr [0x7ea0a4], 0x40000000 */
    MEM32(0x7EA0A8) = 0; /* 0x0077A805: mov dword ptr [0x7ea0a8], 0 */
    MEM32(0x7EA0AC) = 0; /* 0x0077A80F: mov dword ptr [0x7ea0ac], 0 */
    MEM32(0x7EA0B0) = 0; /* 0x0077A819: mov dword ptr [0x7ea0b0], 0 */
    MEM32(0x7EA0B4) = 0; /* 0x0077A823: mov dword ptr [0x7ea0b4], 0 */
    MEM32(0x7EA0B8) = 0; /* 0x0077A82D: mov dword ptr [0x7ea0b8], 0 */
    MEM32(0x7EA0BC) = 0; /* 0x0077A837: mov dword ptr [0x7ea0bc], 0 */
    MEM32(0x7EA0CC) = edx; /* 0x0077A841: mov dword ptr [0x7ea0cc], edx */
    MEM32(0x7EA0D0) = 0; /* 0x0077A847: mov dword ptr [0x7ea0d0], 0 */
    MEM32(0x7EA0D4) = 0; /* 0x0077A851: mov dword ptr [0x7ea0d4], 0 */
    MEM32(0x7EA0D8) = 0; /* 0x0077A85B: mov dword ptr [0x7ea0d8], 0 */
    MEM32(0x7EA0DC) = 0; /* 0x0077A865: mov dword ptr [0x7ea0dc], 0 */
    MEM32(0x7EA0E0) = 0; /* 0x0077A86F: mov dword ptr [0x7ea0e0], 0 */
    MEM32(0x7EA0E4) = 0; /* 0x0077A879: mov dword ptr [0x7ea0e4], 0 */
    MEM8(0x7EA0EA) = (uint8_t)(LO8(eax)); /* 0x0077A883: mov byte ptr [0x7ea0ea], al */
    MEM8(0x7EA0EB) = (uint8_t)(LO8(eax)); /* 0x0077A888: mov byte ptr [0x7ea0eb], al */
    MEM8(0x7EA0EC) = (uint8_t)(LO8(eax)); /* 0x0077A88D: mov byte ptr [0x7ea0ec], al */
    MEM8(0x7EA0ED) = (uint8_t)(LO8(eax)); /* 0x0077A892: mov byte ptr [0x7ea0ed], al */
    MEM8(0x7EA0F4) = (uint8_t)(LO8(eax)); /* 0x0077A897: mov byte ptr [0x7ea0f4], al */
    MEM8(0x7EA0F5) = (uint8_t)(LO8(ecx)); /* 0x0077A89C: mov byte ptr [0x7ea0f5], cl */
    MEM8(0x7EA0F6) = (uint8_t)(LO8(eax)); /* 0x0077A8A2: mov byte ptr [0x7ea0f6], al */
    MEM8(0x7EA0F7) = (uint8_t)(LO8(ecx)); /* 0x0077A8A7: mov byte ptr [0x7ea0f7], cl */
    MEM8(0x7EA0F8) = (uint8_t)(LO8(eax)); /* 0x0077A8AD: mov byte ptr [0x7ea0f8], al */
    MEM8(0x7EA0F9) = (uint8_t)(LO8(eax)); /* 0x0077A8B2: mov byte ptr [0x7ea0f9], al */
    MEM32(0x7EA0FC) = eax; /* 0x0077A8B7: mov dword ptr [0x7ea0fc], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A8BC: ret  */

}

void sub_0077A8C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A8C0u);

L_0077A8C0:
    PUSH32(esp, 0x00781890u); /* 0x0077A8C0: push 0x781890 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077A8C5: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077A8CA: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A8CB: ret  */

}

void sub_0077A8D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A8D0u);

L_0077A8D0:
    ecx = 0x0081E810u; /* 0x0077A8D0: mov ecx, 0x81e810 */
    RECOMP_CALL(sub_0041AA90); /* 0x0077A8D5: call 0x41aa90 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007818E0u); /* 0x0077A8DA: push 0x7818e0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077A8DF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077A8E4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A8E5: ret  */

}

void sub_0077A8F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A8F0u);

L_0077A8F0:
    ecx = 0x0081CBC0u; /* 0x0077A8F0: mov ecx, 0x81cbc0 */
    RECOMP_CALL(sub_004130D0); /* 0x0077A8F5: call 0x4130d0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007818B0u); /* 0x0077A8FA: push 0x7818b0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077A8FF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077A904: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A905: ret  */

}

void sub_0077A910(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A910u);

L_0077A910:
    fp_push(*(float*)&MEM32(0x785BC8)); /* 0x0077A910: fld dword ptr [0x785bc8] */
    _st[0] += _st[0]; /* 0x0077A916: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x827CC4) = _v; } /* 0x0077A918: fstp dword ptr [0x827cc4] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A91E: ret  */

}

void sub_0077A920(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A920u);

L_0077A920:
    fp_push(*(float*)&MEM32(0x785BC8)); /* 0x0077A920: fld dword ptr [0x785bc8] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x0077A926: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x827CC0) = _v; } /* 0x0077A92C: fstp dword ptr [0x827cc0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A932: ret  */

}

void sub_0077A940(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A940u);

L_0077A940:
    fp_push(*(double*)ADDR(0x785BD0)); /* 0x0077A940: fld qword ptr [0x785bd0] */
    _st[0] += _st[0]; /* 0x0077A946: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x827CB8) = _v; } /* 0x0077A948: fstp qword ptr [0x827cb8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A94E: ret  */

}

void sub_0077A950(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A950u);

L_0077A950:
    fp_push(*(double*)ADDR(0x785BD0)); /* 0x0077A950: fld qword ptr [0x785bd0] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x0077A956: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x827CB0) = _v; } /* 0x0077A95C: fstp qword ptr [0x827cb0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A962: ret  */

}

void sub_0077A970(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A970u);

L_0077A970:
    fp_push(*(float*)&MEM32(0x784250)); /* 0x0077A970: fld dword ptr [0x784250] */
    _st[0] /= (double)*(float*)ADDR(0x785BE4); /* 0x0077A976: fdiv dword ptr [0x785be4] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x827DA0) = _v; } /* 0x0077A97C: fstp dword ptr [0x827da0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A982: ret  */

}

void sub_0077A990(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A990u);

L_0077A990:
    PUSH32(esp, 0x00781970u); /* 0x0077A990: push 0x781970 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077A995: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077A99A: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A99B: ret  */

}

void sub_0077A9A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A9A0u);

L_0077A9A0:
    PUSH32(esp, 0x007864E8u); /* 0x0077A9A0: push 0x7864e8 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077A9A5: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077A9AA: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827D34) = eax; /* 0x0077A9AD: mov dword ptr [0x827d34], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A9B2: ret  */

}

void sub_0077A9C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A9C0u);

L_0077A9C0:
    PUSH32(esp, 0x007864FCu); /* 0x0077A9C0: push 0x7864fc */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077A9C5: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077A9CA: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827C5C) = eax; /* 0x0077A9CD: mov dword ptr [0x827c5c], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A9D2: ret  */

}

void sub_0077A9E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077A9E0u);

L_0077A9E0:
    PUSH32(esp, 0x00786510u); /* 0x0077A9E0: push 0x786510 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077A9E5: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077A9EA: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827C68) = eax; /* 0x0077A9ED: mov dword ptr [0x827c68], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077A9F2: ret  */

}

void sub_0077AA00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077AA00u);

L_0077AA00:
    PUSH32(esp, 0x00786520u); /* 0x0077AA00: push 0x786520 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AA05: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077AA0A: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827C98) = eax; /* 0x0077AA0D: mov dword ptr [0x827c98], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077AA12: ret  */

}

void sub_0077AA20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077AA20u);

L_0077AA20:
    PUSH32(esp, 0x00786530u); /* 0x0077AA20: push 0x786530 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AA25: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077AA2A: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827DAC) = eax; /* 0x0077AA2D: mov dword ptr [0x827dac], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077AA32: ret  */

}

void sub_0077AA40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077AA40u);

L_0077AA40:
    PUSH32(esp, 0x00786548u); /* 0x0077AA40: push 0x786548 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AA45: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077AA4A: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827C7C) = eax; /* 0x0077AA4D: mov dword ptr [0x827c7c], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077AA52: ret  */

}

void sub_0077AA60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077AA60u);

L_0077AA60:
    PUSH32(esp, 0x00786560u); /* 0x0077AA60: push 0x786560 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AA65: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077AA6A: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827F40) = eax; /* 0x0077AA6D: mov dword ptr [0x827f40], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077AA72: ret  */

}

void sub_0077AA80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077AA80u);

L_0077AA80:
    PUSH32(esp, 0x0078657Cu); /* 0x0077AA80: push 0x78657c */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AA85: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077AA8A: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827C8C) = eax; /* 0x0077AA8D: mov dword ptr [0x827c8c], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077AA92: ret  */

}

void sub_0077AAA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077AAA0u);

L_0077AAA0:
    PUSH32(esp, 0x00786598u); /* 0x0077AAA0: push 0x786598 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AAA5: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077AAAA: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827DB0) = eax; /* 0x0077AAAD: mov dword ptr [0x827db0], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077AAB2: ret  */

}

void sub_0077AAC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077AAC0u);

L_0077AAC0:
    ecx = 0x00827E88u; /* 0x0077AAC0: mov ecx, 0x827e88 */
    RECOMP_CALL(sub_00430230); /* 0x0077AAC5: call 0x430230 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781980u); /* 0x0077AACA: push 0x781980 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077AACF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077AAD4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077AAD5: ret  */

}

void sub_0077AAE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077AAE0u);

L_0077AAE0:
    ecx = 0x00827C3Cu; /* 0x0077AAE0: mov ecx, 0x827c3c */
    RECOMP_CALL(sub_004EC6D0); /* 0x0077AAE5: call 0x4ec6d0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781A50u); /* 0x0077AAEA: push 0x781a50 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077AAEF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077AAF4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077AAF5: ret  */

}

void sub_0077AB00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077AB00u);

L_0077AB00:
    ecx = 0x00827D98u; /* 0x0077AB00: mov ecx, 0x827d98 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077AB05: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781A70u); /* 0x0077AB0A: push 0x781a70 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077AB0F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077AB14: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077AB15: ret  */

}

void sub_0077AB20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077AB20u);

L_0077AB20:
    eax = MEM32(0x7FAAA8); /* 0x0077AB20: mov eax, dword ptr [0x7faaa8] */
    /* test eax, eax */ /* 0x0077AB25: test eax, eax */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(eax);
    _cf = 0;
    _flag_k = FK_TEST;
    SET_LO8(eax, (TEST_NZ(_flag_a, _flag_b)) ? 1 : 0); /* 0x0077AB27: setne al */
    MEM8(0x827C38) = (uint8_t)(LO8(eax)); /* 0x0077AB2A: mov byte ptr [0x827c38], al */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077AB2F: ret  */

}

void sub_0077AB30(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077AB30u);

L_0077AB30:
    ecx = 0x00827B88u; /* 0x0077AB30: mov ecx, 0x827b88 */
    RECOMP_CALL(sub_00435BE0); /* 0x0077AB35: call 0x435be0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781AA0u); /* 0x0077AB3A: push 0x781aa0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077AB3F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077AB44: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077AB45: ret  */

}

void sub_0077AB50(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077AB50u);

L_0077AB50:
    ecx = 0x00827C60u; /* 0x0077AB50: mov ecx, 0x827c60 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077AB55: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781A60u); /* 0x0077AB5A: push 0x781a60 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077AB5F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077AB64: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077AB65: ret  */

}

void sub_0077AB70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077AB70u);

L_0077AB70:
    eax = MEM32(0x785BF0); /* 0x0077AB70: mov eax, dword ptr [0x785bf0] */
    edx = MEM32(0x785BE8); /* 0x0077AB75: mov edx, dword ptr [0x785be8] */
    ecx = eax; /* 0x0077AB7B: mov ecx, eax */
    MEM32(0x7EA4F0) = eax; /* 0x0077AB7D: mov dword ptr [0x7ea4f0], eax */
    MEM32(0x7EA4F4) = ecx; /* 0x0077AB82: mov dword ptr [0x7ea4f4], ecx */
    ecx = MEM32(0x785BEC); /* 0x0077AB88: mov ecx, dword ptr [0x785bec] */
    eax = edx; /* 0x0077AB8E: mov eax, edx */
    MEM32(0x7EA528) = edx; /* 0x0077AB90: mov dword ptr [0x7ea528], edx */
    edx = ecx; /* 0x0077AB96: mov edx, ecx */
    MEM32(0x7EA52C) = eax; /* 0x0077AB98: mov dword ptr [0x7ea52c], eax */
    MEM32(0x7EA530) = ecx; /* 0x0077AB9D: mov dword ptr [0x7ea530], ecx */
    SET_LO8(ecx, 0x80u); /* 0x0077ABA3: mov cl, 0x80 */
    SET_LO8(eax, 0x25u); /* 0x0077ABA5: mov al, 0x25 */
    MEM8(0x7EA550) = (uint8_t)(LO8(eax)); /* 0x0077ABA7: mov byte ptr [0x7ea550], al */
    MEM8(0x7EA551) = (uint8_t)(LO8(eax)); /* 0x0077ABAC: mov byte ptr [0x7ea551], al */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0077ABB1: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    MEM8(0x7EA556) = (uint8_t)(LO8(ecx)); /* 0x0077ABB3: mov byte ptr [0x7ea556], cl */
    MEM8(0x7EA557) = (uint8_t)(LO8(ecx)); /* 0x0077ABB9: mov byte ptr [0x7ea557], cl */
    MEM8(0x7EA558) = (uint8_t)(LO8(ecx)); /* 0x0077ABBF: mov byte ptr [0x7ea558], cl */
    MEM8(0x7EA559) = (uint8_t)(LO8(ecx)); /* 0x0077ABC5: mov byte ptr [0x7ea559], cl */
    MEM8(0x7EA55A) = (uint8_t)(LO8(ecx)); /* 0x0077ABCB: mov byte ptr [0x7ea55a], cl */
    MEM8(0x7EA55B) = (uint8_t)(LO8(ecx)); /* 0x0077ABD1: mov byte ptr [0x7ea55b], cl */
    SET_LO8(ecx, 0x32u); /* 0x0077ABD7: mov cl, 0x32 */
    MEM32(0x7EA4F8) = 0; /* 0x0077ABD9: mov dword ptr [0x7ea4f8], 0 */
    MEM32(0x7EA4FC) = 0x41200000u; /* 0x0077ABE3: mov dword ptr [0x7ea4fc], 0x41200000 */
    MEM32(0x7EA500) = 0x40000000u; /* 0x0077ABED: mov dword ptr [0x7ea500], 0x40000000 */
    MEM32(0x7EA504) = 0; /* 0x0077ABF7: mov dword ptr [0x7ea504], 0 */
    MEM32(0x7EA508) = 0x41200000u; /* 0x0077AC01: mov dword ptr [0x7ea508], 0x41200000 */
    MEM32(0x7EA50C) = 0x40000000u; /* 0x0077AC0B: mov dword ptr [0x7ea50c], 0x40000000 */
    MEM32(0x7EA510) = 0; /* 0x0077AC15: mov dword ptr [0x7ea510], 0 */
    MEM32(0x7EA514) = 0; /* 0x0077AC1F: mov dword ptr [0x7ea514], 0 */
    MEM32(0x7EA518) = 0; /* 0x0077AC29: mov dword ptr [0x7ea518], 0 */
    MEM32(0x7EA51C) = 0; /* 0x0077AC33: mov dword ptr [0x7ea51c], 0 */
    MEM32(0x7EA520) = 0; /* 0x0077AC3D: mov dword ptr [0x7ea520], 0 */
    MEM32(0x7EA524) = 0; /* 0x0077AC47: mov dword ptr [0x7ea524], 0 */
    MEM32(0x7EA534) = edx; /* 0x0077AC51: mov dword ptr [0x7ea534], edx */
    MEM32(0x7EA538) = 0; /* 0x0077AC57: mov dword ptr [0x7ea538], 0 */
    MEM32(0x7EA53C) = 0; /* 0x0077AC61: mov dword ptr [0x7ea53c], 0 */
    MEM32(0x7EA540) = 0; /* 0x0077AC6B: mov dword ptr [0x7ea540], 0 */
    MEM32(0x7EA544) = 0; /* 0x0077AC75: mov dword ptr [0x7ea544], 0 */
    MEM32(0x7EA548) = 0; /* 0x0077AC7F: mov dword ptr [0x7ea548], 0 */
    MEM32(0x7EA54C) = 0; /* 0x0077AC89: mov dword ptr [0x7ea54c], 0 */
    MEM8(0x7EA552) = (uint8_t)(LO8(eax)); /* 0x0077AC93: mov byte ptr [0x7ea552], al */
    MEM8(0x7EA553) = (uint8_t)(LO8(eax)); /* 0x0077AC98: mov byte ptr [0x7ea553], al */
    MEM8(0x7EA554) = (uint8_t)(LO8(eax)); /* 0x0077AC9D: mov byte ptr [0x7ea554], al */
    MEM8(0x7EA555) = (uint8_t)(LO8(eax)); /* 0x0077ACA2: mov byte ptr [0x7ea555], al */
    MEM8(0x7EA55C) = (uint8_t)(LO8(eax)); /* 0x0077ACA7: mov byte ptr [0x7ea55c], al */
    MEM8(0x7EA55D) = (uint8_t)(LO8(ecx)); /* 0x0077ACAC: mov byte ptr [0x7ea55d], cl */
    MEM8(0x7EA55E) = (uint8_t)(LO8(eax)); /* 0x0077ACB2: mov byte ptr [0x7ea55e], al */
    MEM8(0x7EA55F) = (uint8_t)(LO8(ecx)); /* 0x0077ACB7: mov byte ptr [0x7ea55f], cl */
    MEM8(0x7EA560) = (uint8_t)(LO8(eax)); /* 0x0077ACBD: mov byte ptr [0x7ea560], al */
    MEM8(0x7EA561) = (uint8_t)(LO8(eax)); /* 0x0077ACC2: mov byte ptr [0x7ea561], al */
    MEM32(0x7EA564) = eax; /* 0x0077ACC7: mov dword ptr [0x7ea564], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077ACCC: ret  */

}

void sub_0077ACD0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077ACD0u);

L_0077ACD0:
    PUSH32(esp, 0x00786458u); /* 0x0077ACD0: push 0x786458 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077ACD5: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077ACDA: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827F60) = eax; /* 0x0077ACDD: mov dword ptr [0x827f60], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077ACE2: ret  */

}

void sub_0077ACF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077ACF0u);

L_0077ACF0:
    ecx = 0x00827B80u; /* 0x0077ACF0: mov ecx, 0x827b80 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077ACF5: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781A10u); /* 0x0077ACFA: push 0x781a10 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077ACFF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077AD04: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077AD05: ret  */

}

void sub_0077AD10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077AD10u);

L_0077AD10:
    eax = 0x00827BA0u; /* 0x0077AD10: mov eax, 0x827ba0 */
    edx = 8; /* 0x0077AD15: mov edx, 8 */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    ecx = 0; /* 0x0077AD1A: xor ecx, ecx */
    _cf = 0;
    _flag_k = FK_TEST;
    esp = esp; /* 0x0077AD1C: lea esp, [esp] */

L_0077AD20:
    MEM32(eax + (-0x8)) = ecx; /* 0x0077AD20: mov dword ptr [eax - 8], ecx */
    MEM32(eax + (-0x4)) = ecx; /* 0x0077AD23: mov dword ptr [eax - 4], ecx */
    MEM32(eax) = ecx; /* 0x0077AD26: mov dword ptr [eax], ecx */
    MEM32(eax + 0x4) = ecx; /* 0x0077AD28: mov dword ptr [eax + 4], ecx */
    MEM32(eax + 0x8) = 0xFFFFFFFFu; /* 0x0077AD2B: mov dword ptr [eax + 8], 0xffffffff */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x14u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x14u; /* 0x0077AD32: add eax, 0x14 */
    _flag_k = FK_ADD;
    _flag_a = (uint32_t)(edx); _flag_b = (uint32_t)(1);
    edx = edx - 1; /* 0x0077AD35: dec edx */
    _flag_k = FK_DEC;
    RECOMP_BACKEDGE();
    if (/* dec result */ CMP_NE(_flag_a, _flag_b)) goto L_0077AD20; /* 0x0077AD36: jne 0x77ad20 */

L_0077AD38:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077AD38: ret  */

}

void sub_0077AD40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077AD40u);

L_0077AD40:
    PUSH32(esp, 0x0078660Cu); /* 0x0077AD40: push 0x78660c */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AD45: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00786600u); /* 0x0077AD4A: push 0x786600 */
    MEM32(0x827FA4) = eax; /* 0x0077AD4F: mov dword ptr [0x827fa4], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AD54: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007865F4u); /* 0x0077AD59: push 0x7865f4 */
    MEM32(0x827FA8) = eax; /* 0x0077AD5E: mov dword ptr [0x827fa8], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AD63: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007865E8u); /* 0x0077AD68: push 0x7865e8 */
    MEM32(0x827FAC) = eax; /* 0x0077AD6D: mov dword ptr [0x827fac], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AD72: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007865DCu); /* 0x0077AD77: push 0x7865dc */
    MEM32(0x827FB0) = eax; /* 0x0077AD7C: mov dword ptr [0x827fb0], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AD81: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007865D0u); /* 0x0077AD86: push 0x7865d0 */
    MEM32(0x827FB4) = eax; /* 0x0077AD8B: mov dword ptr [0x827fb4], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AD90: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007865C4u); /* 0x0077AD95: push 0x7865c4 */
    MEM32(0x827FB8) = eax; /* 0x0077AD9A: mov dword ptr [0x827fb8], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AD9F: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007865B8u); /* 0x0077ADA4: push 0x7865b8 */
    MEM32(0x827FBC) = eax; /* 0x0077ADA9: mov dword ptr [0x827fbc], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077ADAE: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0077ADB3: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(0x827FC0) = eax; /* 0x0077ADB6: mov dword ptr [0x827fc0], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077ADBB: ret  */

}

void sub_0077ADC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077ADC0u);

L_0077ADC0:
    PUSH32(esp, 0x0078666Cu); /* 0x0077ADC0: push 0x78666c */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077ADC5: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00786660u); /* 0x0077ADCA: push 0x786660 */
    MEM32(0x827F64) = eax; /* 0x0077ADCF: mov dword ptr [0x827f64], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077ADD4: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00786654u); /* 0x0077ADD9: push 0x786654 */
    MEM32(0x827F68) = eax; /* 0x0077ADDE: mov dword ptr [0x827f68], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077ADE3: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00786648u); /* 0x0077ADE8: push 0x786648 */
    MEM32(0x827F6C) = eax; /* 0x0077ADED: mov dword ptr [0x827f6c], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077ADF2: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x0078663Cu); /* 0x0077ADF7: push 0x78663c */
    MEM32(0x827F70) = eax; /* 0x0077ADFC: mov dword ptr [0x827f70], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AE01: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00786630u); /* 0x0077AE06: push 0x786630 */
    MEM32(0x827F74) = eax; /* 0x0077AE0B: mov dword ptr [0x827f74], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AE10: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00786624u); /* 0x0077AE15: push 0x786624 */
    MEM32(0x827F78) = eax; /* 0x0077AE1A: mov dword ptr [0x827f78], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AE1F: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00786618u); /* 0x0077AE24: push 0x786618 */
    MEM32(0x827F7C) = eax; /* 0x0077AE29: mov dword ptr [0x827f7c], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AE2E: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0077AE33: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(0x827F80) = eax; /* 0x0077AE36: mov dword ptr [0x827f80], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077AE3B: ret  */

}

void sub_0077AE40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077AE40u);

L_0077AE40:
    PUSH32(esp, 0x007866CCu); /* 0x0077AE40: push 0x7866cc */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AE45: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007866C0u); /* 0x0077AE4A: push 0x7866c0 */
    MEM32(0x827FC4) = eax; /* 0x0077AE4F: mov dword ptr [0x827fc4], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AE54: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007866B4u); /* 0x0077AE59: push 0x7866b4 */
    MEM32(0x827FC8) = eax; /* 0x0077AE5E: mov dword ptr [0x827fc8], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AE63: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007866A8u); /* 0x0077AE68: push 0x7866a8 */
    MEM32(0x827FCC) = eax; /* 0x0077AE6D: mov dword ptr [0x827fcc], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AE72: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x0078669Cu); /* 0x0077AE77: push 0x78669c */
    MEM32(0x827FD0) = eax; /* 0x0077AE7C: mov dword ptr [0x827fd0], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AE81: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00786690u); /* 0x0077AE86: push 0x786690 */
    MEM32(0x827FD4) = eax; /* 0x0077AE8B: mov dword ptr [0x827fd4], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AE90: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00786684u); /* 0x0077AE95: push 0x786684 */
    MEM32(0x827FD8) = eax; /* 0x0077AE9A: mov dword ptr [0x827fd8], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AE9F: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00786678u); /* 0x0077AEA4: push 0x786678 */
    MEM32(0x827FDC) = eax; /* 0x0077AEA9: mov dword ptr [0x827fdc], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AEAE: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0077AEB3: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(0x827FE0) = eax; /* 0x0077AEB6: mov dword ptr [0x827fe0], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077AEBB: ret  */

}

void sub_0077AEC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077AEC0u);

L_0077AEC0:
    PUSH32(esp, 0x0078672Cu); /* 0x0077AEC0: push 0x78672c */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AEC5: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00786720u); /* 0x0077AECA: push 0x786720 */
    MEM32(0x827F84) = eax; /* 0x0077AECF: mov dword ptr [0x827f84], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AED4: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00786714u); /* 0x0077AED9: push 0x786714 */
    MEM32(0x827F88) = eax; /* 0x0077AEDE: mov dword ptr [0x827f88], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AEE3: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00786708u); /* 0x0077AEE8: push 0x786708 */
    MEM32(0x827F8C) = eax; /* 0x0077AEED: mov dword ptr [0x827f8c], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AEF2: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007866FCu); /* 0x0077AEF7: push 0x7866fc */
    MEM32(0x827F90) = eax; /* 0x0077AEFC: mov dword ptr [0x827f90], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AF01: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007866F0u); /* 0x0077AF06: push 0x7866f0 */
    MEM32(0x827F94) = eax; /* 0x0077AF0B: mov dword ptr [0x827f94], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AF10: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007866E4u); /* 0x0077AF15: push 0x7866e4 */
    MEM32(0x827F98) = eax; /* 0x0077AF1A: mov dword ptr [0x827f98], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AF1F: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007866D8u); /* 0x0077AF24: push 0x7866d8 */
    MEM32(0x827F9C) = eax; /* 0x0077AF29: mov dword ptr [0x827f9c], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077AF2E: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0077AF33: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(0x827FA0) = eax; /* 0x0077AF36: mov dword ptr [0x827fa0], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077AF3B: ret  */

}

void sub_0077AF40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077AF40u);

L_0077AF40:
    PUSH32(esp, 0x004022D0u); /* 0x0077AF40: push 0x4022d0 */
    PUSH32(esp, 0x004FE8F0u); /* 0x0077AF45: push 0x4fe8f0 */
    PUSH32(esp, 8); /* 0x0077AF4A: push 8 */
    PUSH32(esp, 0xCu); /* 0x0077AF4C: push 0xc */
    PUSH32(esp, 0x00827D38u); /* 0x0077AF4E: push 0x827d38 */
    RECOMP_CALL(sub_0075C39D); /* 0x0077AF53: call 0x75c39d */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007818F0u); /* 0x0077AF58: push 0x7818f0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077AF5D: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077AF62: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077AF63: ret  */

}

void sub_0077AF70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077AF70u);

L_0077AF70:
    PUSH32(esp, 0x004022D0u); /* 0x0077AF70: push 0x4022d0 */
    PUSH32(esp, 0x004FE8F0u); /* 0x0077AF75: push 0x4fe8f0 */
    PUSH32(esp, 8); /* 0x0077AF7A: push 8 */
    PUSH32(esp, 0xCu); /* 0x0077AF7C: push 0xc */
    PUSH32(esp, 0x00827DB8u); /* 0x0077AF7E: push 0x827db8 */
    RECOMP_CALL(sub_0075C39D); /* 0x0077AF83: call 0x75c39d */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781910u); /* 0x0077AF88: push 0x781910 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077AF8D: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077AF92: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077AF93: ret  */

}

void sub_0077AFA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077AFA0u);

L_0077AFA0:
    PUSH32(esp, 0x004022D0u); /* 0x0077AFA0: push 0x4022d0 */
    PUSH32(esp, 0x004FE8F0u); /* 0x0077AFA5: push 0x4fe8f0 */
    PUSH32(esp, 8); /* 0x0077AFAA: push 8 */
    PUSH32(esp, 0xCu); /* 0x0077AFAC: push 0xc */
    PUSH32(esp, 0x00827E28u); /* 0x0077AFAE: push 0x827e28 */
    RECOMP_CALL(sub_0075C39D); /* 0x0077AFB3: call 0x75c39d */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781930u); /* 0x0077AFB8: push 0x781930 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077AFBD: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077AFC2: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077AFC3: ret  */

}

void sub_0077AFD0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077AFD0u);

L_0077AFD0:
    PUSH32(esp, 0x004022D0u); /* 0x0077AFD0: push 0x4022d0 */
    PUSH32(esp, 0x004FE8F0u); /* 0x0077AFD5: push 0x4fe8f0 */
    PUSH32(esp, 8); /* 0x0077AFDA: push 8 */
    PUSH32(esp, 0xCu); /* 0x0077AFDC: push 0xc */
    PUSH32(esp, 0x00827CD0u); /* 0x0077AFDE: push 0x827cd0 */
    RECOMP_CALL(sub_0075C39D); /* 0x0077AFE3: call 0x75c39d */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781950u); /* 0x0077AFE8: push 0x781950 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077AFED: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077AFF2: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077AFF3: ret  */

}

void sub_0077B000(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B000u);

L_0077B000:
    PUSH32(esp, 0x00781990u); /* 0x0077B000: push 0x781990 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077B005: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077B00A: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B00B: ret  */

}

void sub_0077B010(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B010u);

L_0077B010:
    PUSH32(esp, 0x007819B0u); /* 0x0077B010: push 0x7819b0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077B015: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077B01A: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B01B: ret  */

}

void sub_0077B020(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B020u);

L_0077B020:
    PUSH32(esp, 0x007819D0u); /* 0x0077B020: push 0x7819d0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077B025: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077B02A: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B02B: ret  */

}

void sub_0077B030(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B030u);

L_0077B030:
    PUSH32(esp, 0x007819F0u); /* 0x0077B030: push 0x7819f0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077B035: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077B03A: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B03B: ret  */

}

void sub_0077B040(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B040u);

L_0077B040:
    ecx = 0x00827C9Cu; /* 0x0077B040: mov ecx, 0x827c9c */
    RECOMP_CALL(sub_00570FA0); /* 0x0077B045: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781A20u); /* 0x0077B04A: push 0x781a20 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077B04F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077B054: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B055: ret  */

}

void sub_0077B060(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B060u);

L_0077B060:
    ecx = 0x00827CA4u; /* 0x0077B060: mov ecx, 0x827ca4 */
    RECOMP_CALL(sub_004EC6D0); /* 0x0077B065: call 0x4ec6d0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781A80u); /* 0x0077B06A: push 0x781a80 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077B06F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077B074: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B075: ret  */

}

void sub_0077B080(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B080u);

L_0077B080:
    PUSH32(esp, 0x00785C3Cu); /* 0x0077B080: push 0x785c3c */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B085: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077B08A: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827C84) = eax; /* 0x0077B08D: mov dword ptr [0x827c84], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B092: ret  */

}

void sub_0077B0A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B0A0u);

L_0077B0A0:
    PUSH32(esp, 0x00786738u); /* 0x0077B0A0: push 0x786738 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B0A5: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077B0AA: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827F54) = eax; /* 0x0077B0AD: mov dword ptr [0x827f54], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B0B2: ret  */

}

void sub_0077B0C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B0C0u);

L_0077B0C0:
    PUSH32(esp, 0x00786748u); /* 0x0077B0C0: push 0x786748 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B0C5: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077B0CA: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827C6C) = eax; /* 0x0077B0CD: mov dword ptr [0x827c6c], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B0D2: ret  */

}

void sub_0077B0E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B0E0u);

L_0077B0E0:
    PUSH32(esp, 0x00786760u); /* 0x0077B0E0: push 0x786760 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B0E5: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077B0EA: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827F48) = eax; /* 0x0077B0ED: mov dword ptr [0x827f48], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B0F2: ret  */

}

void sub_0077B100(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B100u);

L_0077B100:
    PUSH32(esp, 0x00786774u); /* 0x0077B100: push 0x786774 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B105: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077B10A: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827F4C) = eax; /* 0x0077B10D: mov dword ptr [0x827f4c], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B112: ret  */

}

void sub_0077B120(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B120u);

L_0077B120:
    PUSH32(esp, 0x0078678Cu); /* 0x0077B120: push 0x78678c */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B125: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077B12A: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827CC8) = eax; /* 0x0077B12D: mov dword ptr [0x827cc8], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B132: ret  */

}

void sub_0077B140(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B140u);

L_0077B140:
    PUSH32(esp, 0x007867A0u); /* 0x0077B140: push 0x7867a0 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B145: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077B14A: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827F44) = eax; /* 0x0077B14D: mov dword ptr [0x827f44], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B152: ret  */

}

void sub_0077B160(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B160u);

L_0077B160:
    PUSH32(esp, 0x007867B4u); /* 0x0077B160: push 0x7867b4 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B165: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077B16A: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827F5C) = eax; /* 0x0077B16D: mov dword ptr [0x827f5c], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B172: ret  */

}

void sub_0077B180(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B180u);

L_0077B180:
    PUSH32(esp, 0x007867CCu); /* 0x0077B180: push 0x7867cc */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B185: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077B18A: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827F58) = eax; /* 0x0077B18D: mov dword ptr [0x827f58], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B192: ret  */

}

void sub_0077B1A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B1A0u);

L_0077B1A0:
    PUSH32(esp, 0x007867E4u); /* 0x0077B1A0: push 0x7867e4 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B1A5: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077B1AA: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827F50) = eax; /* 0x0077B1AD: mov dword ptr [0x827f50], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B1B2: ret  */

}

void sub_0077B1C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B1C0u);

L_0077B1C0:
    PUSH32(esp, 0x007867F8u); /* 0x0077B1C0: push 0x7867f8 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B1C5: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077B1CA: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827C44) = eax; /* 0x0077B1CD: mov dword ptr [0x827c44], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B1D2: ret  */

}

void sub_0077B1E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B1E0u);

L_0077B1E0:
    PUSH32(esp, 0x00786810u); /* 0x0077B1E0: push 0x786810 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B1E5: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077B1EA: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827C58) = eax; /* 0x0077B1ED: mov dword ptr [0x827c58], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B1F2: ret  */

}

void sub_0077B200(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B200u);

L_0077B200:
    PUSH32(esp, 0x00786828u); /* 0x0077B200: push 0x786828 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B205: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077B20A: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827C94) = eax; /* 0x0077B20D: mov dword ptr [0x827c94], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B212: ret  */

}

void sub_0077B220(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B220u);

L_0077B220:
    PUSH32(esp, 0x00786838u); /* 0x0077B220: push 0x786838 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B225: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077B22A: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827C90) = eax; /* 0x0077B22D: mov dword ptr [0x827c90], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B232: ret  */

}

void sub_0077B240(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B240u);

L_0077B240:
    PUSH32(esp, 0x0078684Cu); /* 0x0077B240: push 0x78684c */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B245: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077B24A: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827C70) = eax; /* 0x0077B24D: mov dword ptr [0x827c70], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B252: ret  */

}

void sub_0077B260(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B260u);

L_0077B260:
    PUSH32(esp, 0x00786860u); /* 0x0077B260: push 0x786860 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B265: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077B26A: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827C54) = eax; /* 0x0077B26D: mov dword ptr [0x827c54], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B272: ret  */

}

void sub_0077B280(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B280u);

L_0077B280:
    PUSH32(esp, 0x00786874u); /* 0x0077B280: push 0x786874 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B285: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077B28A: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827C80) = eax; /* 0x0077B28D: mov dword ptr [0x827c80], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B292: ret  */

}

void sub_0077B2A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B2A0u);

L_0077B2A0:
    PUSH32(esp, 0x00786888u); /* 0x0077B2A0: push 0x786888 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B2A5: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077B2AA: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827DB4) = eax; /* 0x0077B2AD: mov dword ptr [0x827db4], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B2B2: ret  */

}

void sub_0077B2C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B2C0u);

L_0077B2C0:
    PUSH32(esp, 0x007868A0u); /* 0x0077B2C0: push 0x7868a0 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B2C5: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077B2CA: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827D30) = eax; /* 0x0077B2CD: mov dword ptr [0x827d30], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B2D2: ret  */

}

void sub_0077B2E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B2E0u);

L_0077B2E0:
    PUSH32(esp, 0x007868B8u); /* 0x0077B2E0: push 0x7868b8 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B2E5: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077B2EA: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827C88) = eax; /* 0x0077B2ED: mov dword ptr [0x827c88], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B2F2: ret  */

}

void sub_0077B300(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B300u);

L_0077B300:
    PUSH32(esp, 0x007868D0u); /* 0x0077B300: push 0x7868d0 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B305: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077B30A: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x827E18) = eax; /* 0x0077B30D: mov dword ptr [0x827e18], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B312: ret  */

}

void sub_0077B320(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B320u);

L_0077B320:
    eax = MEM32(0x827C84); /* 0x0077B320: mov eax, dword ptr [0x827c84] */
    ecx = MEM32(0x827F54); /* 0x0077B325: mov ecx, dword ptr [0x827f54] */
    edx = MEM32(0x827C6C); /* 0x0077B32B: mov edx, dword ptr [0x827c6c] */
    MEM32(0x7EA56C) = eax; /* 0x0077B331: mov dword ptr [0x7ea56c], eax */
    eax = MEM32(0x827F48); /* 0x0077B336: mov eax, dword ptr [0x827f48] */
    MEM32(0x7EA574) = ecx; /* 0x0077B33B: mov dword ptr [0x7ea574], ecx */
    ecx = MEM32(0x827F4C); /* 0x0077B341: mov ecx, dword ptr [0x827f4c] */
    MEM32(0x7EA57C) = edx; /* 0x0077B347: mov dword ptr [0x7ea57c], edx */
    edx = MEM32(0x827CC8); /* 0x0077B34D: mov edx, dword ptr [0x827cc8] */
    MEM32(0x7EA584) = eax; /* 0x0077B353: mov dword ptr [0x7ea584], eax */
    eax = MEM32(0x827F44); /* 0x0077B358: mov eax, dword ptr [0x827f44] */
    MEM32(0x7EA58C) = ecx; /* 0x0077B35D: mov dword ptr [0x7ea58c], ecx */
    ecx = MEM32(0x827F5C); /* 0x0077B363: mov ecx, dword ptr [0x827f5c] */
    MEM32(0x7EA594) = edx; /* 0x0077B369: mov dword ptr [0x7ea594], edx */
    edx = MEM32(0x827F58); /* 0x0077B36F: mov edx, dword ptr [0x827f58] */
    MEM32(0x7EA59C) = eax; /* 0x0077B375: mov dword ptr [0x7ea59c], eax */
    eax = MEM32(0x827F50); /* 0x0077B37A: mov eax, dword ptr [0x827f50] */
    MEM32(0x7EA5A4) = ecx; /* 0x0077B37F: mov dword ptr [0x7ea5a4], ecx */
    ecx = MEM32(0x827C44); /* 0x0077B385: mov ecx, dword ptr [0x827c44] */
    MEM32(0x7EA5AC) = edx; /* 0x0077B38B: mov dword ptr [0x7ea5ac], edx */
    edx = MEM32(0x827C58); /* 0x0077B391: mov edx, dword ptr [0x827c58] */
    MEM32(0x7EA5B4) = eax; /* 0x0077B397: mov dword ptr [0x7ea5b4], eax */
    eax = MEM32(0x827C94); /* 0x0077B39C: mov eax, dword ptr [0x827c94] */
    MEM32(0x7EA5BC) = ecx; /* 0x0077B3A1: mov dword ptr [0x7ea5bc], ecx */
    ecx = MEM32(0x827C90); /* 0x0077B3A7: mov ecx, dword ptr [0x827c90] */
    MEM32(0x7EA5C4) = edx; /* 0x0077B3AD: mov dword ptr [0x7ea5c4], edx */
    edx = MEM32(0x827C70); /* 0x0077B3B3: mov edx, dword ptr [0x827c70] */
    MEM32(0x7EA5CC) = eax; /* 0x0077B3B9: mov dword ptr [0x7ea5cc], eax */
    eax = MEM32(0x827C54); /* 0x0077B3BE: mov eax, dword ptr [0x827c54] */
    MEM32(0x7EA5D4) = ecx; /* 0x0077B3C3: mov dword ptr [0x7ea5d4], ecx */
    ecx = MEM32(0x827C80); /* 0x0077B3C9: mov ecx, dword ptr [0x827c80] */
    MEM32(0x7EA5DC) = edx; /* 0x0077B3CF: mov dword ptr [0x7ea5dc], edx */
    edx = MEM32(0x827DB4); /* 0x0077B3D5: mov edx, dword ptr [0x827db4] */
    MEM32(0x7EA5E4) = eax; /* 0x0077B3DB: mov dword ptr [0x7ea5e4], eax */
    eax = MEM32(0x827D30); /* 0x0077B3E0: mov eax, dword ptr [0x827d30] */
    MEM32(0x7EA5EC) = ecx; /* 0x0077B3E5: mov dword ptr [0x7ea5ec], ecx */
    ecx = MEM32(0x827C88); /* 0x0077B3EB: mov ecx, dword ptr [0x827c88] */
    MEM32(0x7EA5F4) = edx; /* 0x0077B3F1: mov dword ptr [0x7ea5f4], edx */
    edx = MEM32(0x827E18); /* 0x0077B3F7: mov edx, dword ptr [0x827e18] */
    MEM32(0x7EA570) = 0x00786738u; /* 0x0077B3FD: mov dword ptr [0x7ea570], 0x786738 */
    MEM32(0x7EA578) = 0x00786748u; /* 0x0077B407: mov dword ptr [0x7ea578], 0x786748 */
    MEM32(0x7EA580) = 0x00786760u; /* 0x0077B411: mov dword ptr [0x7ea580], 0x786760 */
    MEM32(0x7EA588) = 0x00786774u; /* 0x0077B41B: mov dword ptr [0x7ea588], 0x786774 */
    MEM32(0x7EA590) = 0x0078678Cu; /* 0x0077B425: mov dword ptr [0x7ea590], 0x78678c */
    MEM32(0x7EA598) = 0x007867A0u; /* 0x0077B42F: mov dword ptr [0x7ea598], 0x7867a0 */
    MEM32(0x7EA5A0) = 0x007867B4u; /* 0x0077B439: mov dword ptr [0x7ea5a0], 0x7867b4 */
    MEM32(0x7EA5A8) = 0x007867CCu; /* 0x0077B443: mov dword ptr [0x7ea5a8], 0x7867cc */
    MEM32(0x7EA5B0) = 0x007867E4u; /* 0x0077B44D: mov dword ptr [0x7ea5b0], 0x7867e4 */
    MEM32(0x7EA5B8) = 0x007867F8u; /* 0x0077B457: mov dword ptr [0x7ea5b8], 0x7867f8 */
    MEM32(0x7EA5C0) = 0x00786810u; /* 0x0077B461: mov dword ptr [0x7ea5c0], 0x786810 */
    MEM32(0x7EA5C8) = 0x00786828u; /* 0x0077B46B: mov dword ptr [0x7ea5c8], 0x786828 */
    MEM32(0x7EA5D0) = 0x00786838u; /* 0x0077B475: mov dword ptr [0x7ea5d0], 0x786838 */
    MEM32(0x7EA5D8) = 0x0078684Cu; /* 0x0077B47F: mov dword ptr [0x7ea5d8], 0x78684c */
    MEM32(0x7EA5E0) = 0x00786860u; /* 0x0077B489: mov dword ptr [0x7ea5e0], 0x786860 */
    MEM32(0x7EA5E8) = 0x00786874u; /* 0x0077B493: mov dword ptr [0x7ea5e8], 0x786874 */
    MEM32(0x7EA5F0) = 0x00786888u; /* 0x0077B49D: mov dword ptr [0x7ea5f0], 0x786888 */
    MEM32(0x7EA5F8) = 0x007868A0u; /* 0x0077B4A7: mov dword ptr [0x7ea5f8], 0x7868a0 */
    MEM32(0x7EA5FC) = eax; /* 0x0077B4B1: mov dword ptr [0x7ea5fc], eax */
    MEM32(0x7EA600) = 0x007868B8u; /* 0x0077B4B6: mov dword ptr [0x7ea600], 0x7868b8 */
    MEM32(0x7EA604) = ecx; /* 0x0077B4C0: mov dword ptr [0x7ea604], ecx */
    MEM32(0x7EA608) = 0x007868D0u; /* 0x0077B4C6: mov dword ptr [0x7ea608], 0x7868d0 */
    MEM32(0x7EA60C) = edx; /* 0x0077B4D0: mov dword ptr [0x7ea60c], edx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B4D6: ret  */

}

void sub_0077B4E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B4E0u);

L_0077B4E0:
    ecx = 0x00827DA4u; /* 0x0077B4E0: mov ecx, 0x827da4 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077B4E5: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781A30u); /* 0x0077B4EA: push 0x781a30 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077B4EF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077B4F4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B4F5: ret  */

}

void sub_0077B500(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B500u);

L_0077B500:
    ecx = 0x00827C74u; /* 0x0077B500: mov ecx, 0x827c74 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077B505: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781A40u); /* 0x0077B50A: push 0x781a40 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077B50F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077B514: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B515: ret  */

}

void sub_0077B520(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B520u);

L_0077B520:
    ecx = 0x00827EF0u; /* 0x0077B520: mov ecx, 0x827ef0 */
    RECOMP_CALL(sub_00439F00); /* 0x0077B525: call 0x439f00 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781A90u); /* 0x0077B52A: push 0x781a90 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077B52F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077B534: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B535: ret  */

}

void sub_0077B540(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B540u);

L_0077B540:
    ecx = 0x00828520u; /* 0x0077B540: mov ecx, 0x828520 */
    RECOMP_CALL(sub_004EC6D0); /* 0x0077B545: call 0x4ec6d0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781AC0u); /* 0x0077B54A: push 0x781ac0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077B54F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077B554: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B555: ret  */

}

void sub_0077B560(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B560u);

L_0077B560:
    eax = MEM32(0x828050); /* 0x0077B560: mov eax, dword ptr [0x828050] */
    MEM32(0x7EB3F4) = eax; /* 0x0077B565: mov dword ptr [0x7eb3f4], eax */
    SET_LO8(eax, MEM8(0x827FE8)); /* 0x0077B56A: mov al, byte ptr [0x827fe8] */
    _flag_a = (uint32_t)(LO8(eax)) << 24; _flag_b = (uint32_t)(1) << 24;
    SET_LO8(eax, LO8(eax) + 1); /* 0x0077B56F: inc al */
    _flag_k = FK_NARROW(FK_INC, 24);
    MEM32(0x828050) = 0x007EB3F4u; /* 0x0077B571: mov dword ptr [0x828050], 0x7eb3f4 */
    MEM8(0x827FE8) = (uint8_t)(LO8(eax)); /* 0x0077B57B: mov byte ptr [0x827fe8], al */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B580: ret  */

}

void sub_0077B590(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B590u);

L_0077B590:
    ecx = 0x00828528u; /* 0x0077B590: mov ecx, 0x828528 */
    RECOMP_CALL(sub_0043E890); /* 0x0077B595: call 0x43e890 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781AB0u); /* 0x0077B59A: push 0x781ab0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077B59F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077B5A4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B5A5: ret  */

}

void sub_0077B5B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B5B0u);

L_0077B5B0:
    ecx = 0x00828530u; /* 0x0077B5B0: mov ecx, 0x828530 */
    RECOMP_CALL(sub_00440800); /* 0x0077B5B5: call 0x440800 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781AD0u); /* 0x0077B5BA: push 0x781ad0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077B5BF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077B5C4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B5C5: ret  */

}

void sub_0077B5D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B5D0u);

L_0077B5D0:
    fp_push(*(float*)&MEM32(0x784250)); /* 0x0077B5D0: fld dword ptr [0x784250] */
    _st[0] /= (double)*(float*)ADDR(0x786F78); /* 0x0077B5D6: fdiv dword ptr [0x786f78] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x828734) = _v; } /* 0x0077B5DC: fstp dword ptr [0x828734] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B5E2: ret  */

}

void sub_0077B5F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B5F0u);

L_0077B5F0:
    eax = MEM32(0x786F8C); /* 0x0077B5F0: mov eax, dword ptr [0x786f8c] */
    edx = MEM32(0x786F84); /* 0x0077B5F5: mov edx, dword ptr [0x786f84] */
    ecx = eax; /* 0x0077B5FB: mov ecx, eax */
    MEM32(0x7EC7C4) = ecx; /* 0x0077B5FD: mov dword ptr [0x7ec7c4], ecx */
    ecx = MEM32(0x786F88); /* 0x0077B603: mov ecx, dword ptr [0x786f88] */
    MEM32(0x7EC7C0) = eax; /* 0x0077B609: mov dword ptr [0x7ec7c0], eax */
    eax = edx; /* 0x0077B60E: mov eax, edx */
    MEM32(0x7EC7F8) = edx; /* 0x0077B610: mov dword ptr [0x7ec7f8], edx */
    edx = ecx; /* 0x0077B616: mov edx, ecx */
    MEM32(0x7EC7FC) = eax; /* 0x0077B618: mov dword ptr [0x7ec7fc], eax */
    MEM32(0x7EC800) = ecx; /* 0x0077B61D: mov dword ptr [0x7ec800], ecx */
    MEM32(0x7EC804) = edx; /* 0x0077B623: mov dword ptr [0x7ec804], edx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B629: ret  */

}

void sub_0077B630(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B630u);

L_0077B630:
    PUSH32(esp, 0x007881E4u); /* 0x0077B630: push 0x7881e4 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B635: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007881E0u); /* 0x0077B63A: push 0x7881e0 */
    MEM32(0x7EC1F8) = eax; /* 0x0077B63F: mov dword ptr [0x7ec1f8], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B644: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007881D4u); /* 0x0077B649: push 0x7881d4 */
    MEM32(0x7EC1FC) = eax; /* 0x0077B64E: mov dword ptr [0x7ec1fc], eax */
    MEM32(0x7EC214) = 0x007881CCu; /* 0x0077B653: mov dword ptr [0x7ec214], 0x7881cc */
    MEM32(0x7EC218) = 0x00441B30u; /* 0x0077B65D: mov dword ptr [0x7ec218], 0x441b30 */
    MEM32(0x7EC21C) = 0x00404810u; /* 0x0077B667: mov dword ptr [0x7ec21c], 0x404810 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B671: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007881CCu); /* 0x0077B676: push 0x7881cc */
    MEM32(0x7EC20C) = eax; /* 0x0077B67B: mov dword ptr [0x7ec20c], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B680: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007881BCu); /* 0x0077B685: push 0x7881bc */
    MEM32(0x7EC210) = eax; /* 0x0077B68A: mov dword ptr [0x7ec210], eax */
    MEM32(0x7EC228) = 0x007881B4u; /* 0x0077B68F: mov dword ptr [0x7ec228], 0x7881b4 */
    MEM32(0x7EC22C) = 0x00441BE0u; /* 0x0077B699: mov dword ptr [0x7ec22c], 0x441be0 */
    MEM32(0x7EC230) = 0x00404810u; /* 0x0077B6A3: mov dword ptr [0x7ec230], 0x404810 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B6AD: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007881B4u); /* 0x0077B6B2: push 0x7881b4 */
    MEM32(0x7EC220) = eax; /* 0x0077B6B7: mov dword ptr [0x7ec220], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B6BC: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007881A4u); /* 0x0077B6C1: push 0x7881a4 */
    MEM32(0x7EC224) = eax; /* 0x0077B6C6: mov dword ptr [0x7ec224], eax */
    MEM32(0x7EC23C) = 0x0078819Cu; /* 0x0077B6CB: mov dword ptr [0x7ec23c], 0x78819c */
    MEM32(0x7EC240) = 0x00441C70u; /* 0x0077B6D5: mov dword ptr [0x7ec240], 0x441c70 */
    MEM32(0x7EC244) = 0x00441CF0u; /* 0x0077B6DF: mov dword ptr [0x7ec244], 0x441cf0 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B6E9: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x0078819Cu); /* 0x0077B6EE: push 0x78819c */
    MEM32(0x7EC234) = eax; /* 0x0077B6F3: mov dword ptr [0x7ec234], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B6F8: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x0078818Cu); /* 0x0077B6FD: push 0x78818c */
    MEM32(0x7EC238) = eax; /* 0x0077B702: mov dword ptr [0x7ec238], eax */
    MEM32(0x7EC250) = 0x00788184u; /* 0x0077B707: mov dword ptr [0x7ec250], 0x788184 */
    MEM32(0x7EC254) = 0x00441D20u; /* 0x0077B711: mov dword ptr [0x7ec254], 0x441d20 */
    MEM32(0x7EC258) = 0x00404810u; /* 0x0077B71B: mov dword ptr [0x7ec258], 0x404810 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B725: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00788184u); /* 0x0077B72A: push 0x788184 */
    MEM32(0x7EC248) = eax; /* 0x0077B72F: mov dword ptr [0x7ec248], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B734: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00788174u); /* 0x0077B739: push 0x788174 */
    MEM32(0x7EC24C) = eax; /* 0x0077B73E: mov dword ptr [0x7ec24c], eax */
    MEM32(0x7EC264) = 0x00788168u; /* 0x0077B743: mov dword ptr [0x7ec264], 0x788168 */
    MEM32(0x7EC268) = 0x00441E80u; /* 0x0077B74D: mov dword ptr [0x7ec268], 0x441e80 */
    MEM32(0x7EC26C) = 0x00441F30u; /* 0x0077B757: mov dword ptr [0x7ec26c], 0x441f30 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B761: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00788168u); /* 0x0077B766: push 0x788168 */
    MEM32(0x7EC25C) = eax; /* 0x0077B76B: mov dword ptr [0x7ec25c], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077B770: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x30u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x30u; /* 0x0077B775: add esp, 0x30 */
    _flag_k = FK_ADD;
    MEM32(0x7EC260) = eax; /* 0x0077B778: mov dword ptr [0x7ec260], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B77D: ret  */

}

void sub_0077B780(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B780u);

L_0077B780:
    eax = MEM32(0x786FBC); /* 0x0077B780: mov eax, dword ptr [0x786fbc] */
    MEM32(0x8286E0) = eax; /* 0x0077B785: mov dword ptr [0x8286e0], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B78A: ret  */

}

void sub_0077B790(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B790u);

L_0077B790:
    fp_push(*(float*)&MEM32(0x786FB4)); /* 0x0077B790: fld dword ptr [0x786fb4] */
    _st[0] -= (double)*(float*)ADDR(0x786FBC); /* 0x0077B796: fsub dword ptr [0x786fbc] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x82A458) = _v; } /* 0x0077B79C: fstp dword ptr [0x82a458] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B7A2: ret  */

}

void sub_0077B7B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B7B0u);

L_0077B7B0:
    fp_push(*(float*)&MEM32(0x786FB8)); /* 0x0077B7B0: fld dword ptr [0x786fb8] */
    _st[0] -= (double)*(float*)ADDR(0x786FBC); /* 0x0077B7B6: fsub dword ptr [0x786fbc] */
    _st[0] -= (double)*(float*)ADDR(0x7881F0); /* 0x0077B7BC: fsub dword ptr [0x7881f0] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x82871C) = _v; } /* 0x0077B7C2: fstp dword ptr [0x82871c] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B7C8: ret  */

}

void sub_0077B7D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B7D0u);

L_0077B7D0:
    fp_push(*(float*)&MEM32(0x786FB8)); /* 0x0077B7D0: fld dword ptr [0x786fb8] */
    _st[0] -= (double)*(float*)ADDR(0x786FBC); /* 0x0077B7D6: fsub dword ptr [0x786fbc] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x828730) = _v; } /* 0x0077B7DC: fstp dword ptr [0x828730] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B7E2: ret  */

}

void sub_0077B7F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B7F0u);

L_0077B7F0:
    fp_push(*(float*)&MEM32(0x786FB8)); /* 0x0077B7F0: fld dword ptr [0x786fb8] */
    _st[0] -= (double)*(float*)ADDR(0x786FBC); /* 0x0077B7F6: fsub dword ptr [0x786fbc] */
    _st[0] += (double)*(float*)ADDR(0x7881F4); /* 0x0077B7FC: fadd dword ptr [0x7881f4] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8286F4) = _v; } /* 0x0077B802: fstp dword ptr [0x8286f4] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B808: ret  */

}

void sub_0077B810(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B810u);

L_0077B810:
    fp_push(*(float*)&MEM32(0x786FB8)); /* 0x0077B810: fld dword ptr [0x786fb8] */
    _st[0] -= (double)*(float*)ADDR(0x786FBC); /* 0x0077B816: fsub dword ptr [0x786fbc] */
    _st[0] += (double)*(float*)ADDR(0x7881F8); /* 0x0077B81C: fadd dword ptr [0x7881f8] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x828710) = _v; } /* 0x0077B822: fstp dword ptr [0x828710] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B828: ret  */

}

void sub_0077B830(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B830u);

L_0077B830:
    fp_push(*(float*)&MEM32(0x82A458)); /* 0x0077B830: fld dword ptr [0x82a458] */
    _st[0] -= (double)*(float*)ADDR(0x786FF0); /* 0x0077B836: fsub dword ptr [0x786ff0] */
    _st[0] -= (double)*(float*)ADDR(0x784560); /* 0x0077B83C: fsub dword ptr [0x784560] */
    _st[0] -= (double)*(float*)ADDR(0x7844C0); /* 0x0077B842: fsub dword ptr [0x7844c0] */
    _st[0] -= (double)*(float*)ADDR(0x7844C0); /* 0x0077B848: fsub dword ptr [0x7844c0] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x82A4E8) = _v; } /* 0x0077B84E: fstp dword ptr [0x82a4e8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B854: ret  */

}

void sub_0077B860(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B860u);

L_0077B860:
    fp_push(*(float*)&MEM32(0x82871C)); /* 0x0077B860: fld dword ptr [0x82871c] */
    _st[0] -= (double)*(float*)ADDR(0x786FC4); /* 0x0077B866: fsub dword ptr [0x786fc4] */
    _st[0] -= (double)*(float*)ADDR(0x786FF0); /* 0x0077B86C: fsub dword ptr [0x786ff0] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x82874C) = _v; } /* 0x0077B872: fstp dword ptr [0x82874c] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B878: ret  */

}

void sub_0077B880(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B880u);

L_0077B880:
    fp_push(*(float*)&MEM32(0x786FF0)); /* 0x0077B880: fld dword ptr [0x786ff0] */
    _st[0] += _st[0]; /* 0x0077B886: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x828750) = _v; } /* 0x0077B888: fstp dword ptr [0x828750] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B88E: ret  */

}

void sub_0077B890(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B890u);

L_0077B890:
    fp_push(*(float*)&MEM32(0x82A4E8)); /* 0x0077B890: fld dword ptr [0x82a4e8] */
    _st[0] -= (double)*(float*)ADDR(0x786FF0); /* 0x0077B896: fsub dword ptr [0x786ff0] */
    _st[0] -= (double)*(float*)ADDR(0x786FF4); /* 0x0077B89C: fsub dword ptr [0x786ff4] */
    _st[0] -= (double)*(float*)ADDR(0x7844C0); /* 0x0077B8A2: fsub dword ptr [0x7844c0] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x82A468) = _v; } /* 0x0077B8A8: fstp dword ptr [0x82a468] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B8AE: ret  */

}

void sub_0077B8B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B8B0u);

L_0077B8B0:
    fp_push(*(float*)&MEM32(0x786FF4)); /* 0x0077B8B0: fld dword ptr [0x786ff4] */
    _st[0] += (double)*(float*)ADDR(0x786FF0); /* 0x0077B8B6: fadd dword ptr [0x786ff0] */
    _st[0] += (double)*(float*)ADDR(0x82A4E8); /* 0x0077B8BC: fadd dword ptr [0x82a4e8] */
    _st[0] += (double)*(float*)ADDR(0x7844C0); /* 0x0077B8C2: fadd dword ptr [0x7844c0] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x82875C) = _v; } /* 0x0077B8C8: fstp dword ptr [0x82875c] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B8CE: ret  */

}

void sub_0077B8D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B8D0u);

L_0077B8D0:
    eax = MEM32(0x82874C); /* 0x0077B8D0: mov eax, dword ptr [0x82874c] */
    MEM32(0x828724) = eax; /* 0x0077B8D5: mov dword ptr [0x828724], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B8DA: ret  */

}

void sub_0077B8E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B8E0u);

L_0077B8E0:
    fp_push(*(float*)&MEM32(0x786FF0)); /* 0x0077B8E0: fld dword ptr [0x786ff0] */
    _st[0] += _st[0]; /* 0x0077B8E6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x82A464) = _v; } /* 0x0077B8E8: fstp dword ptr [0x82a464] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B8EE: ret  */

}

void sub_0077B8F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B8F0u);

L_0077B8F0:
    eax = MEM32(0x82A4E8); /* 0x0077B8F0: mov eax, dword ptr [0x82a4e8] */
    MEM32(0x82A4EC) = eax; /* 0x0077B8F5: mov dword ptr [0x82a4ec], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B8FA: ret  */

}

void sub_0077B900(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B900u);

L_0077B900:
    fp_push(*(float*)&MEM32(0x82874C)); /* 0x0077B900: fld dword ptr [0x82874c] */
    _st[0] -= (double)*(float*)ADDR(0x786FF0); /* 0x0077B906: fsub dword ptr [0x786ff0] */
    _st[0] -= (double)*(float*)ADDR(0x786FF8); /* 0x0077B90C: fsub dword ptr [0x786ff8] */
    _st[0] -= (double)*(float*)ADDR(0x7844C0); /* 0x0077B912: fsub dword ptr [0x7844c0] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x82876C) = _v; } /* 0x0077B918: fstp dword ptr [0x82876c] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B91E: ret  */

}

void sub_0077B920(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B920u);

L_0077B920:
    fp_push(*(float*)&MEM32(0x786FC4)); /* 0x0077B920: fld dword ptr [0x786fc4] */
    RECOMP_CALL(sub_0075BE10); /* 0x0077B926: call 0x75be10 */
    RECOMP_FLAGS_IN();
    MEM32(0x82A47C) = eax; /* 0x0077B92B: mov dword ptr [0x82a47c], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B930: ret  */

}

void sub_0077B940(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B940u);

L_0077B940:
    fp_push(*(float*)&MEM32(0x82871C)); /* 0x0077B940: fld dword ptr [0x82871c] */
    _st[0] -= (double)*(float*)ADDR(0x786FC4); /* 0x0077B946: fsub dword ptr [0x786fc4] */
    _st[0] -= (double)*(float*)ADDR(0x7881F4); /* 0x0077B94C: fsub dword ptr [0x7881f4] */
    fp_push(*(float*)&MEM32(0x786FB8)); /* 0x0077B952: fld dword ptr [0x786fb8] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x0077B958: fmul dword ptr [0x784260] */
    { double _v = fp_pop(); _st[0] -= _v; } /* 0x0077B95E: fsubp st(1) */
    RECOMP_CALL(sub_0075BE10); /* 0x0077B960: call 0x75be10 */
    RECOMP_FLAGS_IN();
    MEM32(0x82873C) = eax; /* 0x0077B965: mov dword ptr [0x82873c], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B96A: ret  */

}

void sub_0077B970(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B970u);

L_0077B970:
    fp_push(*(float*)&MEM32(0x8286E0)); /* 0x0077B970: fld dword ptr [0x8286e0] */
    _st[0] -= (double)*(float*)ADDR(0x7844C0); /* 0x0077B976: fsub dword ptr [0x7844c0] */
    fp_push(*(float*)&MEM32(0x786FB4)); /* 0x0077B97C: fld dword ptr [0x786fb4] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x0077B982: fmul dword ptr [0x784260] */
    { double _v = fp_pop(); _st[0] -= _v; } /* 0x0077B988: fsubp st(1) */
    RECOMP_CALL(sub_0075BE10); /* 0x0077B98A: call 0x75be10 */
    RECOMP_FLAGS_IN();
    MEM32(0x828718) = eax; /* 0x0077B98F: mov dword ptr [0x828718], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B994: ret  */

}