/* AUTO-GENERATED from SPEED2.analysis.exe by run_lift.py (pcrecomp lift32). DO NOT EDIT, DO NOT COMMIT. */
#define RECOMP_GENERATED_CODE
#include "recomp_types.h"
#include "recomp_funcs.h"
#include "guest_render_probe.h"
#include <math.h>
#include <string.h>

void sub_00774981(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774981u);

    goto L_00774981;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774981:
    eax = 0x007E0720u; /* 0x00774981: mov eax, 0x7e0720 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774986: jmp 0x75bf0e */

}

void sub_00774990(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774990u);

L_00774990:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774990: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00774993: jmp 0x553a80 */

}

void sub_00774998(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774998u);

L_00774998:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774998: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4Cu; /* 0x0077499B: add ecx, 0x4c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004CBAA0u); RECOMP_RETURN(); /* 0x0077499E: jmp 0x4cbaa0 */

}

void sub_007749A3(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007749A3u);

L_007749A3:
    ecx = MEM32(ebp + (-0x10)); /* 0x007749A3: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x908u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x908u; /* 0x007749A6: add ecx, 0x908 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x007749AC: jmp 0x5cde60 */

}

void sub_007749B1(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007749B1u);

    goto L_007749B1;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007749B1:
    eax = 0x007E22E4u; /* 0x007749B1: mov eax, 0x7e22e4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007749B6: jmp 0x75bf0e */

}

void sub_007749C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007749C0u);

L_007749C0:
    PUSH32(esp, 0); /* 0x007749C0: push 0 */
    PUSH32(esp, 0x00796430u); /* 0x007749C2: push 0x796430 */
    eax = MEM32(ebp + (-0x10)); /* 0x007749C7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007749CA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007749CB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007749D0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007749D3: ret  */

}

void sub_007749D4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007749D4u);

    goto L_007749D4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007749D4:
    eax = 0x007E0744u; /* 0x007749D4: mov eax, 0x7e0744 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007749D9: jmp 0x75bf0e */

}

void sub_007749E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007749E0u);

L_007749E0:
    ecx = MEM32(ebp + (-0x30)); /* 0x007749E0: mov ecx, dword ptr [ebp - 0x30] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x007749E3: jmp 0x553a80 */

}

void sub_007749E8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007749E8u);

L_007749E8:
    ecx = MEM32(ebp + (-0x30)); /* 0x007749E8: mov ecx, dword ptr [ebp - 0x30] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4Cu; /* 0x007749EB: add ecx, 0x4c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004CBAA0u); RECOMP_RETURN(); /* 0x007749EE: jmp 0x4cbaa0 */

}

void sub_007749F3(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007749F3u);

    goto L_007749F3;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007749F3:
    eax = 0x007E0770u; /* 0x007749F3: mov eax, 0x7e0770 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007749F8: jmp 0x75bf0e */

}

void sub_00774A00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774A00u);

L_00774A00:
    PUSH32(esp, 0); /* 0x00774A00: push 0 */
    PUSH32(esp, 0x00796490u); /* 0x00774A02: push 0x796490 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774A07: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774A0A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774A0B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774A10: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774A13: ret  */

}

void sub_00774A14(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774A14u);

    goto L_00774A14;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774A14:
    eax = 0x007E0794u; /* 0x00774A14: mov eax, 0x7e0794 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774A19: jmp 0x75bf0e */

}

void sub_00774A20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774A20u);

L_00774A20:
    PUSH32(esp, 0); /* 0x00774A20: push 0 */
    PUSH32(esp, 0x007964B8u); /* 0x00774A22: push 0x7964b8 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774A27: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774A2A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774A2B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774A30: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774A33: ret  */

}

void sub_00774A34(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774A34u);

    goto L_00774A34;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774A34:
    eax = 0x007E07B8u; /* 0x00774A34: mov eax, 0x7e07b8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774A39: jmp 0x75bf0e */

}

void sub_00774A40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774A40u);

L_00774A40:
    PUSH32(esp, 0); /* 0x00774A40: push 0 */
    PUSH32(esp, 0x007964D0u); /* 0x00774A42: push 0x7964d0 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774A47: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774A4A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774A4B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774A50: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774A53: ret  */

}

void sub_00774A54(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774A54u);

    goto L_00774A54;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774A54:
    eax = 0x007E07DCu; /* 0x00774A54: mov eax, 0x7e07dc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774A59: jmp 0x75bf0e */

}

void sub_00774A60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774A60u);

L_00774A60:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774A60: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00774A63: jmp 0x553a80 */

}

void sub_00774A68(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774A68u);

L_00774A68:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774A68: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4Cu; /* 0x00774A6B: add ecx, 0x4c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00479130u); RECOMP_RETURN(); /* 0x00774A6E: jmp 0x479130 */

}

void sub_00774A73(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774A73u);

L_00774A73:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774A73: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x64u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x64u; /* 0x00774A76: add ecx, 0x64 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0052E930u); RECOMP_RETURN(); /* 0x00774A79: jmp 0x52e930 */

}

void sub_00774A7E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774A7Eu);

    goto L_00774A7E;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774A7E:
    eax = 0x007E0810u; /* 0x00774A7E: mov eax, 0x7e0810 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774A83: jmp 0x75bf0e */

}

void sub_00774A90(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774A90u);

L_00774A90:
    PUSH32(esp, 0x00796518u); /* 0x00774A90: push 0x796518 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774A95: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774A98: push eax */
    RECOMP_CALL(sub_004022D0); /* 0x00774A99: call 0x4022d0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(8);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 8; /* 0x00774A9E: add esp, 8 */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774AA1: ret  */

}

void sub_00774AA2(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774AA2u);

    goto L_00774AA2;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774AA2:
    eax = 0x007E0834u; /* 0x00774AA2: mov eax, 0x7e0834 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774AA7: jmp 0x75bf0e */

}

void sub_00774AB0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774AB0u);

L_00774AB0:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774AB0: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 4; /* 0x00774AB3: add ecx, 4 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00490340u); RECOMP_RETURN(); /* 0x00774AB6: jmp 0x490340 */

}

void sub_00774ABB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774ABBu);

    goto L_00774ABB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774ABB:
    eax = 0x007E0858u; /* 0x00774ABB: mov eax, 0x7e0858 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774AC0: jmp 0x75bf0e */

}

void sub_00774AD0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774AD0u);

L_00774AD0:
    PUSH32(esp, 0); /* 0x00774AD0: push 0 */
    PUSH32(esp, 0x00796528u); /* 0x00774AD2: push 0x796528 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774AD7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774ADA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774ADB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774AE0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774AE3: ret  */

}

void sub_00774AE4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774AE4u);

    goto L_00774AE4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774AE4:
    eax = 0x007E087Cu; /* 0x00774AE4: mov eax, 0x7e087c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774AE9: jmp 0x75bf0e */

}

void sub_00774AF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774AF0u);

L_00774AF0:
    PUSH32(esp, 0); /* 0x00774AF0: push 0 */
    PUSH32(esp, 0x00796538u); /* 0x00774AF2: push 0x796538 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774AF7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774AFA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774AFB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774B00: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774B03: ret  */

}

void sub_00774B04(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774B04u);

    goto L_00774B04;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774B04:
    eax = 0x007E08A0u; /* 0x00774B04: mov eax, 0x7e08a0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774B09: jmp 0x75bf0e */

}

void sub_00774B10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774B10u);

L_00774B10:
    PUSH32(esp, 0); /* 0x00774B10: push 0 */
    PUSH32(esp, 0x00796590u); /* 0x00774B12: push 0x796590 */
    eax = MEM32(ebp + (-0x24)); /* 0x00774B17: mov eax, dword ptr [ebp - 0x24] */
    PUSH32(esp, eax); /* 0x00774B1A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774B1B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774B20: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774B23: ret  */

}

void sub_00774B24(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774B24u);

L_00774B24:
    PUSH32(esp, 0); /* 0x00774B24: push 0 */
    PUSH32(esp, 0x00796590u); /* 0x00774B26: push 0x796590 */
    eax = MEM32(ebp + (-0x24)); /* 0x00774B2B: mov eax, dword ptr [ebp - 0x24] */
    PUSH32(esp, eax); /* 0x00774B2E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774B2F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774B34: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774B37: ret  */

}

void sub_00774B38(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774B38u);

    goto L_00774B38;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774B38:
    eax = 0x007E08CCu; /* 0x00774B38: mov eax, 0x7e08cc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774B3D: jmp 0x75bf0e */

}

void sub_00774B50(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774B50u);

L_00774B50:
    PUSH32(esp, 0); /* 0x00774B50: push 0 */
    PUSH32(esp, 0x00796A20u); /* 0x00774B52: push 0x796a20 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774B57: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774B5A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774B5B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774B60: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774B63: ret  */

}

void sub_00774B64(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774B64u);

L_00774B64:
    PUSH32(esp, 0); /* 0x00774B64: push 0 */
    PUSH32(esp, 0x00796A08u); /* 0x00774B66: push 0x796a08 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774B6B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774B6E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774B6F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774B74: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774B77: ret  */

}

void sub_00774B78(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774B78u);

L_00774B78:
    PUSH32(esp, 0); /* 0x00774B78: push 0 */
    PUSH32(esp, 0x007969F4u); /* 0x00774B7A: push 0x7969f4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774B7F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774B82: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774B83: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774B88: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774B8B: ret  */

}

void sub_00774B8C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774B8Cu);

L_00774B8C:
    PUSH32(esp, 0); /* 0x00774B8C: push 0 */
    PUSH32(esp, 0x007969DCu); /* 0x00774B8E: push 0x7969dc */
    eax = MEM32(ebp + (-0x10)); /* 0x00774B93: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774B96: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774B97: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774B9C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774B9F: ret  */

}

void sub_00774BA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774BA0u);

L_00774BA0:
    PUSH32(esp, 0); /* 0x00774BA0: push 0 */
    PUSH32(esp, 0x007969C4u); /* 0x00774BA2: push 0x7969c4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774BA7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774BAA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774BAB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774BB0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774BB3: ret  */

}

void sub_00774BB4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774BB4u);

L_00774BB4:
    PUSH32(esp, 0); /* 0x00774BB4: push 0 */
    PUSH32(esp, 0x007969B0u); /* 0x00774BB6: push 0x7969b0 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774BBB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774BBE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774BBF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774BC4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774BC7: ret  */

}

void sub_00774BC8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774BC8u);

L_00774BC8:
    PUSH32(esp, 0); /* 0x00774BC8: push 0 */
    PUSH32(esp, 0x00796998u); /* 0x00774BCA: push 0x796998 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774BCF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774BD2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774BD3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774BD8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774BDB: ret  */

}

void sub_00774BDC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774BDCu);

L_00774BDC:
    PUSH32(esp, 0); /* 0x00774BDC: push 0 */
    PUSH32(esp, 0x00796984u); /* 0x00774BDE: push 0x796984 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774BE3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774BE6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774BE7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774BEC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774BEF: ret  */

}

void sub_00774BF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774BF0u);

L_00774BF0:
    PUSH32(esp, 0); /* 0x00774BF0: push 0 */
    PUSH32(esp, 0x00796970u); /* 0x00774BF2: push 0x796970 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774BF7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774BFA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774BFB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774C00: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774C03: ret  */

}

void sub_00774C04(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774C04u);

L_00774C04:
    PUSH32(esp, 0); /* 0x00774C04: push 0 */
    PUSH32(esp, 0x0079695Cu); /* 0x00774C06: push 0x79695c */
    eax = MEM32(ebp + (-0x10)); /* 0x00774C0B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774C0E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774C0F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774C14: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774C17: ret  */

}

void sub_00774C18(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774C18u);

L_00774C18:
    PUSH32(esp, 0); /* 0x00774C18: push 0 */
    PUSH32(esp, 0x0079694Cu); /* 0x00774C1A: push 0x79694c */
    eax = MEM32(ebp + (-0x10)); /* 0x00774C1F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774C22: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774C23: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774C28: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774C2B: ret  */

}

void sub_00774C2C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774C2Cu);

L_00774C2C:
    PUSH32(esp, 0); /* 0x00774C2C: push 0 */
    PUSH32(esp, 0x0079693Cu); /* 0x00774C2E: push 0x79693c */
    eax = MEM32(ebp + (-0x10)); /* 0x00774C33: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774C36: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774C37: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774C3C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774C3F: ret  */

}

void sub_00774C40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774C40u);

L_00774C40:
    PUSH32(esp, 0); /* 0x00774C40: push 0 */
    PUSH32(esp, 0x00796924u); /* 0x00774C42: push 0x796924 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774C47: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774C4A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774C4B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774C50: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774C53: ret  */

}

void sub_00774C54(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774C54u);

L_00774C54:
    PUSH32(esp, 0); /* 0x00774C54: push 0 */
    PUSH32(esp, 0x00796910u); /* 0x00774C56: push 0x796910 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774C5B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774C5E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774C5F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774C64: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774C67: ret  */

}

void sub_00774C68(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774C68u);

L_00774C68:
    PUSH32(esp, 0); /* 0x00774C68: push 0 */
    PUSH32(esp, 0x007968FCu); /* 0x00774C6A: push 0x7968fc */
    eax = MEM32(ebp + (-0x10)); /* 0x00774C6F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774C72: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774C73: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774C78: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774C7B: ret  */

}

void sub_00774C7C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774C7Cu);

L_00774C7C:
    PUSH32(esp, 0); /* 0x00774C7C: push 0 */
    PUSH32(esp, 0x007968E4u); /* 0x00774C7E: push 0x7968e4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774C83: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774C86: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774C87: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774C8C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774C8F: ret  */

}

void sub_00774C90(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774C90u);

L_00774C90:
    PUSH32(esp, 0); /* 0x00774C90: push 0 */
    PUSH32(esp, 0x007968CCu); /* 0x00774C92: push 0x7968cc */
    eax = MEM32(ebp + (-0x10)); /* 0x00774C97: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774C9A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774C9B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774CA0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774CA3: ret  */

}

void sub_00774CA4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774CA4u);

L_00774CA4:
    PUSH32(esp, 0); /* 0x00774CA4: push 0 */
    PUSH32(esp, 0x007968B8u); /* 0x00774CA6: push 0x7968b8 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774CAB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774CAE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774CAF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774CB4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774CB7: ret  */

}

void sub_00774CB8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774CB8u);

L_00774CB8:
    PUSH32(esp, 0); /* 0x00774CB8: push 0 */
    PUSH32(esp, 0x007968A4u); /* 0x00774CBA: push 0x7968a4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774CBF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774CC2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774CC3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774CC8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774CCB: ret  */

}

void sub_00774CCC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774CCCu);

L_00774CCC:
    PUSH32(esp, 0); /* 0x00774CCC: push 0 */
    PUSH32(esp, 0x00796890u); /* 0x00774CCE: push 0x796890 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774CD3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774CD6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774CD7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774CDC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774CDF: ret  */

}

void sub_00774CE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774CE0u);

L_00774CE0:
    PUSH32(esp, 0); /* 0x00774CE0: push 0 */
    PUSH32(esp, 0x00796880u); /* 0x00774CE2: push 0x796880 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774CE7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774CEA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774CEB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774CF0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774CF3: ret  */

}

void sub_00774CF4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774CF4u);

L_00774CF4:
    PUSH32(esp, 0); /* 0x00774CF4: push 0 */
    PUSH32(esp, 0x0079686Cu); /* 0x00774CF6: push 0x79686c */
    eax = MEM32(ebp + (-0x10)); /* 0x00774CFB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774CFE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774CFF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774D04: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774D07: ret  */

}

void sub_00774D08(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774D08u);

L_00774D08:
    PUSH32(esp, 0); /* 0x00774D08: push 0 */
    PUSH32(esp, 0x0079685Cu); /* 0x00774D0A: push 0x79685c */
    eax = MEM32(ebp + (-0x10)); /* 0x00774D0F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774D12: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774D13: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774D18: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774D1B: ret  */

}

void sub_00774D1C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774D1Cu);

L_00774D1C:
    PUSH32(esp, 0); /* 0x00774D1C: push 0 */
    PUSH32(esp, 0x0079684Cu); /* 0x00774D1E: push 0x79684c */
    eax = MEM32(ebp + (-0x10)); /* 0x00774D23: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774D26: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774D27: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774D2C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774D2F: ret  */

}

void sub_00774D30(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774D30u);

L_00774D30:
    PUSH32(esp, 0); /* 0x00774D30: push 0 */
    PUSH32(esp, 0x00796838u); /* 0x00774D32: push 0x796838 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774D37: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774D3A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774D3B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774D40: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774D43: ret  */

}

void sub_00774D44(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774D44u);

L_00774D44:
    PUSH32(esp, 0); /* 0x00774D44: push 0 */
    PUSH32(esp, 0x00796824u); /* 0x00774D46: push 0x796824 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774D4B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774D4E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774D4F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774D54: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774D57: ret  */

}

void sub_00774D58(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774D58u);

L_00774D58:
    PUSH32(esp, 0); /* 0x00774D58: push 0 */
    PUSH32(esp, 0x00796814u); /* 0x00774D5A: push 0x796814 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774D5F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774D62: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774D63: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774D68: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774D6B: ret  */

}

void sub_00774D6C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774D6Cu);

L_00774D6C:
    PUSH32(esp, 0); /* 0x00774D6C: push 0 */
    PUSH32(esp, 0x007967FCu); /* 0x00774D6E: push 0x7967fc */
    eax = MEM32(ebp + (-0x10)); /* 0x00774D73: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774D76: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774D77: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774D7C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774D7F: ret  */

}

void sub_00774D80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774D80u);

L_00774D80:
    PUSH32(esp, 0); /* 0x00774D80: push 0 */
    PUSH32(esp, 0x007967E8u); /* 0x00774D82: push 0x7967e8 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774D87: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774D8A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774D8B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774D90: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774D93: ret  */

}

void sub_00774D94(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774D94u);

L_00774D94:
    PUSH32(esp, 0); /* 0x00774D94: push 0 */
    PUSH32(esp, 0x007967D4u); /* 0x00774D96: push 0x7967d4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774D9B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774D9E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774D9F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774DA4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774DA7: ret  */

}

void sub_00774DA8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774DA8u);

L_00774DA8:
    PUSH32(esp, 0); /* 0x00774DA8: push 0 */
    PUSH32(esp, 0x007967C0u); /* 0x00774DAA: push 0x7967c0 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774DAF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774DB2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774DB3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774DB8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774DBB: ret  */

}

void sub_00774DBC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774DBCu);

L_00774DBC:
    PUSH32(esp, 0); /* 0x00774DBC: push 0 */
    PUSH32(esp, 0x007967ACu); /* 0x00774DBE: push 0x7967ac */
    eax = MEM32(ebp + (-0x10)); /* 0x00774DC3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774DC6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774DC7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774DCC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774DCF: ret  */

}

void sub_00774DD0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774DD0u);

L_00774DD0:
    PUSH32(esp, 0); /* 0x00774DD0: push 0 */
    PUSH32(esp, 0x0079679Cu); /* 0x00774DD2: push 0x79679c */
    eax = MEM32(ebp + (-0x10)); /* 0x00774DD7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774DDA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774DDB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774DE0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774DE3: ret  */

}

void sub_00774DE4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774DE4u);

L_00774DE4:
    PUSH32(esp, 0); /* 0x00774DE4: push 0 */
    PUSH32(esp, 0x00796784u); /* 0x00774DE6: push 0x796784 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774DEB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774DEE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774DEF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774DF4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774DF7: ret  */

}

void sub_00774DF8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774DF8u);

L_00774DF8:
    PUSH32(esp, 0); /* 0x00774DF8: push 0 */
    PUSH32(esp, 0x00796770u); /* 0x00774DFA: push 0x796770 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774DFF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774E02: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774E03: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774E08: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774E0B: ret  */

}

void sub_00774E0C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774E0Cu);

L_00774E0C:
    PUSH32(esp, 0); /* 0x00774E0C: push 0 */
    PUSH32(esp, 0x0079675Cu); /* 0x00774E0E: push 0x79675c */
    eax = MEM32(ebp + (-0x10)); /* 0x00774E13: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774E16: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774E17: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774E1C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774E1F: ret  */

}

void sub_00774E20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774E20u);

L_00774E20:
    PUSH32(esp, 0); /* 0x00774E20: push 0 */
    PUSH32(esp, 0x00796744u); /* 0x00774E22: push 0x796744 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774E27: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774E2A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774E2B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774E30: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774E33: ret  */

}

void sub_00774E34(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774E34u);

L_00774E34:
    PUSH32(esp, 0); /* 0x00774E34: push 0 */
    PUSH32(esp, 0x00796730u); /* 0x00774E36: push 0x796730 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774E3B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774E3E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774E3F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774E44: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774E47: ret  */

}

void sub_00774E48(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774E48u);

L_00774E48:
    PUSH32(esp, 0); /* 0x00774E48: push 0 */
    PUSH32(esp, 0x0079671Cu); /* 0x00774E4A: push 0x79671c */
    eax = MEM32(ebp + (-0x10)); /* 0x00774E4F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774E52: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774E53: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774E58: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774E5B: ret  */

}

void sub_00774E5C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774E5Cu);

L_00774E5C:
    PUSH32(esp, 0); /* 0x00774E5C: push 0 */
    PUSH32(esp, 0x00796700u); /* 0x00774E5E: push 0x796700 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774E63: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774E66: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774E67: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774E6C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774E6F: ret  */

}

void sub_00774E70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774E70u);

L_00774E70:
    PUSH32(esp, 0); /* 0x00774E70: push 0 */
    PUSH32(esp, 0x007966E8u); /* 0x00774E72: push 0x7966e8 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774E77: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774E7A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774E7B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774E80: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774E83: ret  */

}

void sub_00774E84(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774E84u);

L_00774E84:
    PUSH32(esp, 0); /* 0x00774E84: push 0 */
    PUSH32(esp, 0x007966D0u); /* 0x00774E86: push 0x7966d0 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774E8B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774E8E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774E8F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774E94: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774E97: ret  */

}

void sub_00774E98(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774E98u);

L_00774E98:
    PUSH32(esp, 0); /* 0x00774E98: push 0 */
    PUSH32(esp, 0x007966BCu); /* 0x00774E9A: push 0x7966bc */
    eax = MEM32(ebp + (-0x10)); /* 0x00774E9F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774EA2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774EA3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774EA8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774EAB: ret  */

}

void sub_00774EAC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774EACu);

L_00774EAC:
    PUSH32(esp, 0); /* 0x00774EAC: push 0 */
    PUSH32(esp, 0x007966A8u); /* 0x00774EAE: push 0x7966a8 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774EB3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774EB6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774EB7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774EBC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774EBF: ret  */

}

void sub_00774EC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774EC0u);

L_00774EC0:
    PUSH32(esp, 0); /* 0x00774EC0: push 0 */
    PUSH32(esp, 0x00796698u); /* 0x00774EC2: push 0x796698 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774EC7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774ECA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774ECB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774ED0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774ED3: ret  */

}

void sub_00774ED4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774ED4u);

L_00774ED4:
    PUSH32(esp, 0); /* 0x00774ED4: push 0 */
    PUSH32(esp, 0x00796674u); /* 0x00774ED6: push 0x796674 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774EDB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774EDE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774EDF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774EE4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774EE7: ret  */

}

void sub_00774EE8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774EE8u);

L_00774EE8:
    PUSH32(esp, 0); /* 0x00774EE8: push 0 */
    PUSH32(esp, 0x00796654u); /* 0x00774EEA: push 0x796654 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774EEF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774EF2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774EF3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774EF8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774EFB: ret  */

}

void sub_00774EFC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774EFCu);

L_00774EFC:
    PUSH32(esp, 0); /* 0x00774EFC: push 0 */
    PUSH32(esp, 0x00796634u); /* 0x00774EFE: push 0x796634 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774F03: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774F06: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774F07: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774F0C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774F0F: ret  */

}

void sub_00774F10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774F10u);

L_00774F10:
    PUSH32(esp, 0); /* 0x00774F10: push 0 */
    PUSH32(esp, 0x00796614u); /* 0x00774F12: push 0x796614 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774F17: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774F1A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774F1B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774F20: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774F23: ret  */

}

void sub_00774F24(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774F24u);

L_00774F24:
    PUSH32(esp, 0); /* 0x00774F24: push 0 */
    PUSH32(esp, 0x007965F8u); /* 0x00774F26: push 0x7965f8 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774F2B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774F2E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774F2F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774F34: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774F37: ret  */

}

void sub_00774F38(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774F38u);

L_00774F38:
    PUSH32(esp, 0); /* 0x00774F38: push 0 */
    PUSH32(esp, 0x007965DCu); /* 0x00774F3A: push 0x7965dc */
    eax = MEM32(ebp + (-0x10)); /* 0x00774F3F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774F42: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774F43: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774F48: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774F4B: ret  */

}

void sub_00774F4C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774F4Cu);

L_00774F4C:
    PUSH32(esp, 0); /* 0x00774F4C: push 0 */
    PUSH32(esp, 0x007965C8u); /* 0x00774F4E: push 0x7965c8 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774F53: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774F56: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774F57: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774F5C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774F5F: ret  */

}

void sub_00774F60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774F60u);

L_00774F60:
    PUSH32(esp, 0); /* 0x00774F60: push 0 */
    PUSH32(esp, 0x007965B4u); /* 0x00774F62: push 0x7965b4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774F67: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774F6A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774F6B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774F70: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774F73: ret  */

}

void sub_00774F74(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774F74u);

L_00774F74:
    PUSH32(esp, 0); /* 0x00774F74: push 0 */
    PUSH32(esp, 0x007965A4u); /* 0x00774F76: push 0x7965a4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774F7B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774F7E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774F7F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774F84: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774F87: ret  */

}

void sub_00774F88(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774F88u);

    goto L_00774F88;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774F88:
    eax = 0x007E0A98u; /* 0x00774F88: mov eax, 0x7e0a98 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774F8D: jmp 0x75bf0e */

}

void sub_00774FA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774FA0u);

L_00774FA0:
    PUSH32(esp, 0); /* 0x00774FA0: push 0 */
    PUSH32(esp, 0x00796FD4u); /* 0x00774FA2: push 0x796fd4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774FA7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774FAA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774FAB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774FB0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774FB3: ret  */

}

void sub_00774FB4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774FB4u);

L_00774FB4:
    PUSH32(esp, 0); /* 0x00774FB4: push 0 */
    PUSH32(esp, 0x00796FB8u); /* 0x00774FB6: push 0x796fb8 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774FBB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774FBE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774FBF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774FC4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774FC7: ret  */

}

void sub_00774FC8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774FC8u);

L_00774FC8:
    PUSH32(esp, 0); /* 0x00774FC8: push 0 */
    PUSH32(esp, 0x00796F9Cu); /* 0x00774FCA: push 0x796f9c */
    eax = MEM32(ebp + (-0x10)); /* 0x00774FCF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774FD2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774FD3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774FD8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774FDB: ret  */

}

void sub_00774FDC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774FDCu);

L_00774FDC:
    PUSH32(esp, 0); /* 0x00774FDC: push 0 */
    PUSH32(esp, 0x00796F7Cu); /* 0x00774FDE: push 0x796f7c */
    eax = MEM32(ebp + (-0x10)); /* 0x00774FE3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774FE6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774FE7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774FEC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774FEF: ret  */

}

void sub_00774FF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774FF0u);

L_00774FF0:
    PUSH32(esp, 0); /* 0x00774FF0: push 0 */
    PUSH32(esp, 0x00796F60u); /* 0x00774FF2: push 0x796f60 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774FF7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774FFA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774FFB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775000: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775003: ret  */

}

void sub_00775004(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775004u);

L_00775004:
    PUSH32(esp, 0); /* 0x00775004: push 0 */
    PUSH32(esp, 0x00796F44u); /* 0x00775006: push 0x796f44 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077500B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077500E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077500F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775014: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775017: ret  */

}

void sub_00775018(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775018u);

L_00775018:
    PUSH32(esp, 0); /* 0x00775018: push 0 */
    PUSH32(esp, 0x00796F28u); /* 0x0077501A: push 0x796f28 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077501F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775022: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775023: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775028: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077502B: ret  */

}

void sub_0077502C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077502Cu);

L_0077502C:
    PUSH32(esp, 0); /* 0x0077502C: push 0 */
    PUSH32(esp, 0x00796F0Cu); /* 0x0077502E: push 0x796f0c */
    eax = MEM32(ebp + (-0x10)); /* 0x00775033: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775036: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775037: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077503C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077503F: ret  */

}

void sub_00775040(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775040u);

L_00775040:
    PUSH32(esp, 0); /* 0x00775040: push 0 */
    PUSH32(esp, 0x00796EF4u); /* 0x00775042: push 0x796ef4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775047: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077504A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077504B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775050: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775053: ret  */

}

void sub_00775054(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775054u);

L_00775054:
    PUSH32(esp, 0); /* 0x00775054: push 0 */
    PUSH32(esp, 0x00796EDCu); /* 0x00775056: push 0x796edc */
    eax = MEM32(ebp + (-0x10)); /* 0x0077505B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077505E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077505F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775064: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775067: ret  */

}

void sub_00775068(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775068u);

L_00775068:
    PUSH32(esp, 0); /* 0x00775068: push 0 */
    PUSH32(esp, 0x00796EC4u); /* 0x0077506A: push 0x796ec4 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077506F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775072: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775073: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775078: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077507B: ret  */

}

void sub_0077507C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077507Cu);

L_0077507C:
    PUSH32(esp, 0); /* 0x0077507C: push 0 */
    PUSH32(esp, 0x00796EB0u); /* 0x0077507E: push 0x796eb0 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775083: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775086: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775087: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077508C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077508F: ret  */

}

void sub_00775090(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775090u);

L_00775090:
    PUSH32(esp, 0); /* 0x00775090: push 0 */
    PUSH32(esp, 0x00796E94u); /* 0x00775092: push 0x796e94 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775097: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077509A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077509B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007750A0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007750A3: ret  */

}

void sub_007750A4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007750A4u);

L_007750A4:
    PUSH32(esp, 0); /* 0x007750A4: push 0 */
    PUSH32(esp, 0x00796E78u); /* 0x007750A6: push 0x796e78 */
    eax = MEM32(ebp + (-0x10)); /* 0x007750AB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007750AE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007750AF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007750B4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007750B7: ret  */

}

void sub_007750B8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007750B8u);

L_007750B8:
    PUSH32(esp, 0); /* 0x007750B8: push 0 */
    PUSH32(esp, 0x00796E60u); /* 0x007750BA: push 0x796e60 */
    eax = MEM32(ebp + (-0x10)); /* 0x007750BF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007750C2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007750C3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007750C8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007750CB: ret  */

}

void sub_007750CC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007750CCu);

L_007750CC:
    PUSH32(esp, 0); /* 0x007750CC: push 0 */
    PUSH32(esp, 0x00796E40u); /* 0x007750CE: push 0x796e40 */
    eax = MEM32(ebp + (-0x10)); /* 0x007750D3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007750D6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007750D7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007750DC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007750DF: ret  */

}

void sub_007750E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007750E0u);

L_007750E0:
    PUSH32(esp, 0); /* 0x007750E0: push 0 */
    PUSH32(esp, 0x00796E24u); /* 0x007750E2: push 0x796e24 */
    eax = MEM32(ebp + (-0x10)); /* 0x007750E7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007750EA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007750EB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007750F0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007750F3: ret  */

}

void sub_007750F4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007750F4u);

L_007750F4:
    PUSH32(esp, 0); /* 0x007750F4: push 0 */
    PUSH32(esp, 0x00796E08u); /* 0x007750F6: push 0x796e08 */
    eax = MEM32(ebp + (-0x10)); /* 0x007750FB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007750FE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007750FF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775104: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775107: ret  */

}

void sub_00775108(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775108u);

L_00775108:
    PUSH32(esp, 0); /* 0x00775108: push 0 */
    PUSH32(esp, 0x00796DECu); /* 0x0077510A: push 0x796dec */
    eax = MEM32(ebp + (-0x10)); /* 0x0077510F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775112: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775113: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775118: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077511B: ret  */

}

void sub_0077511C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077511Cu);

L_0077511C:
    PUSH32(esp, 0); /* 0x0077511C: push 0 */
    PUSH32(esp, 0x00796DD4u); /* 0x0077511E: push 0x796dd4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775123: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775126: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775127: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077512C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077512F: ret  */

}

void sub_00775130(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775130u);

L_00775130:
    PUSH32(esp, 0); /* 0x00775130: push 0 */
    PUSH32(esp, 0x00796DBCu); /* 0x00775132: push 0x796dbc */
    eax = MEM32(ebp + (-0x10)); /* 0x00775137: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077513A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077513B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775140: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775143: ret  */

}

void sub_00775144(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775144u);

L_00775144:
    PUSH32(esp, 0); /* 0x00775144: push 0 */
    PUSH32(esp, 0x00796DA4u); /* 0x00775146: push 0x796da4 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077514B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077514E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077514F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775154: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775157: ret  */

}

void sub_00775158(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775158u);

L_00775158:
    PUSH32(esp, 0); /* 0x00775158: push 0 */
    PUSH32(esp, 0x00796D8Cu); /* 0x0077515A: push 0x796d8c */
    eax = MEM32(ebp + (-0x10)); /* 0x0077515F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775162: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775163: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775168: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077516B: ret  */

}

void sub_0077516C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077516Cu);

L_0077516C:
    PUSH32(esp, 0); /* 0x0077516C: push 0 */
    PUSH32(esp, 0x00796D78u); /* 0x0077516E: push 0x796d78 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775173: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775176: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775177: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077517C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077517F: ret  */

}

void sub_00775180(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775180u);

L_00775180:
    PUSH32(esp, 0); /* 0x00775180: push 0 */
    PUSH32(esp, 0x00796D5Cu); /* 0x00775182: push 0x796d5c */
    eax = MEM32(ebp + (-0x10)); /* 0x00775187: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077518A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077518B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775190: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775193: ret  */

}

void sub_00775194(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775194u);

L_00775194:
    PUSH32(esp, 0); /* 0x00775194: push 0 */
    PUSH32(esp, 0x00796D44u); /* 0x00775196: push 0x796d44 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077519B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077519E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077519F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007751A4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007751A7: ret  */

}

void sub_007751A8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007751A8u);

L_007751A8:
    PUSH32(esp, 0); /* 0x007751A8: push 0 */
    PUSH32(esp, 0x00796D2Cu); /* 0x007751AA: push 0x796d2c */
    eax = MEM32(ebp + (-0x10)); /* 0x007751AF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007751B2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007751B3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007751B8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007751BB: ret  */

}

void sub_007751BC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007751BCu);

L_007751BC:
    PUSH32(esp, 0); /* 0x007751BC: push 0 */
    PUSH32(esp, 0x00796D10u); /* 0x007751BE: push 0x796d10 */
    eax = MEM32(ebp + (-0x10)); /* 0x007751C3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007751C6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007751C7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007751CC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007751CF: ret  */

}

void sub_007751D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007751D0u);

L_007751D0:
    PUSH32(esp, 0); /* 0x007751D0: push 0 */
    PUSH32(esp, 0x00796CF4u); /* 0x007751D2: push 0x796cf4 */
    eax = MEM32(ebp + (-0x10)); /* 0x007751D7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007751DA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007751DB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007751E0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007751E3: ret  */

}

void sub_007751E4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007751E4u);

L_007751E4:
    PUSH32(esp, 0); /* 0x007751E4: push 0 */
    PUSH32(esp, 0x00796CDCu); /* 0x007751E6: push 0x796cdc */
    eax = MEM32(ebp + (-0x10)); /* 0x007751EB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007751EE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007751EF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007751F4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007751F7: ret  */

}

void sub_007751F8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007751F8u);

L_007751F8:
    PUSH32(esp, 0); /* 0x007751F8: push 0 */
    PUSH32(esp, 0x00796CC0u); /* 0x007751FA: push 0x796cc0 */
    eax = MEM32(ebp + (-0x10)); /* 0x007751FF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775202: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775203: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775208: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077520B: ret  */

}

void sub_0077520C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077520Cu);

L_0077520C:
    PUSH32(esp, 0); /* 0x0077520C: push 0 */
    PUSH32(esp, 0x00796CA8u); /* 0x0077520E: push 0x796ca8 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775213: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775216: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775217: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077521C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077521F: ret  */

}

void sub_00775220(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775220u);

L_00775220:
    PUSH32(esp, 0); /* 0x00775220: push 0 */
    PUSH32(esp, 0x00796C90u); /* 0x00775222: push 0x796c90 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775227: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077522A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077522B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775230: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775233: ret  */

}

void sub_00775234(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775234u);

L_00775234:
    PUSH32(esp, 0); /* 0x00775234: push 0 */
    PUSH32(esp, 0x00796C74u); /* 0x00775236: push 0x796c74 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077523B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077523E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077523F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775244: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775247: ret  */

}

void sub_00775248(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775248u);

L_00775248:
    PUSH32(esp, 0); /* 0x00775248: push 0 */
    PUSH32(esp, 0x00796C58u); /* 0x0077524A: push 0x796c58 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077524F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775252: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775253: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775258: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077525B: ret  */

}

void sub_0077525C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077525Cu);

L_0077525C:
    PUSH32(esp, 0); /* 0x0077525C: push 0 */
    PUSH32(esp, 0x00796C40u); /* 0x0077525E: push 0x796c40 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775263: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775266: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775267: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077526C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077526F: ret  */

}

void sub_00775270(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775270u);

L_00775270:
    PUSH32(esp, 0); /* 0x00775270: push 0 */
    PUSH32(esp, 0x00796C24u); /* 0x00775272: push 0x796c24 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775277: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077527A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077527B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775280: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775283: ret  */

}

void sub_00775284(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775284u);

L_00775284:
    PUSH32(esp, 0); /* 0x00775284: push 0 */
    PUSH32(esp, 0x00796C08u); /* 0x00775286: push 0x796c08 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077528B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077528E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077528F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775294: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775297: ret  */

}

void sub_00775298(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775298u);

L_00775298:
    PUSH32(esp, 0); /* 0x00775298: push 0 */
    PUSH32(esp, 0x00796BF0u); /* 0x0077529A: push 0x796bf0 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077529F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007752A2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007752A3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007752A8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007752AB: ret  */

}

void sub_007752AC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007752ACu);

L_007752AC:
    PUSH32(esp, 0); /* 0x007752AC: push 0 */
    PUSH32(esp, 0x00796BD0u); /* 0x007752AE: push 0x796bd0 */
    eax = MEM32(ebp + (-0x10)); /* 0x007752B3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007752B6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007752B7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007752BC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007752BF: ret  */

}

void sub_007752C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007752C0u);

L_007752C0:
    PUSH32(esp, 0); /* 0x007752C0: push 0 */
    PUSH32(esp, 0x00796BB0u); /* 0x007752C2: push 0x796bb0 */
    eax = MEM32(ebp + (-0x10)); /* 0x007752C7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007752CA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007752CB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007752D0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007752D3: ret  */

}

void sub_007752D4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007752D4u);

L_007752D4:
    PUSH32(esp, 0); /* 0x007752D4: push 0 */
    PUSH32(esp, 0x00796B94u); /* 0x007752D6: push 0x796b94 */
    eax = MEM32(ebp + (-0x10)); /* 0x007752DB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007752DE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007752DF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007752E4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007752E7: ret  */

}

void sub_007752FC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007752FCu);

L_007752FC:
    PUSH32(esp, 0); /* 0x007752FC: push 0 */
    PUSH32(esp, 0x00796B60u); /* 0x007752FE: push 0x796b60 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775303: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775306: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775307: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077530C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077530F: ret  */

}

void sub_00775310(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775310u);

L_00775310:
    PUSH32(esp, 0); /* 0x00775310: push 0 */
    PUSH32(esp, 0x00796698u); /* 0x00775312: push 0x796698 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775317: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077531A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077531B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775320: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775323: ret  */

}

void sub_00775324(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775324u);

L_00775324:
    PUSH32(esp, 0); /* 0x00775324: push 0 */
    PUSH32(esp, 0x00796B38u); /* 0x00775326: push 0x796b38 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077532B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077532E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077532F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775334: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775337: ret  */

}

void sub_00775338(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775338u);

L_00775338:
    PUSH32(esp, 0); /* 0x00775338: push 0 */
    PUSH32(esp, 0x00796B10u); /* 0x0077533A: push 0x796b10 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077533F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775342: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775343: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775348: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077534B: ret  */

}

void sub_0077534C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077534Cu);

L_0077534C:
    PUSH32(esp, 0); /* 0x0077534C: push 0 */
    PUSH32(esp, 0x00796AECu); /* 0x0077534E: push 0x796aec */
    eax = MEM32(ebp + (-0x10)); /* 0x00775353: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775356: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775357: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077535C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077535F: ret  */

}

void sub_00775360(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775360u);

L_00775360:
    PUSH32(esp, 0); /* 0x00775360: push 0 */
    PUSH32(esp, 0x00796AC8u); /* 0x00775362: push 0x796ac8 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775367: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077536A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077536B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775370: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775373: ret  */

}

void sub_00775374(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775374u);

L_00775374:
    PUSH32(esp, 0); /* 0x00775374: push 0 */
    PUSH32(esp, 0x00796AA4u); /* 0x00775376: push 0x796aa4 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077537B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077537E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077537F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775384: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775387: ret  */

}

void sub_00775388(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775388u);

L_00775388:
    PUSH32(esp, 0); /* 0x00775388: push 0 */
    PUSH32(esp, 0x00796A84u); /* 0x0077538A: push 0x796a84 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077538F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775392: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775393: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775398: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077539B: ret  */

}

void sub_0077539C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077539Cu);

L_0077539C:
    PUSH32(esp, 0); /* 0x0077539C: push 0 */
    PUSH32(esp, 0x00796A68u); /* 0x0077539E: push 0x796a68 */
    eax = MEM32(ebp + (-0x10)); /* 0x007753A3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007753A6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007753A7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007753AC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007753AF: ret  */

}

void sub_007753B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007753B0u);

L_007753B0:
    PUSH32(esp, 0); /* 0x007753B0: push 0 */
    PUSH32(esp, 0x00796A50u); /* 0x007753B2: push 0x796a50 */
    eax = MEM32(ebp + (-0x10)); /* 0x007753B7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007753BA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007753BB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007753C0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007753C3: ret  */

}

void sub_007753C4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007753C4u);

L_007753C4:
    PUSH32(esp, 0); /* 0x007753C4: push 0 */
    PUSH32(esp, 0x00796A38u); /* 0x007753C6: push 0x796a38 */
    eax = MEM32(ebp + (-0x10)); /* 0x007753CB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007753CE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007753CF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007753D4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007753D7: ret  */

}

void sub_007753D8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007753D8u);

    goto L_007753D8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007753D8:
    eax = 0x007E0C64u; /* 0x007753D8: mov eax, 0x7e0c64 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007753DD: jmp 0x75bf0e */

}

void sub_007753F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007753F0u);

L_007753F0:
    PUSH32(esp, 0); /* 0x007753F0: push 0 */
    PUSH32(esp, 0x007974B8u); /* 0x007753F2: push 0x7974b8 */
    eax = MEM32(ebp + (-0x10)); /* 0x007753F7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007753FA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007753FB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775400: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775403: ret  */

}

void sub_00775404(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775404u);

L_00775404:
    PUSH32(esp, 0); /* 0x00775404: push 0 */
    PUSH32(esp, 0x0079749Cu); /* 0x00775406: push 0x79749c */
    eax = MEM32(ebp + (-0x10)); /* 0x0077540B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077540E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077540F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775414: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775417: ret  */

}

void sub_00775418(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775418u);

L_00775418:
    PUSH32(esp, 0); /* 0x00775418: push 0 */
    PUSH32(esp, 0x00797484u); /* 0x0077541A: push 0x797484 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077541F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775422: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775423: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775428: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077542B: ret  */

}

void sub_0077542C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077542Cu);

L_0077542C:
    PUSH32(esp, 0); /* 0x0077542C: push 0 */
    PUSH32(esp, 0x0079746Cu); /* 0x0077542E: push 0x79746c */
    eax = MEM32(ebp + (-0x10)); /* 0x00775433: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775436: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775437: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077543C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077543F: ret  */

}

void sub_00775440(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775440u);

L_00775440:
    PUSH32(esp, 0); /* 0x00775440: push 0 */
    PUSH32(esp, 0x00797454u); /* 0x00775442: push 0x797454 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775447: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077544A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077544B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775450: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775453: ret  */

}

void sub_00775454(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775454u);

L_00775454:
    PUSH32(esp, 0); /* 0x00775454: push 0 */
    PUSH32(esp, 0x00797440u); /* 0x00775456: push 0x797440 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077545B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077545E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077545F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775464: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775467: ret  */

}

void sub_00775468(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775468u);

L_00775468:
    PUSH32(esp, 0); /* 0x00775468: push 0 */
    PUSH32(esp, 0x00797424u); /* 0x0077546A: push 0x797424 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077546F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775472: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775473: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775478: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077547B: ret  */

}

void sub_0077547C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077547Cu);

L_0077547C:
    PUSH32(esp, 0); /* 0x0077547C: push 0 */
    PUSH32(esp, 0x0079740Cu); /* 0x0077547E: push 0x79740c */
    eax = MEM32(ebp + (-0x10)); /* 0x00775483: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775486: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775487: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077548C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077548F: ret  */

}

void sub_00775490(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775490u);

L_00775490:
    PUSH32(esp, 0); /* 0x00775490: push 0 */
    PUSH32(esp, 0x007973F4u); /* 0x00775492: push 0x7973f4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775497: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077549A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077549B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007754A0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007754A3: ret  */

}

void sub_007754A4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007754A4u);

L_007754A4:
    PUSH32(esp, 0); /* 0x007754A4: push 0 */
    PUSH32(esp, 0x007973D8u); /* 0x007754A6: push 0x7973d8 */
    eax = MEM32(ebp + (-0x10)); /* 0x007754AB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007754AE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007754AF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007754B4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007754B7: ret  */

}

void sub_007754B8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007754B8u);

L_007754B8:
    PUSH32(esp, 0); /* 0x007754B8: push 0 */
    PUSH32(esp, 0x007973BCu); /* 0x007754BA: push 0x7973bc */
    eax = MEM32(ebp + (-0x10)); /* 0x007754BF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007754C2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007754C3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007754C8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007754CB: ret  */

}

void sub_007754CC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007754CCu);

L_007754CC:
    PUSH32(esp, 0); /* 0x007754CC: push 0 */
    PUSH32(esp, 0x007973A4u); /* 0x007754CE: push 0x7973a4 */
    eax = MEM32(ebp + (-0x10)); /* 0x007754D3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007754D6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007754D7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007754DC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007754DF: ret  */

}

void sub_007754E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007754E0u);

L_007754E0:
    PUSH32(esp, 0); /* 0x007754E0: push 0 */
    PUSH32(esp, 0x00797388u); /* 0x007754E2: push 0x797388 */
    eax = MEM32(ebp + (-0x10)); /* 0x007754E7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007754EA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007754EB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007754F0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007754F3: ret  */

}

void sub_007754F4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007754F4u);

L_007754F4:
    PUSH32(esp, 0); /* 0x007754F4: push 0 */
    PUSH32(esp, 0x00797370u); /* 0x007754F6: push 0x797370 */
    eax = MEM32(ebp + (-0x10)); /* 0x007754FB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007754FE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007754FF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775504: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775507: ret  */

}

void sub_00775508(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775508u);

L_00775508:
    PUSH32(esp, 0); /* 0x00775508: push 0 */
    PUSH32(esp, 0x00797358u); /* 0x0077550A: push 0x797358 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077550F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775512: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775513: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775518: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077551B: ret  */

}

void sub_0077551C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077551Cu);

L_0077551C:
    PUSH32(esp, 0); /* 0x0077551C: push 0 */
    PUSH32(esp, 0x00797340u); /* 0x0077551E: push 0x797340 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775523: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775526: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775527: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077552C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077552F: ret  */

}

void sub_00775530(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775530u);

L_00775530:
    PUSH32(esp, 0); /* 0x00775530: push 0 */
    PUSH32(esp, 0x0079732Cu); /* 0x00775532: push 0x79732c */
    eax = MEM32(ebp + (-0x10)); /* 0x00775537: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077553A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077553B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775540: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775543: ret  */

}

void sub_00775544(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775544u);

L_00775544:
    PUSH32(esp, 0); /* 0x00775544: push 0 */
    PUSH32(esp, 0x00797318u); /* 0x00775546: push 0x797318 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077554B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077554E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077554F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775554: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775557: ret  */

}

void sub_00775558(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775558u);

L_00775558:
    PUSH32(esp, 0); /* 0x00775558: push 0 */
    PUSH32(esp, 0x007972FCu); /* 0x0077555A: push 0x7972fc */
    eax = MEM32(ebp + (-0x10)); /* 0x0077555F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775562: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775563: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775568: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077556B: ret  */

}

void sub_0077556C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077556Cu);

L_0077556C:
    PUSH32(esp, 0); /* 0x0077556C: push 0 */
    PUSH32(esp, 0x007972E4u); /* 0x0077556E: push 0x7972e4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775573: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775576: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775577: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077557C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077557F: ret  */

}

void sub_00775580(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775580u);

L_00775580:
    PUSH32(esp, 0); /* 0x00775580: push 0 */
    PUSH32(esp, 0x007972CCu); /* 0x00775582: push 0x7972cc */
    eax = MEM32(ebp + (-0x10)); /* 0x00775587: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077558A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077558B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775590: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775593: ret  */

}

void sub_00775594(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775594u);

L_00775594:
    PUSH32(esp, 0); /* 0x00775594: push 0 */
    PUSH32(esp, 0x007972B0u); /* 0x00775596: push 0x7972b0 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077559B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077559E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077559F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007755A4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007755A7: ret  */

}

void sub_007755A8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007755A8u);

L_007755A8:
    PUSH32(esp, 0); /* 0x007755A8: push 0 */
    PUSH32(esp, 0x00797294u); /* 0x007755AA: push 0x797294 */
    eax = MEM32(ebp + (-0x10)); /* 0x007755AF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007755B2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007755B3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007755B8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007755BB: ret  */

}

void sub_007755BC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007755BCu);

L_007755BC:
    PUSH32(esp, 0); /* 0x007755BC: push 0 */
    PUSH32(esp, 0x0079727Cu); /* 0x007755BE: push 0x79727c */
    eax = MEM32(ebp + (-0x10)); /* 0x007755C3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007755C6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007755C7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007755CC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007755CF: ret  */

}

void sub_007755D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007755D0u);

L_007755D0:
    PUSH32(esp, 0); /* 0x007755D0: push 0 */
    PUSH32(esp, 0x00797260u); /* 0x007755D2: push 0x797260 */
    eax = MEM32(ebp + (-0x10)); /* 0x007755D7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007755DA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007755DB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007755E0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007755E3: ret  */

}

void sub_007755E4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007755E4u);

L_007755E4:
    PUSH32(esp, 0); /* 0x007755E4: push 0 */
    PUSH32(esp, 0x00797248u); /* 0x007755E6: push 0x797248 */
    eax = MEM32(ebp + (-0x10)); /* 0x007755EB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007755EE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007755EF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007755F4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007755F7: ret  */

}

void sub_007755F8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007755F8u);

L_007755F8:
    PUSH32(esp, 0); /* 0x007755F8: push 0 */
    PUSH32(esp, 0x00797230u); /* 0x007755FA: push 0x797230 */
    eax = MEM32(ebp + (-0x10)); /* 0x007755FF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775602: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775603: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775608: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077560B: ret  */

}

void sub_0077560C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077560Cu);

L_0077560C:
    PUSH32(esp, 0); /* 0x0077560C: push 0 */
    PUSH32(esp, 0x00797214u); /* 0x0077560E: push 0x797214 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775613: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775616: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775617: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077561C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077561F: ret  */

}

void sub_00775620(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775620u);

L_00775620:
    PUSH32(esp, 0); /* 0x00775620: push 0 */
    PUSH32(esp, 0x007971F8u); /* 0x00775622: push 0x7971f8 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775627: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077562A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077562B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775630: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775633: ret  */

}

void sub_00775634(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775634u);

L_00775634:
    PUSH32(esp, 0); /* 0x00775634: push 0 */
    PUSH32(esp, 0x007971E0u); /* 0x00775636: push 0x7971e0 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077563B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077563E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077563F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775644: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775647: ret  */

}

void sub_00775648(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775648u);

L_00775648:
    PUSH32(esp, 0); /* 0x00775648: push 0 */
    PUSH32(esp, 0x007971C4u); /* 0x0077564A: push 0x7971c4 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077564F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775652: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775653: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775658: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077565B: ret  */

}

void sub_0077565C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077565Cu);

L_0077565C:
    PUSH32(esp, 0); /* 0x0077565C: push 0 */
    PUSH32(esp, 0x007971ACu); /* 0x0077565E: push 0x7971ac */
    eax = MEM32(ebp + (-0x10)); /* 0x00775663: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775666: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775667: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077566C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077566F: ret  */

}

void sub_00775670(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775670u);

L_00775670:
    PUSH32(esp, 0); /* 0x00775670: push 0 */
    PUSH32(esp, 0x00797194u); /* 0x00775672: push 0x797194 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775677: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077567A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077567B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775680: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775683: ret  */

}

void sub_00775684(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775684u);

L_00775684:
    PUSH32(esp, 0); /* 0x00775684: push 0 */
    PUSH32(esp, 0x00797174u); /* 0x00775686: push 0x797174 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077568B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077568E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077568F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775694: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775697: ret  */

}

void sub_00775698(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775698u);

L_00775698:
    PUSH32(esp, 0); /* 0x00775698: push 0 */
    PUSH32(esp, 0x00797158u); /* 0x0077569A: push 0x797158 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077569F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007756A2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007756A3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007756A8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007756AB: ret  */

}

void sub_007756AC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007756ACu);

L_007756AC:
    PUSH32(esp, 0); /* 0x007756AC: push 0 */
    PUSH32(esp, 0x0079713Cu); /* 0x007756AE: push 0x79713c */
    eax = MEM32(ebp + (-0x10)); /* 0x007756B3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007756B6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007756B7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007756BC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007756BF: ret  */

}

void sub_007756C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007756C0u);

L_007756C0:
    PUSH32(esp, 0); /* 0x007756C0: push 0 */
    PUSH32(esp, 0x00797124u); /* 0x007756C2: push 0x797124 */
    eax = MEM32(ebp + (-0x10)); /* 0x007756C7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007756CA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007756CB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007756D0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007756D3: ret  */

}

void sub_007756D4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007756D4u);

L_007756D4:
    PUSH32(esp, 0); /* 0x007756D4: push 0 */
    PUSH32(esp, 0x0079710Cu); /* 0x007756D6: push 0x79710c */
    eax = MEM32(ebp + (-0x10)); /* 0x007756DB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007756DE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007756DF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007756E4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007756E7: ret  */

}

void sub_007756E8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007756E8u);

L_007756E8:
    PUSH32(esp, 0); /* 0x007756E8: push 0 */
    PUSH32(esp, 0x00796698u); /* 0x007756EA: push 0x796698 */
    eax = MEM32(ebp + (-0x10)); /* 0x007756EF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007756F2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007756F3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007756F8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007756FB: ret  */

}

void sub_007756FC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007756FCu);

L_007756FC:
    PUSH32(esp, 0); /* 0x007756FC: push 0 */
    PUSH32(esp, 0x007970E4u); /* 0x007756FE: push 0x7970e4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775703: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775706: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775707: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077570C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077570F: ret  */

}

void sub_00775710(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775710u);

L_00775710:
    PUSH32(esp, 0); /* 0x00775710: push 0 */
    PUSH32(esp, 0x007970C0u); /* 0x00775712: push 0x7970c0 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775717: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077571A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077571B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775720: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775723: ret  */

}

void sub_00775724(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775724u);

L_00775724:
    PUSH32(esp, 0); /* 0x00775724: push 0 */
    PUSH32(esp, 0x0079709Cu); /* 0x00775726: push 0x79709c */
    eax = MEM32(ebp + (-0x10)); /* 0x0077572B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077572E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077572F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775734: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775737: ret  */

}

void sub_00775738(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775738u);

L_00775738:
    PUSH32(esp, 0); /* 0x00775738: push 0 */
    PUSH32(esp, 0x00797078u); /* 0x0077573A: push 0x797078 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077573F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775742: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775743: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775748: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077574B: ret  */

}

void sub_0077574C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077574Cu);

L_0077574C:
    PUSH32(esp, 0); /* 0x0077574C: push 0 */
    PUSH32(esp, 0x00797058u); /* 0x0077574E: push 0x797058 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775753: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775756: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775757: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077575C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077575F: ret  */

}

void sub_00775760(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775760u);

L_00775760:
    PUSH32(esp, 0); /* 0x00775760: push 0 */
    PUSH32(esp, 0x00797038u); /* 0x00775762: push 0x797038 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775767: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077576A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077576B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775770: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775773: ret  */

}

void sub_00775774(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775774u);

L_00775774:
    PUSH32(esp, 0); /* 0x00775774: push 0 */
    PUSH32(esp, 0x00797020u); /* 0x00775776: push 0x797020 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077577B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077577E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077577F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775784: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775787: ret  */

}

void sub_00775788(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775788u);

L_00775788:
    PUSH32(esp, 0); /* 0x00775788: push 0 */
    PUSH32(esp, 0x00797008u); /* 0x0077578A: push 0x797008 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077578F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775792: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775793: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775798: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077579B: ret  */

}

void sub_0077579C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077579Cu);

L_0077579C:
    PUSH32(esp, 0); /* 0x0077579C: push 0 */
    PUSH32(esp, 0x00796FF4u); /* 0x0077579E: push 0x796ff4 */
    eax = MEM32(ebp + (-0x10)); /* 0x007757A3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007757A6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007757A7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007757AC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007757AF: ret  */

}

void sub_007757B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007757B0u);

    goto L_007757B0;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007757B0:
    eax = 0x007E0E00u; /* 0x007757B0: mov eax, 0x7e0e00 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007757B5: jmp 0x75bf0e */

}

void sub_007757C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007757C0u);

L_007757C0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007757C0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x007757C3: jmp 0x553a80 */

}

void sub_007757C8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007757C8u);

L_007757C8:
    ecx = MEM32(ebp + (-0x10)); /* 0x007757C8: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4Cu; /* 0x007757CB: add ecx, 0x4c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x007757CE: jmp 0x5cde60 */

}

void sub_007757D3(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007757D3u);

L_007757D3:
    ecx = MEM32(ebp + (-0x10)); /* 0x007757D3: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x5Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x5Cu; /* 0x007757D6: add ecx, 0x5c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0052E930u); RECOMP_RETURN(); /* 0x007757D9: jmp 0x52e930 */

}

void sub_007757DE(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007757DEu);

    goto L_007757DE;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007757DE:
    eax = 0x007E0E34u; /* 0x007757DE: mov eax, 0x7e0e34 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007757E3: jmp 0x75bf0e */

}

void sub_007757F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007757F0u);

L_007757F0:
    ecx = MEM32(ebp + (-0x904)); /* 0x007757F0: mov ecx, dword ptr [ebp - 0x904] */
    RECOMP_ITAIL(0x004DEF50u); RECOMP_RETURN(); /* 0x007757F6: jmp 0x4def50 */

}

void sub_007757FB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007757FBu);

L_007757FB:
    ecx = ebp + (-0x8F0); /* 0x007757FB: lea ecx, [ebp - 0x8f0] */
    RECOMP_ITAIL(0x00401830u); RECOMP_RETURN(); /* 0x00775801: jmp 0x401830 */

}

void sub_00775806(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775806u);

L_00775806:
    ecx = ebp + (-0x900); /* 0x00775806: lea ecx, [ebp - 0x900] */
    RECOMP_ITAIL(0x0040BE20u); RECOMP_RETURN(); /* 0x0077580C: jmp 0x40be20 */

}

void sub_00775811(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775811u);

    goto L_00775811;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775811:
    eax = 0x007E0E68u; /* 0x00775811: mov eax, 0x7e0e68 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775816: jmp 0x75bf0e */

}

void sub_00775820(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775820u);

L_00775820:
    ecx = MEM32(ebp + (-0x904)); /* 0x00775820: mov ecx, dword ptr [ebp - 0x904] */
    RECOMP_ITAIL(0x004DEF50u); RECOMP_RETURN(); /* 0x00775826: jmp 0x4def50 */

}

void sub_0077582B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077582Bu);

L_0077582B:
    ecx = MEM32(ebp + (-0x904)); /* 0x0077582B: mov ecx, dword ptr [ebp - 0x904] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x150u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x150u; /* 0x00775831: add ecx, 0x150 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0050DAA0u); RECOMP_RETURN(); /* 0x00775837: jmp 0x50daa0 */

}

void sub_0077583C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077583Cu);

L_0077583C:
    ecx = ebp + (-0x8F0); /* 0x0077583C: lea ecx, [ebp - 0x8f0] */
    RECOMP_ITAIL(0x00401830u); RECOMP_RETURN(); /* 0x00775842: jmp 0x401830 */

}

void sub_00775847(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775847u);

L_00775847:
    ecx = ebp + (-0x900); /* 0x00775847: lea ecx, [ebp - 0x900] */
    RECOMP_ITAIL(0x0040BE20u); RECOMP_RETURN(); /* 0x0077584D: jmp 0x40be20 */

}

void sub_00775852(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775852u);

    goto L_00775852;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775852:
    eax = 0x007E0EA4u; /* 0x00775852: mov eax, 0x7e0ea4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775857: jmp 0x75bf0e */

}

void sub_00775860(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775860u);

L_00775860:
    ecx = ebp + (-0x20); /* 0x00775860: lea ecx, [ebp - 0x20] */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00775863: jmp 0x5cde60 */

}

void sub_00775868(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775868u);

L_00775868:
    PUSH32(esp, 0); /* 0x00775868: push 0 */
    PUSH32(esp, 0x007975C8u); /* 0x0077586A: push 0x7975c8 */
    eax = MEM32(ebp + (-0x14)); /* 0x0077586F: mov eax, dword ptr [ebp - 0x14] */
    PUSH32(esp, eax); /* 0x00775872: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775873: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775878: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077587B: ret  */

}

void sub_0077587C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077587Cu);

    goto L_0077587C;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077587C:
    eax = 0x007E0EF4u; /* 0x0077587C: mov eax, 0x7e0ef4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775881: jmp 0x75bf0e */

}

void sub_00775890(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775890u);

L_00775890:
    PUSH32(esp, 0); /* 0x00775890: push 0 */
    PUSH32(esp, 0x007975D8u); /* 0x00775892: push 0x7975d8 */
    eax = MEM32(ebp + (-0x14)); /* 0x00775897: mov eax, dword ptr [ebp - 0x14] */
    PUSH32(esp, eax); /* 0x0077589A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077589B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007758A0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007758A3: ret  */

}

void sub_007758A4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007758A4u);

L_007758A4:
    PUSH32(esp, 0); /* 0x007758A4: push 0 */
    PUSH32(esp, 0x007975D8u); /* 0x007758A6: push 0x7975d8 */
    eax = MEM32(ebp + (-0x14)); /* 0x007758AB: mov eax, dword ptr [ebp - 0x14] */
    PUSH32(esp, eax); /* 0x007758AE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007758AF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007758B4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007758B7: ret  */

}

void sub_007758B8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007758B8u);

L_007758B8:
    PUSH32(esp, 0); /* 0x007758B8: push 0 */
    PUSH32(esp, 0x007975D8u); /* 0x007758BA: push 0x7975d8 */
    eax = MEM32(ebp + (-0x10)); /* 0x007758BF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007758C2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007758C3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007758C8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007758CB: ret  */

}

void sub_007758CC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007758CCu);

L_007758CC:
    ecx = MEM32(ebp + (-0x14)); /* 0x007758CC: mov ecx, dword ptr [ebp - 0x14] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x10u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x10u; /* 0x007758CF: add ecx, 0x10 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00401830u); RECOMP_RETURN(); /* 0x007758D2: jmp 0x401830 */

}

void sub_007758D7(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007758D7u);

    goto L_007758D7;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007758D7:
    eax = 0x007E0F30u; /* 0x007758D7: mov eax, 0x7e0f30 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007758DC: jmp 0x75bf0e */

}

void sub_007758F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007758F0u);

L_007758F0:
    ecx = MEM32(ebp + (-0x14)); /* 0x007758F0: mov ecx, dword ptr [ebp - 0x14] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 4; /* 0x007758F3: add ecx, 4 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x007758F6: jmp 0x5cde60 */

}

void sub_007758FB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007758FBu);

L_007758FB:
    ecx = MEM32(ebp + (-0x14)); /* 0x007758FB: mov ecx, dword ptr [ebp - 0x14] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0xCu; /* 0x007758FE: add ecx, 0xc */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00775901: jmp 0x5cde60 */

}

void sub_00775906(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775906u);

L_00775906:
    PUSH32(esp, 0); /* 0x00775906: push 0 */
    PUSH32(esp, 0x007975ECu); /* 0x00775908: push 0x7975ec */
    eax = MEM32(ebp + (-0x18)); /* 0x0077590D: mov eax, dword ptr [ebp - 0x18] */
    PUSH32(esp, eax); /* 0x00775910: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775911: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775916: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775919: ret  */

}

void sub_0077591A(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077591Au);

L_0077591A:
    PUSH32(esp, 0); /* 0x0077591A: push 0 */
    PUSH32(esp, 0x007975ECu); /* 0x0077591C: push 0x7975ec */
    eax = MEM32(ebp + (-0x18)); /* 0x00775921: mov eax, dword ptr [ebp - 0x18] */
    PUSH32(esp, eax); /* 0x00775924: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775925: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077592A: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077592D: ret  */

}

void sub_0077592E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077592Eu);

L_0077592E:
    PUSH32(esp, 0); /* 0x0077592E: push 0 */
    PUSH32(esp, 0x007975ECu); /* 0x00775930: push 0x7975ec */
    eax = MEM32(ebp + (-0x18)); /* 0x00775935: mov eax, dword ptr [ebp - 0x18] */
    PUSH32(esp, eax); /* 0x00775938: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775939: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077593E: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775941: ret  */

}

void sub_00775942(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775942u);

    goto L_00775942;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775942:
    eax = 0x007E0F74u; /* 0x00775942: mov eax, 0x7e0f74 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775947: jmp 0x75bf0e */

}

void sub_00775950(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775950u);

L_00775950:
    ecx = MEM32(ebp + (-0x10)); /* 0x00775950: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 4; /* 0x00775953: add ecx, 4 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00775956: jmp 0x5cde60 */

}

void sub_0077595B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077595Bu);

    goto L_0077595B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077595B:
    eax = 0x007E0F98u; /* 0x0077595B: mov eax, 0x7e0f98 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775960: jmp 0x75bf0e */

}

void sub_00775970(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775970u);

L_00775970:
    ecx = MEM32(ebp + (-0x18)); /* 0x00775970: mov ecx, dword ptr [ebp - 0x18] */
    RECOMP_ITAIL(0x004EE660u); RECOMP_RETURN(); /* 0x00775973: jmp 0x4ee660 */

}

void sub_00775978(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775978u);

    goto L_00775978;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775978:
    eax = 0x007E0FBCu; /* 0x00775978: mov eax, 0x7e0fbc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077597D: jmp 0x75bf0e */

}

void sub_00775990(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775990u);

L_00775990:
    PUSH32(esp, 0); /* 0x00775990: push 0 */
    PUSH32(esp, 0x00797608u); /* 0x00775992: push 0x797608 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775997: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077599A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077599B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007759A0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007759A3: ret  */

}

void sub_007759A4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007759A4u);

    goto L_007759A4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007759A4:
    eax = 0x007E0FE0u; /* 0x007759A4: mov eax, 0x7e0fe0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007759A9: jmp 0x75bf0e */

}

void sub_007759B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007759B0u);

L_007759B0:
    ecx = ebp + (-0x18); /* 0x007759B0: lea ecx, [ebp - 0x18] */
    RECOMP_ITAIL(0x00490340u); RECOMP_RETURN(); /* 0x007759B3: jmp 0x490340 */

}

void sub_007759B8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007759B8u);

    goto L_007759B8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007759B8:
    eax = 0x007E1004u; /* 0x007759B8: mov eax, 0x7e1004 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007759BD: jmp 0x75bf0e */

}

void sub_007759D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007759D0u);

L_007759D0:
    PUSH32(esp, 0); /* 0x007759D0: push 0 */
    PUSH32(esp, 0x00790F3Cu); /* 0x007759D2: push 0x790f3c */
    eax = MEM32(ebp + (-0x90)); /* 0x007759D7: mov eax, dword ptr [ebp - 0x90] */
    PUSH32(esp, eax); /* 0x007759DD: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007759DE: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007759E3: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007759E6: ret  */

}

void sub_007759E7(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007759E7u);

    goto L_007759E7;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007759E7:
    eax = 0x007E1028u; /* 0x007759E7: mov eax, 0x7e1028 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007759EC: jmp 0x75bf0e */

}

void sub_00775A00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775A00u);

L_00775A00:
    PUSH32(esp, 0); /* 0x00775A00: push 0 */
    PUSH32(esp, 0x0079767Cu); /* 0x00775A02: push 0x79767c */
    eax = MEM32(ebp + (-0x10)); /* 0x00775A07: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775A0A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775A0B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775A10: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775A13: ret  */

}

void sub_00775A14(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775A14u);

    goto L_00775A14;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775A14:
    eax = 0x007E104Cu; /* 0x00775A14: mov eax, 0x7e104c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775A19: jmp 0x75bf0e */

}

void sub_00775A20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775A20u);

L_00775A20:
    ecx = MEM32(ebp + (-0x18)); /* 0x00775A20: mov ecx, dword ptr [ebp - 0x18] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00775A23: jmp 0x553a80 */

}

void sub_00775A28(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775A28u);

L_00775A28:
    ecx = MEM32(ebp + (-0x18)); /* 0x00775A28: mov ecx, dword ptr [ebp - 0x18] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x50u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x50u; /* 0x00775A2B: add ecx, 0x50 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004CBAA0u); RECOMP_RETURN(); /* 0x00775A2E: jmp 0x4cbaa0 */

}

void sub_00775A33(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775A33u);

L_00775A33:
    ecx = MEM32(ebp + (-0x18)); /* 0x00775A33: mov ecx, dword ptr [ebp - 0x18] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0xFCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0xFCu; /* 0x00775A36: add ecx, 0xfc */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004CBAA0u); RECOMP_RETURN(); /* 0x00775A3C: jmp 0x4cbaa0 */

}

void sub_00775A41(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775A41u);

L_00775A41:
    PUSH32(esp, 0); /* 0x00775A41: push 0 */
    PUSH32(esp, 0x00797690u); /* 0x00775A43: push 0x797690 */
    eax = MEM32(ebp + (-0x14)); /* 0x00775A48: mov eax, dword ptr [ebp - 0x14] */
    PUSH32(esp, eax); /* 0x00775A4B: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775A4C: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775A51: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775A54: ret  */

}

void sub_00775A55(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775A55u);

L_00775A55:
    ecx = MEM32(ebp + (-0x14)); /* 0x00775A55: mov ecx, dword ptr [ebp - 0x14] */
    RECOMP_ITAIL(0x004E89F0u); RECOMP_RETURN(); /* 0x00775A58: jmp 0x4e89f0 */

}

void sub_00775A5D(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775A5Du);

    goto L_00775A5D;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775A5D:
    eax = 0x007E1090u; /* 0x00775A5D: mov eax, 0x7e1090 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775A62: jmp 0x75bf0e */

}

void sub_00775A70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775A70u);

L_00775A70:
    PUSH32(esp, 0); /* 0x00775A70: push 0 */
    PUSH32(esp, 0x007976E8u); /* 0x00775A72: push 0x7976e8 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775A77: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775A7A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775A7B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775A80: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775A83: ret  */

}

void sub_00775A84(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775A84u);

    goto L_00775A84;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775A84:
    eax = 0x007E10B4u; /* 0x00775A84: mov eax, 0x7e10b4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775A89: jmp 0x75bf0e */

}

void sub_00775A90(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775A90u);

L_00775A90:
    ecx = MEM32(ebp + (-0x904)); /* 0x00775A90: mov ecx, dword ptr [ebp - 0x904] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00775A96: jmp 0x553a80 */

}

void sub_00775A9B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775A9Bu);

L_00775A9B:
    ecx = MEM32(ebp + (-0x904)); /* 0x00775A9B: mov ecx, dword ptr [ebp - 0x904] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x50u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x50u; /* 0x00775AA1: add ecx, 0x50 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00479130u); RECOMP_RETURN(); /* 0x00775AA4: jmp 0x479130 */

}

void sub_00775AA9(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775AA9u);

L_00775AA9:
    ecx = MEM32(ebp + (-0x904)); /* 0x00775AA9: mov ecx, dword ptr [ebp - 0x904] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0xD8u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0xD8u; /* 0x00775AAF: add ecx, 0xd8 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004FF410u); RECOMP_RETURN(); /* 0x00775AB5: jmp 0x4ff410 */

}

void sub_00775ABA(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775ABAu);

L_00775ABA:
    ecx = MEM32(ebp + (-0x904)); /* 0x00775ABA: mov ecx, dword ptr [ebp - 0x904] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x11Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x11Cu; /* 0x00775AC0: add ecx, 0x11c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004FF410u); RECOMP_RETURN(); /* 0x00775AC6: jmp 0x4ff410 */

}

void sub_00775ACB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775ACBu);

L_00775ACB:
    ecx = MEM32(ebp + (-0x904)); /* 0x00775ACB: mov ecx, dword ptr [ebp - 0x904] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x160u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x160u; /* 0x00775AD1: add ecx, 0x160 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004FF410u); RECOMP_RETURN(); /* 0x00775AD7: jmp 0x4ff410 */

}

void sub_00775ADC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775ADCu);

L_00775ADC:
    ecx = ebp + (-0x900); /* 0x00775ADC: lea ecx, [ebp - 0x900] */
    RECOMP_ITAIL(0x0040BE20u); RECOMP_RETURN(); /* 0x00775AE2: jmp 0x40be20 */

}

void sub_00775AE7(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775AE7u);

    goto L_00775AE7;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775AE7:
    eax = 0x007E1100u; /* 0x00775AE7: mov eax, 0x7e1100 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775AEC: jmp 0x75bf0e */

}

void sub_00775B00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775B00u);

L_00775B00:
    PUSH32(esp, 0); /* 0x00775B00: push 0 */
    PUSH32(esp, 0x007975C8u); /* 0x00775B02: push 0x7975c8 */
    eax = MEM32(ebp + (-0x20)); /* 0x00775B07: mov eax, dword ptr [ebp - 0x20] */
    PUSH32(esp, eax); /* 0x00775B0A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775B0B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775B10: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775B13: ret  */

}

void sub_00775B14(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775B14u);

    goto L_00775B14;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775B14:
    eax = 0x007E1124u; /* 0x00775B14: mov eax, 0x7e1124 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775B19: jmp 0x75bf0e */

}

void sub_00775B20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775B20u);

L_00775B20:
    ecx = MEM32(ebp + (-0x10)); /* 0x00775B20: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00775B23: jmp 0x553a80 */

}

void sub_00775B28(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775B28u);

L_00775B28:
    ecx = MEM32(ebp + (-0x10)); /* 0x00775B28: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4Cu; /* 0x00775B2B: add ecx, 0x4c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00775B2E: jmp 0x5cde60 */

}

void sub_00775B33(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775B33u);

L_00775B33:
    ecx = MEM32(ebp + (-0x10)); /* 0x00775B33: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x5Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x5Cu; /* 0x00775B36: add ecx, 0x5c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0052E930u); RECOMP_RETURN(); /* 0x00775B39: jmp 0x52e930 */

}

void sub_00775B3E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775B3Eu);

L_00775B3E:
    ecx = MEM32(ebp + (-0x10)); /* 0x00775B3E: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x118u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x118u; /* 0x00775B41: add ecx, 0x118 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00498560u); RECOMP_RETURN(); /* 0x00775B47: jmp 0x498560 */

}

void sub_00775B4C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775B4Cu);

    goto L_00775B4C;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775B4C:
    eax = 0x007E1160u; /* 0x00775B4C: mov eax, 0x7e1160 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775B51: jmp 0x75bf0e */

}

void sub_00775B60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775B60u);

L_00775B60:
    PUSH32(esp, 0); /* 0x00775B60: push 0 */
    PUSH32(esp, 0x00797768u); /* 0x00775B62: push 0x797768 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775B67: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775B6A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775B6B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775B70: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775B73: ret  */

}

void sub_00775B74(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775B74u);

    goto L_00775B74;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775B74:
    eax = 0x007E1184u; /* 0x00775B74: mov eax, 0x7e1184 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775B79: jmp 0x75bf0e */

}

void sub_00775B80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775B80u);

L_00775B80:
    PUSH32(esp, 0); /* 0x00775B80: push 0 */
    PUSH32(esp, 0x0079777Cu); /* 0x00775B82: push 0x79777c */
    eax = MEM32(ebp + (-0x10)); /* 0x00775B87: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775B8A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775B8B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775B90: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775B93: ret  */

}

void sub_00775B94(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775B94u);

    goto L_00775B94;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775B94:
    eax = 0x007E11A8u; /* 0x00775B94: mov eax, 0x7e11a8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775B99: jmp 0x75bf0e */

}

void sub_00775BA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775BA0u);

L_00775BA0:
    PUSH32(esp, 0); /* 0x00775BA0: push 0 */
    PUSH32(esp, 0x007977B0u); /* 0x00775BA2: push 0x7977b0 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775BA7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775BAA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775BAB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775BB0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775BB3: ret  */

}

void sub_00775BB4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775BB4u);

    goto L_00775BB4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775BB4:
    eax = 0x007E11CCu; /* 0x00775BB4: mov eax, 0x7e11cc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775BB9: jmp 0x75bf0e */

}

void sub_00775BC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775BC0u);

L_00775BC0:
    PUSH32(esp, 0); /* 0x00775BC0: push 0 */
    PUSH32(esp, 0x007977CCu); /* 0x00775BC2: push 0x7977cc */
    eax = MEM32(ebp + (-0x10)); /* 0x00775BC7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775BCA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775BCB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775BD0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775BD3: ret  */

}

void sub_00775BD4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775BD4u);

    goto L_00775BD4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775BD4:
    eax = 0x007E11F0u; /* 0x00775BD4: mov eax, 0x7e11f0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775BD9: jmp 0x75bf0e */

}

void sub_00775BE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775BE0u);

L_00775BE0:
    PUSH32(esp, 0); /* 0x00775BE0: push 0 */
    PUSH32(esp, 0x007977DCu); /* 0x00775BE2: push 0x7977dc */
    eax = MEM32(ebp + (-0x10)); /* 0x00775BE7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775BEA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775BEB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775BF0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775BF3: ret  */

}

void sub_00775BF4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775BF4u);

    goto L_00775BF4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775BF4:
    eax = 0x007E1214u; /* 0x00775BF4: mov eax, 0x7e1214 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775BF9: jmp 0x75bf0e */

}

void sub_00775C00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775C00u);

L_00775C00:
    ecx = MEM32(ebp + (-0x10)); /* 0x00775C00: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x138u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x138u; /* 0x00775C03: add ecx, 0x138 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00775C09: jmp 0x5cde60 */

}

void sub_00775C0E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775C0Eu);

    goto L_00775C0E;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775C0E:
    eax = 0x007E1238u; /* 0x00775C0E: mov eax, 0x7e1238 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775C13: jmp 0x75bf0e */

}

void sub_00775C20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775C20u);

L_00775C20:
    PUSH32(esp, 0); /* 0x00775C20: push 0 */
    PUSH32(esp, 0x007977F4u); /* 0x00775C22: push 0x7977f4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775C27: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775C2A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775C2B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775C30: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775C33: ret  */

}

void sub_00775C34(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775C34u);

    goto L_00775C34;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775C34:
    eax = 0x007E125Cu; /* 0x00775C34: mov eax, 0x7e125c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775C39: jmp 0x75bf0e */

}

void sub_00775C40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775C40u);

L_00775C40:
    PUSH32(esp, 0); /* 0x00775C40: push 0 */
    PUSH32(esp, 0x0079780Cu); /* 0x00775C42: push 0x79780c */
    eax = MEM32(ebp + (-0x10)); /* 0x00775C47: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775C4A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775C4B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775C50: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775C53: ret  */

}

void sub_00775C54(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775C54u);

    goto L_00775C54;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775C54:
    eax = 0x007E1280u; /* 0x00775C54: mov eax, 0x7e1280 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775C59: jmp 0x75bf0e */

}

void sub_00775C60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775C60u);

L_00775C60:
    PUSH32(esp, 0); /* 0x00775C60: push 0 */
    PUSH32(esp, 0x00797818u); /* 0x00775C62: push 0x797818 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775C67: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775C6A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775C6B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775C70: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775C73: ret  */

}

void sub_00775C74(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775C74u);

    goto L_00775C74;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775C74:
    eax = 0x007E12A4u; /* 0x00775C74: mov eax, 0x7e12a4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775C79: jmp 0x75bf0e */

}

void sub_00775C80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775C80u);

L_00775C80:
    PUSH32(esp, 0); /* 0x00775C80: push 0 */
    PUSH32(esp, 0x00797828u); /* 0x00775C82: push 0x797828 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775C87: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775C8A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775C8B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775C90: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775C93: ret  */

}

void sub_00775C94(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775C94u);

    goto L_00775C94;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775C94:
    eax = 0x007E12C8u; /* 0x00775C94: mov eax, 0x7e12c8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775C99: jmp 0x75bf0e */

}

void sub_00775CA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775CA0u);

L_00775CA0:
    PUSH32(esp, 0); /* 0x00775CA0: push 0 */
    PUSH32(esp, 0x0079783Cu); /* 0x00775CA2: push 0x79783c */
    eax = MEM32(ebp + (-0x10)); /* 0x00775CA7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775CAA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775CAB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775CB0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775CB3: ret  */

}

void sub_00775CB4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775CB4u);

    goto L_00775CB4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775CB4:
    eax = 0x007E12ECu; /* 0x00775CB4: mov eax, 0x7e12ec */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775CB9: jmp 0x75bf0e */

}

void sub_00775CC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775CC0u);

L_00775CC0:
    PUSH32(esp, 0); /* 0x00775CC0: push 0 */
    PUSH32(esp, 0x0079784Cu); /* 0x00775CC2: push 0x79784c */
    eax = MEM32(ebp + (-0x10)); /* 0x00775CC7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775CCA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775CCB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775CD0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775CD3: ret  */

}

void sub_00775CD4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775CD4u);

    goto L_00775CD4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775CD4:
    eax = 0x007E1310u; /* 0x00775CD4: mov eax, 0x7e1310 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775CD9: jmp 0x75bf0e */

}

void sub_00775CE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775CE0u);

L_00775CE0:
    PUSH32(esp, 0); /* 0x00775CE0: push 0 */
    PUSH32(esp, 0x007978B4u); /* 0x00775CE2: push 0x7978b4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775CE7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775CEA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775CEB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775CF0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775CF3: ret  */

}

void sub_00775CF4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775CF4u);

    goto L_00775CF4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775CF4:
    eax = 0x007E1334u; /* 0x00775CF4: mov eax, 0x7e1334 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775CF9: jmp 0x75bf0e */

}

void sub_00775D00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775D00u);

L_00775D00:
    ecx = MEM32(ebp + (-0x14)); /* 0x00775D00: mov ecx, dword ptr [ebp - 0x14] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00775D03: jmp 0x553a80 */

}

void sub_00775D08(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775D08u);

L_00775D08:
    ecx = MEM32(ebp + (-0x14)); /* 0x00775D08: mov ecx, dword ptr [ebp - 0x14] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4Cu; /* 0x00775D0B: add ecx, 0x4c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004CBAA0u); RECOMP_RETURN(); /* 0x00775D0E: jmp 0x4cbaa0 */

}

void sub_00775D13(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775D13u);

    goto L_00775D13;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775D13:
    eax = 0x007E1360u; /* 0x00775D13: mov eax, 0x7e1360 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775D18: jmp 0x75bf0e */

}

void sub_00775D20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775D20u);

L_00775D20:
    ecx = MEM32(ebp + (-0x904)); /* 0x00775D20: mov ecx, dword ptr [ebp - 0x904] */
    RECOMP_ITAIL(0x004DEF50u); RECOMP_RETURN(); /* 0x00775D26: jmp 0x4def50 */

}

void sub_00775D2B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775D2Bu);

L_00775D2B:
    ecx = MEM32(ebp + (-0x904)); /* 0x00775D2B: mov ecx, dword ptr [ebp - 0x904] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x150u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x150u; /* 0x00775D31: add ecx, 0x150 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0049D820u); RECOMP_RETURN(); /* 0x00775D37: jmp 0x49d820 */

}

void sub_00775D3C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775D3Cu);

L_00775D3C:
    ecx = ebp + (-0x8F0); /* 0x00775D3C: lea ecx, [ebp - 0x8f0] */
    RECOMP_ITAIL(0x00401830u); RECOMP_RETURN(); /* 0x00775D42: jmp 0x401830 */

}

void sub_00775D47(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775D47u);

L_00775D47:
    ecx = ebp + (-0x900); /* 0x00775D47: lea ecx, [ebp - 0x900] */
    RECOMP_ITAIL(0x0040BE20u); RECOMP_RETURN(); /* 0x00775D4D: jmp 0x40be20 */

}

void sub_00775D52(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775D52u);

    goto L_00775D52;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775D52:
    eax = 0x007E13C8u; /* 0x00775D52: mov eax, 0x7e13c8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775D57: jmp 0x75bf0e */

}

void sub_00775D60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775D60u);

L_00775D60:
    PUSH32(esp, 0); /* 0x00775D60: push 0 */
    PUSH32(esp, 0x00797964u); /* 0x00775D62: push 0x797964 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775D67: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775D6A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775D6B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775D70: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775D73: ret  */

}

void sub_00775D74(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775D74u);

    goto L_00775D74;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775D74:
    eax = 0x007E1418u; /* 0x00775D74: mov eax, 0x7e1418 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775D79: jmp 0x75bf0e */

}

void sub_00775D80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775D80u);

L_00775D80:
    PUSH32(esp, 0); /* 0x00775D80: push 0 */
    PUSH32(esp, 0x0079797Cu); /* 0x00775D82: push 0x79797c */
    eax = MEM32(ebp + (-0x10)); /* 0x00775D87: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775D8A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775D8B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775D90: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775D93: ret  */

}

void sub_00775D94(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775D94u);

    goto L_00775D94;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775D94:
    eax = 0x007E143Cu; /* 0x00775D94: mov eax, 0x7e143c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775D99: jmp 0x75bf0e */

}

void sub_00775DA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775DA0u);

L_00775DA0:
    ecx = MEM32(ebp + (-0x10)); /* 0x00775DA0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00775DA3: jmp 0x553a80 */

}

void sub_00775DA8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775DA8u);

L_00775DA8:
    ecx = MEM32(ebp + (-0x10)); /* 0x00775DA8: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x64u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x64u; /* 0x00775DAB: add ecx, 0x64 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004CBAA0u); RECOMP_RETURN(); /* 0x00775DAE: jmp 0x4cbaa0 */

}

void sub_00775DB3(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775DB3u);

L_00775DB3:
    ecx = MEM32(ebp + (-0x10)); /* 0x00775DB3: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x128u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x128u; /* 0x00775DB6: add ecx, 0x128 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00495660u); RECOMP_RETURN(); /* 0x00775DBC: jmp 0x495660 */

}

void sub_00775DC1(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775DC1u);

    goto L_00775DC1;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775DC1:
    eax = 0x007E06A4u; /* 0x00775DC1: mov eax, 0x7e06a4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775DC6: jmp 0x75bf0e */

}

void sub_00775DD0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775DD0u);

L_00775DD0:
    ecx = MEM32(ebp + (-0x28C)); /* 0x00775DD0: mov ecx, dword ptr [ebp - 0x28c] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00775DD6: jmp 0x553a80 */

}

void sub_00775DDB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775DDBu);

L_00775DDB:
    ecx = MEM32(ebp + (-0x28C)); /* 0x00775DDB: mov ecx, dword ptr [ebp - 0x28c] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x64u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x64u; /* 0x00775DE1: add ecx, 0x64 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004CBAA0u); RECOMP_RETURN(); /* 0x00775DE4: jmp 0x4cbaa0 */

}

void sub_00775DE9(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775DE9u);

    goto L_00775DE9;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775DE9:
    eax = 0x007E1468u; /* 0x00775DE9: mov eax, 0x7e1468 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775DEE: jmp 0x75bf0e */

}

void sub_00775E00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775E00u);

L_00775E00:
    ecx = MEM32(ebp + (-0x904)); /* 0x00775E00: mov ecx, dword ptr [ebp - 0x904] */
    RECOMP_ITAIL(0x004E2060u); RECOMP_RETURN(); /* 0x00775E06: jmp 0x4e2060 */

}

void sub_00775E0B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775E0Bu);

L_00775E0B:
    ecx = ebp + (-0x900); /* 0x00775E0B: lea ecx, [ebp - 0x900] */
    RECOMP_ITAIL(0x0040BE20u); RECOMP_RETURN(); /* 0x00775E11: jmp 0x40be20 */

}

void sub_00775E16(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775E16u);

    goto L_00775E16;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775E16:
    eax = 0x007E14C0u; /* 0x00775E16: mov eax, 0x7e14c0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775E1B: jmp 0x75bf0e */

}

void sub_00775E20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775E20u);

L_00775E20:
    PUSH32(esp, 0); /* 0x00775E20: push 0 */
    PUSH32(esp, 0x00797A40u); /* 0x00775E22: push 0x797a40 */
    eax = MEM32(ebp + (-0x10)); /* 0x00775E27: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00775E2A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775E2B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775E30: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775E33: ret  */

}

void sub_00775E34(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775E34u);

    goto L_00775E34;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775E34:
    eax = 0x007E14E4u; /* 0x00775E34: mov eax, 0x7e14e4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775E39: jmp 0x75bf0e */

}

void sub_00775E40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775E40u);

L_00775E40:
    ecx = MEM32(ebp + (-0x10)); /* 0x00775E40: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004958F0u); RECOMP_RETURN(); /* 0x00775E43: jmp 0x4958f0 */

}

void sub_00775E48(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775E48u);

L_00775E48:
    ecx = MEM32(ebp + (-0x10)); /* 0x00775E48: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x90u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x90u; /* 0x00775E4B: add ecx, 0x90 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00775E51: jmp 0x5cde60 */

}

void sub_00775E56(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775E56u);

    goto L_00775E56;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775E56:
    eax = 0x007E1510u; /* 0x00775E56: mov eax, 0x7e1510 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775E5B: jmp 0x75bf0e */

}

void sub_00775E60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775E60u);

L_00775E60:
    ecx = MEM32(ebp + (-0x10)); /* 0x00775E60: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x10u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x10u; /* 0x00775E63: add ecx, 0x10 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x00775E66: jmp 0x5ce0f0 */

}

void sub_00775E6B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775E6Bu);

    goto L_00775E6B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775E6B:
    eax = 0x007E1534u; /* 0x00775E6B: mov eax, 0x7e1534 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775E70: jmp 0x75bf0e */

}

void sub_00775E80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775E80u);

L_00775E80:
    PUSH32(esp, 0); /* 0x00775E80: push 0 */
    PUSH32(esp, 0x00797B40u); /* 0x00775E82: push 0x797b40 */
    eax = MEM32(ebp + 0x4); /* 0x00775E87: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00775E8A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775E8B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775E90: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775E93: ret  */

}

void sub_00775E94(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775E94u);

L_00775E94:
    PUSH32(esp, 0); /* 0x00775E94: push 0 */
    PUSH32(esp, 0x00797B2Cu); /* 0x00775E96: push 0x797b2c */
    eax = MEM32(ebp + 0x4); /* 0x00775E9B: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00775E9E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775E9F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775EA4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775EA7: ret  */

}

void sub_00775EA8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775EA8u);

L_00775EA8:
    PUSH32(esp, 0); /* 0x00775EA8: push 0 */
    PUSH32(esp, 0x00797B1Cu); /* 0x00775EAA: push 0x797b1c */
    eax = MEM32(ebp + 0x4); /* 0x00775EAF: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00775EB2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775EB3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775EB8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775EBB: ret  */

}

void sub_00775EBC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775EBCu);

L_00775EBC:
    PUSH32(esp, 0); /* 0x00775EBC: push 0 */
    PUSH32(esp, 0x00797B10u); /* 0x00775EBE: push 0x797b10 */
    eax = MEM32(ebp + 0x4); /* 0x00775EC3: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00775EC6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775EC7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775ECC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775ECF: ret  */

}

void sub_00775ED0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775ED0u);

L_00775ED0:
    PUSH32(esp, 0); /* 0x00775ED0: push 0 */
    PUSH32(esp, 0x00797B00u); /* 0x00775ED2: push 0x797b00 */
    eax = MEM32(ebp + 0x4); /* 0x00775ED7: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00775EDA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775EDB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775EE0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775EE3: ret  */

}

void sub_00775EE4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775EE4u);

L_00775EE4:
    PUSH32(esp, 0); /* 0x00775EE4: push 0 */
    PUSH32(esp, 0x00797AF0u); /* 0x00775EE6: push 0x797af0 */
    eax = MEM32(ebp + 0x4); /* 0x00775EEB: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00775EEE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775EEF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775EF4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775EF7: ret  */

}

void sub_00775EF8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775EF8u);

L_00775EF8:
    PUSH32(esp, 0); /* 0x00775EF8: push 0 */
    PUSH32(esp, 0x00797AE0u); /* 0x00775EFA: push 0x797ae0 */
    eax = MEM32(ebp + 0x4); /* 0x00775EFF: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00775F02: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775F03: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775F08: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775F0B: ret  */

}

void sub_00775F0C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775F0Cu);

L_00775F0C:
    PUSH32(esp, 0); /* 0x00775F0C: push 0 */
    PUSH32(esp, 0x00797B10u); /* 0x00775F0E: push 0x797b10 */
    eax = MEM32(ebp + 0x4); /* 0x00775F13: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00775F16: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775F17: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775F1C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775F1F: ret  */

}

void sub_00775F20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775F20u);

L_00775F20:
    PUSH32(esp, 0); /* 0x00775F20: push 0 */
    PUSH32(esp, 0x00797B00u); /* 0x00775F22: push 0x797b00 */
    eax = MEM32(ebp + 0x4); /* 0x00775F27: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00775F2A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775F2B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775F30: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775F33: ret  */

}

void sub_00775F34(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775F34u);

L_00775F34:
    PUSH32(esp, 0); /* 0x00775F34: push 0 */
    PUSH32(esp, 0x00797AD0u); /* 0x00775F36: push 0x797ad0 */
    eax = MEM32(ebp + 0x4); /* 0x00775F3B: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00775F3E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775F3F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775F44: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775F47: ret  */

}

void sub_00775F48(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775F48u);

L_00775F48:
    PUSH32(esp, 0); /* 0x00775F48: push 0 */
    PUSH32(esp, 0x00797AC0u); /* 0x00775F4A: push 0x797ac0 */
    eax = MEM32(ebp + 0x4); /* 0x00775F4F: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00775F52: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775F53: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775F58: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775F5B: ret  */

}

void sub_00775F5C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775F5Cu);

L_00775F5C:
    PUSH32(esp, 0); /* 0x00775F5C: push 0 */
    PUSH32(esp, 0x00797AB4u); /* 0x00775F5E: push 0x797ab4 */
    eax = MEM32(ebp + 0x4); /* 0x00775F63: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00775F66: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775F67: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00775F6C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00775F6F: ret  */

}

void sub_00775F70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775F70u);

    goto L_00775F70;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775F70:
    eax = 0x007E15B0u; /* 0x00775F70: mov eax, 0x7e15b0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775F75: jmp 0x75bf0e */

}

void sub_00775F80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775F80u);

L_00775F80:
    ecx = MEM32(ebp + (-0x10)); /* 0x00775F80: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00775F83: jmp 0x553a80 */

}

void sub_00775F88(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775F88u);

L_00775F88:
    ecx = MEM32(ebp + (-0x10)); /* 0x00775F88: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4Cu; /* 0x00775F8B: add ecx, 0x4c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00775F8E: jmp 0x5cde60 */

}

void sub_00775F93(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775F93u);

L_00775F93:
    ecx = MEM32(ebp + (-0x10)); /* 0x00775F93: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x70u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x70u; /* 0x00775F96: add ecx, 0x70 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0049D820u); RECOMP_RETURN(); /* 0x00775F99: jmp 0x49d820 */

}

void sub_00775F9E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775F9Eu);

    goto L_00775F9E;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775F9E:
    eax = 0x007E1D88u; /* 0x00775F9E: mov eax, 0x7e1d88 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775FA3: jmp 0x75bf0e */

}

void sub_00775FB0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775FB0u);

L_00775FB0:
    ecx = MEM32(ebp + (-0x10)); /* 0x00775FB0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004DEF50u); RECOMP_RETURN(); /* 0x00775FB3: jmp 0x4def50 */

}

void sub_00775FB8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775FB8u);

L_00775FB8:
    ecx = MEM32(ebp + (-0x10)); /* 0x00775FB8: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x160u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x160u; /* 0x00775FBB: add ecx, 0x160 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0050DAA0u); RECOMP_RETURN(); /* 0x00775FC1: jmp 0x50daa0 */

}

void sub_00775FC6(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775FC6u);

    goto L_00775FC6;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00775FC6:
    eax = 0x007E15DCu; /* 0x00775FC6: mov eax, 0x7e15dc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00775FCB: jmp 0x75bf0e */

}

void sub_00775FD0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775FD0u);

L_00775FD0:
    ecx = MEM32(ebp + (-0x10)); /* 0x00775FD0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00775FD3: jmp 0x553a80 */

}

void sub_00775FD8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775FD8u);

L_00775FD8:
    ecx = MEM32(ebp + (-0x10)); /* 0x00775FD8: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x6Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x6Cu; /* 0x00775FDB: add ecx, 0x6c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004C1940u); RECOMP_RETURN(); /* 0x00775FDE: jmp 0x4c1940 */

}

void sub_00775FE3(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775FE3u);

L_00775FE3:
    ecx = MEM32(ebp + (-0x10)); /* 0x00775FE3: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x23Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x23Cu; /* 0x00775FE6: add ecx, 0x23c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004C1680u); RECOMP_RETURN(); /* 0x00775FEC: jmp 0x4c1680 */

}

void sub_00775FF1(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00775FF1u);

L_00775FF1:
    PUSH32(esp, 0); /* 0x00775FF1: push 0 */
    PUSH32(esp, 0x00797C00u); /* 0x00775FF3: push 0x797c00 */
    eax = MEM32(ebp + 0x14); /* 0x00775FF8: mov eax, dword ptr [ebp + 0x14] */
    PUSH32(esp, eax); /* 0x00775FFB: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00775FFC: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776001: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776004: ret  */

}

void sub_00776005(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776005u);

L_00776005:
    PUSH32(esp, 0); /* 0x00776005: push 0 */
    PUSH32(esp, 0x00797BE8u); /* 0x00776007: push 0x797be8 */
    eax = MEM32(ebp + 0x14); /* 0x0077600C: mov eax, dword ptr [ebp + 0x14] */
    PUSH32(esp, eax); /* 0x0077600F: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776010: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776015: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776018: ret  */

}

void sub_00776019(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776019u);

L_00776019:
    PUSH32(esp, 0); /* 0x00776019: push 0 */
    PUSH32(esp, 0x00797BE8u); /* 0x0077601B: push 0x797be8 */
    eax = MEM32(ebp + 0x14); /* 0x00776020: mov eax, dword ptr [ebp + 0x14] */
    PUSH32(esp, eax); /* 0x00776023: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776024: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776029: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077602C: ret  */

}

void sub_0077602D(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077602Du);

L_0077602D:
    PUSH32(esp, 0); /* 0x0077602D: push 0 */
    PUSH32(esp, 0x00797BD0u); /* 0x0077602F: push 0x797bd0 */
    eax = MEM32(ebp + 0x14); /* 0x00776034: mov eax, dword ptr [ebp + 0x14] */
    PUSH32(esp, eax); /* 0x00776037: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776038: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077603D: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776040: ret  */

}

void sub_00776041(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776041u);

    goto L_00776041;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776041:
    eax = 0x007E1630u; /* 0x00776041: mov eax, 0x7e1630 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776046: jmp 0x75bf0e */

}

void sub_00776050(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776050u);

L_00776050:
    PUSH32(esp, 0); /* 0x00776050: push 0 */
    PUSH32(esp, 0x00797C68u); /* 0x00776052: push 0x797c68 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776057: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077605A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077605B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776060: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776063: ret  */

}

void sub_00776064(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776064u);

    goto L_00776064;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776064:
    eax = 0x007E1654u; /* 0x00776064: mov eax, 0x7e1654 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776069: jmp 0x75bf0e */

}

void sub_00776070(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776070u);

L_00776070:
    PUSH32(esp, 0); /* 0x00776070: push 0 */
    PUSH32(esp, 0x00797C7Cu); /* 0x00776072: push 0x797c7c */
    eax = MEM32(ebp + (-0x10)); /* 0x00776077: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077607A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077607B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776080: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776083: ret  */

}

void sub_00776084(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776084u);

    goto L_00776084;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776084:
    eax = 0x007E1678u; /* 0x00776084: mov eax, 0x7e1678 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776089: jmp 0x75bf0e */

}

void sub_00776090(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776090u);

L_00776090:
    PUSH32(esp, 0); /* 0x00776090: push 0 */
    PUSH32(esp, 0x00797CE8u); /* 0x00776092: push 0x797ce8 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776097: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077609A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077609B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007760A0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007760A3: ret  */

}

void sub_007760A4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007760A4u);

    goto L_007760A4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007760A4:
    eax = 0x007E169Cu; /* 0x007760A4: mov eax, 0x7e169c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007760A9: jmp 0x75bf0e */

}

void sub_007760B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007760B0u);

L_007760B0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007760B0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004DEF50u); RECOMP_RETURN(); /* 0x007760B3: jmp 0x4def50 */

}

void sub_007760B8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007760B8u);

    goto L_007760B8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007760B8:
    eax = 0x007E0EC8u; /* 0x007760B8: mov eax, 0x7e0ec8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007760BD: jmp 0x75bf0e */

}

void sub_007760D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007760D0u);

L_007760D0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007760D0: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x14u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x14u; /* 0x007760D3: add ecx, 0x14 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x007760D6: jmp 0x5ce0f0 */

}

void sub_007760DB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007760DBu);

    goto L_007760DB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007760DB:
    eax = 0x007E16C0u; /* 0x007760DB: mov eax, 0x7e16c0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007760E0: jmp 0x75bf0e */

}

void sub_007760F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007760F0u);

L_007760F0:
    eax = MEM32(ebp + (-0x10)); /* 0x007760F0: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007760F3: push eax */
    RECOMP_CALL(sub_004AC200); /* 0x007760F4: call 0x4ac200 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x007760F9: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007760FA: ret  */

}

void sub_007760FB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007760FBu);

    goto L_007760FB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007760FB:
    eax = 0x007E1708u; /* 0x007760FB: mov eax, 0x7e1708 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776100: jmp 0x75bf0e */

}

void sub_00776110(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776110u);

L_00776110:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776110: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004DEF10u); RECOMP_RETURN(); /* 0x00776113: jmp 0x4def10 */

}

void sub_00776118(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776118u);

    goto L_00776118;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776118:
    eax = 0x007E172Cu; /* 0x00776118: mov eax, 0x7e172c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077611D: jmp 0x75bf0e */

}

void sub_00776130(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776130u);

L_00776130:
    PUSH32(esp, 0); /* 0x00776130: push 0 */
    PUSH32(esp, 0x00797D60u); /* 0x00776132: push 0x797d60 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776137: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077613A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077613B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776140: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776143: ret  */

}

void sub_00776144(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776144u);

    goto L_00776144;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776144:
    eax = 0x007E1750u; /* 0x00776144: mov eax, 0x7e1750 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776149: jmp 0x75bf0e */

}

void sub_00776150(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776150u);

L_00776150:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776150: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00776153: jmp 0x553a80 */

}

void sub_00776158(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776158u);

L_00776158:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776158: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4Cu; /* 0x0077615B: add ecx, 0x4c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00490340u); RECOMP_RETURN(); /* 0x0077615E: jmp 0x490340 */

}

void sub_00776163(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776163u);

L_00776163:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776163: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x54u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x54u; /* 0x00776166: add ecx, 0x54 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00490340u); RECOMP_RETURN(); /* 0x00776169: jmp 0x490340 */

}

void sub_0077616E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077616Eu);

L_0077616E:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077616E: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x5Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x5Cu; /* 0x00776171: add ecx, 0x5c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00490340u); RECOMP_RETURN(); /* 0x00776174: jmp 0x490340 */

}

void sub_00776179(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776179u);

    goto L_00776179;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776179:
    eax = 0x007E178Cu; /* 0x00776179: mov eax, 0x7e178c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077617E: jmp 0x75bf0e */

}

void sub_00776190(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776190u);

L_00776190:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776190: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00776193: jmp 0x553a80 */

}

void sub_00776198(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776198u);

L_00776198:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776198: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4Cu; /* 0x0077619B: add ecx, 0x4c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00490340u); RECOMP_RETURN(); /* 0x0077619E: jmp 0x490340 */

}

void sub_007761A3(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007761A3u);

L_007761A3:
    ecx = MEM32(ebp + (-0x10)); /* 0x007761A3: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x54u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x54u; /* 0x007761A6: add ecx, 0x54 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00490340u); RECOMP_RETURN(); /* 0x007761A9: jmp 0x490340 */

}

void sub_007761AE(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007761AEu);

    goto L_007761AE;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007761AE:
    eax = 0x007E17C0u; /* 0x007761AE: mov eax, 0x7e17c0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007761B3: jmp 0x75bf0e */

}

void sub_007761C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007761C0u);

L_007761C0:
    PUSH32(esp, 0); /* 0x007761C0: push 0 */
    PUSH32(esp, 0x00797E10u); /* 0x007761C2: push 0x797e10 */
    eax = MEM32(ebp + (-0x10)); /* 0x007761C7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007761CA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007761CB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007761D0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007761D3: ret  */

}

void sub_007761D4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007761D4u);

    goto L_007761D4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007761D4:
    eax = 0x007E17E4u; /* 0x007761D4: mov eax, 0x7e17e4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007761D9: jmp 0x75bf0e */

}

void sub_007761E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007761E0u);

L_007761E0:
    PUSH32(esp, 0); /* 0x007761E0: push 0 */
    PUSH32(esp, 0x00797E18u); /* 0x007761E2: push 0x797e18 */
    eax = MEM32(ebp + (-0x10)); /* 0x007761E7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007761EA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007761EB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007761F0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007761F3: ret  */

}

void sub_007761F4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007761F4u);

    goto L_007761F4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007761F4:
    eax = 0x007E1808u; /* 0x007761F4: mov eax, 0x7e1808 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007761F9: jmp 0x75bf0e */

}

void sub_00776200(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776200u);

L_00776200:
    PUSH32(esp, 0); /* 0x00776200: push 0 */
    PUSH32(esp, 0x00797E28u); /* 0x00776202: push 0x797e28 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776207: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077620A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077620B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776210: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776213: ret  */

}

void sub_00776214(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776214u);

    goto L_00776214;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776214:
    eax = 0x007E182Cu; /* 0x00776214: mov eax, 0x7e182c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776219: jmp 0x75bf0e */

}

void sub_00776220(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776220u);

L_00776220:
    PUSH32(esp, 0); /* 0x00776220: push 0 */
    PUSH32(esp, 0x00797E38u); /* 0x00776222: push 0x797e38 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776227: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077622A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077622B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776230: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776233: ret  */

}

void sub_00776234(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776234u);

    goto L_00776234;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776234:
    eax = 0x007E1850u; /* 0x00776234: mov eax, 0x7e1850 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776239: jmp 0x75bf0e */

}

void sub_00776240(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776240u);

L_00776240:
    PUSH32(esp, 0); /* 0x00776240: push 0 */
    PUSH32(esp, 0x00797E50u); /* 0x00776242: push 0x797e50 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776247: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077624A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077624B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776250: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776253: ret  */

}

void sub_00776254(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776254u);

    goto L_00776254;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776254:
    eax = 0x007E1874u; /* 0x00776254: mov eax, 0x7e1874 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776259: jmp 0x75bf0e */

}

void sub_00776260(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776260u);

L_00776260:
    ecx = MEM32(ebp + (-0x1C)); /* 0x00776260: mov ecx, dword ptr [ebp - 0x1c] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00776263: jmp 0x553a80 */

}

void sub_00776268(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776268u);

L_00776268:
    ecx = MEM32(ebp + (-0x1C)); /* 0x00776268: mov ecx, dword ptr [ebp - 0x1c] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x54u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x54u; /* 0x0077626B: add ecx, 0x54 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x0077626E: jmp 0x5cde60 */

}

void sub_00776273(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776273u);

L_00776273:
    PUSH32(esp, 0); /* 0x00776273: push 0 */
    PUSH32(esp, 0x00797F04u); /* 0x00776275: push 0x797f04 */
    eax = MEM32(ebp + 0x8); /* 0x0077627A: mov eax, dword ptr [ebp + 8] */
    PUSH32(esp, eax); /* 0x0077627D: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077627E: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776283: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776286: ret  */

}

void sub_00776287(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776287u);

L_00776287:
    PUSH32(esp, 0); /* 0x00776287: push 0 */
    PUSH32(esp, 0x00797EF4u); /* 0x00776289: push 0x797ef4 */
    eax = MEM32(ebp + 0x8); /* 0x0077628E: mov eax, dword ptr [ebp + 8] */
    PUSH32(esp, eax); /* 0x00776291: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776292: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776297: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077629A: ret  */

}

void sub_0077629B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077629Bu);

L_0077629B:
    PUSH32(esp, 0); /* 0x0077629B: push 0 */
    PUSH32(esp, 0x00797EF4u); /* 0x0077629D: push 0x797ef4 */
    eax = MEM32(ebp + 0x8); /* 0x007762A2: mov eax, dword ptr [ebp + 8] */
    PUSH32(esp, eax); /* 0x007762A5: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007762A6: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007762AB: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007762AE: ret  */

}

void sub_007762AF(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007762AFu);

L_007762AF:
    PUSH32(esp, 0); /* 0x007762AF: push 0 */
    PUSH32(esp, 0x00797EE4u); /* 0x007762B1: push 0x797ee4 */
    eax = MEM32(ebp + (-0x18)); /* 0x007762B6: mov eax, dword ptr [ebp - 0x18] */
    PUSH32(esp, eax); /* 0x007762B9: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007762BA: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007762BF: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007762C2: ret  */

}

void sub_007762C3(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007762C3u);

L_007762C3:
    PUSH32(esp, 0); /* 0x007762C3: push 0 */
    PUSH32(esp, 0x00797ED0u); /* 0x007762C5: push 0x797ed0 */
    eax = MEM32(ebp + (-0x20)); /* 0x007762CA: mov eax, dword ptr [ebp - 0x20] */
    PUSH32(esp, eax); /* 0x007762CD: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007762CE: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007762D3: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007762D6: ret  */

}

void sub_007762D7(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007762D7u);

    goto L_007762D7;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007762D7:
    eax = 0x007E18C8u; /* 0x007762D7: mov eax, 0x7e18c8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007762DC: jmp 0x75bf0e */

}

void sub_007762F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007762F0u);

L_007762F0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007762F0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x007762F3: jmp 0x553a80 */

}

void sub_007762F8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007762F8u);

L_007762F8:
    ecx = MEM32(ebp + (-0x10)); /* 0x007762F8: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x8Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x8Cu; /* 0x007762FB: add ecx, 0x8c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004CBAA0u); RECOMP_RETURN(); /* 0x00776301: jmp 0x4cbaa0 */

}

void sub_00776306(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776306u);

L_00776306:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776306: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x138u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x138u; /* 0x00776309: add ecx, 0x138 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0052E930u); RECOMP_RETURN(); /* 0x0077630F: jmp 0x52e930 */

}

void sub_00776314(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776314u);

L_00776314:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776314: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x1F4u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x1F4u; /* 0x00776317: add ecx, 0x1f4 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00498560u); RECOMP_RETURN(); /* 0x0077631D: jmp 0x498560 */

}

void sub_00776322(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776322u);

    goto L_00776322;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776322:
    eax = 0x007E1904u; /* 0x00776322: mov eax, 0x7e1904 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776327: jmp 0x75bf0e */

}

void sub_00776330(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776330u);

L_00776330:
    ecx = MEM32(ebp + (-0x14)); /* 0x00776330: mov ecx, dword ptr [ebp - 0x14] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00776333: jmp 0x553a80 */

}

void sub_00776338(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776338u);

L_00776338:
    ecx = MEM32(ebp + (-0x14)); /* 0x00776338: mov ecx, dword ptr [ebp - 0x14] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4Cu; /* 0x0077633B: add ecx, 0x4c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004CC190u); RECOMP_RETURN(); /* 0x0077633E: jmp 0x4cc190 */

}

void sub_00776343(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776343u);

    goto L_00776343;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776343:
    eax = 0x007E1930u; /* 0x00776343: mov eax, 0x7e1930 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776348: jmp 0x75bf0e */

}

void sub_00776350(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776350u);

L_00776350:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776350: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00776353: jmp 0x553a80 */

}

void sub_00776358(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776358u);

    goto L_00776358;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776358:
    eax = 0x007DEE80u; /* 0x00776358: mov eax, 0x7dee80 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077635D: jmp 0x75bf0e */

}

void sub_00776370(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776370u);

L_00776370:
    PUSH32(esp, 0); /* 0x00776370: push 0 */
    PUSH32(esp, 0x00797FBCu); /* 0x00776372: push 0x797fbc */
    eax = MEM32(ebp + (-0x10)); /* 0x00776377: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077637A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077637B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776380: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776383: ret  */

}

void sub_00776384(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776384u);

    goto L_00776384;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776384:
    eax = 0x007E1954u; /* 0x00776384: mov eax, 0x7e1954 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776389: jmp 0x75bf0e */

}

void sub_00776390(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776390u);

L_00776390:
    PUSH32(esp, 0); /* 0x00776390: push 0 */
    PUSH32(esp, 0x00797FE8u); /* 0x00776392: push 0x797fe8 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776397: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077639A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077639B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007763A0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007763A3: ret  */

}

void sub_007763A4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007763A4u);

    goto L_007763A4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007763A4:
    eax = 0x007E1978u; /* 0x007763A4: mov eax, 0x7e1978 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007763A9: jmp 0x75bf0e */

}

void sub_007763B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007763B0u);

L_007763B0:
    ecx = ebp + (-0x900); /* 0x007763B0: lea ecx, [ebp - 0x900] */
    RECOMP_ITAIL(0x0040BE20u); RECOMP_RETURN(); /* 0x007763B6: jmp 0x40be20 */

}

void sub_007763BB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007763BBu);

L_007763BB:
    PUSH32(esp, 0); /* 0x007763BB: push 0 */
    PUSH32(esp, 0x00798004u); /* 0x007763BD: push 0x798004 */
    eax = MEM32(ebp + (-0x904)); /* 0x007763C2: mov eax, dword ptr [ebp - 0x904] */
    PUSH32(esp, eax); /* 0x007763C8: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007763C9: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007763CE: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007763D1: ret  */

}

void sub_007763D2(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007763D2u);

    goto L_007763D2;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007763D2:
    eax = 0x007E19A4u; /* 0x007763D2: mov eax, 0x7e19a4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007763D7: jmp 0x75bf0e */

}

void sub_007763E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007763E0u);

L_007763E0:
    PUSH32(esp, 0); /* 0x007763E0: push 0 */
    PUSH32(esp, 0x00798028u); /* 0x007763E2: push 0x798028 */
    eax = MEM32(ebp + (-0x10)); /* 0x007763E7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007763EA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007763EB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007763F0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007763F3: ret  */

}

void sub_007763F4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007763F4u);

    goto L_007763F4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007763F4:
    eax = 0x007E19C8u; /* 0x007763F4: mov eax, 0x7e19c8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007763F9: jmp 0x75bf0e */

}

void sub_00776400(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776400u);

L_00776400:
    PUSH32(esp, 0); /* 0x00776400: push 0 */
    PUSH32(esp, 0x00798038u); /* 0x00776402: push 0x798038 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776407: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077640A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077640B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776410: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776413: ret  */

}

void sub_00776414(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776414u);

    goto L_00776414;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776414:
    eax = 0x007E19ECu; /* 0x00776414: mov eax, 0x7e19ec */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776419: jmp 0x75bf0e */

}

void sub_00776420(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776420u);

L_00776420:
    PUSH32(esp, 0); /* 0x00776420: push 0 */
    PUSH32(esp, 0x00798044u); /* 0x00776422: push 0x798044 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776427: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077642A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077642B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776430: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776433: ret  */

}

void sub_00776434(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776434u);

    goto L_00776434;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776434:
    eax = 0x007E1A10u; /* 0x00776434: mov eax, 0x7e1a10 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776439: jmp 0x75bf0e */

}

void sub_00776440(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776440u);

L_00776440:
    PUSH32(esp, 0); /* 0x00776440: push 0 */
    PUSH32(esp, 0x00798054u); /* 0x00776442: push 0x798054 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776447: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077644A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077644B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776450: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776453: ret  */

}