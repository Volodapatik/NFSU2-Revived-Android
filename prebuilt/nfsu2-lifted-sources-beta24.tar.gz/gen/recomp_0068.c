/* AUTO-GENERATED from SPEED2.analysis.exe by run_lift.py (pcrecomp lift32). DO NOT EDIT, DO NOT COMMIT. */
#define RECOMP_GENERATED_CODE
#include "recomp_types.h"
#include "recomp_funcs.h"
#include "guest_render_probe.h"
#include <math.h>
#include <string.h>

void sub_0077F9C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F9C0u);

L_0077F9C0:
    fp_push(*(float*)&MEM32(0x7C0648)); /* 0x0077F9C0: fld dword ptr [0x7c0648] */
    _st[0] += _st[0]; /* 0x0077F9C6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A7204) = _v; } /* 0x0077F9C8: fstp dword ptr [0x8a7204] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F9CE: ret  */

}

void sub_0077F9D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F9D0u);

L_0077F9D0:
    fp_push(*(float*)&MEM32(0x7C0648)); /* 0x0077F9D0: fld dword ptr [0x7c0648] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x0077F9D6: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A7200) = _v; } /* 0x0077F9DC: fstp dword ptr [0x8a7200] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F9E2: ret  */

}

void sub_0077F9F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F9F0u);

L_0077F9F0:
    fp_push(*(double*)ADDR(0x7C0650)); /* 0x0077F9F0: fld qword ptr [0x7c0650] */
    _st[0] += _st[0]; /* 0x0077F9F6: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8A71F8) = _v; } /* 0x0077F9F8: fstp qword ptr [0x8a71f8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F9FE: ret  */

}

void sub_0077FA00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FA00u);

L_0077FA00:
    fp_push(*(double*)ADDR(0x7C0650)); /* 0x0077FA00: fld qword ptr [0x7c0650] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x0077FA06: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8A71F0) = _v; } /* 0x0077FA0C: fstp qword ptr [0x8a71f0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FA12: ret  */

}

void sub_0077FA20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FA20u);

L_0077FA20:
    fp_push(*(float*)&MEM32(0x7C0658)); /* 0x0077FA20: fld dword ptr [0x7c0658] */
    _st[0] += _st[0]; /* 0x0077FA26: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A721C) = _v; } /* 0x0077FA28: fstp dword ptr [0x8a721c] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FA2E: ret  */

}

void sub_0077FA30(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FA30u);

L_0077FA30:
    fp_push(*(float*)&MEM32(0x7C0658)); /* 0x0077FA30: fld dword ptr [0x7c0658] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x0077FA36: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A7218) = _v; } /* 0x0077FA3C: fstp dword ptr [0x8a7218] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FA42: ret  */

}

void sub_0077FA50(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FA50u);

L_0077FA50:
    fp_push(*(double*)ADDR(0x7C0660)); /* 0x0077FA50: fld qword ptr [0x7c0660] */
    _st[0] += _st[0]; /* 0x0077FA56: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8A7210) = _v; } /* 0x0077FA58: fstp qword ptr [0x8a7210] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FA5E: ret  */

}

void sub_0077FA60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FA60u);

L_0077FA60:
    fp_push(*(double*)ADDR(0x7C0660)); /* 0x0077FA60: fld qword ptr [0x7c0660] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x0077FA66: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8A7208) = _v; } /* 0x0077FA6C: fstp qword ptr [0x8a7208] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FA72: ret  */

}

void sub_0077FA80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FA80u);

L_0077FA80:
    fp_push(*(float*)&MEM32(0x7C0668)); /* 0x0077FA80: fld dword ptr [0x7c0668] */
    _st[0] += _st[0]; /* 0x0077FA86: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A7304) = _v; } /* 0x0077FA88: fstp dword ptr [0x8a7304] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FA8E: ret  */

}

void sub_0077FA90(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FA90u);

L_0077FA90:
    fp_push(*(float*)&MEM32(0x7C0668)); /* 0x0077FA90: fld dword ptr [0x7c0668] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x0077FA96: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A7300) = _v; } /* 0x0077FA9C: fstp dword ptr [0x8a7300] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FAA2: ret  */

}

void sub_0077FAB0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FAB0u);

L_0077FAB0:
    fp_push(*(double*)ADDR(0x7C0670)); /* 0x0077FAB0: fld qword ptr [0x7c0670] */
    _st[0] += _st[0]; /* 0x0077FAB6: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8A72F8) = _v; } /* 0x0077FAB8: fstp qword ptr [0x8a72f8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FABE: ret  */

}

void sub_0077FAC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FAC0u);

L_0077FAC0:
    fp_push(*(double*)ADDR(0x7C0670)); /* 0x0077FAC0: fld qword ptr [0x7c0670] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x0077FAC6: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8A72F0) = _v; } /* 0x0077FACC: fstp qword ptr [0x8a72f0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FAD2: ret  */

}

void sub_0077FAE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FAE0u);

L_0077FAE0:
    fp_push(*(float*)&MEM32(0x7C0780)); /* 0x0077FAE0: fld dword ptr [0x7c0780] */
    _st[0] += _st[0]; /* 0x0077FAE6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A79DC) = _v; } /* 0x0077FAE8: fstp dword ptr [0x8a79dc] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FAEE: ret  */

}

void sub_0077FAF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FAF0u);

L_0077FAF0:
    fp_push(*(float*)&MEM32(0x7C0780)); /* 0x0077FAF0: fld dword ptr [0x7c0780] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x0077FAF6: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A79D8) = _v; } /* 0x0077FAFC: fstp dword ptr [0x8a79d8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FB02: ret  */

}

void sub_0077FB10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FB10u);

L_0077FB10:
    fp_push(*(double*)ADDR(0x7C0788)); /* 0x0077FB10: fld qword ptr [0x7c0788] */
    _st[0] += _st[0]; /* 0x0077FB16: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8A79D0) = _v; } /* 0x0077FB18: fstp qword ptr [0x8a79d0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FB1E: ret  */

}

void sub_0077FB20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FB20u);

L_0077FB20:
    fp_push(*(double*)ADDR(0x7C0788)); /* 0x0077FB20: fld qword ptr [0x7c0788] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x0077FB26: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8A79C8) = _v; } /* 0x0077FB2C: fstp qword ptr [0x8a79c8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FB32: ret  */

}

void sub_0077FB40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FB40u);

L_0077FB40:
    PUSH32(esp, esi); /* 0x0077FB40: push esi */
    esi = MEM32(0x783134); /* 0x0077FB41: mov esi, dword ptr [0x783134] */
    PUSH32(esp, 0); /* 0x0077FB47: push 0 */
    RECOMP_ICALL(esi); /* 0x0077FB49: call esi */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x7F00u); /* 0x0077FB4B: push 0x7f00 */
    PUSH32(esp, 0); /* 0x0077FB50: push 0 */
    MEM32(0x80C0CC) = eax; /* 0x0077FB52: mov dword ptr [0x80c0cc], eax */
    RECOMP_ICALL(esi); /* 0x0077FB57: call esi */
    RECOMP_FLAGS_IN();
    PUSH32(esp, eax); /* 0x0077FB59: push eax */
    RECOMP_ICALL(MEM32(0x783334)); /* 0x0077FB5A: call dword ptr [0x783334] */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x7F00u); /* 0x0077FB60: push 0x7f00 */
    PUSH32(esp, 0); /* 0x0077FB65: push 0 */
    MEM32(0x80C0D0) = eax; /* 0x0077FB67: mov dword ptr [0x80c0d0], eax */
    RECOMP_ICALL(MEM32(0x783338)); /* 0x0077FB6C: call dword ptr [0x783338] */
    RECOMP_FLAGS_IN();
    MEM32(0x80C0D4) = eax; /* 0x0077FB72: mov dword ptr [0x80c0d4], eax */
    MEM32(0x80C0D8) = 0; /* 0x0077FB77: mov dword ptr [0x80c0d8], 0 */
    MEM32(0x80C0DC) = 0; /* 0x0077FB81: mov dword ptr [0x80c0dc], 0 */
    MEM32(0x80C0E0) = 0x007C08FCu; /* 0x0077FB8B: mov dword ptr [0x80c0e0], 0x7c08fc */
    MEM32(0x80C0E4) = 0; /* 0x0077FB95: mov dword ptr [0x80c0e4], 0 */
    esi = POP32_VAL(esp); /* 0x0077FB9F: pop esi */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FBA0: ret  */

}

void sub_0077FBB0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FBB0u);

L_0077FBB0:
    fp_push(*(float*)&MEM32(0x7C0978)); /* 0x0077FBB0: fld dword ptr [0x7c0978] */
    _st[0] += _st[0]; /* 0x0077FBB6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A79F4) = _v; } /* 0x0077FBB8: fstp dword ptr [0x8a79f4] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FBBE: ret  */

}

void sub_0077FBC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FBC0u);

L_0077FBC0:
    fp_push(*(float*)&MEM32(0x7C0978)); /* 0x0077FBC0: fld dword ptr [0x7c0978] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x0077FBC6: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A79F0) = _v; } /* 0x0077FBCC: fstp dword ptr [0x8a79f0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FBD2: ret  */

}

void sub_0077FBE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FBE0u);

L_0077FBE0:
    fp_push(*(double*)ADDR(0x7C0980)); /* 0x0077FBE0: fld qword ptr [0x7c0980] */
    _st[0] += _st[0]; /* 0x0077FBE6: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8A79E8) = _v; } /* 0x0077FBE8: fstp qword ptr [0x8a79e8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FBEE: ret  */

}

void sub_0077FBF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FBF0u);

L_0077FBF0:
    fp_push(*(double*)ADDR(0x7C0980)); /* 0x0077FBF0: fld qword ptr [0x7c0980] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x0077FBF6: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8A79E0) = _v; } /* 0x0077FBFC: fstp qword ptr [0x8a79e0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FC02: ret  */

}

void sub_0077FC10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FC10u);

L_0077FC10:
    fp_push(*(float*)&MEM32(0x7C0990)); /* 0x0077FC10: fld dword ptr [0x7c0990] */
    _st[0] += _st[0]; /* 0x0077FC16: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A7A0C) = _v; } /* 0x0077FC18: fstp dword ptr [0x8a7a0c] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FC1E: ret  */

}

void sub_0077FC20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FC20u);

L_0077FC20:
    fp_push(*(float*)&MEM32(0x7C0990)); /* 0x0077FC20: fld dword ptr [0x7c0990] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x0077FC26: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A7A08) = _v; } /* 0x0077FC2C: fstp dword ptr [0x8a7a08] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FC32: ret  */

}

void sub_0077FC40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FC40u);

L_0077FC40:
    fp_push(*(double*)ADDR(0x7C0998)); /* 0x0077FC40: fld qword ptr [0x7c0998] */
    _st[0] += _st[0]; /* 0x0077FC46: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8A7A00) = _v; } /* 0x0077FC48: fstp qword ptr [0x8a7a00] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FC4E: ret  */

}

void sub_0077FC50(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FC50u);

L_0077FC50:
    fp_push(*(double*)ADDR(0x7C0998)); /* 0x0077FC50: fld qword ptr [0x7c0998] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x0077FC56: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8A79F8) = _v; } /* 0x0077FC5C: fstp qword ptr [0x8a79f8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FC62: ret  */

}

void sub_0077FC70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FC70u);

L_0077FC70:
    fp_push(*(float*)&MEM32(0x7C09A8)); /* 0x0077FC70: fld dword ptr [0x7c09a8] */
    _st[0] += _st[0]; /* 0x0077FC76: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A7AA4) = _v; } /* 0x0077FC78: fstp dword ptr [0x8a7aa4] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FC7E: ret  */

}

void sub_0077FC80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FC80u);

L_0077FC80:
    fp_push(*(float*)&MEM32(0x7C09A8)); /* 0x0077FC80: fld dword ptr [0x7c09a8] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x0077FC86: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A7AA0) = _v; } /* 0x0077FC8C: fstp dword ptr [0x8a7aa0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FC92: ret  */

}

void sub_0077FCA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FCA0u);

L_0077FCA0:
    fp_push(*(double*)ADDR(0x7C09B0)); /* 0x0077FCA0: fld qword ptr [0x7c09b0] */
    _st[0] += _st[0]; /* 0x0077FCA6: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8A7A98) = _v; } /* 0x0077FCA8: fstp qword ptr [0x8a7a98] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FCAE: ret  */

}

void sub_0077FCB0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FCB0u);

L_0077FCB0:
    fp_push(*(double*)ADDR(0x7C09B0)); /* 0x0077FCB0: fld qword ptr [0x7c09b0] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x0077FCB6: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8A7A90) = _v; } /* 0x0077FCBC: fstp qword ptr [0x8a7a90] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FCC2: ret  */

}

void sub_0077FCD0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FCD0u);

L_0077FCD0:
    fp_push(*(float*)&MEM32(0x7C0AB8)); /* 0x0077FCD0: fld dword ptr [0x7c0ab8] */
    _st[0] += _st[0]; /* 0x0077FCD6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A7ABC) = _v; } /* 0x0077FCD8: fstp dword ptr [0x8a7abc] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FCDE: ret  */

}

void sub_0077FCE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FCE0u);

L_0077FCE0:
    fp_push(*(float*)&MEM32(0x7C0AB8)); /* 0x0077FCE0: fld dword ptr [0x7c0ab8] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x0077FCE6: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A7AB8) = _v; } /* 0x0077FCEC: fstp dword ptr [0x8a7ab8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FCF2: ret  */

}

void sub_0077FD00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FD00u);

L_0077FD00:
    fp_push(*(double*)ADDR(0x7C0AC0)); /* 0x0077FD00: fld qword ptr [0x7c0ac0] */
    _st[0] += _st[0]; /* 0x0077FD06: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8A7AB0) = _v; } /* 0x0077FD08: fstp qword ptr [0x8a7ab0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FD0E: ret  */

}

void sub_0077FD10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FD10u);

L_0077FD10:
    fp_push(*(double*)ADDR(0x7C0AC0)); /* 0x0077FD10: fld qword ptr [0x7c0ac0] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x0077FD16: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8A7AA8) = _v; } /* 0x0077FD1C: fstp qword ptr [0x8a7aa8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FD22: ret  */

}

void sub_0077FD30(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FD30u);

L_0077FD30:
    fp_push(*(float*)&MEM32(0x7C0AC8)); /* 0x0077FD30: fld dword ptr [0x7c0ac8] */
    _st[0] += _st[0]; /* 0x0077FD36: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A7B2C) = _v; } /* 0x0077FD38: fstp dword ptr [0x8a7b2c] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FD3E: ret  */

}

void sub_0077FD40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FD40u);

L_0077FD40:
    fp_push(*(float*)&MEM32(0x7C0AC8)); /* 0x0077FD40: fld dword ptr [0x7c0ac8] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x0077FD46: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A7B28) = _v; } /* 0x0077FD4C: fstp dword ptr [0x8a7b28] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FD52: ret  */

}

void sub_0077FD60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FD60u);

L_0077FD60:
    fp_push(*(double*)ADDR(0x7C0AD0)); /* 0x0077FD60: fld qword ptr [0x7c0ad0] */
    _st[0] += _st[0]; /* 0x0077FD66: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8A7B20) = _v; } /* 0x0077FD68: fstp qword ptr [0x8a7b20] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FD6E: ret  */

}

void sub_0077FD70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FD70u);

L_0077FD70:
    fp_push(*(double*)ADDR(0x7C0AD0)); /* 0x0077FD70: fld qword ptr [0x7c0ad0] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x0077FD76: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8A7B18) = _v; } /* 0x0077FD7C: fstp qword ptr [0x8a7b18] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FD82: ret  */

}

void sub_0077FD90(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FD90u);

L_0077FD90:
    fp_push(*(float*)&MEM32(0x7C0BE0)); /* 0x0077FD90: fld dword ptr [0x7c0be0] */
    _st[0] += _st[0]; /* 0x0077FD96: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A7B8C) = _v; } /* 0x0077FD98: fstp dword ptr [0x8a7b8c] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FD9E: ret  */

}

void sub_0077FDA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FDA0u);

L_0077FDA0:
    fp_push(*(float*)&MEM32(0x7C0BE0)); /* 0x0077FDA0: fld dword ptr [0x7c0be0] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x0077FDA6: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A7B88) = _v; } /* 0x0077FDAC: fstp dword ptr [0x8a7b88] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FDB2: ret  */

}

void sub_0077FDC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FDC0u);

L_0077FDC0:
    fp_push(*(double*)ADDR(0x7C0BE8)); /* 0x0077FDC0: fld qword ptr [0x7c0be8] */
    _st[0] += _st[0]; /* 0x0077FDC6: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8A7B80) = _v; } /* 0x0077FDC8: fstp qword ptr [0x8a7b80] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FDCE: ret  */

}

void sub_0077FDD0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FDD0u);

L_0077FDD0:
    fp_push(*(double*)ADDR(0x7C0BE8)); /* 0x0077FDD0: fld qword ptr [0x7c0be8] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x0077FDD6: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8A7B78) = _v; } /* 0x0077FDDC: fstp qword ptr [0x8a7b78] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FDE2: ret  */

}

void sub_0077FDF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FDF0u);

L_0077FDF0:
    fp_push(*(float*)&MEM32(0x7C0BF8)); /* 0x0077FDF0: fld dword ptr [0x7c0bf8] */
    _st[0] += _st[0]; /* 0x0077FDF6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A7BAC) = _v; } /* 0x0077FDF8: fstp dword ptr [0x8a7bac] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FDFE: ret  */

}

void sub_0077FE00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FE00u);

L_0077FE00:
    fp_push(*(float*)&MEM32(0x7C0BF8)); /* 0x0077FE00: fld dword ptr [0x7c0bf8] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x0077FE06: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A7BA8) = _v; } /* 0x0077FE0C: fstp dword ptr [0x8a7ba8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FE12: ret  */

}

void sub_0077FE20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FE20u);

L_0077FE20:
    fp_push(*(double*)ADDR(0x7C0C00)); /* 0x0077FE20: fld qword ptr [0x7c0c00] */
    _st[0] += _st[0]; /* 0x0077FE26: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8A7BA0) = _v; } /* 0x0077FE28: fstp qword ptr [0x8a7ba0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FE2E: ret  */

}

void sub_0077FE30(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FE30u);

L_0077FE30:
    fp_push(*(double*)ADDR(0x7C0C00)); /* 0x0077FE30: fld qword ptr [0x7c0c00] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x0077FE36: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8A7B98) = _v; } /* 0x0077FE3C: fstp qword ptr [0x8a7b98] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FE42: ret  */

}

void sub_0077FE50(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FE50u);

L_0077FE50:
    fp_push(*(float*)&MEM32(0x7C0D10)); /* 0x0077FE50: fld dword ptr [0x7c0d10] */
    _st[0] += _st[0]; /* 0x0077FE56: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A7BC4) = _v; } /* 0x0077FE58: fstp dword ptr [0x8a7bc4] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FE5E: ret  */

}

void sub_0077FE60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FE60u);

L_0077FE60:
    fp_push(*(float*)&MEM32(0x7C0D10)); /* 0x0077FE60: fld dword ptr [0x7c0d10] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x0077FE66: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A7BC0) = _v; } /* 0x0077FE6C: fstp dword ptr [0x8a7bc0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FE72: ret  */

}

void sub_0077FE80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FE80u);

L_0077FE80:
    fp_push(*(double*)ADDR(0x7C0D18)); /* 0x0077FE80: fld qword ptr [0x7c0d18] */
    _st[0] += _st[0]; /* 0x0077FE86: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8A7BB8) = _v; } /* 0x0077FE88: fstp qword ptr [0x8a7bb8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FE8E: ret  */

}

void sub_0077FE90(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FE90u);

L_0077FE90:
    fp_push(*(double*)ADDR(0x7C0D18)); /* 0x0077FE90: fld qword ptr [0x7c0d18] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x0077FE96: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8A7BB0) = _v; } /* 0x0077FE9C: fstp qword ptr [0x8a7bb0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FEA2: ret  */

}

void sub_0077FEB0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FEB0u);

L_0077FEB0:
    fp_push(*(float*)&MEM32(0x7C0D20)); /* 0x0077FEB0: fld dword ptr [0x7c0d20] */
    _st[0] += _st[0]; /* 0x0077FEB6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A7BF4) = _v; } /* 0x0077FEB8: fstp dword ptr [0x8a7bf4] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FEBE: ret  */

}

void sub_0077FEC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FEC0u);

L_0077FEC0:
    fp_push(*(float*)&MEM32(0x7C0D20)); /* 0x0077FEC0: fld dword ptr [0x7c0d20] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x0077FEC6: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A7BF0) = _v; } /* 0x0077FECC: fstp dword ptr [0x8a7bf0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FED2: ret  */

}

void sub_0077FEE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FEE0u);

L_0077FEE0:
    fp_push(*(double*)ADDR(0x7C0D28)); /* 0x0077FEE0: fld qword ptr [0x7c0d28] */
    _st[0] += _st[0]; /* 0x0077FEE6: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8A7BE8) = _v; } /* 0x0077FEE8: fstp qword ptr [0x8a7be8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FEEE: ret  */

}

void sub_0077FEF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FEF0u);

L_0077FEF0:
    fp_push(*(double*)ADDR(0x7C0D28)); /* 0x0077FEF0: fld qword ptr [0x7c0d28] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x0077FEF6: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8A7BE0) = _v; } /* 0x0077FEFC: fstp qword ptr [0x8a7be0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FF02: ret  */

}

void sub_0077FF10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FF10u);

L_0077FF10:
    fp_push(*(float*)&MEM32(0x7C0D30)); /* 0x0077FF10: fld dword ptr [0x7c0d30] */
    _st[0] += _st[0]; /* 0x0077FF16: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A7E34) = _v; } /* 0x0077FF18: fstp dword ptr [0x8a7e34] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FF1E: ret  */

}

void sub_0077FF20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FF20u);

L_0077FF20:
    fp_push(*(float*)&MEM32(0x7C0D30)); /* 0x0077FF20: fld dword ptr [0x7c0d30] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x0077FF26: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A7E30) = _v; } /* 0x0077FF2C: fstp dword ptr [0x8a7e30] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FF32: ret  */

}

void sub_0077FF40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FF40u);

L_0077FF40:
    fp_push(*(double*)ADDR(0x7C0D38)); /* 0x0077FF40: fld qword ptr [0x7c0d38] */
    _st[0] += _st[0]; /* 0x0077FF46: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8A7E28) = _v; } /* 0x0077FF48: fstp qword ptr [0x8a7e28] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FF4E: ret  */

}

void sub_0077FF50(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FF50u);

L_0077FF50:
    fp_push(*(double*)ADDR(0x7C0D38)); /* 0x0077FF50: fld qword ptr [0x7c0d38] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x0077FF56: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8A7E20) = _v; } /* 0x0077FF5C: fstp qword ptr [0x8a7e20] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FF62: ret  */

}

void sub_0077FF70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FF70u);

L_0077FF70:
    ecx = 0x008A7BF8u; /* 0x0077FF70: mov ecx, 0x8a7bf8 */
    RECOMP_CALL(sub_006DD220); /* 0x0077FF75: call 0x6dd220 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782840u); /* 0x0077FF7A: push 0x782840 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077FF7F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077FF84: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FF85: ret  */

}

void sub_0077FF90(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FF90u);

L_0077FF90:
    ecx = 0x008A7E38u; /* 0x0077FF90: mov ecx, 0x8a7e38 */
    RECOMP_CALL(sub_006DD220); /* 0x0077FF95: call 0x6dd220 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782850u); /* 0x0077FF9A: push 0x782850 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077FF9F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077FFA4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FFA5: ret  */

}

void sub_0077FFB0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FFB0u);

L_0077FFB0:
    fp_push(*(float*)&MEM32(0x7C0E50)); /* 0x0077FFB0: fld dword ptr [0x7c0e50] */
    _st[0] += _st[0]; /* 0x0077FFB6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A80EC) = _v; } /* 0x0077FFB8: fstp dword ptr [0x8a80ec] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FFBE: ret  */

}

void sub_0077FFC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FFC0u);

L_0077FFC0:
    fp_push(*(float*)&MEM32(0x7C0E50)); /* 0x0077FFC0: fld dword ptr [0x7c0e50] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x0077FFC6: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A80E8) = _v; } /* 0x0077FFCC: fstp dword ptr [0x8a80e8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FFD2: ret  */

}

void sub_0077FFE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FFE0u);

L_0077FFE0:
    fp_push(*(double*)ADDR(0x7C0E58)); /* 0x0077FFE0: fld qword ptr [0x7c0e58] */
    _st[0] += _st[0]; /* 0x0077FFE6: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8A80E0) = _v; } /* 0x0077FFE8: fstp qword ptr [0x8a80e0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077FFEE: ret  */

}

void sub_0077FFF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077FFF0u);

L_0077FFF0:
    fp_push(*(double*)ADDR(0x7C0E58)); /* 0x0077FFF0: fld qword ptr [0x7c0e58] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x0077FFF6: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8A80D8) = _v; } /* 0x0077FFFC: fstp qword ptr [0x8a80d8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780002: ret  */

}

void sub_00780010(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780010u);

L_00780010:
    fp_push(*(float*)&MEM32(0x7C0E60)); /* 0x00780010: fld dword ptr [0x7c0e60] */
    _st[0] += _st[0]; /* 0x00780016: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A812C) = _v; } /* 0x00780018: fstp dword ptr [0x8a812c] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078001E: ret  */

}

void sub_00780020(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780020u);

L_00780020:
    fp_push(*(float*)&MEM32(0x7C0E60)); /* 0x00780020: fld dword ptr [0x7c0e60] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00780026: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A8128) = _v; } /* 0x0078002C: fstp dword ptr [0x8a8128] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780032: ret  */

}

void sub_00780040(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780040u);

L_00780040:
    fp_push(*(double*)ADDR(0x7C0E68)); /* 0x00780040: fld qword ptr [0x7c0e68] */
    _st[0] += _st[0]; /* 0x00780046: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8A8120) = _v; } /* 0x00780048: fstp qword ptr [0x8a8120] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078004E: ret  */

}

void sub_00780050(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780050u);

L_00780050:
    fp_push(*(double*)ADDR(0x7C0E68)); /* 0x00780050: fld qword ptr [0x7c0e68] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00780056: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8A8118) = _v; } /* 0x0078005C: fstp qword ptr [0x8a8118] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780062: ret  */

}

void sub_00780070(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780070u);

L_00780070:
    fp_push(*(float*)&MEM32(0x7C0E80)); /* 0x00780070: fld dword ptr [0x7c0e80] */
    _st[0] += _st[0]; /* 0x00780076: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A814C) = _v; } /* 0x00780078: fstp dword ptr [0x8a814c] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078007E: ret  */

}

void sub_00780080(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780080u);

L_00780080:
    fp_push(*(float*)&MEM32(0x7C0E80)); /* 0x00780080: fld dword ptr [0x7c0e80] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00780086: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A8148) = _v; } /* 0x0078008C: fstp dword ptr [0x8a8148] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780092: ret  */

}

void sub_007800A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007800A0u);

L_007800A0:
    fp_push(*(double*)ADDR(0x7C0E88)); /* 0x007800A0: fld qword ptr [0x7c0e88] */
    _st[0] += _st[0]; /* 0x007800A6: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8A8140) = _v; } /* 0x007800A8: fstp qword ptr [0x8a8140] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007800AE: ret  */

}

void sub_007800B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007800B0u);

L_007800B0:
    fp_push(*(double*)ADDR(0x7C0E88)); /* 0x007800B0: fld qword ptr [0x7c0e88] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x007800B6: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8A8138) = _v; } /* 0x007800BC: fstp qword ptr [0x8a8138] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007800C2: ret  */

}

void sub_007800D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007800D0u);

L_007800D0:
    fp_push(*(float*)&MEM32(0x7C0E98)); /* 0x007800D0: fld dword ptr [0x7c0e98] */
    _st[0] += _st[0]; /* 0x007800D6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A838C) = _v; } /* 0x007800D8: fstp dword ptr [0x8a838c] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007800DE: ret  */

}

void sub_007800E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007800E0u);

L_007800E0:
    fp_push(*(float*)&MEM32(0x7C0E98)); /* 0x007800E0: fld dword ptr [0x7c0e98] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x007800E6: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A8388) = _v; } /* 0x007800EC: fstp dword ptr [0x8a8388] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007800F2: ret  */

}

void sub_00780100(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780100u);

L_00780100:
    fp_push(*(double*)ADDR(0x7C0EA0)); /* 0x00780100: fld qword ptr [0x7c0ea0] */
    _st[0] += _st[0]; /* 0x00780106: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8A8380) = _v; } /* 0x00780108: fstp qword ptr [0x8a8380] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078010E: ret  */

}

void sub_00780110(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780110u);

L_00780110:
    fp_push(*(double*)ADDR(0x7C0EA0)); /* 0x00780110: fld qword ptr [0x7c0ea0] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00780116: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8A8378) = _v; } /* 0x0078011C: fstp qword ptr [0x8a8378] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780122: ret  */

}

void sub_00780130(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780130u);

L_00780130:
    ecx = 0x008A8390u; /* 0x00780130: mov ecx, 0x8a8390 */
    RECOMP_CALL(sub_006DD220); /* 0x00780135: call 0x6dd220 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782860u); /* 0x0078013A: push 0x782860 */
    RECOMP_CALL(sub_0075C51D); /* 0x0078013F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00780144: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780145: ret  */

}

void sub_00780150(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780150u);

L_00780150:
    fp_push(*(float*)&MEM32(0x7C0EA8)); /* 0x00780150: fld dword ptr [0x7c0ea8] */
    _st[0] += _st[0]; /* 0x00780156: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A8730) = _v; } /* 0x00780158: fstp dword ptr [0x8a8730] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078015E: ret  */

}

void sub_00780160(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780160u);

L_00780160:
    fp_push(*(float*)&MEM32(0x7C0EA8)); /* 0x00780160: fld dword ptr [0x7c0ea8] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00780166: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A872C) = _v; } /* 0x0078016C: fstp dword ptr [0x8a872c] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780172: ret  */

}

void sub_00780180(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780180u);

L_00780180:
    fp_push(*(double*)ADDR(0x7C0EB0)); /* 0x00780180: fld qword ptr [0x7c0eb0] */
    _st[0] += _st[0]; /* 0x00780186: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8A85E8) = _v; } /* 0x00780188: fstp qword ptr [0x8a85e8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078018E: ret  */

}

void sub_00780190(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780190u);

L_00780190:
    fp_push(*(double*)ADDR(0x7C0EB0)); /* 0x00780190: fld qword ptr [0x7c0eb0] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00780196: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8A85E0) = _v; } /* 0x0078019C: fstp qword ptr [0x8a85e0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007801A2: ret  */

}

void sub_007801B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007801B0u);

L_007801B0:
    PUSH32(esp, 0xFF00AAAAu); /* 0x007801B0: push 0xff00aaaa */
    PUSH32(esp, 0x007C0FECu); /* 0x007801B5: push 0x7c0fec */
    ecx = 0x008A85F0u; /* 0x007801BA: mov ecx, 0x8a85f0 */
    RECOMP_CALL(sub_006DE3D0); /* 0x007801BF: call 0x6de3d0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782870u); /* 0x007801C4: push 0x782870 */
    RECOMP_CALL(sub_0075C51D); /* 0x007801C9: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x007801CE: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007801CF: ret  */

}

void sub_007801D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007801D0u);

L_007801D0:
    PUSH32(esp, 0xFFFFFF50u); /* 0x007801D0: push 0xffffff50 */
    PUSH32(esp, 0x007C0FF8u); /* 0x007801D5: push 0x7c0ff8 */
    ecx = 0x008A8738u; /* 0x007801DA: mov ecx, 0x8a8738 */
    RECOMP_CALL(sub_006DE3D0); /* 0x007801DF: call 0x6de3d0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782880u); /* 0x007801E4: push 0x782880 */
    RECOMP_CALL(sub_0075C51D); /* 0x007801E9: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x007801EE: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007801EF: ret  */

}

void sub_007801F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007801F0u);

L_007801F0:
    ecx = 0x008A8718u; /* 0x007801F0: mov ecx, 0x8a8718 */
    MEM32(0x8A8718) = 0x008A8738u; /* 0x007801F5: mov dword ptr [0x8a8718], 0x8a8738 */
    RECOMP_CALL(sub_006DE690); /* 0x007801FF: call 0x6de690 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782890u); /* 0x00780204: push 0x782890 */
    RECOMP_CALL(sub_0075C51D); /* 0x00780209: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0078020E: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078020F: ret  */

}

void sub_00780210(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780210u);

L_00780210:
    fp_push(*(float*)&MEM32(0x7C1008)); /* 0x00780210: fld dword ptr [0x7c1008] */
    _st[0] += _st[0]; /* 0x00780216: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AAAD4) = _v; } /* 0x00780218: fstp dword ptr [0x8aaad4] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078021E: ret  */

}

void sub_00780220(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780220u);

L_00780220:
    fp_push(*(float*)&MEM32(0x7C1008)); /* 0x00780220: fld dword ptr [0x7c1008] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00780226: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AAAD0) = _v; } /* 0x0078022C: fstp dword ptr [0x8aaad0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780232: ret  */

}

void sub_00780240(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780240u);

L_00780240:
    fp_push(*(double*)ADDR(0x7C1010)); /* 0x00780240: fld qword ptr [0x7c1010] */
    _st[0] += _st[0]; /* 0x00780246: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AAAC8) = _v; } /* 0x00780248: fstp qword ptr [0x8aaac8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078024E: ret  */

}

void sub_00780250(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780250u);

L_00780250:
    fp_push(*(double*)ADDR(0x7C1010)); /* 0x00780250: fld qword ptr [0x7c1010] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00780256: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AAAC0) = _v; } /* 0x0078025C: fstp qword ptr [0x8aaac0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780262: ret  */

}

void sub_00780270(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780270u);

L_00780270:
    ecx = 0x008AAAD8u; /* 0x00780270: mov ecx, 0x8aaad8 */
    RECOMP_CALL(sub_006DB720); /* 0x00780275: call 0x6db720 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007828A0u); /* 0x0078027A: push 0x7828a0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0078027F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00780284: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780285: ret  */

}

void sub_00780290(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780290u);

L_00780290:
    fp_push(*(float*)&MEM32(0x7C1120)); /* 0x00780290: fld dword ptr [0x7c1120] */
    _st[0] += _st[0]; /* 0x00780296: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AACBC) = _v; } /* 0x00780298: fstp dword ptr [0x8aacbc] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078029E: ret  */

}

void sub_007802A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007802A0u);

L_007802A0:
    fp_push(*(float*)&MEM32(0x7C1120)); /* 0x007802A0: fld dword ptr [0x7c1120] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x007802A6: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AACB8) = _v; } /* 0x007802AC: fstp dword ptr [0x8aacb8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007802B2: ret  */

}

void sub_007802C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007802C0u);

L_007802C0:
    fp_push(*(double*)ADDR(0x7C1128)); /* 0x007802C0: fld qword ptr [0x7c1128] */
    _st[0] += _st[0]; /* 0x007802C6: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AACB0) = _v; } /* 0x007802C8: fstp qword ptr [0x8aacb0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007802CE: ret  */

}

void sub_007802D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007802D0u);

L_007802D0:
    fp_push(*(double*)ADDR(0x7C1128)); /* 0x007802D0: fld qword ptr [0x7c1128] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x007802D6: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AACA8) = _v; } /* 0x007802DC: fstp qword ptr [0x8aaca8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007802E2: ret  */

}

void sub_007802F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007802F0u);

L_007802F0:
    fp_push(*(float*)&MEM32(0x7C1238)); /* 0x007802F0: fld dword ptr [0x7c1238] */
    _st[0] += _st[0]; /* 0x007802F6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AADAC) = _v; } /* 0x007802F8: fstp dword ptr [0x8aadac] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007802FE: ret  */

}

void sub_00780300(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780300u);

L_00780300:
    fp_push(*(float*)&MEM32(0x7C1238)); /* 0x00780300: fld dword ptr [0x7c1238] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00780306: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AADA8) = _v; } /* 0x0078030C: fstp dword ptr [0x8aada8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780312: ret  */

}

void sub_00780320(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780320u);

L_00780320:
    fp_push(*(double*)ADDR(0x7C1240)); /* 0x00780320: fld qword ptr [0x7c1240] */
    _st[0] += _st[0]; /* 0x00780326: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AADA0) = _v; } /* 0x00780328: fstp qword ptr [0x8aada0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078032E: ret  */

}

void sub_00780330(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780330u);

L_00780330:
    fp_push(*(double*)ADDR(0x7C1240)); /* 0x00780330: fld qword ptr [0x7c1240] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00780336: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AAD98) = _v; } /* 0x0078033C: fstp qword ptr [0x8aad98] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780342: ret  */

}

void sub_00780350(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780350u);

L_00780350:
    fp_push(*(float*)&MEM32(0x7C1348)); /* 0x00780350: fld dword ptr [0x7c1348] */
    _st[0] += _st[0]; /* 0x00780356: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AADC4) = _v; } /* 0x00780358: fstp dword ptr [0x8aadc4] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078035E: ret  */

}

void sub_00780360(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780360u);

L_00780360:
    fp_push(*(float*)&MEM32(0x7C1348)); /* 0x00780360: fld dword ptr [0x7c1348] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00780366: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AADC0) = _v; } /* 0x0078036C: fstp dword ptr [0x8aadc0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780372: ret  */

}

void sub_00780380(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780380u);

L_00780380:
    fp_push(*(double*)ADDR(0x7C1350)); /* 0x00780380: fld qword ptr [0x7c1350] */
    _st[0] += _st[0]; /* 0x00780386: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AADB8) = _v; } /* 0x00780388: fstp qword ptr [0x8aadb8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078038E: ret  */

}

void sub_00780390(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780390u);

L_00780390:
    fp_push(*(double*)ADDR(0x7C1350)); /* 0x00780390: fld qword ptr [0x7c1350] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00780396: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AADB0) = _v; } /* 0x0078039C: fstp qword ptr [0x8aadb0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007803A2: ret  */

}

void sub_007803B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007803B0u);

L_007803B0:
    fp_push(*(float*)&MEM32(0x7C1358)); /* 0x007803B0: fld dword ptr [0x7c1358] */
    _st[0] += _st[0]; /* 0x007803B6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AADDC) = _v; } /* 0x007803B8: fstp dword ptr [0x8aaddc] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007803BE: ret  */

}

void sub_007803C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007803C0u);

L_007803C0:
    fp_push(*(float*)&MEM32(0x7C1358)); /* 0x007803C0: fld dword ptr [0x7c1358] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x007803C6: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AADD8) = _v; } /* 0x007803CC: fstp dword ptr [0x8aadd8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007803D2: ret  */

}

void sub_007803E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007803E0u);

L_007803E0:
    fp_push(*(double*)ADDR(0x7C1360)); /* 0x007803E0: fld qword ptr [0x7c1360] */
    _st[0] += _st[0]; /* 0x007803E6: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AADD0) = _v; } /* 0x007803E8: fstp qword ptr [0x8aadd0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007803EE: ret  */

}

void sub_007803F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007803F0u);

L_007803F0:
    fp_push(*(double*)ADDR(0x7C1360)); /* 0x007803F0: fld qword ptr [0x7c1360] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x007803F6: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AADC8) = _v; } /* 0x007803FC: fstp qword ptr [0x8aadc8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780402: ret  */

}

void sub_00780410(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780410u);

L_00780410:
    fp_push(*(float*)&MEM32(0x7C1368)); /* 0x00780410: fld dword ptr [0x7c1368] */
    _st[0] += _st[0]; /* 0x00780416: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AADF4) = _v; } /* 0x00780418: fstp dword ptr [0x8aadf4] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078041E: ret  */

}

void sub_00780420(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780420u);

L_00780420:
    fp_push(*(float*)&MEM32(0x7C1368)); /* 0x00780420: fld dword ptr [0x7c1368] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00780426: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AADF0) = _v; } /* 0x0078042C: fstp dword ptr [0x8aadf0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780432: ret  */

}

void sub_00780440(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780440u);

L_00780440:
    fp_push(*(double*)ADDR(0x7C1370)); /* 0x00780440: fld qword ptr [0x7c1370] */
    _st[0] += _st[0]; /* 0x00780446: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AADE8) = _v; } /* 0x00780448: fstp qword ptr [0x8aade8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078044E: ret  */

}

void sub_00780450(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780450u);

L_00780450:
    fp_push(*(double*)ADDR(0x7C1370)); /* 0x00780450: fld qword ptr [0x7c1370] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00780456: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AADE0) = _v; } /* 0x0078045C: fstp qword ptr [0x8aade0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780462: ret  */

}

void sub_00780470(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780470u);

L_00780470:
    fp_push(*(float*)&MEM32(0x7C1478)); /* 0x00780470: fld dword ptr [0x7c1478] */
    _st[0] += _st[0]; /* 0x00780476: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AAE0C) = _v; } /* 0x00780478: fstp dword ptr [0x8aae0c] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078047E: ret  */

}

void sub_00780480(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780480u);

L_00780480:
    fp_push(*(float*)&MEM32(0x7C1478)); /* 0x00780480: fld dword ptr [0x7c1478] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00780486: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AAE08) = _v; } /* 0x0078048C: fstp dword ptr [0x8aae08] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780492: ret  */

}

void sub_007804A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007804A0u);

L_007804A0:
    fp_push(*(double*)ADDR(0x7C1480)); /* 0x007804A0: fld qword ptr [0x7c1480] */
    _st[0] += _st[0]; /* 0x007804A6: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AAE00) = _v; } /* 0x007804A8: fstp qword ptr [0x8aae00] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007804AE: ret  */

}

void sub_007804B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007804B0u);

L_007804B0:
    fp_push(*(double*)ADDR(0x7C1480)); /* 0x007804B0: fld qword ptr [0x7c1480] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x007804B6: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AADF8) = _v; } /* 0x007804BC: fstp qword ptr [0x8aadf8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007804C2: ret  */

}

void sub_007804D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007804D0u);

L_007804D0:
    fp_push(*(float*)&MEM32(0x7C14C8)); /* 0x007804D0: fld dword ptr [0x7c14c8] */
    _st[0] += _st[0]; /* 0x007804D6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB2BC) = _v; } /* 0x007804D8: fstp dword ptr [0x8ab2bc] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007804DE: ret  */

}

void sub_007804E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007804E0u);

L_007804E0:
    fp_push(*(float*)&MEM32(0x7C14C8)); /* 0x007804E0: fld dword ptr [0x7c14c8] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x007804E6: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB2B8) = _v; } /* 0x007804EC: fstp dword ptr [0x8ab2b8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007804F2: ret  */

}

void sub_00780500(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780500u);

L_00780500:
    fp_push(*(double*)ADDR(0x7C14D0)); /* 0x00780500: fld qword ptr [0x7c14d0] */
    _st[0] += _st[0]; /* 0x00780506: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB2B0) = _v; } /* 0x00780508: fstp qword ptr [0x8ab2b0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078050E: ret  */

}

void sub_00780510(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780510u);

L_00780510:
    fp_push(*(double*)ADDR(0x7C14D0)); /* 0x00780510: fld qword ptr [0x7c14d0] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00780516: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB2A8) = _v; } /* 0x0078051C: fstp qword ptr [0x8ab2a8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780522: ret  */

}

void sub_00780530(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780530u);

L_00780530:
    fp_push(*(float*)&MEM32(0x7C14F4)); /* 0x00780530: fld dword ptr [0x7c14f4] */
    _st[0] -= (double)*(float*)ADDR(0x7C14F0); /* 0x00780536: fsub dword ptr [0x7c14f0] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB29C) = _v; } /* 0x0078053C: fstp dword ptr [0x8ab29c] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780542: ret  */

}

void sub_00780550(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780550u);

L_00780550:
    fp_push(*(float*)&MEM32(0x7C14EC)); /* 0x00780550: fld dword ptr [0x7c14ec] */
    _st[0] += _st[0]; /* 0x00780556: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB2A0) = _v; } /* 0x00780558: fstp dword ptr [0x8ab2a0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078055E: ret  */

}

void sub_00780560(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780560u);

L_00780560:
    fp_push(*(float*)&MEM32(0x7C14E0)); /* 0x00780560: fld dword ptr [0x7c14e0] */
    _st[0] += _st[0]; /* 0x00780566: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB2C0) = _v; } /* 0x00780568: fstp dword ptr [0x8ab2c0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078056E: ret  */

}

void sub_00780570(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780570u);

L_00780570:
    fp_push(*(float*)&MEM32(0x7C14E8)); /* 0x00780570: fld dword ptr [0x7c14e8] */
    _st[0] += _st[0]; /* 0x00780576: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB298) = _v; } /* 0x00780578: fstp dword ptr [0x8ab298] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078057E: ret  */

}

void sub_00780580(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780580u);

L_00780580:
    fp_push(*(float*)&MEM32(0x7C1B00)); /* 0x00780580: fld dword ptr [0x7c1b00] */
    _st[0] += _st[0]; /* 0x00780586: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB2DC) = _v; } /* 0x00780588: fstp dword ptr [0x8ab2dc] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078058E: ret  */

}

void sub_00780590(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780590u);

L_00780590:
    fp_push(*(float*)&MEM32(0x7C1B00)); /* 0x00780590: fld dword ptr [0x7c1b00] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00780596: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB2D8) = _v; } /* 0x0078059C: fstp dword ptr [0x8ab2d8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007805A2: ret  */

}

void sub_007805B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007805B0u);

L_007805B0:
    fp_push(*(double*)ADDR(0x7C1B08)); /* 0x007805B0: fld qword ptr [0x7c1b08] */
    _st[0] += _st[0]; /* 0x007805B6: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB2D0) = _v; } /* 0x007805B8: fstp qword ptr [0x8ab2d0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007805BE: ret  */

}

void sub_007805C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007805C0u);

L_007805C0:
    fp_push(*(double*)ADDR(0x7C1B08)); /* 0x007805C0: fld qword ptr [0x7c1b08] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x007805C6: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB2C8) = _v; } /* 0x007805CC: fstp qword ptr [0x8ab2c8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007805D2: ret  */

}

void sub_007805E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007805E0u);

L_007805E0:
    fp_push(*(float*)&MEM32(0x7C1B18)); /* 0x007805E0: fld dword ptr [0x7c1b18] */
    _st[0] += _st[0]; /* 0x007805E6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB2F4) = _v; } /* 0x007805E8: fstp dword ptr [0x8ab2f4] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007805EE: ret  */

}

void sub_007805F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007805F0u);

L_007805F0:
    fp_push(*(float*)&MEM32(0x7C1B18)); /* 0x007805F0: fld dword ptr [0x7c1b18] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x007805F6: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB2F0) = _v; } /* 0x007805FC: fstp dword ptr [0x8ab2f0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780602: ret  */

}

void sub_00780610(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780610u);

L_00780610:
    fp_push(*(double*)ADDR(0x7C1B20)); /* 0x00780610: fld qword ptr [0x7c1b20] */
    _st[0] += _st[0]; /* 0x00780616: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB2E8) = _v; } /* 0x00780618: fstp qword ptr [0x8ab2e8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078061E: ret  */

}

void sub_00780620(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780620u);

L_00780620:
    fp_push(*(double*)ADDR(0x7C1B20)); /* 0x00780620: fld qword ptr [0x7c1b20] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00780626: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB2E0) = _v; } /* 0x0078062C: fstp qword ptr [0x8ab2e0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780632: ret  */

}

void sub_00780640(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780640u);

L_00780640:
    fp_push(*(float*)&MEM32(0x7C1B30)); /* 0x00780640: fld dword ptr [0x7c1b30] */
    _st[0] += _st[0]; /* 0x00780646: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB314) = _v; } /* 0x00780648: fstp dword ptr [0x8ab314] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078064E: ret  */

}

void sub_00780650(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780650u);

L_00780650:
    fp_push(*(float*)&MEM32(0x7C1B30)); /* 0x00780650: fld dword ptr [0x7c1b30] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00780656: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB310) = _v; } /* 0x0078065C: fstp dword ptr [0x8ab310] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780662: ret  */

}

void sub_00780670(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780670u);

L_00780670:
    fp_push(*(double*)ADDR(0x7C1B38)); /* 0x00780670: fld qword ptr [0x7c1b38] */
    _st[0] += _st[0]; /* 0x00780676: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB308) = _v; } /* 0x00780678: fstp qword ptr [0x8ab308] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078067E: ret  */

}

void sub_00780680(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780680u);

L_00780680:
    fp_push(*(double*)ADDR(0x7C1B38)); /* 0x00780680: fld qword ptr [0x7c1b38] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00780686: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB300) = _v; } /* 0x0078068C: fstp qword ptr [0x8ab300] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780692: ret  */

}

void sub_007806A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007806A0u);

L_007806A0:
    fp_push(*(float*)&MEM32(0x7C1B40)); /* 0x007806A0: fld dword ptr [0x7c1b40] */
    _st[0] += _st[0]; /* 0x007806A6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB354) = _v; } /* 0x007806A8: fstp dword ptr [0x8ab354] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007806AE: ret  */

}

void sub_007806B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007806B0u);

L_007806B0:
    fp_push(*(float*)&MEM32(0x7C1B40)); /* 0x007806B0: fld dword ptr [0x7c1b40] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x007806B6: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB350) = _v; } /* 0x007806BC: fstp dword ptr [0x8ab350] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007806C2: ret  */

}

void sub_007806D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007806D0u);

L_007806D0:
    fp_push(*(double*)ADDR(0x7C1B48)); /* 0x007806D0: fld qword ptr [0x7c1b48] */
    _st[0] += _st[0]; /* 0x007806D6: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB348) = _v; } /* 0x007806D8: fstp qword ptr [0x8ab348] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007806DE: ret  */

}

void sub_007806E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007806E0u);

L_007806E0:
    fp_push(*(double*)ADDR(0x7C1B48)); /* 0x007806E0: fld qword ptr [0x7c1b48] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x007806E6: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB340) = _v; } /* 0x007806EC: fstp qword ptr [0x8ab340] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007806F2: ret  */

}

void sub_00780700(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780700u);

L_00780700:
    eax = 0x008AB320u; /* 0x00780700: mov eax, 0x8ab320 */
    ecx = 3; /* 0x00780705: mov ecx, 3 */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    edx = 0; /* 0x0078070A: xor edx, edx */
    _cf = 0;
    _flag_k = FK_TEST;
    esp = esp; /* 0x0078070C: lea esp, [esp] */

L_00780710:
    MEM32(eax + (-0x8)) = edx; /* 0x00780710: mov dword ptr [eax - 8], edx */
    MEM32(eax + (-0x4)) = edx; /* 0x00780713: mov dword ptr [eax - 4], edx */
    MEM32(eax) = edx; /* 0x00780716: mov dword ptr [eax], edx */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0xCu; /* 0x00780718: add eax, 0xc */
    _flag_k = FK_ADD;
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(1);
    ecx = ecx - 1; /* 0x0078071B: dec ecx */
    _flag_k = FK_DEC;
    RECOMP_BACKEDGE();
    if (/* dec result */ CMP_NE(_flag_a, _flag_b)) goto L_00780710; /* 0x0078071C: jne 0x780710 */

L_0078071E:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078071E: ret  */

}

void sub_00780720(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780720u);

L_00780720:
    fp_push(*(float*)&MEM32(0x7C1B50)); /* 0x00780720: fld dword ptr [0x7c1b50] */
    _st[0] += _st[0]; /* 0x00780726: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB36C) = _v; } /* 0x00780728: fstp dword ptr [0x8ab36c] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078072E: ret  */

}

void sub_00780730(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780730u);

L_00780730:
    fp_push(*(float*)&MEM32(0x7C1B50)); /* 0x00780730: fld dword ptr [0x7c1b50] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00780736: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB368) = _v; } /* 0x0078073C: fstp dword ptr [0x8ab368] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780742: ret  */

}

void sub_00780750(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780750u);

L_00780750:
    fp_push(*(double*)ADDR(0x7C1B58)); /* 0x00780750: fld qword ptr [0x7c1b58] */
    _st[0] += _st[0]; /* 0x00780756: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB360) = _v; } /* 0x00780758: fstp qword ptr [0x8ab360] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078075E: ret  */

}

void sub_00780760(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780760u);

L_00780760:
    fp_push(*(double*)ADDR(0x7C1B58)); /* 0x00780760: fld qword ptr [0x7c1b58] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00780766: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB358) = _v; } /* 0x0078076C: fstp qword ptr [0x8ab358] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780772: ret  */

}

void sub_00780780(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780780u);

L_00780780:
    fp_push(*(float*)&MEM32(0x7C1B60)); /* 0x00780780: fld dword ptr [0x7c1b60] */
    _st[0] += _st[0]; /* 0x00780786: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB384) = _v; } /* 0x00780788: fstp dword ptr [0x8ab384] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078078E: ret  */

}

void sub_00780790(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780790u);

L_00780790:
    fp_push(*(float*)&MEM32(0x7C1B60)); /* 0x00780790: fld dword ptr [0x7c1b60] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00780796: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB380) = _v; } /* 0x0078079C: fstp dword ptr [0x8ab380] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007807A2: ret  */

}

void sub_007807B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007807B0u);

L_007807B0:
    fp_push(*(double*)ADDR(0x7C1B68)); /* 0x007807B0: fld qword ptr [0x7c1b68] */
    _st[0] += _st[0]; /* 0x007807B6: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB378) = _v; } /* 0x007807B8: fstp qword ptr [0x8ab378] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007807BE: ret  */

}

void sub_007807C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007807C0u);

L_007807C0:
    fp_push(*(double*)ADDR(0x7C1B68)); /* 0x007807C0: fld qword ptr [0x7c1b68] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x007807C6: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB370) = _v; } /* 0x007807CC: fstp qword ptr [0x8ab370] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007807D2: ret  */

}

void sub_007807E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007807E0u);

L_007807E0:
    fp_push(*(float*)&MEM32(0x7C1BC8)); /* 0x007807E0: fld dword ptr [0x7c1bc8] */
    _st[0] += _st[0]; /* 0x007807E6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB39C) = _v; } /* 0x007807E8: fstp dword ptr [0x8ab39c] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007807EE: ret  */

}

void sub_007807F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007807F0u);

L_007807F0:
    fp_push(*(float*)&MEM32(0x7C1BC8)); /* 0x007807F0: fld dword ptr [0x7c1bc8] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x007807F6: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB398) = _v; } /* 0x007807FC: fstp dword ptr [0x8ab398] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780802: ret  */

}

void sub_00780810(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780810u);

L_00780810:
    fp_push(*(double*)ADDR(0x7C1BD0)); /* 0x00780810: fld qword ptr [0x7c1bd0] */
    _st[0] += _st[0]; /* 0x00780816: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB390) = _v; } /* 0x00780818: fstp qword ptr [0x8ab390] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078081E: ret  */

}

void sub_00780820(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780820u);

L_00780820:
    fp_push(*(double*)ADDR(0x7C1BD0)); /* 0x00780820: fld qword ptr [0x7c1bd0] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00780826: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB388) = _v; } /* 0x0078082C: fstp qword ptr [0x8ab388] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780832: ret  */

}

void sub_00780840(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780840u);

L_00780840:
    fp_push(*(float*)&MEM32(0x7C1BE0)); /* 0x00780840: fld dword ptr [0x7c1be0] */
    _st[0] += _st[0]; /* 0x00780846: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB3B4) = _v; } /* 0x00780848: fstp dword ptr [0x8ab3b4] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078084E: ret  */

}

void sub_00780850(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780850u);

L_00780850:
    fp_push(*(float*)&MEM32(0x7C1BE0)); /* 0x00780850: fld dword ptr [0x7c1be0] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00780856: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB3B0) = _v; } /* 0x0078085C: fstp dword ptr [0x8ab3b0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780862: ret  */

}

void sub_00780870(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780870u);

L_00780870:
    fp_push(*(double*)ADDR(0x7C1BE8)); /* 0x00780870: fld qword ptr [0x7c1be8] */
    _st[0] += _st[0]; /* 0x00780876: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB3A8) = _v; } /* 0x00780878: fstp qword ptr [0x8ab3a8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078087E: ret  */

}

void sub_00780880(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780880u);

L_00780880:
    fp_push(*(double*)ADDR(0x7C1BE8)); /* 0x00780880: fld qword ptr [0x7c1be8] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00780886: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB3A0) = _v; } /* 0x0078088C: fstp qword ptr [0x8ab3a0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780892: ret  */

}

void sub_007808A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007808A0u);

L_007808A0:
    fp_push(*(float*)&MEM32(0x7C1BF0)); /* 0x007808A0: fld dword ptr [0x7c1bf0] */
    _st[0] += _st[0]; /* 0x007808A6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB3CC) = _v; } /* 0x007808A8: fstp dword ptr [0x8ab3cc] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007808AE: ret  */

}

void sub_007808B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007808B0u);

L_007808B0:
    fp_push(*(float*)&MEM32(0x7C1BF0)); /* 0x007808B0: fld dword ptr [0x7c1bf0] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x007808B6: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB3C8) = _v; } /* 0x007808BC: fstp dword ptr [0x8ab3c8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007808C2: ret  */

}

void sub_007808D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007808D0u);

L_007808D0:
    fp_push(*(double*)ADDR(0x7C1BF8)); /* 0x007808D0: fld qword ptr [0x7c1bf8] */
    _st[0] += _st[0]; /* 0x007808D6: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB3C0) = _v; } /* 0x007808D8: fstp qword ptr [0x8ab3c0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007808DE: ret  */

}

void sub_007808E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007808E0u);

L_007808E0:
    fp_push(*(double*)ADDR(0x7C1BF8)); /* 0x007808E0: fld qword ptr [0x7c1bf8] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x007808E6: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB3B8) = _v; } /* 0x007808EC: fstp qword ptr [0x8ab3b8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007808F2: ret  */

}

void sub_00780900(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780900u);

L_00780900:
    fp_push(*(float*)&MEM32(0x7C1C08)); /* 0x00780900: fld dword ptr [0x7c1c08] */
    _st[0] += _st[0]; /* 0x00780906: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB3E4) = _v; } /* 0x00780908: fstp dword ptr [0x8ab3e4] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078090E: ret  */

}

void sub_00780910(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780910u);

L_00780910:
    fp_push(*(float*)&MEM32(0x7C1C08)); /* 0x00780910: fld dword ptr [0x7c1c08] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00780916: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB3E0) = _v; } /* 0x0078091C: fstp dword ptr [0x8ab3e0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780922: ret  */

}

void sub_00780930(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780930u);

L_00780930:
    fp_push(*(double*)ADDR(0x7C1C10)); /* 0x00780930: fld qword ptr [0x7c1c10] */
    _st[0] += _st[0]; /* 0x00780936: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB3D8) = _v; } /* 0x00780938: fstp qword ptr [0x8ab3d8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078093E: ret  */

}

void sub_00780940(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780940u);

L_00780940:
    fp_push(*(double*)ADDR(0x7C1C10)); /* 0x00780940: fld qword ptr [0x7c1c10] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00780946: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB3D0) = _v; } /* 0x0078094C: fstp qword ptr [0x8ab3d0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780952: ret  */

}

void sub_00780960(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780960u);

L_00780960:
    fp_push(*(float*)&MEM32(0x7C1C20)); /* 0x00780960: fld dword ptr [0x7c1c20] */
    _st[0] += _st[0]; /* 0x00780966: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB3FC) = _v; } /* 0x00780968: fstp dword ptr [0x8ab3fc] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078096E: ret  */

}

void sub_00780970(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780970u);

L_00780970:
    fp_push(*(float*)&MEM32(0x7C1C20)); /* 0x00780970: fld dword ptr [0x7c1c20] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00780976: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB3F8) = _v; } /* 0x0078097C: fstp dword ptr [0x8ab3f8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780982: ret  */

}

void sub_00780990(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780990u);

L_00780990:
    fp_push(*(double*)ADDR(0x7C1C28)); /* 0x00780990: fld qword ptr [0x7c1c28] */
    _st[0] += _st[0]; /* 0x00780996: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB3F0) = _v; } /* 0x00780998: fstp qword ptr [0x8ab3f0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078099E: ret  */

}

void sub_007809A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007809A0u);

L_007809A0:
    fp_push(*(double*)ADDR(0x7C1C28)); /* 0x007809A0: fld qword ptr [0x7c1c28] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x007809A6: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB3E8) = _v; } /* 0x007809AC: fstp qword ptr [0x8ab3e8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007809B2: ret  */

}

void sub_007809C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007809C0u);

L_007809C0:
    fp_push(*(float*)&MEM32(0x7C1C38)); /* 0x007809C0: fld dword ptr [0x7c1c38] */
    _st[0] += _st[0]; /* 0x007809C6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB414) = _v; } /* 0x007809C8: fstp dword ptr [0x8ab414] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007809CE: ret  */

}

void sub_007809D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007809D0u);

L_007809D0:
    fp_push(*(float*)&MEM32(0x7C1C38)); /* 0x007809D0: fld dword ptr [0x7c1c38] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x007809D6: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB410) = _v; } /* 0x007809DC: fstp dword ptr [0x8ab410] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007809E2: ret  */

}

void sub_007809F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007809F0u);

L_007809F0:
    fp_push(*(double*)ADDR(0x7C1C40)); /* 0x007809F0: fld qword ptr [0x7c1c40] */
    _st[0] += _st[0]; /* 0x007809F6: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB408) = _v; } /* 0x007809F8: fstp qword ptr [0x8ab408] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007809FE: ret  */

}

void sub_00780A00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780A00u);

L_00780A00:
    fp_push(*(double*)ADDR(0x7C1C40)); /* 0x00780A00: fld qword ptr [0x7c1c40] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00780A06: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB400) = _v; } /* 0x00780A0C: fstp qword ptr [0x8ab400] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780A12: ret  */

}

void sub_00780A20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780A20u);

L_00780A20:
    fp_push(*(float*)&MEM32(0x7C1C48)); /* 0x00780A20: fld dword ptr [0x7c1c48] */
    _st[0] += _st[0]; /* 0x00780A26: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB42C) = _v; } /* 0x00780A28: fstp dword ptr [0x8ab42c] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780A2E: ret  */

}

void sub_00780A30(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780A30u);

L_00780A30:
    fp_push(*(float*)&MEM32(0x7C1C48)); /* 0x00780A30: fld dword ptr [0x7c1c48] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00780A36: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB428) = _v; } /* 0x00780A3C: fstp dword ptr [0x8ab428] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780A42: ret  */

}

void sub_00780A50(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780A50u);

L_00780A50:
    fp_push(*(double*)ADDR(0x7C1C50)); /* 0x00780A50: fld qword ptr [0x7c1c50] */
    _st[0] += _st[0]; /* 0x00780A56: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB420) = _v; } /* 0x00780A58: fstp qword ptr [0x8ab420] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780A5E: ret  */

}

void sub_00780A60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780A60u);

L_00780A60:
    fp_push(*(double*)ADDR(0x7C1C50)); /* 0x00780A60: fld qword ptr [0x7c1c50] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00780A66: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB418) = _v; } /* 0x00780A6C: fstp qword ptr [0x8ab418] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780A72: ret  */

}

void sub_00780A80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780A80u);

L_00780A80:
    fp_push(*(float*)&MEM32(0x7C1C60)); /* 0x00780A80: fld dword ptr [0x7c1c60] */
    _st[0] += _st[0]; /* 0x00780A86: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB444) = _v; } /* 0x00780A88: fstp dword ptr [0x8ab444] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780A8E: ret  */

}

void sub_00780A90(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780A90u);

L_00780A90:
    fp_push(*(float*)&MEM32(0x7C1C60)); /* 0x00780A90: fld dword ptr [0x7c1c60] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00780A96: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB440) = _v; } /* 0x00780A9C: fstp dword ptr [0x8ab440] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780AA2: ret  */

}

void sub_00780AB0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780AB0u);

L_00780AB0:
    fp_push(*(double*)ADDR(0x7C1C68)); /* 0x00780AB0: fld qword ptr [0x7c1c68] */
    _st[0] += _st[0]; /* 0x00780AB6: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB438) = _v; } /* 0x00780AB8: fstp qword ptr [0x8ab438] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780ABE: ret  */

}

void sub_00780AC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780AC0u);

L_00780AC0:
    fp_push(*(double*)ADDR(0x7C1C68)); /* 0x00780AC0: fld qword ptr [0x7c1c68] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00780AC6: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB430) = _v; } /* 0x00780ACC: fstp qword ptr [0x8ab430] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780AD2: ret  */

}

void sub_00780AE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780AE0u);

L_00780AE0:
    fp_push(*(float*)&MEM32(0x7C1C78)); /* 0x00780AE0: fld dword ptr [0x7c1c78] */
    _st[0] += _st[0]; /* 0x00780AE6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB45C) = _v; } /* 0x00780AE8: fstp dword ptr [0x8ab45c] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780AEE: ret  */

}

void sub_00780AF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780AF0u);

L_00780AF0:
    fp_push(*(float*)&MEM32(0x7C1C78)); /* 0x00780AF0: fld dword ptr [0x7c1c78] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00780AF6: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB458) = _v; } /* 0x00780AFC: fstp dword ptr [0x8ab458] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780B02: ret  */

}

void sub_00780B10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780B10u);

L_00780B10:
    fp_push(*(double*)ADDR(0x7C1C80)); /* 0x00780B10: fld qword ptr [0x7c1c80] */
    _st[0] += _st[0]; /* 0x00780B16: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB450) = _v; } /* 0x00780B18: fstp qword ptr [0x8ab450] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780B1E: ret  */

}

void sub_00780B20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780B20u);

L_00780B20:
    fp_push(*(double*)ADDR(0x7C1C80)); /* 0x00780B20: fld qword ptr [0x7c1c80] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00780B26: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB448) = _v; } /* 0x00780B2C: fstp qword ptr [0x8ab448] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780B32: ret  */

}

void sub_00780B40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780B40u);

L_00780B40:
    fp_push(*(float*)&MEM32(0x7C1C90)); /* 0x00780B40: fld dword ptr [0x7c1c90] */
    _st[0] += _st[0]; /* 0x00780B46: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB474) = _v; } /* 0x00780B48: fstp dword ptr [0x8ab474] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780B4E: ret  */

}

void sub_00780B50(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780B50u);

L_00780B50:
    fp_push(*(float*)&MEM32(0x7C1C90)); /* 0x00780B50: fld dword ptr [0x7c1c90] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00780B56: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB470) = _v; } /* 0x00780B5C: fstp dword ptr [0x8ab470] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780B62: ret  */

}

void sub_00780B70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780B70u);

L_00780B70:
    fp_push(*(double*)ADDR(0x7C1C98)); /* 0x00780B70: fld qword ptr [0x7c1c98] */
    _st[0] += _st[0]; /* 0x00780B76: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB468) = _v; } /* 0x00780B78: fstp qword ptr [0x8ab468] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780B7E: ret  */

}

void sub_00780B80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780B80u);

L_00780B80:
    fp_push(*(double*)ADDR(0x7C1C98)); /* 0x00780B80: fld qword ptr [0x7c1c98] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00780B86: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB460) = _v; } /* 0x00780B8C: fstp qword ptr [0x8ab460] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780B92: ret  */

}

void sub_00780BA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780BA0u);

L_00780BA0:
    fp_push(*(float*)&MEM32(0x7C1CA8)); /* 0x00780BA0: fld dword ptr [0x7c1ca8] */
    _st[0] += _st[0]; /* 0x00780BA6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB48C) = _v; } /* 0x00780BA8: fstp dword ptr [0x8ab48c] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780BAE: ret  */

}

void sub_00780BB0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780BB0u);

L_00780BB0:
    fp_push(*(float*)&MEM32(0x7C1CA8)); /* 0x00780BB0: fld dword ptr [0x7c1ca8] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00780BB6: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB488) = _v; } /* 0x00780BBC: fstp dword ptr [0x8ab488] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780BC2: ret  */

}

void sub_00780BD0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780BD0u);

L_00780BD0:
    fp_push(*(double*)ADDR(0x7C1CB0)); /* 0x00780BD0: fld qword ptr [0x7c1cb0] */
    _st[0] += _st[0]; /* 0x00780BD6: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB480) = _v; } /* 0x00780BD8: fstp qword ptr [0x8ab480] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780BDE: ret  */

}

void sub_00780BE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780BE0u);

L_00780BE0:
    fp_push(*(double*)ADDR(0x7C1CB0)); /* 0x00780BE0: fld qword ptr [0x7c1cb0] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00780BE6: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB478) = _v; } /* 0x00780BEC: fstp qword ptr [0x8ab478] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780BF2: ret  */

}

void sub_00780C00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780C00u);

L_00780C00:
    fp_push(*(float*)&MEM32(0x7C1CC0)); /* 0x00780C00: fld dword ptr [0x7c1cc0] */
    _st[0] += _st[0]; /* 0x00780C06: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB4A4) = _v; } /* 0x00780C08: fstp dword ptr [0x8ab4a4] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780C0E: ret  */

}

void sub_00780C10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780C10u);

L_00780C10:
    fp_push(*(float*)&MEM32(0x7C1CC0)); /* 0x00780C10: fld dword ptr [0x7c1cc0] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00780C16: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB4A0) = _v; } /* 0x00780C1C: fstp dword ptr [0x8ab4a0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780C22: ret  */

}

void sub_00780C30(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780C30u);

L_00780C30:
    fp_push(*(double*)ADDR(0x7C1CC8)); /* 0x00780C30: fld qword ptr [0x7c1cc8] */
    _st[0] += _st[0]; /* 0x00780C36: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB498) = _v; } /* 0x00780C38: fstp qword ptr [0x8ab498] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780C3E: ret  */

}

void sub_00780C40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780C40u);

L_00780C40:
    fp_push(*(double*)ADDR(0x7C1CC8)); /* 0x00780C40: fld qword ptr [0x7c1cc8] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00780C46: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB490) = _v; } /* 0x00780C4C: fstp qword ptr [0x8ab490] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780C52: ret  */

}

void sub_00780C60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780C60u);

L_00780C60:
    fp_push(*(float*)&MEM32(0x7C1CD8)); /* 0x00780C60: fld dword ptr [0x7c1cd8] */
    _st[0] += _st[0]; /* 0x00780C66: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB4DC) = _v; } /* 0x00780C68: fstp dword ptr [0x8ab4dc] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780C6E: ret  */

}

void sub_00780C70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780C70u);

L_00780C70:
    fp_push(*(float*)&MEM32(0x7C1CD8)); /* 0x00780C70: fld dword ptr [0x7c1cd8] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00780C76: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB4D8) = _v; } /* 0x00780C7C: fstp dword ptr [0x8ab4d8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780C82: ret  */

}

void sub_00780C90(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780C90u);

L_00780C90:
    fp_push(*(double*)ADDR(0x7C1CE0)); /* 0x00780C90: fld qword ptr [0x7c1ce0] */
    _st[0] += _st[0]; /* 0x00780C96: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB4D0) = _v; } /* 0x00780C98: fstp qword ptr [0x8ab4d0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780C9E: ret  */

}

void sub_00780CA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780CA0u);

L_00780CA0:
    fp_push(*(double*)ADDR(0x7C1CE0)); /* 0x00780CA0: fld qword ptr [0x7c1ce0] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00780CA6: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB4C8) = _v; } /* 0x00780CAC: fstp qword ptr [0x8ab4c8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780CB2: ret  */

}

void sub_00780CC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780CC0u);

L_00780CC0:
    fp_push(*(float*)&MEM32(0x7C1D08)); /* 0x00780CC0: fld dword ptr [0x7c1d08] */
    _st[0] += _st[0]; /* 0x00780CC6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB4FC) = _v; } /* 0x00780CC8: fstp dword ptr [0x8ab4fc] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780CCE: ret  */

}

void sub_00780CD0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780CD0u);

L_00780CD0:
    fp_push(*(float*)&MEM32(0x7C1D08)); /* 0x00780CD0: fld dword ptr [0x7c1d08] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00780CD6: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB4F8) = _v; } /* 0x00780CDC: fstp dword ptr [0x8ab4f8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780CE2: ret  */

}

void sub_00780CF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780CF0u);

L_00780CF0:
    fp_push(*(double*)ADDR(0x7C1D10)); /* 0x00780CF0: fld qword ptr [0x7c1d10] */
    _st[0] += _st[0]; /* 0x00780CF6: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB4F0) = _v; } /* 0x00780CF8: fstp qword ptr [0x8ab4f0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780CFE: ret  */

}

void sub_00780D00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780D00u);

L_00780D00:
    fp_push(*(double*)ADDR(0x7C1D10)); /* 0x00780D00: fld qword ptr [0x7c1d10] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00780D06: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB4E8) = _v; } /* 0x00780D0C: fstp qword ptr [0x8ab4e8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780D12: ret  */

}

void sub_00780D20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780D20u);

L_00780D20:
    fp_push(*(float*)&MEM32(0x7C1D34)); /* 0x00780D20: fld dword ptr [0x7c1d34] */
    _st[0] -= (double)*(float*)ADDR(0x7C1D30); /* 0x00780D26: fsub dword ptr [0x7c1d30] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB4E0) = _v; } /* 0x00780D2C: fstp dword ptr [0x8ab4e0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780D32: ret  */

}

void sub_00780D40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780D40u);

L_00780D40:
    fp_push(*(float*)&MEM32(0x7C1D90)); /* 0x00780D40: fld dword ptr [0x7c1d90] */
    _st[0] += _st[0]; /* 0x00780D46: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB524) = _v; } /* 0x00780D48: fstp dword ptr [0x8ab524] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780D4E: ret  */

}

void sub_00780D50(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780D50u);

L_00780D50:
    fp_push(*(float*)&MEM32(0x7C1D90)); /* 0x00780D50: fld dword ptr [0x7c1d90] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00780D56: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB520) = _v; } /* 0x00780D5C: fstp dword ptr [0x8ab520] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780D62: ret  */

}

void sub_00780D70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780D70u);

L_00780D70:
    fp_push(*(double*)ADDR(0x7C1D98)); /* 0x00780D70: fld qword ptr [0x7c1d98] */
    _st[0] += _st[0]; /* 0x00780D76: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB518) = _v; } /* 0x00780D78: fstp qword ptr [0x8ab518] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780D7E: ret  */

}

void sub_00780D80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780D80u);

L_00780D80:
    fp_push(*(double*)ADDR(0x7C1D98)); /* 0x00780D80: fld qword ptr [0x7c1d98] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00780D86: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB510) = _v; } /* 0x00780D8C: fstp qword ptr [0x8ab510] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780D92: ret  */

}

void sub_00780DA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780DA0u);

L_00780DA0:
    fp_push(*(float*)&MEM32(0x7C1DBC)); /* 0x00780DA0: fld dword ptr [0x7c1dbc] */
    _st[0] -= (double)*(float*)ADDR(0x7C1DB8); /* 0x00780DA6: fsub dword ptr [0x7c1db8] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB504) = _v; } /* 0x00780DAC: fstp dword ptr [0x8ab504] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780DB2: ret  */

}

void sub_00780DC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780DC0u);

L_00780DC0:
    fp_push(*(float*)&MEM32(0x7C1DB4)); /* 0x00780DC0: fld dword ptr [0x7c1db4] */
    _st[0] += _st[0]; /* 0x00780DC6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB508) = _v; } /* 0x00780DC8: fstp dword ptr [0x8ab508] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780DCE: ret  */

}

void sub_00780DD0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780DD0u);

L_00780DD0:
    fp_push(*(float*)&MEM32(0x7C1DA8)); /* 0x00780DD0: fld dword ptr [0x7c1da8] */
    _st[0] += _st[0]; /* 0x00780DD6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB528) = _v; } /* 0x00780DD8: fstp dword ptr [0x8ab528] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780DDE: ret  */

}

void sub_00780DE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780DE0u);

L_00780DE0:
    fp_push(*(float*)&MEM32(0x7C1DB0)); /* 0x00780DE0: fld dword ptr [0x7c1db0] */
    _st[0] += _st[0]; /* 0x00780DE6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB500) = _v; } /* 0x00780DE8: fstp dword ptr [0x8ab500] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780DEE: ret  */

}

void sub_00780DF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780DF0u);

L_00780DF0:
    fp_push(*(float*)&MEM32(0x7C1E18)); /* 0x00780DF0: fld dword ptr [0x7c1e18] */
    _st[0] += _st[0]; /* 0x00780DF6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB54C) = _v; } /* 0x00780DF8: fstp dword ptr [0x8ab54c] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780DFE: ret  */

}

void sub_00780E00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780E00u);

L_00780E00:
    fp_push(*(float*)&MEM32(0x7C1E18)); /* 0x00780E00: fld dword ptr [0x7c1e18] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00780E06: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB548) = _v; } /* 0x00780E0C: fstp dword ptr [0x8ab548] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780E12: ret  */

}

void sub_00780E20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780E20u);

L_00780E20:
    fp_push(*(double*)ADDR(0x7C1E20)); /* 0x00780E20: fld qword ptr [0x7c1e20] */
    _st[0] += _st[0]; /* 0x00780E26: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB540) = _v; } /* 0x00780E28: fstp qword ptr [0x8ab540] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780E2E: ret  */

}

void sub_00780E30(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780E30u);

L_00780E30:
    fp_push(*(double*)ADDR(0x7C1E20)); /* 0x00780E30: fld qword ptr [0x7c1e20] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00780E36: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB538) = _v; } /* 0x00780E3C: fstp qword ptr [0x8ab538] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780E42: ret  */

}

void sub_00780E50(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780E50u);

L_00780E50:
    fp_push(*(float*)&MEM32(0x7C1E44)); /* 0x00780E50: fld dword ptr [0x7c1e44] */
    _st[0] -= (double)*(float*)ADDR(0x7C1E40); /* 0x00780E56: fsub dword ptr [0x7c1e40] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB530) = _v; } /* 0x00780E5C: fstp dword ptr [0x8ab530] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780E62: ret  */

}

void sub_00780E70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780E70u);

L_00780E70:
    fp_push(*(float*)&MEM32(0x7C1EA0)); /* 0x00780E70: fld dword ptr [0x7c1ea0] */
    _st[0] += _st[0]; /* 0x00780E76: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB56C) = _v; } /* 0x00780E78: fstp dword ptr [0x8ab56c] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780E7E: ret  */

}

void sub_00780E80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780E80u);

L_00780E80:
    fp_push(*(float*)&MEM32(0x7C1EA0)); /* 0x00780E80: fld dword ptr [0x7c1ea0] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00780E86: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB568) = _v; } /* 0x00780E8C: fstp dword ptr [0x8ab568] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780E92: ret  */

}

void sub_00780EA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780EA0u);

L_00780EA0:
    fp_push(*(double*)ADDR(0x7C1EA8)); /* 0x00780EA0: fld qword ptr [0x7c1ea8] */
    _st[0] += _st[0]; /* 0x00780EA6: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB560) = _v; } /* 0x00780EA8: fstp qword ptr [0x8ab560] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780EAE: ret  */

}

void sub_00780EB0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780EB0u);

L_00780EB0:
    fp_push(*(double*)ADDR(0x7C1EA8)); /* 0x00780EB0: fld qword ptr [0x7c1ea8] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00780EB6: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB558) = _v; } /* 0x00780EBC: fstp qword ptr [0x8ab558] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780EC2: ret  */

}

void sub_00780ED0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780ED0u);

L_00780ED0:
    fp_push(*(float*)&MEM32(0x7C1ECC)); /* 0x00780ED0: fld dword ptr [0x7c1ecc] */
    _st[0] -= (double)*(float*)ADDR(0x7C1EC8); /* 0x00780ED6: fsub dword ptr [0x7c1ec8] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB550) = _v; } /* 0x00780EDC: fstp dword ptr [0x8ab550] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780EE2: ret  */

}

void sub_00780EF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780EF0u);

L_00780EF0:
    fp_push(*(float*)&MEM32(0x7C1F38)); /* 0x00780EF0: fld dword ptr [0x7c1f38] */
    _st[0] += _st[0]; /* 0x00780EF6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB584) = _v; } /* 0x00780EF8: fstp dword ptr [0x8ab584] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780EFE: ret  */

}

void sub_00780F00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780F00u);

L_00780F00:
    fp_push(*(float*)&MEM32(0x7C1F38)); /* 0x00780F00: fld dword ptr [0x7c1f38] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00780F06: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB580) = _v; } /* 0x00780F0C: fstp dword ptr [0x8ab580] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780F12: ret  */

}

void sub_00780F20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780F20u);

L_00780F20:
    fp_push(*(double*)ADDR(0x7C1F40)); /* 0x00780F20: fld qword ptr [0x7c1f40] */
    _st[0] += _st[0]; /* 0x00780F26: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB578) = _v; } /* 0x00780F28: fstp qword ptr [0x8ab578] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780F2E: ret  */

}

void sub_00780F30(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780F30u);

L_00780F30:
    fp_push(*(double*)ADDR(0x7C1F40)); /* 0x00780F30: fld qword ptr [0x7c1f40] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00780F36: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB570) = _v; } /* 0x00780F3C: fstp qword ptr [0x8ab570] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780F42: ret  */

}

void sub_00780F50(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780F50u);

L_00780F50:
    fp_push(*(float*)&MEM32(0x7C1FB8)); /* 0x00780F50: fld dword ptr [0x7c1fb8] */
    _st[0] += _st[0]; /* 0x00780F56: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB5A4) = _v; } /* 0x00780F58: fstp dword ptr [0x8ab5a4] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780F5E: ret  */

}

void sub_00780F60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780F60u);

L_00780F60:
    fp_push(*(float*)&MEM32(0x7C1FB8)); /* 0x00780F60: fld dword ptr [0x7c1fb8] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00780F66: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB5A0) = _v; } /* 0x00780F6C: fstp dword ptr [0x8ab5a0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780F72: ret  */

}

void sub_00780F80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780F80u);

L_00780F80:
    fp_push(*(double*)ADDR(0x7C1FC0)); /* 0x00780F80: fld qword ptr [0x7c1fc0] */
    _st[0] += _st[0]; /* 0x00780F86: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB598) = _v; } /* 0x00780F88: fstp qword ptr [0x8ab598] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780F8E: ret  */

}

void sub_00780F90(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780F90u);

L_00780F90:
    fp_push(*(double*)ADDR(0x7C1FC0)); /* 0x00780F90: fld qword ptr [0x7c1fc0] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00780F96: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB590) = _v; } /* 0x00780F9C: fstp qword ptr [0x8ab590] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780FA2: ret  */

}

void sub_00780FB0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780FB0u);

L_00780FB0:
    fp_push(*(float*)&MEM32(0x7C20C8)); /* 0x00780FB0: fld dword ptr [0x7c20c8] */
    _st[0] += _st[0]; /* 0x00780FB6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB5BC) = _v; } /* 0x00780FB8: fstp dword ptr [0x8ab5bc] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780FBE: ret  */

}

void sub_00780FC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780FC0u);

L_00780FC0:
    fp_push(*(float*)&MEM32(0x7C20C8)); /* 0x00780FC0: fld dword ptr [0x7c20c8] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00780FC6: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB5B8) = _v; } /* 0x00780FCC: fstp dword ptr [0x8ab5b8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780FD2: ret  */

}

void sub_00780FE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780FE0u);

L_00780FE0:
    fp_push(*(double*)ADDR(0x7C20D0)); /* 0x00780FE0: fld qword ptr [0x7c20d0] */
    _st[0] += _st[0]; /* 0x00780FE6: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB5B0) = _v; } /* 0x00780FE8: fstp qword ptr [0x8ab5b0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00780FEE: ret  */

}

void sub_00780FF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00780FF0u);

L_00780FF0:
    fp_push(*(double*)ADDR(0x7C20D0)); /* 0x00780FF0: fld qword ptr [0x7c20d0] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00780FF6: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB5A8) = _v; } /* 0x00780FFC: fstp qword ptr [0x8ab5a8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781002: ret  */

}

void sub_00781010(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781010u);

L_00781010:
    fp_push(*(float*)&MEM32(0x7C2128)); /* 0x00781010: fld dword ptr [0x7c2128] */
    _st[0] += _st[0]; /* 0x00781016: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB5D4) = _v; } /* 0x00781018: fstp dword ptr [0x8ab5d4] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078101E: ret  */

}

void sub_00781020(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781020u);

L_00781020:
    fp_push(*(float*)&MEM32(0x7C2128)); /* 0x00781020: fld dword ptr [0x7c2128] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00781026: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB5D0) = _v; } /* 0x0078102C: fstp dword ptr [0x8ab5d0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781032: ret  */

}

void sub_00781040(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781040u);

L_00781040:
    fp_push(*(double*)ADDR(0x7C2130)); /* 0x00781040: fld qword ptr [0x7c2130] */
    _st[0] += _st[0]; /* 0x00781046: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB5C8) = _v; } /* 0x00781048: fstp qword ptr [0x8ab5c8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078104E: ret  */

}

void sub_00781050(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781050u);

L_00781050:
    fp_push(*(double*)ADDR(0x7C2130)); /* 0x00781050: fld qword ptr [0x7c2130] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00781056: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB5C0) = _v; } /* 0x0078105C: fstp qword ptr [0x8ab5c0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781062: ret  */

}

void sub_00781070(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781070u);

L_00781070:
    fp_push(*(float*)&MEM32(0x7C2138)); /* 0x00781070: fld dword ptr [0x7c2138] */
    _st[0] += _st[0]; /* 0x00781076: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB5EC) = _v; } /* 0x00781078: fstp dword ptr [0x8ab5ec] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078107E: ret  */

}

void sub_00781080(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781080u);

L_00781080:
    fp_push(*(float*)&MEM32(0x7C2138)); /* 0x00781080: fld dword ptr [0x7c2138] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00781086: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB5E8) = _v; } /* 0x0078108C: fstp dword ptr [0x8ab5e8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781092: ret  */

}

void sub_007810A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007810A0u);

L_007810A0:
    fp_push(*(double*)ADDR(0x7C2140)); /* 0x007810A0: fld qword ptr [0x7c2140] */
    _st[0] += _st[0]; /* 0x007810A6: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB5E0) = _v; } /* 0x007810A8: fstp qword ptr [0x8ab5e0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007810AE: ret  */

}

void sub_007810B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007810B0u);

L_007810B0:
    fp_push(*(double*)ADDR(0x7C2140)); /* 0x007810B0: fld qword ptr [0x7c2140] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x007810B6: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB5D8) = _v; } /* 0x007810BC: fstp qword ptr [0x8ab5d8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007810C2: ret  */

}

void sub_007810D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007810D0u);

L_007810D0:
    fp_push(*(float*)&MEM32(0x7C2148)); /* 0x007810D0: fld dword ptr [0x7c2148] */
    _st[0] += _st[0]; /* 0x007810D6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB604) = _v; } /* 0x007810D8: fstp dword ptr [0x8ab604] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007810DE: ret  */

}

void sub_007810E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007810E0u);

L_007810E0:
    fp_push(*(float*)&MEM32(0x7C2148)); /* 0x007810E0: fld dword ptr [0x7c2148] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x007810E6: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB600) = _v; } /* 0x007810EC: fstp dword ptr [0x8ab600] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007810F2: ret  */

}

void sub_00781100(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781100u);

L_00781100:
    fp_push(*(double*)ADDR(0x7C2150)); /* 0x00781100: fld qword ptr [0x7c2150] */
    _st[0] += _st[0]; /* 0x00781106: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB5F8) = _v; } /* 0x00781108: fstp qword ptr [0x8ab5f8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078110E: ret  */

}

void sub_00781110(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781110u);

L_00781110:
    fp_push(*(double*)ADDR(0x7C2150)); /* 0x00781110: fld qword ptr [0x7c2150] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00781116: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB5F0) = _v; } /* 0x0078111C: fstp qword ptr [0x8ab5f0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781122: ret  */

}

void sub_00781130(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781130u);

L_00781130:
    fp_push(*(float*)&MEM32(0x7C2158)); /* 0x00781130: fld dword ptr [0x7c2158] */
    _st[0] += _st[0]; /* 0x00781136: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB61C) = _v; } /* 0x00781138: fstp dword ptr [0x8ab61c] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078113E: ret  */

}

void sub_00781140(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781140u);

L_00781140:
    fp_push(*(float*)&MEM32(0x7C2158)); /* 0x00781140: fld dword ptr [0x7c2158] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00781146: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB618) = _v; } /* 0x0078114C: fstp dword ptr [0x8ab618] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781152: ret  */

}

void sub_00781160(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781160u);

L_00781160:
    fp_push(*(double*)ADDR(0x7C2160)); /* 0x00781160: fld qword ptr [0x7c2160] */
    _st[0] += _st[0]; /* 0x00781166: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB610) = _v; } /* 0x00781168: fstp qword ptr [0x8ab610] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078116E: ret  */

}

void sub_00781170(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781170u);

L_00781170:
    fp_push(*(double*)ADDR(0x7C2160)); /* 0x00781170: fld qword ptr [0x7c2160] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00781176: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB608) = _v; } /* 0x0078117C: fstp qword ptr [0x8ab608] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781182: ret  */

}

void sub_00781190(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781190u);

L_00781190:
    fp_push(*(float*)&MEM32(0x7C2168)); /* 0x00781190: fld dword ptr [0x7c2168] */
    _st[0] += _st[0]; /* 0x00781196: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB634) = _v; } /* 0x00781198: fstp dword ptr [0x8ab634] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078119E: ret  */

}

void sub_007811A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007811A0u);

L_007811A0:
    fp_push(*(float*)&MEM32(0x7C2168)); /* 0x007811A0: fld dword ptr [0x7c2168] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x007811A6: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB630) = _v; } /* 0x007811AC: fstp dword ptr [0x8ab630] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007811B2: ret  */

}

void sub_007811C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007811C0u);

L_007811C0:
    fp_push(*(double*)ADDR(0x7C2170)); /* 0x007811C0: fld qword ptr [0x7c2170] */
    _st[0] += _st[0]; /* 0x007811C6: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB628) = _v; } /* 0x007811C8: fstp qword ptr [0x8ab628] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007811CE: ret  */

}

void sub_007811D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007811D0u);

L_007811D0:
    fp_push(*(double*)ADDR(0x7C2170)); /* 0x007811D0: fld qword ptr [0x7c2170] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x007811D6: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB620) = _v; } /* 0x007811DC: fstp qword ptr [0x8ab620] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007811E2: ret  */

}

void sub_007811F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007811F0u);

L_007811F0:
    fp_push(*(float*)&MEM32(0x7C21D8)); /* 0x007811F0: fld dword ptr [0x7c21d8] */
    _st[0] += _st[0]; /* 0x007811F6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB64C) = _v; } /* 0x007811F8: fstp dword ptr [0x8ab64c] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007811FE: ret  */

}

void sub_00781200(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781200u);

L_00781200:
    fp_push(*(float*)&MEM32(0x7C21D8)); /* 0x00781200: fld dword ptr [0x7c21d8] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00781206: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB648) = _v; } /* 0x0078120C: fstp dword ptr [0x8ab648] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781212: ret  */

}

void sub_00781220(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781220u);

L_00781220:
    fp_push(*(double*)ADDR(0x7C21E0)); /* 0x00781220: fld qword ptr [0x7c21e0] */
    _st[0] += _st[0]; /* 0x00781226: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB640) = _v; } /* 0x00781228: fstp qword ptr [0x8ab640] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078122E: ret  */

}

void sub_00781230(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781230u);

L_00781230:
    fp_push(*(double*)ADDR(0x7C21E0)); /* 0x00781230: fld qword ptr [0x7c21e0] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00781236: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB638) = _v; } /* 0x0078123C: fstp qword ptr [0x8ab638] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781242: ret  */

}

void sub_00781250(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781250u);

L_00781250:
    fp_push(*(float*)&MEM32(0x7C2248)); /* 0x00781250: fld dword ptr [0x7c2248] */
    _st[0] += _st[0]; /* 0x00781256: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB664) = _v; } /* 0x00781258: fstp dword ptr [0x8ab664] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078125E: ret  */

}

void sub_00781260(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781260u);

L_00781260:
    fp_push(*(float*)&MEM32(0x7C2248)); /* 0x00781260: fld dword ptr [0x7c2248] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00781266: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB660) = _v; } /* 0x0078126C: fstp dword ptr [0x8ab660] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781272: ret  */

}

void sub_00781280(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781280u);

L_00781280:
    fp_push(*(double*)ADDR(0x7C2250)); /* 0x00781280: fld qword ptr [0x7c2250] */
    _st[0] += _st[0]; /* 0x00781286: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB658) = _v; } /* 0x00781288: fstp qword ptr [0x8ab658] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078128E: ret  */

}

void sub_00781290(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781290u);

L_00781290:
    fp_push(*(double*)ADDR(0x7C2250)); /* 0x00781290: fld qword ptr [0x7c2250] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00781296: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB650) = _v; } /* 0x0078129C: fstp qword ptr [0x8ab650] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007812A2: ret  */

}

void sub_007812B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007812B0u);

L_007812B0:
    fp_push(*(float*)&MEM32(0x7C22B8)); /* 0x007812B0: fld dword ptr [0x7c22b8] */
    _st[0] += _st[0]; /* 0x007812B6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB6B4) = _v; } /* 0x007812B8: fstp dword ptr [0x8ab6b4] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007812BE: ret  */

}

void sub_007812C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007812C0u);

L_007812C0:
    fp_push(*(float*)&MEM32(0x7C22B8)); /* 0x007812C0: fld dword ptr [0x7c22b8] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x007812C6: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB6B0) = _v; } /* 0x007812CC: fstp dword ptr [0x8ab6b0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007812D2: ret  */

}

void sub_007812E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007812E0u);

L_007812E0:
    fp_push(*(double*)ADDR(0x7C22C0)); /* 0x007812E0: fld qword ptr [0x7c22c0] */
    _st[0] += _st[0]; /* 0x007812E6: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB6A8) = _v; } /* 0x007812E8: fstp qword ptr [0x8ab6a8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007812EE: ret  */

}

void sub_007812F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007812F0u);

L_007812F0:
    fp_push(*(double*)ADDR(0x7C22C0)); /* 0x007812F0: fld qword ptr [0x7c22c0] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x007812F6: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB6A0) = _v; } /* 0x007812FC: fstp qword ptr [0x8ab6a0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781302: ret  */

}

void sub_00781310(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781310u);

L_00781310:
    PUSH32(esp, 0x007C23C8u); /* 0x00781310: push 0x7c23c8 */
    PUSH32(esp, 1); /* 0x00781315: push 1 */
    PUSH32(esp, 0x00812504u); /* 0x00781317: push 0x812504 */
    PUSH32(esp, 0); /* 0x0078131C: push 0 */
    PUSH32(esp, 0x00811E38u); /* 0x0078131E: push 0x811e38 */
    PUSH32(esp, 0x008123A0u); /* 0x00781323: push 0x8123a0 */
    ecx = 0x008AB668u; /* 0x00781328: mov ecx, 0x8ab668 */
    RECOMP_CALL(sub_006DAB60); /* 0x0078132D: call 0x6dab60 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007828B0u); /* 0x00781332: push 0x7828b0 */
    RECOMP_CALL(sub_0075C51D); /* 0x00781337: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0078133C: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078133D: ret  */

}

void sub_00781340(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781340u);

L_00781340:
    fp_push(*(float*)&MEM32(0x7C23D0)); /* 0x00781340: fld dword ptr [0x7c23d0] */
    _st[0] += _st[0]; /* 0x00781346: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB704) = _v; } /* 0x00781348: fstp dword ptr [0x8ab704] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078134E: ret  */

}

void sub_00781350(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781350u);

L_00781350:
    fp_push(*(float*)&MEM32(0x7C23D0)); /* 0x00781350: fld dword ptr [0x7c23d0] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x00781356: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AB700) = _v; } /* 0x0078135C: fstp dword ptr [0x8ab700] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781362: ret  */

}

void sub_00781370(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781370u);

L_00781370:
    fp_push(*(double*)ADDR(0x7C23D8)); /* 0x00781370: fld qword ptr [0x7c23d8] */
    _st[0] += _st[0]; /* 0x00781376: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB6F8) = _v; } /* 0x00781378: fstp qword ptr [0x8ab6f8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078137E: ret  */

}

void sub_00781380(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781380u);

L_00781380:
    fp_push(*(double*)ADDR(0x7C23D8)); /* 0x00781380: fld qword ptr [0x7c23d8] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00781386: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AB6F0) = _v; } /* 0x0078138C: fstp qword ptr [0x8ab6f0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781392: ret  */

}

void sub_007813A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007813A0u);

L_007813A0:
    PUSH32(esp, 0x007C0910u); /* 0x007813A0: push 0x7c0910 */
    PUSH32(esp, 1); /* 0x007813A5: push 1 */
    PUSH32(esp, 0x008139DCu); /* 0x007813A7: push 0x8139dc */
    PUSH32(esp, 0); /* 0x007813AC: push 0 */
    PUSH32(esp, 0x00812528u); /* 0x007813AE: push 0x812528 */
    PUSH32(esp, 0x00813520u); /* 0x007813B3: push 0x813520 */
    ecx = 0x008AB6B8u; /* 0x007813B8: mov ecx, 0x8ab6b8 */
    RECOMP_CALL(sub_006DAB60); /* 0x007813BD: call 0x6dab60 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007828C0u); /* 0x007813C2: push 0x7828c0 */
    RECOMP_CALL(sub_0075C51D); /* 0x007813C7: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x007813CC: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007813CD: ret  */

}

void sub_007813D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007813D0u);

L_007813D0:
    fp_push(*(float*)&MEM32(0x7C24E0)); /* 0x007813D0: fld dword ptr [0x7c24e0] */
    _st[0] += _st[0]; /* 0x007813D6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AD2AC) = _v; } /* 0x007813D8: fstp dword ptr [0x8ad2ac] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007813DE: ret  */

}

void sub_007813E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007813E0u);

L_007813E0:
    fp_push(*(float*)&MEM32(0x7C24E0)); /* 0x007813E0: fld dword ptr [0x7c24e0] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x007813E6: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8AD2A8) = _v; } /* 0x007813EC: fstp dword ptr [0x8ad2a8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007813F2: ret  */

}

void sub_00781400(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781400u);

L_00781400:
    fp_push(*(double*)ADDR(0x7C24E8)); /* 0x00781400: fld qword ptr [0x7c24e8] */
    _st[0] += _st[0]; /* 0x00781406: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8AD2A0) = _v; } /* 0x00781408: fstp qword ptr [0x8ad2a0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078140E: ret  */

}

void sub_00781410(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781410u);

L_00781410:
    fp_push(*(double*)ADDR(0x7C24E8)); /* 0x00781410: fld qword ptr [0x7c24e8] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x00781416: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8AD298) = _v; } /* 0x0078141C: fstp qword ptr [0x8ad298] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781422: ret  */

}

void sub_00781430(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781430u);

    goto L_00781430;

L_006F5596:
    PUSH32(esp, esi); /* 0x006F5596: push esi */
    esi = ecx; /* 0x006F5597: mov esi, ecx */
    PUSH32(esp, 0x1Cu); /* 0x006F5599: push 0x1c */
    PUSH32(esp, esi); /* 0x006F559B: push esi */
    RECOMP_CALL(sub_006FAFCD); /* 0x006F559C: call 0x6fafcd */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x006F55A1: pop ecx */
    ecx = POP32_VAL(esp); /* 0x006F55A2: pop ecx */
    eax = esi; /* 0x006F55A3: mov eax, esi */
    esi = POP32_VAL(esp); /* 0x006F55A5: pop esi */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x006F55A6: ret  */

L_00781430:
    ecx = 0x008AD4F0u; /* 0x00781430: mov ecx, 0x8ad4f0 */
    RECOMP_BACKEDGE();
    goto L_006F5596; /* 0x00781435: jmp 0x6f5596 */

}

void sub_0078143A(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0078143Au);

L_0078143A:
    PUSH32(esp, 0x007C2FE8u); /* 0x0078143A: push 0x7c2fe8 */
    ecx = 0x008AD618u; /* 0x0078143F: mov ecx, 0x8ad618 */
    RECOMP_CALL(sub_006F6C44); /* 0x00781444: call 0x6f6c44 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007828D0u); /* 0x00781449: push 0x7828d0 */
    MEM32(0x8AD618) = 0x007C2EE0u; /* 0x0078144E: mov dword ptr [0x8ad618], 0x7c2ee0 */
    RECOMP_CALL(sub_0075C51D); /* 0x00781458: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0078145D: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078145E: ret  */

}

void sub_0078145F(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0078145Fu);

    goto L_0078145F;

L_006F5596:
    PUSH32(esp, esi); /* 0x006F5596: push esi */
    esi = ecx; /* 0x006F5597: mov esi, ecx */
    PUSH32(esp, 0x1Cu); /* 0x006F5599: push 0x1c */
    PUSH32(esp, esi); /* 0x006F559B: push esi */
    RECOMP_CALL(sub_006FAFCD); /* 0x006F559C: call 0x6fafcd */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x006F55A1: pop ecx */
    ecx = POP32_VAL(esp); /* 0x006F55A2: pop ecx */
    eax = esi; /* 0x006F55A3: mov eax, esi */
    esi = POP32_VAL(esp); /* 0x006F55A5: pop esi */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x006F55A6: ret  */

L_0078145F:
    ecx = 0x008AD644u; /* 0x0078145F: mov ecx, 0x8ad644 */
    RECOMP_BACKEDGE();
    goto L_006F5596; /* 0x00781464: jmp 0x6f5596 */

}

void sub_00781469(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781469u);

    goto L_00781469;

L_006F5596:
    PUSH32(esp, esi); /* 0x006F5596: push esi */
    esi = ecx; /* 0x006F5597: mov esi, ecx */
    PUSH32(esp, 0x1Cu); /* 0x006F5599: push 0x1c */
    PUSH32(esp, esi); /* 0x006F559B: push esi */
    RECOMP_CALL(sub_006FAFCD); /* 0x006F559C: call 0x6fafcd */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x006F55A1: pop ecx */
    ecx = POP32_VAL(esp); /* 0x006F55A2: pop ecx */
    eax = esi; /* 0x006F55A3: mov eax, esi */
    esi = POP32_VAL(esp); /* 0x006F55A5: pop esi */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x006F55A6: ret  */

L_00781469:
    ecx = 0x008AD680u; /* 0x00781469: mov ecx, 0x8ad680 */
    RECOMP_BACKEDGE();
    goto L_006F5596; /* 0x0078146E: jmp 0x6f5596 */

}

void sub_00781473(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781473u);

L_00781473:
    PUSH32(esp, 0x007828DBu); /* 0x00781473: push 0x7828db */
    RECOMP_CALL(sub_0075C51D); /* 0x00781478: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0078147D: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078147E: ret  */

}

void sub_0078147F(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0078147Fu);

L_0078147F:
    PUSH32(esp, 0x007C3140u); /* 0x0078147F: push 0x7c3140 */
    ecx = 0x008AD74Cu; /* 0x00781484: mov ecx, 0x8ad74c */
    RECOMP_CALL(sub_006F6C44); /* 0x00781489: call 0x6f6c44 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007828E5u); /* 0x0078148E: push 0x7828e5 */
    MEM32(0x8AD74C) = 0x007C3108u; /* 0x00781493: mov dword ptr [0x8ad74c], 0x7c3108 */
    RECOMP_CALL(sub_0075C51D); /* 0x0078149D: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x007814A2: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007814A3: ret  */

}

void sub_007814A4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007814A4u);

L_007814A4:
    PUSH32(esp, 0x007C3144u); /* 0x007814A4: push 0x7c3144 */
    ecx = 0x008AD7B0u; /* 0x007814A9: mov ecx, 0x8ad7b0 */
    RECOMP_CALL(sub_006F6C44); /* 0x007814AE: call 0x6f6c44 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007828F0u); /* 0x007814B3: push 0x7828f0 */
    MEM32(0x8AD7B0) = 0x007C3108u; /* 0x007814B8: mov dword ptr [0x8ad7b0], 0x7c3108 */
    RECOMP_CALL(sub_0075C51D); /* 0x007814C2: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x007814C7: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007814C8: ret  */

}

void sub_007814C9(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007814C9u);

L_007814C9:
    PUSH32(esp, 0x007C3148u); /* 0x007814C9: push 0x7c3148 */
    ecx = 0x008AD7D8u; /* 0x007814CE: mov ecx, 0x8ad7d8 */
    RECOMP_CALL(sub_006F6C44); /* 0x007814D3: call 0x6f6c44 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007828FBu); /* 0x007814D8: push 0x7828fb */
    MEM32(0x8AD7D8) = 0x007C3108u; /* 0x007814DD: mov dword ptr [0x8ad7d8], 0x7c3108 */
    RECOMP_CALL(sub_0075C51D); /* 0x007814E7: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x007814EC: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007814ED: ret  */

}

void sub_007814EE(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007814EEu);

L_007814EE:
    PUSH32(esp, 0x007C314Cu); /* 0x007814EE: push 0x7c314c */
    ecx = 0x008AD710u; /* 0x007814F3: mov ecx, 0x8ad710 */
    RECOMP_CALL(sub_006F6C44); /* 0x007814F8: call 0x6f6c44 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782906u); /* 0x007814FD: push 0x782906 */
    MEM32(0x8AD710) = 0x007C3108u; /* 0x00781502: mov dword ptr [0x8ad710], 0x7c3108 */
    RECOMP_CALL(sub_0075C51D); /* 0x0078150C: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00781511: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781512: ret  */

}

void sub_00781513(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781513u);

L_00781513:
    PUSH32(esp, 0x007C3150u); /* 0x00781513: push 0x7c3150 */
    ecx = 0x008AD800u; /* 0x00781518: mov ecx, 0x8ad800 */
    RECOMP_CALL(sub_006F6C44); /* 0x0078151D: call 0x6f6c44 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782911u); /* 0x00781522: push 0x782911 */
    MEM32(0x8AD800) = 0x007C3108u; /* 0x00781527: mov dword ptr [0x8ad800], 0x7c3108 */
    RECOMP_CALL(sub_0075C51D); /* 0x00781531: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00781536: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781537: ret  */

}

void sub_00781538(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781538u);

L_00781538:
    PUSH32(esp, 0x007C3154u); /* 0x00781538: push 0x7c3154 */
    ecx = 0x008AD760u; /* 0x0078153D: mov ecx, 0x8ad760 */
    RECOMP_CALL(sub_006F6C44); /* 0x00781542: call 0x6f6c44 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x0078291Cu); /* 0x00781547: push 0x78291c */
    MEM32(0x8AD760) = 0x007C3108u; /* 0x0078154C: mov dword ptr [0x8ad760], 0x7c3108 */
    RECOMP_CALL(sub_0075C51D); /* 0x00781556: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0078155B: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078155C: ret  */

}

void sub_0078155D(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0078155Du);

L_0078155D:
    PUSH32(esp, 0x007C3158u); /* 0x0078155D: push 0x7c3158 */
    ecx = 0x008AD850u; /* 0x00781562: mov ecx, 0x8ad850 */
    RECOMP_CALL(sub_006F6C44); /* 0x00781567: call 0x6f6c44 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782927u); /* 0x0078156C: push 0x782927 */
    MEM32(0x8AD850) = 0x007C3108u; /* 0x00781571: mov dword ptr [0x8ad850], 0x7c3108 */
    RECOMP_CALL(sub_0075C51D); /* 0x0078157B: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00781580: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781581: ret  */

}

void sub_00781582(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781582u);

L_00781582:
    PUSH32(esp, 0x007C315Cu); /* 0x00781582: push 0x7c315c */
    ecx = 0x008AD724u; /* 0x00781587: mov ecx, 0x8ad724 */
    RECOMP_CALL(sub_006F6C44); /* 0x0078158C: call 0x6f6c44 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782932u); /* 0x00781591: push 0x782932 */
    MEM32(0x8AD724) = 0x007C3108u; /* 0x00781596: mov dword ptr [0x8ad724], 0x7c3108 */
    RECOMP_CALL(sub_0075C51D); /* 0x007815A0: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x007815A5: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007815A6: ret  */

}

void sub_007815A7(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007815A7u);

L_007815A7:
    PUSH32(esp, 0x007C3160u); /* 0x007815A7: push 0x7c3160 */
    ecx = 0x008AD83Cu; /* 0x007815AC: mov ecx, 0x8ad83c */
    RECOMP_CALL(sub_006F6C44); /* 0x007815B1: call 0x6f6c44 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x0078293Du); /* 0x007815B6: push 0x78293d */
    MEM32(0x8AD83C) = 0x007C3108u; /* 0x007815BB: mov dword ptr [0x8ad83c], 0x7c3108 */
    RECOMP_CALL(sub_0075C51D); /* 0x007815C5: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x007815CA: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007815CB: ret  */

}

void sub_007815CC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007815CCu);

L_007815CC:
    PUSH32(esp, 0x007C3164u); /* 0x007815CC: push 0x7c3164 */
    ecx = 0x008AD788u; /* 0x007815D1: mov ecx, 0x8ad788 */
    RECOMP_CALL(sub_006F6C44); /* 0x007815D6: call 0x6f6c44 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782948u); /* 0x007815DB: push 0x782948 */
    MEM32(0x8AD788) = 0x007C3108u; /* 0x007815E0: mov dword ptr [0x8ad788], 0x7c3108 */
    RECOMP_CALL(sub_0075C51D); /* 0x007815EA: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x007815EF: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007815F0: ret  */

}

void sub_007815F1(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007815F1u);

L_007815F1:
    PUSH32(esp, 0x007C3168u); /* 0x007815F1: push 0x7c3168 */
    ecx = 0x008AD814u; /* 0x007815F6: mov ecx, 0x8ad814 */
    RECOMP_CALL(sub_006F6C44); /* 0x007815FB: call 0x6f6c44 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782953u); /* 0x00781600: push 0x782953 */
    MEM32(0x8AD814) = 0x007C3108u; /* 0x00781605: mov dword ptr [0x8ad814], 0x7c3108 */
    RECOMP_CALL(sub_0075C51D); /* 0x0078160F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00781614: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781615: ret  */

}

void sub_00781616(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781616u);

L_00781616:
    PUSH32(esp, 0x007C316Cu); /* 0x00781616: push 0x7c316c */
    ecx = 0x008AD8B4u; /* 0x0078161B: mov ecx, 0x8ad8b4 */
    RECOMP_CALL(sub_006F6C44); /* 0x00781620: call 0x6f6c44 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x0078295Eu); /* 0x00781625: push 0x78295e */
    MEM32(0x8AD8B4) = 0x007C3108u; /* 0x0078162A: mov dword ptr [0x8ad8b4], 0x7c3108 */
    RECOMP_CALL(sub_0075C51D); /* 0x00781634: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00781639: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078163A: ret  */

}

void sub_0078163B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0078163Bu);

L_0078163B:
    PUSH32(esp, 0x007C3170u); /* 0x0078163B: push 0x7c3170 */
    ecx = 0x008AD904u; /* 0x00781640: mov ecx, 0x8ad904 */
    RECOMP_CALL(sub_006F6C44); /* 0x00781645: call 0x6f6c44 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782969u); /* 0x0078164A: push 0x782969 */
    MEM32(0x8AD904) = 0x007C3108u; /* 0x0078164F: mov dword ptr [0x8ad904], 0x7c3108 */
    RECOMP_CALL(sub_0075C51D); /* 0x00781659: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0078165E: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078165F: ret  */

}

void sub_00781660(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781660u);

L_00781660:
    PUSH32(esp, 0x007C3174u); /* 0x00781660: push 0x7c3174 */
    ecx = 0x008AD878u; /* 0x00781665: mov ecx, 0x8ad878 */
    RECOMP_CALL(sub_006F6C44); /* 0x0078166A: call 0x6f6c44 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782974u); /* 0x0078166F: push 0x782974 */
    MEM32(0x8AD878) = 0x007C3108u; /* 0x00781674: mov dword ptr [0x8ad878], 0x7c3108 */
    RECOMP_CALL(sub_0075C51D); /* 0x0078167E: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00781683: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781684: ret  */

}

void sub_00781685(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781685u);

L_00781685:
    PUSH32(esp, 0x007C3178u); /* 0x00781685: push 0x7c3178 */
    ecx = 0x008AD864u; /* 0x0078168A: mov ecx, 0x8ad864 */
    RECOMP_CALL(sub_006F6C44); /* 0x0078168F: call 0x6f6c44 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x0078297Fu); /* 0x00781694: push 0x78297f */
    MEM32(0x8AD864) = 0x007C3108u; /* 0x00781699: mov dword ptr [0x8ad864], 0x7c3108 */
    RECOMP_CALL(sub_0075C51D); /* 0x007816A3: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x007816A8: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007816A9: ret  */

}

void sub_007816AA(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007816AAu);

L_007816AA:
    PUSH32(esp, 0x007C317Cu); /* 0x007816AA: push 0x7c317c */
    ecx = 0x008AD8C8u; /* 0x007816AF: mov ecx, 0x8ad8c8 */
    RECOMP_CALL(sub_006F6C44); /* 0x007816B4: call 0x6f6c44 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x0078298Au); /* 0x007816B9: push 0x78298a */
    MEM32(0x8AD8C8) = 0x007C3108u; /* 0x007816BE: mov dword ptr [0x8ad8c8], 0x7c3108 */
    RECOMP_CALL(sub_0075C51D); /* 0x007816C8: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x007816CD: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007816CE: ret  */

}

void sub_007816CF(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007816CFu);

L_007816CF:
    PUSH32(esp, 0x007C3180u); /* 0x007816CF: push 0x7c3180 */
    ecx = 0x008AD738u; /* 0x007816D4: mov ecx, 0x8ad738 */
    RECOMP_CALL(sub_006F6C44); /* 0x007816D9: call 0x6f6c44 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782995u); /* 0x007816DE: push 0x782995 */
    MEM32(0x8AD738) = 0x007C3108u; /* 0x007816E3: mov dword ptr [0x8ad738], 0x7c3108 */
    RECOMP_CALL(sub_0075C51D); /* 0x007816ED: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x007816F2: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007816F3: ret  */

}

void sub_007816F4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007816F4u);

L_007816F4:
    PUSH32(esp, 0x007C3184u); /* 0x007816F4: push 0x7c3184 */
    ecx = 0x008AD828u; /* 0x007816F9: mov ecx, 0x8ad828 */
    RECOMP_CALL(sub_006F6C44); /* 0x007816FE: call 0x6f6c44 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007829A0u); /* 0x00781703: push 0x7829a0 */
    MEM32(0x8AD828) = 0x007C3108u; /* 0x00781708: mov dword ptr [0x8ad828], 0x7c3108 */
    RECOMP_CALL(sub_0075C51D); /* 0x00781712: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00781717: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781718: ret  */

}

void sub_00781719(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781719u);

L_00781719:
    PUSH32(esp, 0x007C3188u); /* 0x00781719: push 0x7c3188 */
    ecx = 0x008AD774u; /* 0x0078171E: mov ecx, 0x8ad774 */
    RECOMP_CALL(sub_006F6C44); /* 0x00781723: call 0x6f6c44 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007829ABu); /* 0x00781728: push 0x7829ab */
    MEM32(0x8AD774) = 0x007C3108u; /* 0x0078172D: mov dword ptr [0x8ad774], 0x7c3108 */
    RECOMP_CALL(sub_0075C51D); /* 0x00781737: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0078173C: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078173D: ret  */

}

void sub_0078173E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0078173Eu);

L_0078173E:
    PUSH32(esp, 0x007C318Cu); /* 0x0078173E: push 0x7c318c */
    ecx = 0x008AD8A0u; /* 0x00781743: mov ecx, 0x8ad8a0 */
    RECOMP_CALL(sub_006F6C44); /* 0x00781748: call 0x6f6c44 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007829B6u); /* 0x0078174D: push 0x7829b6 */
    MEM32(0x8AD8A0) = 0x007C3108u; /* 0x00781752: mov dword ptr [0x8ad8a0], 0x7c3108 */
    RECOMP_CALL(sub_0075C51D); /* 0x0078175C: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00781761: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781762: ret  */

}

void sub_00781763(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781763u);

L_00781763:
    PUSH32(esp, 0x007C3190u); /* 0x00781763: push 0x7c3190 */
    ecx = 0x008AD8DCu; /* 0x00781768: mov ecx, 0x8ad8dc */
    RECOMP_CALL(sub_006F6C44); /* 0x0078176D: call 0x6f6c44 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007829C1u); /* 0x00781772: push 0x7829c1 */
    MEM32(0x8AD8DC) = 0x007C3108u; /* 0x00781777: mov dword ptr [0x8ad8dc], 0x7c3108 */
    RECOMP_CALL(sub_0075C51D); /* 0x00781781: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00781786: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781787: ret  */

}

void sub_00781788(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781788u);

L_00781788:
    PUSH32(esp, 0x007C3194u); /* 0x00781788: push 0x7c3194 */
    ecx = 0x008AD8F0u; /* 0x0078178D: mov ecx, 0x8ad8f0 */
    RECOMP_CALL(sub_006F6C44); /* 0x00781792: call 0x6f6c44 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007829CCu); /* 0x00781797: push 0x7829cc */
    MEM32(0x8AD8F0) = 0x007C3108u; /* 0x0078179C: mov dword ptr [0x8ad8f0], 0x7c3108 */
    RECOMP_CALL(sub_0075C51D); /* 0x007817A6: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x007817AB: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007817AC: ret  */

}

void sub_007817AD(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007817ADu);

L_007817AD:
    PUSH32(esp, 0x007C3198u); /* 0x007817AD: push 0x7c3198 */
    ecx = 0x008AD7C4u; /* 0x007817B2: mov ecx, 0x8ad7c4 */
    RECOMP_CALL(sub_006F6C44); /* 0x007817B7: call 0x6f6c44 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007829D7u); /* 0x007817BC: push 0x7829d7 */
    MEM32(0x8AD7C4) = 0x007C3108u; /* 0x007817C1: mov dword ptr [0x8ad7c4], 0x7c3108 */
    RECOMP_CALL(sub_0075C51D); /* 0x007817CB: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x007817D0: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007817D1: ret  */

}

void sub_007817D2(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007817D2u);

L_007817D2:
    PUSH32(esp, 0x007C319Cu); /* 0x007817D2: push 0x7c319c */
    ecx = 0x008AD88Cu; /* 0x007817D7: mov ecx, 0x8ad88c */
    RECOMP_CALL(sub_006F6C44); /* 0x007817DC: call 0x6f6c44 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007829E2u); /* 0x007817E1: push 0x7829e2 */
    MEM32(0x8AD88C) = 0x007C3108u; /* 0x007817E6: mov dword ptr [0x8ad88c], 0x7c3108 */
    RECOMP_CALL(sub_0075C51D); /* 0x007817F0: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x007817F5: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007817F6: ret  */

}

void sub_007817F7(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007817F7u);

L_007817F7:
    PUSH32(esp, 0x007C31A0u); /* 0x007817F7: push 0x7c31a0 */
    ecx = 0x008AD79Cu; /* 0x007817FC: mov ecx, 0x8ad79c */
    RECOMP_CALL(sub_006F6C44); /* 0x00781801: call 0x6f6c44 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007829EDu); /* 0x00781806: push 0x7829ed */
    MEM32(0x8AD79C) = 0x007C3108u; /* 0x0078180B: mov dword ptr [0x8ad79c], 0x7c3108 */
    RECOMP_CALL(sub_0075C51D); /* 0x00781815: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0078181A: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078181B: ret  */

}

void sub_0078181C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0078181Cu);

L_0078181C:
    PUSH32(esp, 0x007C31A4u); /* 0x0078181C: push 0x7c31a4 */
    ecx = 0x008AD7ECu; /* 0x00781821: mov ecx, 0x8ad7ec */
    RECOMP_CALL(sub_006F6C44); /* 0x00781826: call 0x6f6c44 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007829F8u); /* 0x0078182B: push 0x7829f8 */
    MEM32(0x8AD7EC) = 0x007C3108u; /* 0x00781830: mov dword ptr [0x8ad7ec], 0x7c3108 */
    RECOMP_CALL(sub_0075C51D); /* 0x0078183A: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0078183F: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781840: ret  */

}

void sub_00781841(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781841u);

L_00781841:
    PUSH32(esp, 0x00782A03u); /* 0x00781841: push 0x782a03 */
    RECOMP_CALL(sub_0075C51D); /* 0x00781846: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0078184B: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078184C: ret  */

}

void sub_0078184D(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0078184Du);

L_0078184D:
    PUSH32(esp, 0x00782A0Eu); /* 0x0078184D: push 0x782a0e */
    RECOMP_CALL(sub_0075C51D); /* 0x00781852: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00781857: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781858: ret  */

}

void sub_00781859(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781859u);

L_00781859:
    RECOMP_CALL(sub_0072CC9E); /* 0x00781859: call 0x72cc9e */
    RECOMP_FLAGS_IN();
    MEM32(0x8B4A20) = eax; /* 0x0078185E: mov dword ptr [0x8b4a20], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781863: ret  */

}

void sub_00781864(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781864u);

L_00781864:
    RECOMP_CALL(sub_0072D911); /* 0x00781864: call 0x72d911 */
    RECOMP_FLAGS_IN();
    eax = (uint32_t)LO8(eax); /* 0x00781869: movzx eax, al */
    MEM32(0x8B4A2C) = eax; /* 0x0078186C: mov dword ptr [0x8b4a2c], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781871: ret  */

}

void sub_00781880(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781880u);

L_00781880:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781880: ret  */

}

void sub_00781890(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781890u);

L_00781890:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781890: ret  */

}

void sub_007818A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007818A0u);

L_007818A0:
    ecx = 0x0081E7ECu; /* 0x007818A0: mov ecx, 0x81e7ec */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x007818A5: jmp 0x5cde60 */

}

void sub_007818B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007818B0u);

L_007818B0:
    ecx = 0x0081CBC0u; /* 0x007818B0: mov ecx, 0x81cbc0 */
    RECOMP_ITAIL(0x00413560u); RECOMP_RETURN(); /* 0x007818B5: jmp 0x413560 */

}

void sub_007818C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007818C0u);

L_007818C0:
    ecx = 0x0081E5B8u; /* 0x007818C0: mov ecx, 0x81e5b8 */
    RECOMP_ITAIL(0x00415150u); RECOMP_RETURN(); /* 0x007818C5: jmp 0x415150 */

}

void sub_007818D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007818D0u);

L_007818D0:
    ecx = 0x0081E388u; /* 0x007818D0: mov ecx, 0x81e388 */
    RECOMP_ITAIL(0x00415150u); RECOMP_RETURN(); /* 0x007818D5: jmp 0x415150 */

}

void sub_007818E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007818E0u);

L_007818E0:
    ecx = 0x0081E810u; /* 0x007818E0: mov ecx, 0x81e810 */
    RECOMP_ITAIL(0x0041E7F0u); RECOMP_RETURN(); /* 0x007818E5: jmp 0x41e7f0 */

}

void sub_007818F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007818F0u);

L_007818F0:
    PUSH32(esp, 0x004022D0u); /* 0x007818F0: push 0x4022d0 */
    PUSH32(esp, 8); /* 0x007818F5: push 8 */
    PUSH32(esp, 0xCu); /* 0x007818F7: push 0xc */
    PUSH32(esp, 0x00827D38u); /* 0x007818F9: push 0x827d38 */
    RECOMP_CALL(sub_0075C33D); /* 0x007818FE: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781903: ret  */

}

void sub_00781910(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781910u);

L_00781910:
    PUSH32(esp, 0x004022D0u); /* 0x00781910: push 0x4022d0 */
    PUSH32(esp, 8); /* 0x00781915: push 8 */
    PUSH32(esp, 0xCu); /* 0x00781917: push 0xc */
    PUSH32(esp, 0x00827DB8u); /* 0x00781919: push 0x827db8 */
    RECOMP_CALL(sub_0075C33D); /* 0x0078191E: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781923: ret  */

}

void sub_00781930(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781930u);

L_00781930:
    PUSH32(esp, 0x004022D0u); /* 0x00781930: push 0x4022d0 */
    PUSH32(esp, 8); /* 0x00781935: push 8 */
    PUSH32(esp, 0xCu); /* 0x00781937: push 0xc */
    PUSH32(esp, 0x00827E28u); /* 0x00781939: push 0x827e28 */
    RECOMP_CALL(sub_0075C33D); /* 0x0078193E: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781943: ret  */

}

void sub_00781950(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781950u);

L_00781950:
    PUSH32(esp, 0x004022D0u); /* 0x00781950: push 0x4022d0 */
    PUSH32(esp, 8); /* 0x00781955: push 8 */
    PUSH32(esp, 0xCu); /* 0x00781957: push 0xc */
    PUSH32(esp, 0x00827CD0u); /* 0x00781959: push 0x827cd0 */
    RECOMP_CALL(sub_0075C33D); /* 0x0078195E: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781963: ret  */

}

void sub_00781970(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781970u);

L_00781970:
    MEM32(0x7EA23C) = 0x00785D9Cu; /* 0x00781970: mov dword ptr [0x7ea23c], 0x785d9c */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078197A: ret  */

}

void sub_00781980(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781980u);

L_00781980:
    MEM32(0x827E88) = 0x00785DA0u; /* 0x00781980: mov dword ptr [0x827e88], 0x785da0 */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078198A: ret  */

}

void sub_00781990(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781990u);

L_00781990:
    PUSH32(esp, 0x004022D0u); /* 0x00781990: push 0x4022d0 */
    PUSH32(esp, 4); /* 0x00781995: push 4 */
    PUSH32(esp, 0x1Cu); /* 0x00781997: push 0x1c */
    PUSH32(esp, 0x007EA240u); /* 0x00781999: push 0x7ea240 */
    RECOMP_CALL(sub_0075C33D); /* 0x0078199E: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007819A3: ret  */

}

void sub_007819B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007819B0u);

L_007819B0:
    PUSH32(esp, 0x004022D0u); /* 0x007819B0: push 0x4022d0 */
    PUSH32(esp, 0xAu); /* 0x007819B5: push 0xa */
    PUSH32(esp, 0x1Cu); /* 0x007819B7: push 0x1c */
    PUSH32(esp, 0x007EA2B0u); /* 0x007819B9: push 0x7ea2b0 */
    RECOMP_CALL(sub_0075C33D); /* 0x007819BE: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007819C3: ret  */

}

void sub_007819D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007819D0u);

L_007819D0:
    PUSH32(esp, 0x004022D0u); /* 0x007819D0: push 0x4022d0 */
    PUSH32(esp, 6); /* 0x007819D5: push 6 */
    PUSH32(esp, 0x1Cu); /* 0x007819D7: push 0x1c */
    PUSH32(esp, 0x007EA3C8u); /* 0x007819D9: push 0x7ea3c8 */
    RECOMP_CALL(sub_0075C33D); /* 0x007819DE: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007819E3: ret  */

}

void sub_007819F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007819F0u);

L_007819F0:
    PUSH32(esp, 0x004022D0u); /* 0x007819F0: push 0x4022d0 */
    PUSH32(esp, 4); /* 0x007819F5: push 4 */
    PUSH32(esp, 0x1Cu); /* 0x007819F7: push 0x1c */
    PUSH32(esp, 0x007EA470u); /* 0x007819F9: push 0x7ea470 */
    RECOMP_CALL(sub_0075C33D); /* 0x007819FE: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781A03: ret  */

}

void sub_00781A10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781A10u);

L_00781A10:
    ecx = 0x00827B80u; /* 0x00781A10: mov ecx, 0x827b80 */
    RECOMP_ITAIL(0x00490340u); RECOMP_RETURN(); /* 0x00781A15: jmp 0x490340 */

}

void sub_00781A20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781A20u);

L_00781A20:
    ecx = 0x00827C9Cu; /* 0x00781A20: mov ecx, 0x827c9c */
    RECOMP_ITAIL(0x00490340u); RECOMP_RETURN(); /* 0x00781A25: jmp 0x490340 */

}

void sub_00781A30(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781A30u);

L_00781A30:
    ecx = 0x00827DA4u; /* 0x00781A30: mov ecx, 0x827da4 */
    RECOMP_ITAIL(0x00490340u); RECOMP_RETURN(); /* 0x00781A35: jmp 0x490340 */

}

void sub_00781A40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781A40u);

L_00781A40:
    ecx = 0x00827C74u; /* 0x00781A40: mov ecx, 0x827c74 */
    RECOMP_ITAIL(0x00435970u); RECOMP_RETURN(); /* 0x00781A45: jmp 0x435970 */

}

void sub_00781A50(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781A50u);

L_00781A50:
    ecx = 0x00827C3Cu; /* 0x00781A50: mov ecx, 0x827c3c */
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x00781A55: jmp 0x5ce0f0 */

}

void sub_00781A60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781A60u);

L_00781A60:
    ecx = 0x00827C60u; /* 0x00781A60: mov ecx, 0x827c60 */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00781A65: jmp 0x5cde60 */

}

void sub_00781A70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781A70u);

L_00781A70:
    ecx = 0x00827D98u; /* 0x00781A70: mov ecx, 0x827d98 */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00781A75: jmp 0x5cde60 */

}

void sub_00781A80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781A80u);

L_00781A80:
    ecx = 0x00827CA4u; /* 0x00781A80: mov ecx, 0x827ca4 */
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x00781A85: jmp 0x5ce0f0 */

}

void sub_00781A90(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781A90u);

L_00781A90:
    ecx = 0x00827EF0u; /* 0x00781A90: mov ecx, 0x827ef0 */
    RECOMP_ITAIL(0x0043A170u); RECOMP_RETURN(); /* 0x00781A95: jmp 0x43a170 */

}

void sub_00781AA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781AA0u);

L_00781AA0:
    ecx = 0x00827B88u; /* 0x00781AA0: mov ecx, 0x827b88 */
    RECOMP_ITAIL(0x0043AA00u); RECOMP_RETURN(); /* 0x00781AA5: jmp 0x43aa00 */

}

void sub_00781AB0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781AB0u);

L_00781AB0:
    ecx = 0x00828528u; /* 0x00781AB0: mov ecx, 0x828528 */
    RECOMP_ITAIL(0x004FE350u); RECOMP_RETURN(); /* 0x00781AB5: jmp 0x4fe350 */

}

void sub_00781AC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781AC0u);

L_00781AC0:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781AC0: ret  */

}

void sub_00781AD0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781AD0u);

L_00781AD0:
    ecx = 0x00828530u; /* 0x00781AD0: mov ecx, 0x828530 */
    RECOMP_ITAIL(0x00440820u); RECOMP_RETURN(); /* 0x00781AD5: jmp 0x440820 */

}

void sub_00781AE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781AE0u);

L_00781AE0:
    ecx = 0x008286FCu; /* 0x00781AE0: mov ecx, 0x8286fc */
    RECOMP_ITAIL(0x004466B0u); RECOMP_RETURN(); /* 0x00781AE5: jmp 0x4466b0 */

}

void sub_00781AF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781AF0u);

L_00781AF0:
    ecx = 0x00828770u; /* 0x00781AF0: mov ecx, 0x828770 */
    RECOMP_ITAIL(0x00457990u); RECOMP_RETURN(); /* 0x00781AF5: jmp 0x457990 */

}

void sub_00781B00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781B00u);

L_00781B00:
    ecx = 0x0082C6E8u; /* 0x00781B00: mov ecx, 0x82c6e8 */
    RECOMP_ITAIL(0x00576850u); RECOMP_RETURN(); /* 0x00781B05: jmp 0x576850 */

}

void sub_00781B10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781B10u);

L_00781B10:
    ecx = 0x0082C694u; /* 0x00781B10: mov ecx, 0x82c694 */
    RECOMP_ITAIL(0x004FE350u); RECOMP_RETURN(); /* 0x00781B15: jmp 0x4fe350 */

}

void sub_00781B20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781B20u);

L_00781B20:
    ecx = 0x0082C710u; /* 0x00781B20: mov ecx, 0x82c710 */
    RECOMP_ITAIL(0x00605390u); RECOMP_RETURN(); /* 0x00781B25: jmp 0x605390 */

}

void sub_00781B30(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781B30u);

L_00781B30:
    ecx = 0x0082BEA0u; /* 0x00781B30: mov ecx, 0x82bea0 */
    RECOMP_ITAIL(0x00605390u); RECOMP_RETURN(); /* 0x00781B35: jmp 0x605390 */

}

void sub_00781B40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781B40u);

L_00781B40:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781B40: ret  */

}

void sub_00781B50(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781B50u);

L_00781B50:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781B50: ret  */

}

void sub_00781B60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781B60u);

L_00781B60:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781B60: ret  */

}

void sub_00781B70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781B70u);

L_00781B70:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781B70: ret  */

}

void sub_00781B80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781B80u);

L_00781B80:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781B80: ret  */

}

void sub_00781B90(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781B90u);

L_00781B90:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781B90: ret  */

}

void sub_00781BA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781BA0u);

L_00781BA0:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781BA0: ret  */

}

void sub_00781BB0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781BB0u);

L_00781BB0:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781BB0: ret  */

}

void sub_00781BC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781BC0u);

L_00781BC0:
    ecx = 0x0082C5E8u; /* 0x00781BC0: mov ecx, 0x82c5e8 */
    RECOMP_ITAIL(0x00605390u); RECOMP_RETURN(); /* 0x00781BC5: jmp 0x605390 */

}

void sub_00781BD0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781BD0u);

L_00781BD0:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781BD0: ret  */

}

void sub_00781BE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781BE0u);

L_00781BE0:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781BE0: ret  */

}

void sub_00781BF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781BF0u);

L_00781BF0:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781BF0: ret  */

}

void sub_00781C00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781C00u);

L_00781C00:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781C00: ret  */

}

void sub_00781C10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781C10u);

L_00781C10:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781C10: ret  */

}

void sub_00781C20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781C20u);

L_00781C20:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781C20: ret  */

}

void sub_00781C30(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781C30u);

L_00781C30:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781C30: ret  */

}

void sub_00781C40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781C40u);

L_00781C40:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781C40: ret  */

}

void sub_00781C50(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781C50u);

L_00781C50:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781C50: ret  */

}

void sub_00781C60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781C60u);

L_00781C60:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781C60: ret  */

}

void sub_00781C70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781C70u);

L_00781C70:
    ecx = 0x0082BEBCu; /* 0x00781C70: mov ecx, 0x82bebc */
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x00781C75: jmp 0x5ce0f0 */

}

void sub_00781C80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781C80u);

L_00781C80:
    ecx = 0x0082C6A4u; /* 0x00781C80: mov ecx, 0x82c6a4 */
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x00781C85: jmp 0x5ce0f0 */

}

void sub_00781C90(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781C90u);

L_00781C90:
    ecx = 0x0082BEC4u; /* 0x00781C90: mov ecx, 0x82bec4 */
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x00781C95: jmp 0x5ce0f0 */

}

void sub_00781CA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781CA0u);

L_00781CA0:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781CA0: ret  */

}

void sub_00781CB0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781CB0u);

L_00781CB0:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781CB0: ret  */

}

void sub_00781CC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781CC0u);

L_00781CC0:
    PUSH32(esp, 0x004022D0u); /* 0x00781CC0: push 0x4022d0 */
    PUSH32(esp, 0xFAu); /* 0x00781CC5: push 0xfa */
    PUSH32(esp, 0x30u); /* 0x00781CCA: push 0x30 */
    PUSH32(esp, 0x0082DC08u); /* 0x00781CCC: push 0x82dc08 */
    RECOMP_CALL(sub_0075C33D); /* 0x00781CD1: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781CD6: ret  */

}

void sub_00781CE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781CE0u);

L_00781CE0:
    ecx = 0x00830D08u; /* 0x00781CE0: mov ecx, 0x830d08 */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00781CE5: jmp 0x5cde60 */

}

void sub_00781CF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781CF0u);

L_00781CF0:
    ecx = 0x0082DBC8u; /* 0x00781CF0: mov ecx, 0x82dbc8 */
    RECOMP_ITAIL(0x004933A0u); RECOMP_RETURN(); /* 0x00781CF5: jmp 0x4933a0 */

}

void sub_00781D00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781D00u);

L_00781D00:
    ecx = 0x008358C0u; /* 0x00781D00: mov ecx, 0x8358c0 */
    RECOMP_ITAIL(0x00491B00u); RECOMP_RETURN(); /* 0x00781D05: jmp 0x491b00 */

}

void sub_00781D10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781D10u);

L_00781D10:
    PUSH32(esp, 0x00491990u); /* 0x00781D10: push 0x491990 */
    PUSH32(esp, 0x16u); /* 0x00781D15: push 0x16 */
    PUSH32(esp, 0x70u); /* 0x00781D17: push 0x70 */
    PUSH32(esp, 0x00832DE0u); /* 0x00781D19: push 0x832de0 */
    RECOMP_CALL(sub_0075C33D); /* 0x00781D1E: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781D23: ret  */

}

void sub_00781D30(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781D30u);

L_00781D30:
    ecx = 0x00830AF0u; /* 0x00781D30: mov ecx, 0x830af0 */
    RECOMP_ITAIL(0x00491B40u); RECOMP_RETURN(); /* 0x00781D35: jmp 0x491b40 */

}

void sub_00781D40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781D40u);

L_00781D40:
    ecx = 0x0082DC00u; /* 0x00781D40: mov ecx, 0x82dc00 */
    RECOMP_ITAIL(0x00491B80u); RECOMP_RETURN(); /* 0x00781D45: jmp 0x491b80 */

}

void sub_00781D50(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781D50u);

L_00781D50:
    ecx = 0x0083579Cu; /* 0x00781D50: mov ecx, 0x83579c */
    RECOMP_ITAIL(0x004933A0u); RECOMP_RETURN(); /* 0x00781D55: jmp 0x4933a0 */

}

void sub_00781D60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781D60u);

L_00781D60:
    ecx = 0x008357E0u; /* 0x00781D60: mov ecx, 0x8357e0 */
    RECOMP_ITAIL(0x00494580u); RECOMP_RETURN(); /* 0x00781D65: jmp 0x494580 */

}

void sub_00781D70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781D70u);

L_00781D70:
    ecx = 0x0082DBC0u; /* 0x00781D70: mov ecx, 0x82dbc0 */
    RECOMP_ITAIL(0x00494530u); RECOMP_RETURN(); /* 0x00781D75: jmp 0x494530 */

}

void sub_00781D80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781D80u);

L_00781D80:
    ecx = 0x00832DA4u; /* 0x00781D80: mov ecx, 0x832da4 */
    RECOMP_ITAIL(0x00494530u); RECOMP_RETURN(); /* 0x00781D85: jmp 0x494530 */

}

void sub_00781D90(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781D90u);

L_00781D90:
    ecx = 0x00830D30u; /* 0x00781D90: mov ecx, 0x830d30 */
    RECOMP_ITAIL(0x00494200u); RECOMP_RETURN(); /* 0x00781D95: jmp 0x494200 */

}

void sub_00781DA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781DA0u);

L_00781DA0:
    ecx = 0x00830D14u; /* 0x00781DA0: mov ecx, 0x830d14 */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00781DA5: jmp 0x5cde60 */

}

void sub_00781DB0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781DB0u);

L_00781DB0:
    ecx = 0x008358C8u; /* 0x00781DB0: mov ecx, 0x8358c8 */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00781DB5: jmp 0x5cde60 */

}

void sub_00781DC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781DC0u);

L_00781DC0:
    ecx = 0x00835860u; /* 0x00781DC0: mov ecx, 0x835860 */
    RECOMP_ITAIL(0x00494580u); RECOMP_RETURN(); /* 0x00781DC5: jmp 0x494580 */

}

void sub_00781DD0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781DD0u);

L_00781DD0:
    ecx = 0x00830C78u; /* 0x00781DD0: mov ecx, 0x830c78 */
    RECOMP_ITAIL(0x00494940u); RECOMP_RETURN(); /* 0x00781DD5: jmp 0x494940 */

}

void sub_00781DE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781DE0u);

L_00781DE0:
    ecx = 0x00830AE8u; /* 0x00781DE0: mov ecx, 0x830ae8 */
    RECOMP_ITAIL(0x00494D50u); RECOMP_RETURN(); /* 0x00781DE5: jmp 0x494d50 */

}

void sub_00781DF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781DF0u);

L_00781DF0:
    ecx = 0x00830D1Cu; /* 0x00781DF0: mov ecx, 0x830d1c */
    RECOMP_ITAIL(0x004950B0u); RECOMP_RETURN(); /* 0x00781DF5: jmp 0x4950b0 */

}

void sub_00781E00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781E00u);

L_00781E00:
    ecx = 0x00835858u; /* 0x00781E00: mov ecx, 0x835858 */
    RECOMP_ITAIL(0x004950F0u); RECOMP_RETURN(); /* 0x00781E05: jmp 0x4950f0 */

}

void sub_00781E10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781E10u);

L_00781E10:
    ecx = 0x00835794u; /* 0x00781E10: mov ecx, 0x835794 */
    RECOMP_ITAIL(0x004950F0u); RECOMP_RETURN(); /* 0x00781E15: jmp 0x4950f0 */

}

void sub_00781E20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781E20u);

L_00781E20:
    ecx = 0x00835850u; /* 0x00781E20: mov ecx, 0x835850 */
    RECOMP_ITAIL(0x00495130u); RECOMP_RETURN(); /* 0x00781E25: jmp 0x495130 */

}

void sub_00781E30(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781E30u);

L_00781E30:
    PUSH32(esp, 0x004FF410u); /* 0x00781E30: push 0x4ff410 */
    PUSH32(esp, 7); /* 0x00781E35: push 7 */
    PUSH32(esp, 0x44u); /* 0x00781E37: push 0x44 */
    PUSH32(esp, 0x00836568u); /* 0x00781E39: push 0x836568 */
    RECOMP_CALL(sub_0075C33D); /* 0x00781E3E: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781E43: ret  */

}

void sub_00781E50(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781E50u);

L_00781E50:
    ecx = 0x008364F4u; /* 0x00781E50: mov ecx, 0x8364f4 */
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x00781E55: jmp 0x4022d0 */

}

void sub_00781E60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781E60u);

L_00781E60:
    ecx = 0x008371B0u; /* 0x00781E60: mov ecx, 0x8371b0 */
    RECOMP_ITAIL(0x0040BE20u); RECOMP_RETURN(); /* 0x00781E65: jmp 0x40be20 */

}

void sub_00781E70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781E70u);

L_00781E70:
    ecx = 0x00836750u; /* 0x00781E70: mov ecx, 0x836750 */
    RECOMP_ITAIL(0x0040BE20u); RECOMP_RETURN(); /* 0x00781E75: jmp 0x40be20 */

}

void sub_00781E80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781E80u);

L_00781E80:
    ecx = 0x00836560u; /* 0x00781E80: mov ecx, 0x836560 */
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x00781E85: jmp 0x5ce0f0 */

}

void sub_00781E90(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781E90u);

L_00781E90:
    ecx = 0x00863760u; /* 0x00781E90: mov ecx, 0x863760 */
    RECOMP_ITAIL(0x004FE350u); RECOMP_RETURN(); /* 0x00781E95: jmp 0x4fe350 */

}

void sub_00781EA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781EA0u);

L_00781EA0:
    ecx = 0x00839C40u; /* 0x00781EA0: mov ecx, 0x839c40 */
    RECOMP_ITAIL(0x0050F700u); RECOMP_RETURN(); /* 0x00781EA5: jmp 0x50f700 */

}

void sub_00781EB0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781EB0u);

L_00781EB0:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781EB0: ret  */

}

void sub_00781EC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781EC0u);

L_00781EC0:
    ecx = 0x008637D0u; /* 0x00781EC0: mov ecx, 0x8637d0 */
    RECOMP_ITAIL(0x005103E0u); RECOMP_RETURN(); /* 0x00781EC5: jmp 0x5103e0 */

}

void sub_00781ED0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781ED0u);

L_00781ED0:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781ED0: ret  */

}