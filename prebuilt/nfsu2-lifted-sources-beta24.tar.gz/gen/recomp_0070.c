/* AUTO-GENERATED from SPEED2.EXE by run_lift.py (pcrecomp lift32). DO NOT EDIT, DO NOT COMMIT. */
#define RECOMP_GENERATED_CODE
#include "recomp_types.h"
#include "recomp_funcs.h"
#include "guest_render_probe.h"
#include <math.h>
#include <string.h>

void sub_004C4E20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x004C4E20u);

L_004C4E20:
    PUSH32(esp, esi); /* 0x004C4E20: push esi */
    esi = ecx; /* 0x004C4E21: mov esi, ecx */
    RECOMP_CALL(sub_004C4E40); /* 0x004C4E23: call 0x4c4e40 */
    RECOMP_FLAGS_IN();
    /* test MEM8(esp + 0x8), 1 */ /* 0x004C4E28: test byte ptr [esp + 8], 1 */
    _flag_a = (uint32_t)(MEM8(esp + 0x8)) << 24; _flag_b = (uint32_t)(1) << 24;
    _cf = 0;
    _flag_k = FK_NARROW(FK_TEST, 24);
    if (TEST_Z(_flag_a, _flag_b)) goto L_004C4E38; /* 0x004C4E2D: je 0x4c4e38 */

L_004C4E2F:
    PUSH32(esp, esi); /* 0x004C4E2F: push esi */
    RECOMP_CALL(sub_00575590); /* 0x004C4E30: call 0x575590 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x004C4E35: add esp, 4 */
    _flag_k = FK_ADD;

L_004C4E38:
    eax = esi; /* 0x004C4E38: mov eax, esi */
    esi = POP32_VAL(esp); /* 0x004C4E3A: pop esi */
    RECOMP_FLAGS_OUT(); esp += 8; RECOMP_RETURN(); /* 0x004C4E3B: ret 4 */
}
