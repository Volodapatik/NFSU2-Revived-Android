/* AUTO-GENERATED from exact NoCD v1.1 seed 0x00470030 by pcrecomp lift32. */
#define RECOMP_GENERATED_CODE
#include "recomp_types.h"
#include "recomp_funcs.h"
#include "guest_render_probe.h"
#include <math.h>
#include <string.h>

void sub_00470030(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00470030u);

L_00470030:
    eax = MEM32(0x7EC840); /* 0x00470030: mov eax, dword ptr [0x7ec840] */
    PUSH32(esp, eax); /* 0x00470035: push eax */
    RECOMP_CALL(sub_0043E960); /* 0x00470036: call 0x43e960 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0047003B: add esp, 4 */
    _flag_k = FK_ADD;
    /* cmp eax, 0x4DCu */ /* 0x0047003E: cmp eax, 0x4dc */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x4DCu);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    _flag_k = FK_CMP;
    if (CMP_L(_flag_a, _flag_b)) goto L_0047006D; /* 0x00470043: jl 0x47006d */

L_00470045:
    ecx = MEM32(0x7EC840); /* 0x00470045: mov ecx, dword ptr [0x7ec840] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(7);
    ecx = ecx & 7; /* 0x0047004B: and ecx, 7 */
    _cf = 0;
    _flag_k = FK_TEST;
    _flag_a = (uint32_t)((ecx | 0x1000u)); _flag_b = (uint32_t)((ecx | 0x1000u));
    ecx = ecx | 0x1000u; /* 0x0047004E: or ecx, 0x1000 */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, ecx); /* 0x00470054: push ecx */
    PUSH32(esp, 0xDCu); /* 0x00470055: push 0xdc */
    RECOMP_CALL(sub_00440870); /* 0x0047005A: call 0x440870 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(8);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 8; /* 0x0047005F: add esp, 8 */
    _flag_k = FK_ADD;
    /* test eax, eax */ /* 0x00470062: test eax, eax */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(eax);
    _cf = 0;
    _flag_k = FK_TEST;
    if (TEST_Z(_flag_a, _flag_b)) goto L_0047006D; /* 0x00470064: je 0x47006d */

L_00470066:
    ecx = eax; /* 0x00470066: mov ecx, eax */
    RECOMP_ITAIL(0x0045CA10u); RECOMP_RETURN(); /* 0x00470068: jmp 0x45ca10 */

L_0047006D:
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0047006D: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0047006F: ret  */

}
