/* AUTO-GENERATED from SPEED2.analysis.exe by run_lift.py (pcrecomp lift32). DO NOT EDIT, DO NOT COMMIT. */
#define RECOMP_GENERATED_CODE
#include "recomp_types.h"
#include "recomp_funcs.h"
#include "guest_render_probe.h"
#include <math.h>
#include <string.h>

void sub_00776454(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776454u);

    goto L_00776454;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776454:
    eax = 0x007E1A34u; /* 0x00776454: mov eax, 0x7e1a34 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776459: jmp 0x75bf0e */

}

void sub_00776460(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776460u);

L_00776460:
    ecx = MEM32(ebp + (-0x904)); /* 0x00776460: mov ecx, dword ptr [ebp - 0x904] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00776466: jmp 0x553a80 */

}

void sub_0077646B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077646Bu);

L_0077646B:
    ecx = MEM32(ebp + (-0x904)); /* 0x0077646B: mov ecx, dword ptr [ebp - 0x904] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4Cu; /* 0x00776471: add ecx, 0x4c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004CBAA0u); RECOMP_RETURN(); /* 0x00776474: jmp 0x4cbaa0 */

}

void sub_00776479(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776479u);

L_00776479:
    ecx = MEM32(ebp + (-0x904)); /* 0x00776479: mov ecx, dword ptr [ebp - 0x904] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x120u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x120u; /* 0x0077647F: add ecx, 0x120 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0049D820u); RECOMP_RETURN(); /* 0x00776485: jmp 0x49d820 */

}

void sub_0077648A(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077648Au);

L_0077648A:
    ecx = ebp + (-0x8F0); /* 0x0077648A: lea ecx, [ebp - 0x8f0] */
    RECOMP_ITAIL(0x00401830u); RECOMP_RETURN(); /* 0x00776490: jmp 0x401830 */

}

void sub_00776495(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776495u);

L_00776495:
    ecx = ebp + (-0x900); /* 0x00776495: lea ecx, [ebp - 0x900] */
    RECOMP_ITAIL(0x0040BE20u); RECOMP_RETURN(); /* 0x0077649B: jmp 0x40be20 */

}

void sub_007764A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007764A0u);

    goto L_007764A0;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007764A0:
    eax = 0x007E1A78u; /* 0x007764A0: mov eax, 0x7e1a78 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007764A5: jmp 0x75bf0e */

}

void sub_007764B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007764B0u);

L_007764B0:
    PUSH32(esp, 0); /* 0x007764B0: push 0 */
    PUSH32(esp, 0x007980F0u); /* 0x007764B2: push 0x7980f0 */
    eax = MEM32(ebp + (-0x10)); /* 0x007764B7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007764BA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007764BB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007764C0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007764C3: ret  */

}

void sub_007764C4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007764C4u);

    goto L_007764C4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007764C4:
    eax = 0x007E1A9Cu; /* 0x007764C4: mov eax, 0x7e1a9c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007764C9: jmp 0x75bf0e */

}

void sub_007764D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007764D0u);

L_007764D0:
    PUSH32(esp, 0); /* 0x007764D0: push 0 */
    PUSH32(esp, 0x00798100u); /* 0x007764D2: push 0x798100 */
    eax = MEM32(ebp + (-0x10)); /* 0x007764D7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007764DA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007764DB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007764E0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007764E3: ret  */

}

void sub_007764E4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007764E4u);

    goto L_007764E4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007764E4:
    eax = 0x007E1AC0u; /* 0x007764E4: mov eax, 0x7e1ac0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007764E9: jmp 0x75bf0e */

}

void sub_007764F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007764F0u);

L_007764F0:
    PUSH32(esp, 0); /* 0x007764F0: push 0 */
    PUSH32(esp, 0x00798114u); /* 0x007764F2: push 0x798114 */
    eax = MEM32(ebp + (-0x10)); /* 0x007764F7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007764FA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007764FB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776500: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776503: ret  */

}

void sub_00776504(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776504u);

    goto L_00776504;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776504:
    eax = 0x007E1AE4u; /* 0x00776504: mov eax, 0x7e1ae4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776509: jmp 0x75bf0e */

}

void sub_00776510(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776510u);

L_00776510:
    PUSH32(esp, 0); /* 0x00776510: push 0 */
    PUSH32(esp, 0x00798128u); /* 0x00776512: push 0x798128 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776517: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077651A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077651B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776520: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776523: ret  */

}

void sub_00776524(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776524u);

    goto L_00776524;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776524:
    eax = 0x007E1B08u; /* 0x00776524: mov eax, 0x7e1b08 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776529: jmp 0x75bf0e */

}

void sub_00776530(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776530u);

L_00776530:
    PUSH32(esp, 0); /* 0x00776530: push 0 */
    PUSH32(esp, 0x00798218u); /* 0x00776532: push 0x798218 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776537: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077653A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077653B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776540: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776543: ret  */

}

void sub_00776544(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776544u);

    goto L_00776544;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776544:
    eax = 0x007E1B2Cu; /* 0x00776544: mov eax, 0x7e1b2c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776549: jmp 0x75bf0e */

}

void sub_00776550(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776550u);

L_00776550:
    ecx = MEM32(ebp + (-0x40)); /* 0x00776550: mov ecx, dword ptr [ebp - 0x40] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00776553: jmp 0x553a80 */

}

void sub_00776558(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776558u);

L_00776558:
    ecx = MEM32(ebp + (-0x40)); /* 0x00776558: mov ecx, dword ptr [ebp - 0x40] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x5Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x5Cu; /* 0x0077655B: add ecx, 0x5c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004CBA10u); RECOMP_RETURN(); /* 0x0077655E: jmp 0x4cba10 */

}

void sub_00776563(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776563u);

L_00776563:
    ecx = MEM32(ebp + (-0x40)); /* 0x00776563: mov ecx, dword ptr [ebp - 0x40] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x1A4u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x1A4u; /* 0x00776566: add ecx, 0x1a4 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004CBAA0u); RECOMP_RETURN(); /* 0x0077656C: jmp 0x4cbaa0 */

}

void sub_00776571(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776571u);

L_00776571:
    ecx = MEM32(ebp + (-0x40)); /* 0x00776571: mov ecx, dword ptr [ebp - 0x40] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x380u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x380u; /* 0x00776574: add ecx, 0x380 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004FF410u); RECOMP_RETURN(); /* 0x0077657A: jmp 0x4ff410 */

}

void sub_0077657F(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077657Fu);

    goto L_0077657F;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077657F:
    eax = 0x007E1B68u; /* 0x0077657F: mov eax, 0x7e1b68 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776584: jmp 0x75bf0e */

}

void sub_00776590(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776590u);

L_00776590:
    PUSH32(esp, 0); /* 0x00776590: push 0 */
    PUSH32(esp, 0x00798274u); /* 0x00776592: push 0x798274 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776597: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077659A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077659B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007765A0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007765A3: ret  */

}

void sub_007765A4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007765A4u);

    goto L_007765A4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007765A4:
    eax = 0x007E1B8Cu; /* 0x007765A4: mov eax, 0x7e1b8c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007765A9: jmp 0x75bf0e */

}

void sub_007765B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007765B0u);

L_007765B0:
    PUSH32(esp, 0); /* 0x007765B0: push 0 */
    PUSH32(esp, 0x0079829Cu); /* 0x007765B2: push 0x79829c */
    eax = MEM32(ebp + (-0x10)); /* 0x007765B7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007765BA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007765BB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007765C0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007765C3: ret  */

}

void sub_007765C4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007765C4u);

    goto L_007765C4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007765C4:
    eax = 0x007E1BDCu; /* 0x007765C4: mov eax, 0x7e1bdc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007765C9: jmp 0x75bf0e */

}

void sub_007765D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007765D0u);

L_007765D0:
    PUSH32(esp, 0); /* 0x007765D0: push 0 */
    PUSH32(esp, 0x007982B0u); /* 0x007765D2: push 0x7982b0 */
    eax = MEM32(ebp + (-0x10)); /* 0x007765D7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007765DA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007765DB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007765E0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007765E3: ret  */

}

void sub_007765E4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007765E4u);

    goto L_007765E4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007765E4:
    eax = 0x007E1C00u; /* 0x007765E4: mov eax, 0x7e1c00 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007765E9: jmp 0x75bf0e */

}

void sub_007765F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007765F0u);

L_007765F0:
    PUSH32(esp, 0); /* 0x007765F0: push 0 */
    PUSH32(esp, 0x007982C8u); /* 0x007765F2: push 0x7982c8 */
    eax = MEM32(ebp + (-0x10)); /* 0x007765F7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007765FA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007765FB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776600: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776603: ret  */

}

void sub_00776604(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776604u);

    goto L_00776604;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776604:
    eax = 0x007E1C24u; /* 0x00776604: mov eax, 0x7e1c24 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776609: jmp 0x75bf0e */

}

void sub_00776610(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776610u);

L_00776610:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776610: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00776613: jmp 0x553a80 */

}

void sub_00776618(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776618u);

L_00776618:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776618: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x54u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x54u; /* 0x0077661B: add ecx, 0x54 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004FF410u); RECOMP_RETURN(); /* 0x0077661E: jmp 0x4ff410 */

}

void sub_00776623(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776623u);

L_00776623:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776623: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x98u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x98u; /* 0x00776626: add ecx, 0x98 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004FF410u); RECOMP_RETURN(); /* 0x0077662C: jmp 0x4ff410 */

}

void sub_00776631(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776631u);

L_00776631:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776631: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0xDCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0xDCu; /* 0x00776634: add ecx, 0xdc */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004FF410u); RECOMP_RETURN(); /* 0x0077663A: jmp 0x4ff410 */

}

void sub_0077663F(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077663Fu);

    goto L_0077663F;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077663F:
    eax = 0x007DEFF4u; /* 0x0077663F: mov eax, 0x7deff4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776644: jmp 0x75bf0e */

}

void sub_00776650(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776650u);

L_00776650:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776650: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004DEFD0u); RECOMP_RETURN(); /* 0x00776653: jmp 0x4defd0 */

}

void sub_00776658(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776658u);

    goto L_00776658;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776658:
    eax = 0x007E1C48u; /* 0x00776658: mov eax, 0x7e1c48 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077665D: jmp 0x75bf0e */

}

void sub_00776670(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776670u);

L_00776670:
    PUSH32(esp, 0); /* 0x00776670: push 0 */
    PUSH32(esp, 0x007982F0u); /* 0x00776672: push 0x7982f0 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776677: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077667A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077667B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776680: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776683: ret  */

}

void sub_00776684(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776684u);

    goto L_00776684;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776684:
    eax = 0x007E1C6Cu; /* 0x00776684: mov eax, 0x7e1c6c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776689: jmp 0x75bf0e */

}

void sub_00776690(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776690u);

L_00776690:
    PUSH32(esp, 0); /* 0x00776690: push 0 */
    PUSH32(esp, 0x00798324u); /* 0x00776692: push 0x798324 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776697: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077669A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077669B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007766A0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007766A3: ret  */

}

void sub_007766A4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007766A4u);

    goto L_007766A4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007766A4:
    eax = 0x007E1C90u; /* 0x007766A4: mov eax, 0x7e1c90 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007766A9: jmp 0x75bf0e */

}

void sub_007766B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007766B0u);

L_007766B0:
    PUSH32(esp, 0); /* 0x007766B0: push 0 */
    PUSH32(esp, 0x00798338u); /* 0x007766B2: push 0x798338 */
    eax = MEM32(ebp + (-0x10)); /* 0x007766B7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007766BA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007766BB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007766C0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007766C3: ret  */

}

void sub_007766C4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007766C4u);

    goto L_007766C4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007766C4:
    eax = 0x007E1CB4u; /* 0x007766C4: mov eax, 0x7e1cb4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007766C9: jmp 0x75bf0e */

}

void sub_007766D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007766D0u);

L_007766D0:
    PUSH32(esp, 0); /* 0x007766D0: push 0 */
    PUSH32(esp, 0x0079834Cu); /* 0x007766D2: push 0x79834c */
    eax = MEM32(ebp + (-0x10)); /* 0x007766D7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007766DA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007766DB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007766E0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007766E3: ret  */

}

void sub_007766E4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007766E4u);

    goto L_007766E4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007766E4:
    eax = 0x007E1CD8u; /* 0x007766E4: mov eax, 0x7e1cd8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007766E9: jmp 0x75bf0e */

}

void sub_007766F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007766F0u);

L_007766F0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007766F0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x007766F3: jmp 0x553a80 */

}

void sub_007766F8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007766F8u);

L_007766F8:
    ecx = MEM32(ebp + (-0x10)); /* 0x007766F8: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4Cu; /* 0x007766FB: add ecx, 0x4c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x007766FE: jmp 0x5cde60 */

}

void sub_00776703(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776703u);

    goto L_00776703;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776703:
    eax = 0x007E1D04u; /* 0x00776703: mov eax, 0x7e1d04 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776708: jmp 0x75bf0e */

}

void sub_00776710(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776710u);

L_00776710:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776710: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 4; /* 0x00776713: add ecx, 4 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004E9180u); RECOMP_RETURN(); /* 0x00776716: jmp 0x4e9180 */

}

void sub_0077671B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077671Bu);

L_0077671B:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077671B: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x30u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x30u; /* 0x0077671E: add ecx, 0x30 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x00776721: jmp 0x5ce0f0 */

}

void sub_00776726(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776726u);

    goto L_00776726;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776726:
    eax = 0x007E1D30u; /* 0x00776726: mov eax, 0x7e1d30 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077672B: jmp 0x75bf0e */

}

void sub_00776730(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776730u);

L_00776730:
    PUSH32(esp, 0); /* 0x00776730: push 0 */
    PUSH32(esp, 0x00798378u); /* 0x00776732: push 0x798378 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776737: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077673A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077673B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776740: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776743: ret  */

}

void sub_00776744(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776744u);

    goto L_00776744;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776744:
    eax = 0x007E1D54u; /* 0x00776744: mov eax, 0x7e1d54 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776749: jmp 0x75bf0e */

}

void sub_00776750(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776750u);

L_00776750:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776750: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004EA360u); RECOMP_RETURN(); /* 0x00776753: jmp 0x4ea360 */

}

void sub_00776758(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776758u);

L_00776758:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776758: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x8Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x8Cu; /* 0x0077675B: add ecx, 0x8c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00776761: jmp 0x5cde60 */

}

void sub_00776766(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776766u);

    goto L_00776766;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776766:
    eax = 0x007E1DB4u; /* 0x00776766: mov eax, 0x7e1db4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077676B: jmp 0x75bf0e */

}

void sub_00776770(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776770u);

L_00776770:
    PUSH32(esp, 0); /* 0x00776770: push 0 */
    PUSH32(esp, 0x007983A0u); /* 0x00776772: push 0x7983a0 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776777: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077677A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077677B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776780: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776783: ret  */

}

void sub_00776784(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776784u);

    goto L_00776784;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776784:
    eax = 0x007E1DD8u; /* 0x00776784: mov eax, 0x7e1dd8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776789: jmp 0x75bf0e */

}

void sub_00776790(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776790u);

L_00776790:
    PUSH32(esp, 0); /* 0x00776790: push 0 */
    PUSH32(esp, 0x007983B0u); /* 0x00776792: push 0x7983b0 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776797: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077679A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077679B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007767A0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007767A3: ret  */

}

void sub_007767A4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007767A4u);

    goto L_007767A4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007767A4:
    eax = 0x007E1DFCu; /* 0x007767A4: mov eax, 0x7e1dfc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007767A9: jmp 0x75bf0e */

}

void sub_007767B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007767B0u);

L_007767B0:
    PUSH32(esp, 0); /* 0x007767B0: push 0 */
    PUSH32(esp, 0x007983BCu); /* 0x007767B2: push 0x7983bc */
    eax = MEM32(ebp + (-0x10)); /* 0x007767B7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007767BA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007767BB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007767C0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007767C3: ret  */

}

void sub_007767C4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007767C4u);

    goto L_007767C4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007767C4:
    eax = 0x007E1E20u; /* 0x007767C4: mov eax, 0x7e1e20 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007767C9: jmp 0x75bf0e */

}

void sub_007767D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007767D0u);

L_007767D0:
    PUSH32(esp, 0); /* 0x007767D0: push 0 */
    PUSH32(esp, 0x007983D0u); /* 0x007767D2: push 0x7983d0 */
    eax = MEM32(ebp + (-0x10)); /* 0x007767D7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007767DA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007767DB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007767E0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007767E3: ret  */

}

void sub_007767E4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007767E4u);

    goto L_007767E4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007767E4:
    eax = 0x007E1E44u; /* 0x007767E4: mov eax, 0x7e1e44 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007767E9: jmp 0x75bf0e */

}

void sub_007767F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007767F0u);

L_007767F0:
    PUSH32(esp, 0); /* 0x007767F0: push 0 */
    PUSH32(esp, 0x007983E8u); /* 0x007767F2: push 0x7983e8 */
    eax = MEM32(ebp + (-0x10)); /* 0x007767F7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007767FA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007767FB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776800: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776803: ret  */

}

void sub_00776804(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776804u);

    goto L_00776804;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776804:
    eax = 0x007E1E68u; /* 0x00776804: mov eax, 0x7e1e68 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776809: jmp 0x75bf0e */

}

void sub_00776810(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776810u);

L_00776810:
    PUSH32(esp, 0); /* 0x00776810: push 0 */
    PUSH32(esp, 0x00798400u); /* 0x00776812: push 0x798400 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776817: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077681A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077681B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776820: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776823: ret  */

}

void sub_00776824(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776824u);

    goto L_00776824;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776824:
    eax = 0x007E1E8Cu; /* 0x00776824: mov eax, 0x7e1e8c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776829: jmp 0x75bf0e */

}

void sub_00776830(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776830u);

L_00776830:
    ecx = MEM32(ebp + (-0x30)); /* 0x00776830: mov ecx, dword ptr [ebp - 0x30] */
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x00776833: jmp 0x5ce0f0 */

}

void sub_00776838(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776838u);

    goto L_00776838;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776838:
    eax = 0x007E1EB0u; /* 0x00776838: mov eax, 0x7e1eb0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077683D: jmp 0x75bf0e */

}

void sub_00776850(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776850u);

L_00776850:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776850: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x00776853: jmp 0x5ce0f0 */

}

void sub_00776858(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776858u);

    goto L_00776858;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776858:
    eax = 0x007E16E4u; /* 0x00776858: mov eax, 0x7e16e4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077685D: jmp 0x75bf0e */

}

void sub_00776870(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776870u);

L_00776870:
    ecx = MEM32(ebp + (-0x50)); /* 0x00776870: mov ecx, dword ptr [ebp - 0x50] */
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x00776873: jmp 0x5ce0f0 */

}

void sub_00776878(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776878u);

    goto L_00776878;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776878:
    eax = 0x007E1ED4u; /* 0x00776878: mov eax, 0x7e1ed4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077687D: jmp 0x75bf0e */

}

void sub_00776890(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776890u);

L_00776890:
    ecx = MEM32(ebp + (-0x40)); /* 0x00776890: mov ecx, dword ptr [ebp - 0x40] */
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x00776893: jmp 0x5ce0f0 */

}

void sub_00776898(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776898u);

    goto L_00776898;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776898:
    eax = 0x007E1EF8u; /* 0x00776898: mov eax, 0x7e1ef8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077689D: jmp 0x75bf0e */

}

void sub_007768B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007768B0u);

L_007768B0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007768B0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x007768B3: jmp 0x5ce0f0 */

}

void sub_007768B8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007768B8u);

L_007768B8:
    ecx = MEM32(ebp + (-0x10)); /* 0x007768B8: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x20u; /* 0x007768BB: add ecx, 0x20 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x007768BE: jmp 0x5cde60 */

}

void sub_007768C3(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007768C3u);

    goto L_007768C3;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007768C3:
    eax = 0x007E1F24u; /* 0x007768C3: mov eax, 0x7e1f24 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007768C8: jmp 0x75bf0e */

}

void sub_007768D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007768D0u);

L_007768D0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007768D0: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(8);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 8; /* 0x007768D3: add ecx, 8 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x007768D6: jmp 0x5ce0f0 */

}

void sub_007768DB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007768DBu);

L_007768DB:
    ecx = MEM32(ebp + (-0x10)); /* 0x007768DB: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x28u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x28u; /* 0x007768DE: add ecx, 0x28 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00490340u); RECOMP_RETURN(); /* 0x007768E1: jmp 0x490340 */

}

void sub_007768E6(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007768E6u);

    goto L_007768E6;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007768E6:
    eax = 0x007E1F50u; /* 0x007768E6: mov eax, 0x7e1f50 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007768EB: jmp 0x75bf0e */

}

void sub_007768F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007768F0u);

L_007768F0:
    /* cmp MEM32(ebp + (-0x10)), 0 */ /* 0x007768F0: cmp dword ptr [ebp - 0x10], 0 */
    _flag_a = (uint32_t)(MEM32(ebp + (-0x10))); _flag_b = (uint32_t)(0);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    _flag_k = FK_CMP;
    if (CMP_EQ(_flag_a, _flag_b)) goto L_00776908; /* 0x007768F4: je 0x776908 */

L_007768FA:
    eax = MEM32(ebp + (-0x10)); /* 0x007768FA: mov eax, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(8);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 8; /* 0x007768FD: add eax, 8 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x1C)) = eax; /* 0x00776900: mov dword ptr [ebp - 0x1c], eax */
    goto L_0077690F; /* 0x00776903: jmp 0x77690f */

L_00776908:
    MEM32(ebp + (-0x1C)) = 0; /* 0x00776908: mov dword ptr [ebp - 0x1c], 0 */

L_0077690F:
    ecx = MEM32(ebp + (-0x1C)); /* 0x0077690F: mov ecx, dword ptr [ebp - 0x1c] */
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x00776912: jmp 0x5ce0f0 */

}

void sub_0077690F(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077690Fu);

L_0077690F:
    ecx = MEM32(ebp + (-0x1C)); /* 0x0077690F: mov ecx, dword ptr [ebp - 0x1c] */
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x00776912: jmp 0x5ce0f0 */

}

void sub_00776917(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776917u);

    goto L_00776917;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776917:
    eax = 0x007E1F74u; /* 0x00776917: mov eax, 0x7e1f74 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077691C: jmp 0x75bf0e */

}

void sub_00776930(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776930u);

L_00776930:
    PUSH32(esp, 0); /* 0x00776930: push 0 */
    PUSH32(esp, 0x00798EFCu); /* 0x00776932: push 0x798efc */
    eax = MEM32(ebp + 0x4); /* 0x00776937: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x0077693A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077693B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776940: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776943: ret  */

}

void sub_00776944(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776944u);

L_00776944:
    PUSH32(esp, 0); /* 0x00776944: push 0 */
    PUSH32(esp, 0x00798EF0u); /* 0x00776946: push 0x798ef0 */
    eax = MEM32(ebp + 0x4); /* 0x0077694B: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x0077694E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077694F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776954: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776957: ret  */

}

void sub_00776958(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776958u);

L_00776958:
    PUSH32(esp, 0); /* 0x00776958: push 0 */
    PUSH32(esp, 0x00798EE4u); /* 0x0077695A: push 0x798ee4 */
    eax = MEM32(ebp + 0x4); /* 0x0077695F: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00776962: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776963: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776968: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077696B: ret  */

}

void sub_0077696C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077696Cu);

L_0077696C:
    PUSH32(esp, 0); /* 0x0077696C: push 0 */
    PUSH32(esp, 0x00798EF0u); /* 0x0077696E: push 0x798ef0 */
    eax = MEM32(ebp + 0x4); /* 0x00776973: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00776976: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776977: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077697C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077697F: ret  */

}

void sub_00776980(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776980u);

L_00776980:
    PUSH32(esp, 0); /* 0x00776980: push 0 */
    PUSH32(esp, 0x00798ED8u); /* 0x00776982: push 0x798ed8 */
    eax = MEM32(ebp + 0x4); /* 0x00776987: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x0077698A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077698B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776990: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776993: ret  */

}

void sub_00776994(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776994u);

L_00776994:
    PUSH32(esp, 0); /* 0x00776994: push 0 */
    PUSH32(esp, 0x00798EC8u); /* 0x00776996: push 0x798ec8 */
    eax = MEM32(ebp + 0x4); /* 0x0077699B: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x0077699E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077699F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007769A4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007769A7: ret  */

}

void sub_007769A8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007769A8u);

L_007769A8:
    PUSH32(esp, 0); /* 0x007769A8: push 0 */
    PUSH32(esp, 0x00798EB8u); /* 0x007769AA: push 0x798eb8 */
    eax = MEM32(ebp + 0x4); /* 0x007769AF: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x007769B2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007769B3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007769B8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007769BB: ret  */

}

void sub_007769BC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007769BCu);

L_007769BC:
    PUSH32(esp, 0); /* 0x007769BC: push 0 */
    PUSH32(esp, 0x00798EA8u); /* 0x007769BE: push 0x798ea8 */
    eax = MEM32(ebp + 0x4); /* 0x007769C3: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x007769C6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007769C7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007769CC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007769CF: ret  */

}

void sub_007769D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007769D0u);

L_007769D0:
    PUSH32(esp, 0); /* 0x007769D0: push 0 */
    PUSH32(esp, 0x00798E9Cu); /* 0x007769D2: push 0x798e9c */
    eax = MEM32(ebp + 0x4); /* 0x007769D7: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x007769DA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007769DB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007769E0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007769E3: ret  */

}

void sub_007769E4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007769E4u);

L_007769E4:
    PUSH32(esp, 0); /* 0x007769E4: push 0 */
    PUSH32(esp, 0x00798A50u); /* 0x007769E6: push 0x798a50 */
    eax = MEM32(ebp + 0x4); /* 0x007769EB: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x007769EE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007769EF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007769F4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007769F7: ret  */

}

void sub_007769F8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007769F8u);

L_007769F8:
    PUSH32(esp, 0); /* 0x007769F8: push 0 */
    PUSH32(esp, 0x00798E90u); /* 0x007769FA: push 0x798e90 */
    eax = MEM32(ebp + 0x4); /* 0x007769FF: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00776A02: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776A03: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776A08: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776A0B: ret  */

}

void sub_00776A0C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776A0Cu);

L_00776A0C:
    PUSH32(esp, 0); /* 0x00776A0C: push 0 */
    PUSH32(esp, 0x00798E84u); /* 0x00776A0E: push 0x798e84 */
    eax = MEM32(ebp + 0x4); /* 0x00776A13: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00776A16: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776A17: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776A1C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776A1F: ret  */

}

void sub_00776A20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776A20u);

L_00776A20:
    PUSH32(esp, 0); /* 0x00776A20: push 0 */
    PUSH32(esp, 0x00798E78u); /* 0x00776A22: push 0x798e78 */
    eax = MEM32(ebp + 0x4); /* 0x00776A27: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00776A2A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776A2B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776A30: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776A33: ret  */

}

void sub_00776A34(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776A34u);

L_00776A34:
    PUSH32(esp, 0); /* 0x00776A34: push 0 */
    PUSH32(esp, 0x00798E64u); /* 0x00776A36: push 0x798e64 */
    eax = MEM32(ebp + 0x4); /* 0x00776A3B: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00776A3E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776A3F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776A44: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776A47: ret  */

}

void sub_00776A48(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776A48u);

L_00776A48:
    PUSH32(esp, 0); /* 0x00776A48: push 0 */
    PUSH32(esp, 0x00798E58u); /* 0x00776A4A: push 0x798e58 */
    eax = MEM32(ebp + 0x4); /* 0x00776A4F: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00776A52: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776A53: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776A58: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776A5B: ret  */

}

void sub_00776A5C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776A5Cu);

L_00776A5C:
    PUSH32(esp, 0); /* 0x00776A5C: push 0 */
    PUSH32(esp, 0x00798E48u); /* 0x00776A5E: push 0x798e48 */
    eax = MEM32(ebp + 0x4); /* 0x00776A63: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00776A66: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776A67: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776A6C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776A6F: ret  */

}

void sub_00776A70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776A70u);

L_00776A70:
    PUSH32(esp, 0); /* 0x00776A70: push 0 */
    PUSH32(esp, 0x00798E38u); /* 0x00776A72: push 0x798e38 */
    eax = MEM32(ebp + 0x4); /* 0x00776A77: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00776A7A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776A7B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776A80: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776A83: ret  */

}

void sub_00776A84(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776A84u);

L_00776A84:
    PUSH32(esp, 0); /* 0x00776A84: push 0 */
    PUSH32(esp, 0x00798E24u); /* 0x00776A86: push 0x798e24 */
    eax = MEM32(ebp + 0x4); /* 0x00776A8B: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00776A8E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776A8F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776A94: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776A97: ret  */

}

void sub_00776A98(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776A98u);

L_00776A98:
    PUSH32(esp, 0); /* 0x00776A98: push 0 */
    PUSH32(esp, 0x00798E14u); /* 0x00776A9A: push 0x798e14 */
    eax = MEM32(ebp + 0x4); /* 0x00776A9F: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00776AA2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776AA3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776AA8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776AAB: ret  */

}

void sub_00776AAC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776AACu);

L_00776AAC:
    PUSH32(esp, 0); /* 0x00776AAC: push 0 */
    PUSH32(esp, 0x00798DFCu); /* 0x00776AAE: push 0x798dfc */
    eax = MEM32(ebp + 0x4); /* 0x00776AB3: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00776AB6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776AB7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776ABC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776ABF: ret  */

}

void sub_00776AC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776AC0u);

L_00776AC0:
    PUSH32(esp, 0); /* 0x00776AC0: push 0 */
    PUSH32(esp, 0x00798DE4u); /* 0x00776AC2: push 0x798de4 */
    eax = MEM32(ebp + 0x4); /* 0x00776AC7: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00776ACA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776ACB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776AD0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776AD3: ret  */

}

void sub_00776AD4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776AD4u);

L_00776AD4:
    PUSH32(esp, 0); /* 0x00776AD4: push 0 */
    PUSH32(esp, 0x00798DCCu); /* 0x00776AD6: push 0x798dcc */
    eax = MEM32(ebp + 0x4); /* 0x00776ADB: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00776ADE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776ADF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776AE4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776AE7: ret  */

}

void sub_00776AE8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776AE8u);

L_00776AE8:
    PUSH32(esp, 0); /* 0x00776AE8: push 0 */
    PUSH32(esp, 0x00798DBCu); /* 0x00776AEA: push 0x798dbc */
    eax = MEM32(ebp + 0x4); /* 0x00776AEF: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00776AF2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776AF3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776AF8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776AFB: ret  */

}

void sub_00776AFC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776AFCu);

L_00776AFC:
    PUSH32(esp, 0); /* 0x00776AFC: push 0 */
    PUSH32(esp, 0x00798DA8u); /* 0x00776AFE: push 0x798da8 */
    eax = MEM32(ebp + 0x4); /* 0x00776B03: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00776B06: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776B07: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776B0C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776B0F: ret  */

}

void sub_00776B10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776B10u);

    goto L_00776B10;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776B10:
    eax = 0x007E2050u; /* 0x00776B10: mov eax, 0x7e2050 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776B15: jmp 0x75bf0e */

}

void sub_00776B20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776B20u);

L_00776B20:
    PUSH32(esp, 0); /* 0x00776B20: push 0 */
    PUSH32(esp, 0x00798F14u); /* 0x00776B22: push 0x798f14 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776B27: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00776B2A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776B2B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776B30: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776B33: ret  */

}

void sub_00776B34(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776B34u);

    goto L_00776B34;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776B34:
    eax = 0x007E2074u; /* 0x00776B34: mov eax, 0x7e2074 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776B39: jmp 0x75bf0e */

}

void sub_00776B40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776B40u);

L_00776B40:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776B40: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00776B43: jmp 0x553a80 */

}

void sub_00776B48(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776B48u);

L_00776B48:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776B48: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x50u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x50u; /* 0x00776B4B: add ecx, 0x50 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00479130u); RECOMP_RETURN(); /* 0x00776B4E: jmp 0x479130 */

}

void sub_00776B53(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776B53u);

L_00776B53:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776B53: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0xF0u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0xF0u; /* 0x00776B56: add ecx, 0xf0 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004FF410u); RECOMP_RETURN(); /* 0x00776B5C: jmp 0x4ff410 */

}

void sub_00776B61(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776B61u);

L_00776B61:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776B61: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x134u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x134u; /* 0x00776B64: add ecx, 0x134 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004FF410u); RECOMP_RETURN(); /* 0x00776B6A: jmp 0x4ff410 */

}

void sub_00776B6F(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776B6Fu);

L_00776B6F:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776B6F: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x178u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x178u; /* 0x00776B72: add ecx, 0x178 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004FF410u); RECOMP_RETURN(); /* 0x00776B78: jmp 0x4ff410 */

}

void sub_00776B7D(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776B7Du);

    goto L_00776B7D;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776B7D:
    eax = 0x007E20B8u; /* 0x00776B7D: mov eax, 0x7e20b8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776B82: jmp 0x75bf0e */

}

void sub_00776B90(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776B90u);

L_00776B90:
    PUSH32(esp, 0); /* 0x00776B90: push 0 */
    PUSH32(esp, 0x00798F3Cu); /* 0x00776B92: push 0x798f3c */
    eax = MEM32(ebp + (-0x10)); /* 0x00776B97: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00776B9A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776B9B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776BA0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776BA3: ret  */

}

void sub_00776BA4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776BA4u);

    goto L_00776BA4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776BA4:
    eax = 0x007E2120u; /* 0x00776BA4: mov eax, 0x7e2120 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776BA9: jmp 0x75bf0e */

}

void sub_00776BB0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776BB0u);

L_00776BB0:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776BB0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00776BB3: jmp 0x553a80 */

}

void sub_00776BB8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776BB8u);

L_00776BB8:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776BB8: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x54u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x54u; /* 0x00776BBB: add ecx, 0x54 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00776BBE: jmp 0x5cde60 */

}

void sub_00776BC3(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776BC3u);

    goto L_00776BC3;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776BC3:
    eax = 0x007E214Cu; /* 0x00776BC3: mov eax, 0x7e214c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776BC8: jmp 0x75bf0e */

}

void sub_00776BD0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776BD0u);

L_00776BD0:
    PUSH32(esp, 0); /* 0x00776BD0: push 0 */
    PUSH32(esp, 0x00798F54u); /* 0x00776BD2: push 0x798f54 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776BD7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00776BDA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776BDB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776BE0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776BE3: ret  */

}

void sub_00776BE4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776BE4u);

    goto L_00776BE4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776BE4:
    eax = 0x007E2170u; /* 0x00776BE4: mov eax, 0x7e2170 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776BE9: jmp 0x75bf0e */

}

void sub_00776BF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776BF0u);

L_00776BF0:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776BF0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00776BF3: jmp 0x553a80 */

}

void sub_00776BF8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776BF8u);

L_00776BF8:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776BF8: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x50u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x50u; /* 0x00776BFB: add ecx, 0x50 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00479130u); RECOMP_RETURN(); /* 0x00776BFE: jmp 0x479130 */

}

void sub_00776C03(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776C03u);

L_00776C03:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776C03: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0xD8u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0xD8u; /* 0x00776C06: add ecx, 0xd8 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004FF410u); RECOMP_RETURN(); /* 0x00776C0C: jmp 0x4ff410 */

}

void sub_00776C11(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776C11u);

L_00776C11:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776C11: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x11Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x11Cu; /* 0x00776C14: add ecx, 0x11c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004FF410u); RECOMP_RETURN(); /* 0x00776C1A: jmp 0x4ff410 */

}

void sub_00776C1F(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776C1Fu);

L_00776C1F:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776C1F: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x160u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x160u; /* 0x00776C22: add ecx, 0x160 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004FF410u); RECOMP_RETURN(); /* 0x00776C28: jmp 0x4ff410 */

}

void sub_00776C2D(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776C2Du);

    goto L_00776C2D;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776C2D:
    eax = 0x007E21B4u; /* 0x00776C2D: mov eax, 0x7e21b4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776C32: jmp 0x75bf0e */

}

void sub_00776C40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776C40u);

L_00776C40:
    PUSH32(esp, 0); /* 0x00776C40: push 0 */
    PUSH32(esp, 0x00798F7Cu); /* 0x00776C42: push 0x798f7c */
    eax = MEM32(ebp + (-0x10)); /* 0x00776C47: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00776C4A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776C4B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776C50: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776C53: ret  */

}

void sub_00776C54(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776C54u);

    goto L_00776C54;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776C54:
    eax = 0x007E21D8u; /* 0x00776C54: mov eax, 0x7e21d8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776C59: jmp 0x75bf0e */

}

void sub_00776C60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776C60u);

L_00776C60:
    PUSH32(esp, 0); /* 0x00776C60: push 0 */
    PUSH32(esp, 0x00798FACu); /* 0x00776C62: push 0x798fac */
    eax = MEM32(ebp + (-0x10)); /* 0x00776C67: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00776C6A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776C6B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776C70: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776C73: ret  */

}

void sub_00776C74(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776C74u);

    goto L_00776C74;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776C74:
    eax = 0x007E21FCu; /* 0x00776C74: mov eax, 0x7e21fc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776C79: jmp 0x75bf0e */

}

void sub_00776C80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776C80u);

L_00776C80:
    PUSH32(esp, 0); /* 0x00776C80: push 0 */
    PUSH32(esp, 0x00798FE4u); /* 0x00776C82: push 0x798fe4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776C87: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00776C8A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776C8B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776C90: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776C93: ret  */

}

void sub_00776C94(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776C94u);

    goto L_00776C94;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776C94:
    eax = 0x007E2220u; /* 0x00776C94: mov eax, 0x7e2220 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776C99: jmp 0x75bf0e */

}

void sub_00776CA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776CA0u);

L_00776CA0:
    PUSH32(esp, 0); /* 0x00776CA0: push 0 */
    PUSH32(esp, 0x00798FFCu); /* 0x00776CA2: push 0x798ffc */
    eax = MEM32(ebp + (-0x10)); /* 0x00776CA7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00776CAA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776CAB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776CB0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776CB3: ret  */

}

void sub_00776CB4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776CB4u);

    goto L_00776CB4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776CB4:
    eax = 0x007E2244u; /* 0x00776CB4: mov eax, 0x7e2244 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776CB9: jmp 0x75bf0e */

}

void sub_00776CC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776CC0u);

L_00776CC0:
    PUSH32(esp, 0); /* 0x00776CC0: push 0 */
    PUSH32(esp, 0x00799010u); /* 0x00776CC2: push 0x799010 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776CC7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00776CCA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776CCB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776CD0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776CD3: ret  */

}

void sub_00776CD4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776CD4u);

    goto L_00776CD4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776CD4:
    eax = 0x007E2268u; /* 0x00776CD4: mov eax, 0x7e2268 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776CD9: jmp 0x75bf0e */

}

void sub_00776CE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776CE0u);

L_00776CE0:
    PUSH32(esp, 0); /* 0x00776CE0: push 0 */
    PUSH32(esp, 0x00799020u); /* 0x00776CE2: push 0x799020 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776CE7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00776CEA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776CEB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776CF0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776CF3: ret  */

}

void sub_00776CF4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776CF4u);

    goto L_00776CF4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776CF4:
    eax = 0x007E228Cu; /* 0x00776CF4: mov eax, 0x7e228c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776CF9: jmp 0x75bf0e */

}

void sub_00776D00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776D00u);

L_00776D00:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776D00: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004E2060u); RECOMP_RETURN(); /* 0x00776D03: jmp 0x4e2060 */

}

void sub_00776D08(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776D08u);

    goto L_00776D08;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776D08:
    eax = 0x007E22B0u; /* 0x00776D08: mov eax, 0x7e22b0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776D0D: jmp 0x75bf0e */

}

void sub_00776D20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776D20u);

L_00776D20:
    PUSH32(esp, 0); /* 0x00776D20: push 0 */
    PUSH32(esp, 0x007990F0u); /* 0x00776D22: push 0x7990f0 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776D27: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00776D2A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776D2B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776D30: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776D33: ret  */

}

void sub_00776D34(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776D34u);

    goto L_00776D34;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776D34:
    eax = 0x007E2308u; /* 0x00776D34: mov eax, 0x7e2308 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776D39: jmp 0x75bf0e */

}

void sub_00776D40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776D40u);

L_00776D40:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776D40: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004CBB50u); RECOMP_RETURN(); /* 0x00776D43: jmp 0x4cbb50 */

}

void sub_00776D48(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776D48u);

L_00776D48:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776D48: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x178u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x178u; /* 0x00776D4B: add ecx, 0x178 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00490340u); RECOMP_RETURN(); /* 0x00776D51: jmp 0x490340 */

}

void sub_00776D56(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776D56u);

    goto L_00776D56;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776D56:
    eax = 0x007E2334u; /* 0x00776D56: mov eax, 0x7e2334 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776D5B: jmp 0x75bf0e */

}

void sub_00776D60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776D60u);

L_00776D60:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776D60: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004CBB50u); RECOMP_RETURN(); /* 0x00776D63: jmp 0x4cbb50 */

}

void sub_00776D68(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776D68u);

    goto L_00776D68;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776D68:
    eax = 0x007E02D0u; /* 0x00776D68: mov eax, 0x7e02d0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776D6D: jmp 0x75bf0e */

}

void sub_00776D80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776D80u);

L_00776D80:
    PUSH32(esp, 0); /* 0x00776D80: push 0 */
    PUSH32(esp, 0x00799130u); /* 0x00776D82: push 0x799130 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776D87: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00776D8A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776D8B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776D90: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776D93: ret  */

}

void sub_00776D94(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776D94u);

    goto L_00776D94;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776D94:
    eax = 0x007E2358u; /* 0x00776D94: mov eax, 0x7e2358 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776D99: jmp 0x75bf0e */

}

void sub_00776DA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776DA0u);

L_00776DA0:
    PUSH32(esp, 0); /* 0x00776DA0: push 0 */
    PUSH32(esp, 0x0079914Cu); /* 0x00776DA2: push 0x79914c */
    eax = MEM32(ebp + (-0x10)); /* 0x00776DA7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00776DAA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776DAB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776DB0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776DB3: ret  */

}

void sub_00776DB4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776DB4u);

    goto L_00776DB4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776DB4:
    eax = 0x007E237Cu; /* 0x00776DB4: mov eax, 0x7e237c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776DB9: jmp 0x75bf0e */

}

void sub_00776DC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776DC0u);

L_00776DC0:
    PUSH32(esp, 0); /* 0x00776DC0: push 0 */
    PUSH32(esp, 0x0079916Cu); /* 0x00776DC2: push 0x79916c */
    eax = MEM32(ebp + (-0x10)); /* 0x00776DC7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00776DCA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776DCB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776DD0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776DD3: ret  */

}

void sub_00776DD4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776DD4u);

    goto L_00776DD4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776DD4:
    eax = 0x007E23A0u; /* 0x00776DD4: mov eax, 0x7e23a0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776DD9: jmp 0x75bf0e */

}

void sub_00776DE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776DE0u);

L_00776DE0:
    PUSH32(esp, 0); /* 0x00776DE0: push 0 */
    PUSH32(esp, 0x0079917Cu); /* 0x00776DE2: push 0x79917c */
    eax = MEM32(ebp + (-0x10)); /* 0x00776DE7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00776DEA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776DEB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776DF0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776DF3: ret  */

}

void sub_00776DF4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776DF4u);

    goto L_00776DF4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776DF4:
    eax = 0x007E23C4u; /* 0x00776DF4: mov eax, 0x7e23c4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776DF9: jmp 0x75bf0e */

}

void sub_00776E00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776E00u);

L_00776E00:
    PUSH32(esp, 0); /* 0x00776E00: push 0 */
    PUSH32(esp, 0x00799194u); /* 0x00776E02: push 0x799194 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776E07: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00776E0A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776E0B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776E10: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776E13: ret  */

}

void sub_00776E14(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776E14u);

    goto L_00776E14;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776E14:
    eax = 0x007E23E8u; /* 0x00776E14: mov eax, 0x7e23e8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776E19: jmp 0x75bf0e */

}

void sub_00776E20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776E20u);

L_00776E20:
    PUSH32(esp, 0); /* 0x00776E20: push 0 */
    PUSH32(esp, 0x007991A4u); /* 0x00776E22: push 0x7991a4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776E27: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00776E2A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776E2B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776E30: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776E33: ret  */

}

void sub_00776E34(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776E34u);

    goto L_00776E34;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776E34:
    eax = 0x007E240Cu; /* 0x00776E34: mov eax, 0x7e240c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776E39: jmp 0x75bf0e */

}

void sub_00776E40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776E40u);

L_00776E40:
    PUSH32(esp, 0); /* 0x00776E40: push 0 */
    PUSH32(esp, 0x007991B4u); /* 0x00776E42: push 0x7991b4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776E47: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00776E4A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776E4B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776E50: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776E53: ret  */

}

void sub_00776E54(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776E54u);

    goto L_00776E54;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776E54:
    eax = 0x007E2430u; /* 0x00776E54: mov eax, 0x7e2430 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776E59: jmp 0x75bf0e */

}

void sub_00776E60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776E60u);

L_00776E60:
    PUSH32(esp, 0); /* 0x00776E60: push 0 */
    PUSH32(esp, 0x007991C4u); /* 0x00776E62: push 0x7991c4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00776E67: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00776E6A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776E6B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776E70: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776E73: ret  */

}

void sub_00776E74(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776E74u);

    goto L_00776E74;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776E74:
    eax = 0x007E2454u; /* 0x00776E74: mov eax, 0x7e2454 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776E79: jmp 0x75bf0e */

}

void sub_00776E80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776E80u);

L_00776E80:
    ecx = ebp + (-0x950); /* 0x00776E80: lea ecx, [ebp - 0x950] */
    RECOMP_ITAIL(0x0050F700u); RECOMP_RETURN(); /* 0x00776E86: jmp 0x50f700 */

}

void sub_00776E8B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776E8Bu);

    goto L_00776E8B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776E8B:
    eax = 0x007E2478u; /* 0x00776E8B: mov eax, 0x7e2478 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776E90: jmp 0x75bf0e */

}

void sub_00776EA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776EA0u);

L_00776EA0:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776EA0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x0051AA70u); RECOMP_RETURN(); /* 0x00776EA3: jmp 0x51aa70 */

}

void sub_00776EA8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776EA8u);

    goto L_00776EA8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776EA8:
    eax = 0x007E249Cu; /* 0x00776EA8: mov eax, 0x7e249c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776EAD: jmp 0x75bf0e */

}

void sub_00776EC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776EC0u);

L_00776EC0:
    ecx = ebp + (-0x18); /* 0x00776EC0: lea ecx, [ebp - 0x18] */
    RECOMP_ITAIL(0x0050C9F0u); RECOMP_RETURN(); /* 0x00776EC3: jmp 0x50c9f0 */

}

void sub_00776EC8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776EC8u);

    goto L_00776EC8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776EC8:
    eax = 0x007E24C0u; /* 0x00776EC8: mov eax, 0x7e24c0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776ECD: jmp 0x75bf0e */

}

void sub_00776EE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776EE0u);

L_00776EE0:
    ecx = ebp + (-0x14); /* 0x00776EE0: lea ecx, [ebp - 0x14] */
    RECOMP_ITAIL(0x0050C9F0u); RECOMP_RETURN(); /* 0x00776EE3: jmp 0x50c9f0 */

}

void sub_00776EE8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776EE8u);

    goto L_00776EE8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776EE8:
    eax = 0x007E35F4u; /* 0x00776EE8: mov eax, 0x7e35f4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776EED: jmp 0x75bf0e */

}

void sub_00776F00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776F00u);

L_00776F00:
    PUSH32(esp, 0); /* 0x00776F00: push 0 */
    PUSH32(esp, 0x0079AC14u); /* 0x00776F02: push 0x79ac14 */
    eax = MEM32(ebp + 0x4); /* 0x00776F07: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00776F0A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00776F0B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00776F10: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776F13: ret  */

}

void sub_00776F14(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776F14u);

    goto L_00776F14;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776F14:
    eax = 0x007E24E4u; /* 0x00776F14: mov eax, 0x7e24e4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776F19: jmp 0x75bf0e */

}

void sub_00776F20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776F20u);

L_00776F20:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776F20: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00776F23: jmp 0x553a80 */

}

void sub_00776F28(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776F28u);

    goto L_00776F28;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776F28:
    eax = 0x007E3CFCu; /* 0x00776F28: mov eax, 0x7e3cfc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776F2D: jmp 0x75bf0e */

}

void sub_00776F40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776F40u);

L_00776F40:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776F40: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(8);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 8; /* 0x00776F43: add ecx, 8 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004FF410u); RECOMP_RETURN(); /* 0x00776F46: jmp 0x4ff410 */

}

void sub_00776F4B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776F4Bu);

    goto L_00776F4B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776F4B:
    eax = 0x007E2508u; /* 0x00776F4B: mov eax, 0x7e2508 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776F50: jmp 0x75bf0e */

}

void sub_00776F60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776F60u);

L_00776F60:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776F60: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x005052E0u); RECOMP_RETURN(); /* 0x00776F63: jmp 0x5052e0 */

}

void sub_00776F68(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776F68u);

    goto L_00776F68;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776F68:
    eax = 0x007E2550u; /* 0x00776F68: mov eax, 0x7e2550 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776F6D: jmp 0x75bf0e */

}

void sub_00776F80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776F80u);

L_00776F80:
    ecx = MEM32(ebp + (-0x10)); /* 0x00776F80: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004FE130u); RECOMP_RETURN(); /* 0x00776F83: jmp 0x4fe130 */

}

void sub_00776F88(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776F88u);

    goto L_00776F88;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776F88:
    eax = 0x007E2574u; /* 0x00776F88: mov eax, 0x7e2574 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776F8D: jmp 0x75bf0e */

}

void sub_00776FA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776FA0u);

L_00776FA0:
    ecx = ebp + (-0x8F0); /* 0x00776FA0: lea ecx, [ebp - 0x8f0] */
    RECOMP_ITAIL(0x00401830u); RECOMP_RETURN(); /* 0x00776FA6: jmp 0x401830 */

}

void sub_00776FAB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776FABu);

L_00776FAB:
    ecx = ebp + (-0x900); /* 0x00776FAB: lea ecx, [ebp - 0x900] */
    RECOMP_ITAIL(0x0040BE20u); RECOMP_RETURN(); /* 0x00776FB1: jmp 0x40be20 */

}

void sub_00776FB6(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776FB6u);

    goto L_00776FB6;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776FB6:
    eax = 0x007E25A0u; /* 0x00776FB6: mov eax, 0x7e25a0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776FBB: jmp 0x75bf0e */

}

void sub_00776FC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776FC0u);

L_00776FC0:
    eax = MEM32(ebp + 0x4); /* 0x00776FC0: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00776FC3: push eax */
    RECOMP_CALL(sub_00575590); /* 0x00776FC4: call 0x575590 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00776FC9: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776FCA: ret  */

}

void sub_00776FCB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776FCBu);

    goto L_00776FCB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776FCB:
    eax = 0x007E25C4u; /* 0x00776FCB: mov eax, 0x7e25c4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776FD0: jmp 0x75bf0e */

}

void sub_00776FE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776FE0u);

L_00776FE0:
    ecx = ebp + (-0x18); /* 0x00776FE0: lea ecx, [ebp - 0x18] */
    RECOMP_ITAIL(0x0050C9F0u); RECOMP_RETURN(); /* 0x00776FE3: jmp 0x50c9f0 */

}

void sub_00776FE8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776FE8u);

L_00776FE8:
    eax = MEM32(ebp + (-0x20)); /* 0x00776FE8: mov eax, dword ptr [ebp - 0x20] */
    PUSH32(esp, eax); /* 0x00776FEB: push eax */
    RECOMP_CALL(sub_00575590); /* 0x00776FEC: call 0x575590 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00776FF1: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00776FF2: ret  */

}

void sub_00776FF3(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00776FF3u);

    goto L_00776FF3;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00776FF3:
    eax = 0x007E25F0u; /* 0x00776FF3: mov eax, 0x7e25f0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00776FF8: jmp 0x75bf0e */

}

void sub_00777000(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777000u);

L_00777000:
    eax = MEM32(ebp + (-0x14)); /* 0x00777000: mov eax, dword ptr [ebp - 0x14] */
    PUSH32(esp, eax); /* 0x00777003: push eax */
    RECOMP_CALL(sub_00505550); /* 0x00777004: call 0x505550 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00777009: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077700A: ret  */

}

void sub_0077700B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077700Bu);

    goto L_0077700B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077700B:
    eax = 0x007E2614u; /* 0x0077700B: mov eax, 0x7e2614 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777010: jmp 0x75bf0e */

}

void sub_00777020(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777020u);

L_00777020:
    eax = MEM32(ebp + (-0x298)); /* 0x00777020: mov eax, dword ptr [ebp - 0x298] */
    PUSH32(esp, eax); /* 0x00777026: push eax */
    RECOMP_CALL(sub_00505550); /* 0x00777027: call 0x505550 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077702C: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077702D: ret  */

}

void sub_0077702E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077702Eu);

    goto L_0077702E;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077702E:
    eax = 0x007E2638u; /* 0x0077702E: mov eax, 0x7e2638 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777033: jmp 0x75bf0e */

}

void sub_00777040(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777040u);

L_00777040:
    ecx = ebp + (-0x10); /* 0x00777040: lea ecx, [ebp - 0x10] */
    RECOMP_ITAIL(0x0050C9F0u); RECOMP_RETURN(); /* 0x00777043: jmp 0x50c9f0 */

}

void sub_00777048(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777048u);

    goto L_00777048;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777048:
    eax = 0x007E265Cu; /* 0x00777048: mov eax, 0x7e265c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077704D: jmp 0x75bf0e */

}

void sub_00777060(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777060u);

L_00777060:
    PUSH32(esp, 0); /* 0x00777060: push 0 */
    PUSH32(esp, 0x0079B1A4u); /* 0x00777062: push 0x79b1a4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777067: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077706A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077706B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777070: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777073: ret  */

}

void sub_00777074(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777074u);

    goto L_00777074;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777074:
    eax = 0x007E2680u; /* 0x00777074: mov eax, 0x7e2680 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777079: jmp 0x75bf0e */

}

void sub_00777080(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777080u);

L_00777080:
    ecx = ebp + (-0x1C); /* 0x00777080: lea ecx, [ebp - 0x1c] */
    RECOMP_ITAIL(0x0050C9F0u); RECOMP_RETURN(); /* 0x00777083: jmp 0x50c9f0 */

}

void sub_00777088(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777088u);

L_00777088:
    ecx = ebp + (-0x18); /* 0x00777088: lea ecx, [ebp - 0x18] */
    RECOMP_ITAIL(0x0050C9F0u); RECOMP_RETURN(); /* 0x0077708B: jmp 0x50c9f0 */

}

void sub_00777090(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777090u);

    goto L_00777090;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777090:
    eax = 0x007E26ACu; /* 0x00777090: mov eax, 0x7e26ac */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777095: jmp 0x75bf0e */

}

void sub_007770A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007770A0u);

L_007770A0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007770A0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004CF610u); RECOMP_RETURN(); /* 0x007770A3: jmp 0x4cf610 */

}

void sub_007770A8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007770A8u);

    goto L_007770A8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007770A8:
    eax = 0x007E26D0u; /* 0x007770A8: mov eax, 0x7e26d0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007770AD: jmp 0x75bf0e */

}

void sub_007770C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007770C0u);

L_007770C0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007770C0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004CF610u); RECOMP_RETURN(); /* 0x007770C3: jmp 0x4cf610 */

}

void sub_007770C8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007770C8u);

L_007770C8:
    PUSH32(esp, 0); /* 0x007770C8: push 0 */
    PUSH32(esp, 0x0079B4E4u); /* 0x007770CA: push 0x79b4e4 */
    eax = MEM32(ebp + 0x18); /* 0x007770CF: mov eax, dword ptr [ebp + 0x18] */
    PUSH32(esp, eax); /* 0x007770D2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007770D3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007770D8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007770DB: ret  */

}

void sub_007770DC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007770DCu);

    goto L_007770DC;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007770DC:
    eax = 0x007E26FCu; /* 0x007770DC: mov eax, 0x7e26fc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007770E1: jmp 0x75bf0e */

}

void sub_007770F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007770F0u);

L_007770F0:
    ecx = ebp + (-0x11F0); /* 0x007770F0: lea ecx, [ebp - 0x11f0] */
    RECOMP_ITAIL(0x0040BE20u); RECOMP_RETURN(); /* 0x007770F6: jmp 0x40be20 */

}

void sub_007770FB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007770FBu);

L_007770FB:
    ecx = ebp + (-0x900); /* 0x007770FB: lea ecx, [ebp - 0x900] */
    RECOMP_ITAIL(0x0040BE20u); RECOMP_RETURN(); /* 0x00777101: jmp 0x40be20 */

}

void sub_00777106(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777106u);

    goto L_00777106;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777106:
    eax = 0x007E2728u; /* 0x00777106: mov eax, 0x7e2728 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077710B: jmp 0x75bf0e */

}

void sub_00777110(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777110u);

L_00777110:
    eax = MEM32(ebp + (-0x14)); /* 0x00777110: mov eax, dword ptr [ebp - 0x14] */
    PUSH32(esp, eax); /* 0x00777113: push eax */
    RECOMP_CALL(sub_00575590); /* 0x00777114: call 0x575590 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00777119: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077711A: ret  */

}

void sub_0077711B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077711Bu);

L_0077711B:
    PUSH32(esp, 0); /* 0x0077711B: push 0 */
    PUSH32(esp, 0x0079B538u); /* 0x0077711D: push 0x79b538 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777122: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00777125: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00777126: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077712B: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077712E: ret  */

}

void sub_0077712F(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077712Fu);

L_0077712F:
    PUSH32(esp, 0); /* 0x0077712F: push 0 */
    PUSH32(esp, 0x0079B538u); /* 0x00777131: push 0x79b538 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777136: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00777139: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077713A: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077713F: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777142: ret  */

}

void sub_00777143(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777143u);

L_00777143:
    PUSH32(esp, 0); /* 0x00777143: push 0 */
    PUSH32(esp, 0x0079B538u); /* 0x00777145: push 0x79b538 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077714A: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077714D: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077714E: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777153: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777156: ret  */

}

void sub_00777157(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777157u);

    goto L_00777157;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777157:
    eax = 0x007E2764u; /* 0x00777157: mov eax, 0x7e2764 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077715C: jmp 0x75bf0e */

}

void sub_00777170(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777170u);

L_00777170:
    PUSH32(esp, 0); /* 0x00777170: push 0 */
    PUSH32(esp, 0x0079B580u); /* 0x00777172: push 0x79b580 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777177: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077717A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077717B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777180: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777183: ret  */

}

void sub_00777184(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777184u);

L_00777184:
    PUSH32(esp, 0); /* 0x00777184: push 0 */
    PUSH32(esp, 0x0079B580u); /* 0x00777186: push 0x79b580 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077718B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077718E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077718F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777194: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777197: ret  */

}

void sub_00777198(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777198u);

    goto L_00777198;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777198:
    eax = 0x007E2790u; /* 0x00777198: mov eax, 0x7e2790 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077719D: jmp 0x75bf0e */

}

void sub_007771B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007771B0u);

L_007771B0:
    PUSH32(esp, 0); /* 0x007771B0: push 0 */
    PUSH32(esp, 0x0079B590u); /* 0x007771B2: push 0x79b590 */
    eax = MEM32(ebp + 0x8); /* 0x007771B7: mov eax, dword ptr [ebp + 8] */
    PUSH32(esp, eax); /* 0x007771BA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007771BB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007771C0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007771C3: ret  */

}

void sub_007771C4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007771C4u);

    goto L_007771C4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007771C4:
    eax = 0x007E27B4u; /* 0x007771C4: mov eax, 0x7e27b4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007771C9: jmp 0x75bf0e */

}

void sub_007771D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007771D0u);

L_007771D0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007771D0: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x10u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x10u; /* 0x007771D3: add ecx, 0x10 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0040BE20u); RECOMP_RETURN(); /* 0x007771D6: jmp 0x40be20 */

}

void sub_007771DB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007771DBu);

    goto L_007771DB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007771DB:
    eax = 0x007E27D8u; /* 0x007771DB: mov eax, 0x7e27d8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007771E0: jmp 0x75bf0e */

}

void sub_007771F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007771F0u);

L_007771F0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007771F0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004CF5B0u); RECOMP_RETURN(); /* 0x007771F3: jmp 0x4cf5b0 */

}

void sub_007771F8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007771F8u);

    goto L_007771F8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007771F8:
    eax = 0x007E2E60u; /* 0x007771F8: mov eax, 0x7e2e60 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007771FD: jmp 0x75bf0e */

}

void sub_00777210(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777210u);

L_00777210:
    PUSH32(esp, 0); /* 0x00777210: push 0 */
    PUSH32(esp, 0x0079B770u); /* 0x00777212: push 0x79b770 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777217: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077721A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077721B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777220: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777223: ret  */

}

void sub_00777224(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777224u);

    goto L_00777224;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777224:
    eax = 0x007E27FCu; /* 0x00777224: mov eax, 0x7e27fc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777229: jmp 0x75bf0e */

}

void sub_00777230(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777230u);

L_00777230:
    PUSH32(esp, 0); /* 0x00777230: push 0 */
    PUSH32(esp, 0x0079B794u); /* 0x00777232: push 0x79b794 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777237: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077723A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077723B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777240: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777243: ret  */

}

void sub_00777244(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777244u);

    goto L_00777244;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777244:
    eax = 0x007E2820u; /* 0x00777244: mov eax, 0x7e2820 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777249: jmp 0x75bf0e */

}

void sub_00777250(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777250u);

L_00777250:
    PUSH32(esp, 0); /* 0x00777250: push 0 */
    PUSH32(esp, 0x0079B848u); /* 0x00777252: push 0x79b848 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777257: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077725A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077725B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777260: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777263: ret  */

}

void sub_00777264(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777264u);

    goto L_00777264;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777264:
    eax = 0x007E2844u; /* 0x00777264: mov eax, 0x7e2844 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777269: jmp 0x75bf0e */

}

void sub_00777270(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777270u);

L_00777270:
    ecx = ebp + (-0x1230); /* 0x00777270: lea ecx, [ebp - 0x1230] */
    RECOMP_ITAIL(0x00401830u); RECOMP_RETURN(); /* 0x00777276: jmp 0x401830 */

}

void sub_0077727B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077727Bu);

L_0077727B:
    ecx = ebp + (-0x1240); /* 0x0077727B: lea ecx, [ebp - 0x1240] */
    RECOMP_ITAIL(0x0040BE20u); RECOMP_RETURN(); /* 0x00777281: jmp 0x40be20 */

}

void sub_00777286(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777286u);

L_00777286:
    ecx = ebp + (-0x950); /* 0x00777286: lea ecx, [ebp - 0x950] */
    RECOMP_ITAIL(0x0050F700u); RECOMP_RETURN(); /* 0x0077728C: jmp 0x50f700 */

}

void sub_00777291(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777291u);

    goto L_00777291;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777291:
    eax = 0x007E2D28u; /* 0x00777291: mov eax, 0x7e2d28 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777296: jmp 0x75bf0e */

}

void sub_007772A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007772A0u);

L_007772A0:
    ecx = ebp + (-0x900); /* 0x007772A0: lea ecx, [ebp - 0x900] */
    RECOMP_ITAIL(0x0040BE20u); RECOMP_RETURN(); /* 0x007772A6: jmp 0x40be20 */

}

void sub_007772AB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007772ABu);

    goto L_007772AB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007772AB:
    eax = 0x007E2868u; /* 0x007772AB: mov eax, 0x7e2868 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007772B0: jmp 0x75bf0e */

}

void sub_007772C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007772C0u);

L_007772C0:
    PUSH32(esp, 0x004FE260u); /* 0x007772C0: push 0x4fe260 */
    PUSH32(esp, 6); /* 0x007772C5: push 6 */
    PUSH32(esp, 0xCu); /* 0x007772C7: push 0xc */
    eax = MEM32(ebp + (-0x10)); /* 0x007772C9: mov eax, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(8);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 8; /* 0x007772CC: add eax, 8 */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x007772CF: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x007772D0: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007772D5: ret  */

}

void sub_007772D6(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007772D6u);

    goto L_007772D6;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007772D6:
    eax = 0x007E288Cu; /* 0x007772D6: mov eax, 0x7e288c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007772DB: jmp 0x75bf0e */

}

void sub_007772E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007772E0u);

L_007772E0:
    PUSH32(esp, 0x004FE130u); /* 0x007772E0: push 0x4fe130 */
    PUSH32(esp, 0x30u); /* 0x007772E5: push 0x30 */
    PUSH32(esp, 0x1Cu); /* 0x007772E7: push 0x1c */
    eax = MEM32(ebp + (-0x10)); /* 0x007772E9: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007772EC: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x007772ED: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007772F2: ret  */

}

void sub_007772F3(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007772F3u);

L_007772F3:
    PUSH32(esp, 0x004FE130u); /* 0x007772F3: push 0x4fe130 */
    PUSH32(esp, 0x14u); /* 0x007772F8: push 0x14 */
    PUSH32(esp, 0x434u); /* 0x007772FA: push 0x434 */
    eax = MEM32(ebp + (-0x10)); /* 0x007772FF: mov eax, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x544u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x544u; /* 0x00777302: add eax, 0x544 */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x00777307: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x00777308: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077730D: ret  */

}

void sub_0077730E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077730Eu);

L_0077730E:
    PUSH32(esp, 0x004FE130u); /* 0x0077730E: push 0x4fe130 */
    PUSH32(esp, 5); /* 0x00777313: push 5 */
    PUSH32(esp, 0x7F8u); /* 0x00777315: push 0x7f8 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077731A: mov eax, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x5954u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x5954u; /* 0x0077731D: add eax, 0x5954 */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x00777322: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x00777323: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777328: ret  */

}

void sub_00777329(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777329u);

L_00777329:
    PUSH32(esp, 0x004FE130u); /* 0x00777329: push 0x4fe130 */
    PUSH32(esp, 6); /* 0x0077732E: push 6 */
    PUSH32(esp, 0x438u); /* 0x00777330: push 0x438 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777335: mov eax, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x8130u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x8130u; /* 0x00777338: add eax, 0x8130 */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x0077733D: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x0077733E: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777343: ret  */

}

void sub_0077732E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077732Eu);

L_0077732E:
    PUSH32(esp, 6); /* 0x0077732E: push 6 */
    PUSH32(esp, 0x438u); /* 0x00777330: push 0x438 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777335: mov eax, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x8130u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x8130u; /* 0x00777338: add eax, 0x8130 */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x0077733D: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x0077733E: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777343: ret  */

}

void sub_00777344(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777344u);

    goto L_00777344;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777344:
    eax = 0x007E28C8u; /* 0x00777344: mov eax, 0x7e28c8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777349: jmp 0x75bf0e */

}

void sub_00777350(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777350u);

L_00777350:
    eax = MEM32(ebp + (-0x18)); /* 0x00777350: mov eax, dword ptr [ebp - 0x18] */
    PUSH32(esp, eax); /* 0x00777353: push eax */
    RECOMP_CALL(sub_00575590); /* 0x00777354: call 0x575590 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00777359: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077735A: ret  */

}

void sub_0077735B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077735Bu);

    goto L_0077735B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077735B:
    eax = 0x007E28ECu; /* 0x0077735B: mov eax, 0x7e28ec */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777360: jmp 0x75bf0e */

}

void sub_00777370(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777370u);

L_00777370:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777370: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x0051AA70u); RECOMP_RETURN(); /* 0x00777373: jmp 0x51aa70 */

}

void sub_00777378(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777378u);

L_00777378:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777378: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x34u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x34u; /* 0x0077737B: add ecx, 0x34 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00525C10u); RECOMP_RETURN(); /* 0x0077737E: jmp 0x525c10 */

}

void sub_00777383(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777383u);

L_00777383:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777383: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x44u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x44u; /* 0x00777386: add ecx, 0x44 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00525C10u); RECOMP_RETURN(); /* 0x00777389: jmp 0x525c10 */

}

void sub_0077738E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077738Eu);

    goto L_0077738E;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077738E:
    eax = 0x007E2920u; /* 0x0077738E: mov eax, 0x7e2920 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777393: jmp 0x75bf0e */

}

void sub_007773A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007773A0u);

L_007773A0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007773A0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x005052E0u); RECOMP_RETURN(); /* 0x007773A3: jmp 0x5052e0 */

}

void sub_007773A8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007773A8u);

L_007773A8:
    ecx = MEM32(ebp + (-0x10)); /* 0x007773A8: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x44u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x44u; /* 0x007773AB: add ecx, 0x44 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00525C10u); RECOMP_RETURN(); /* 0x007773AE: jmp 0x525c10 */

}

void sub_007773B3(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007773B3u);

L_007773B3:
    ecx = MEM32(ebp + (-0x10)); /* 0x007773B3: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x54u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x54u; /* 0x007773B6: add ecx, 0x54 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00525C10u); RECOMP_RETURN(); /* 0x007773B9: jmp 0x525c10 */

}

void sub_007773BE(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007773BEu);

L_007773BE:
    ecx = MEM32(ebp + (-0x10)); /* 0x007773BE: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x74u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x74u; /* 0x007773C1: add ecx, 0x74 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00525C10u); RECOMP_RETURN(); /* 0x007773C4: jmp 0x525c10 */

}

void sub_007773C9(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007773C9u);

L_007773C9:
    ecx = MEM32(ebp + (-0x10)); /* 0x007773C9: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x90u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x90u; /* 0x007773CC: add ecx, 0x90 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004FDB10u); RECOMP_RETURN(); /* 0x007773D2: jmp 0x4fdb10 */

}

void sub_007773D7(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007773D7u);

L_007773D7:
    ecx = MEM32(ebp + (-0x10)); /* 0x007773D7: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x9Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x9Cu; /* 0x007773DA: add ecx, 0x9c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00525C10u); RECOMP_RETURN(); /* 0x007773E0: jmp 0x525c10 */

}

void sub_007773E5(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007773E5u);

    goto L_007773E5;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007773E5:
    eax = 0x007E296Cu; /* 0x007773E5: mov eax, 0x7e296c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007773EA: jmp 0x75bf0e */

}

void sub_007773F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007773F0u);

L_007773F0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007773F0: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(8);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 8; /* 0x007773F3: add ecx, 8 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0051AA70u); RECOMP_RETURN(); /* 0x007773F6: jmp 0x51aa70 */

}

void sub_007773FB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007773FBu);

    goto L_007773FB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007773FB:
    eax = 0x007E2990u; /* 0x007773FB: mov eax, 0x7e2990 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777400: jmp 0x75bf0e */

}

void sub_00777410(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777410u);

L_00777410:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777410: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x0052AF20u); RECOMP_RETURN(); /* 0x00777413: jmp 0x52af20 */

}

void sub_00777418(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777418u);

    goto L_00777418;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777418:
    eax = 0x007E335Cu; /* 0x00777418: mov eax, 0x7e335c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077741D: jmp 0x75bf0e */

}

void sub_00777430(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777430u);

L_00777430:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777430: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x18u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x18u; /* 0x00777433: add ecx, 0x18 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00525A50u); RECOMP_RETURN(); /* 0x00777436: jmp 0x525a50 */

}

void sub_0077743B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077743Bu);

    goto L_0077743B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077743B:
    eax = 0x007E29B4u; /* 0x0077743B: mov eax, 0x7e29b4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777440: jmp 0x75bf0e */

}

void sub_00777450(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777450u);

L_00777450:
    eax = MEM32(ebp + (-0x10)); /* 0x00777450: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00777453: push eax */
    RECOMP_CALL(sub_004FF1B0); /* 0x00777454: call 0x4ff1b0 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00777459: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077745A: ret  */

}

void sub_0077745B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077745Bu);

    goto L_0077745B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077745B:
    eax = 0x007E2A24u; /* 0x0077745B: mov eax, 0x7e2a24 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777460: jmp 0x75bf0e */

}

void sub_00777470(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777470u);

L_00777470:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777470: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x005002A0u); RECOMP_RETURN(); /* 0x00777473: jmp 0x5002a0 */

}

void sub_00777478(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777478u);

    goto L_00777478;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777478:
    eax = 0x007E2A48u; /* 0x00777478: mov eax, 0x7e2a48 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077747D: jmp 0x75bf0e */

}

void sub_00777490(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777490u);

L_00777490:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777490: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x0051AA70u); RECOMP_RETURN(); /* 0x00777493: jmp 0x51aa70 */

}

void sub_00777498(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777498u);

L_00777498:
    PUSH32(esp, 0x0051AA70u); /* 0x00777498: push 0x51aa70 */
    PUSH32(esp, 0x100u); /* 0x0077749D: push 0x100 */
    PUSH32(esp, 0x20u); /* 0x007774A2: push 0x20 */
    eax = MEM32(ebp + (-0x10)); /* 0x007774A4: mov eax, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0xCu; /* 0x007774A7: add eax, 0xc */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x007774AA: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x007774AB: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007774B0: ret  */

}

void sub_007774B1(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007774B1u);

    goto L_007774B1;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007774B1:
    eax = 0x007E2A74u; /* 0x007774B1: mov eax, 0x7e2a74 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007774B6: jmp 0x75bf0e */

}

void sub_007774C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007774C0u);

L_007774C0:
    ecx = ebp + (-0x1240); /* 0x007774C0: lea ecx, [ebp - 0x1240] */
    RECOMP_ITAIL(0x0040BE20u); RECOMP_RETURN(); /* 0x007774C6: jmp 0x40be20 */

}

void sub_007774CB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007774CBu);

L_007774CB:
    ecx = ebp + (-0x950); /* 0x007774CB: lea ecx, [ebp - 0x950] */
    RECOMP_ITAIL(0x0050F700u); RECOMP_RETURN(); /* 0x007774D1: jmp 0x50f700 */

}

void sub_007774D6(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007774D6u);

    goto L_007774D6;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007774D6:
    eax = 0x007E2AC4u; /* 0x007774D6: mov eax, 0x7e2ac4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007774DB: jmp 0x75bf0e */

}

void sub_007774E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007774E0u);

L_007774E0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007774E0: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0xD24u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0xD24u; /* 0x007774E3: add ecx, 0xd24 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00500380u); RECOMP_RETURN(); /* 0x007774E9: jmp 0x500380 */

}

void sub_007774EE(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007774EEu);

    goto L_007774EE;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007774EE:
    eax = 0x007E252Cu; /* 0x007774EE: mov eax, 0x7e252c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007774F3: jmp 0x75bf0e */

}

void sub_00777500(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777500u);

L_00777500:
    ecx = ebp + (-0x14); /* 0x00777500: lea ecx, [ebp - 0x14] */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00777503: jmp 0x5cde60 */

}

void sub_00777508(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777508u);

    goto L_00777508;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777508:
    eax = 0x007E3AF8u; /* 0x00777508: mov eax, 0x7e3af8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077750D: jmp 0x75bf0e */

}

void sub_00777520(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777520u);

L_00777520:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777520: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x10u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x10u; /* 0x00777523: add ecx, 0x10 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00531860u); RECOMP_RETURN(); /* 0x00777526: jmp 0x531860 */

}

void sub_0077752B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077752Bu);

    goto L_0077752B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077752B:
    eax = 0x007E2B14u; /* 0x0077752B: mov eax, 0x7e2b14 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777530: jmp 0x75bf0e */

}

void sub_00777540(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777540u);

L_00777540:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777540: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0xDCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0xDCu; /* 0x00777543: add ecx, 0xdc */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00525C10u); RECOMP_RETURN(); /* 0x00777549: jmp 0x525c10 */

}

void sub_0077754E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077754Eu);

L_0077754E:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077754E: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0xECu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0xECu; /* 0x00777551: add ecx, 0xec */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00525C10u); RECOMP_RETURN(); /* 0x00777557: jmp 0x525c10 */

}

void sub_0077755C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077755Cu);

L_0077755C:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077755C: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0xFCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0xFCu; /* 0x0077755F: add ecx, 0xfc */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00525C10u); RECOMP_RETURN(); /* 0x00777565: jmp 0x525c10 */

}

void sub_0077756A(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077756Au);

L_0077756A:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077756A: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4114u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4114u; /* 0x0077756D: add ecx, 0x4114 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00525C10u); RECOMP_RETURN(); /* 0x00777573: jmp 0x525c10 */

}

void sub_00777578(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777578u);

L_00777578:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777578: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4124u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4124u; /* 0x0077757B: add ecx, 0x4124 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00525C10u); RECOMP_RETURN(); /* 0x00777581: jmp 0x525c10 */

}

void sub_00777586(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777586u);

L_00777586:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777586: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4134u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4134u; /* 0x00777589: add ecx, 0x4134 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00525C10u); RECOMP_RETURN(); /* 0x0077758F: jmp 0x525c10 */

}

void sub_00777594(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777594u);

    goto L_00777594;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777594:
    eax = 0x007E2A00u; /* 0x00777594: mov eax, 0x7e2a00 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777599: jmp 0x75bf0e */

}

void sub_007775A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007775A0u);

L_007775A0:
    ecx = MEM32(ebp + (-0x14)); /* 0x007775A0: mov ecx, dword ptr [ebp - 0x14] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x10u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x10u; /* 0x007775A3: add ecx, 0x10 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00531820u); RECOMP_RETURN(); /* 0x007775A6: jmp 0x531820 */

}

void sub_007775AB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007775ABu);

L_007775AB:
    PUSH32(esp, 0); /* 0x007775AB: push 0 */
    PUSH32(esp, 0x0079BCB8u); /* 0x007775AD: push 0x79bcb8 */
    eax = MEM32(ebp + (-0x10)); /* 0x007775B2: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007775B5: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007775B6: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007775BB: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007775BE: ret  */

}

void sub_007775BF(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007775BFu);

L_007775BF:
    PUSH32(esp, 0); /* 0x007775BF: push 0 */
    PUSH32(esp, 0x0079BCA8u); /* 0x007775C1: push 0x79bca8 */
    eax = MEM32(ebp + (-0x10)); /* 0x007775C6: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007775C9: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007775CA: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007775CF: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007775D2: ret  */

}

void sub_007775D3(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007775D3u);

    goto L_007775D3;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007775D3:
    eax = 0x007E2B48u; /* 0x007775D3: mov eax, 0x7e2b48 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007775D8: jmp 0x75bf0e */

}

void sub_007775E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007775E0u);

L_007775E0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007775E0: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x10u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x10u; /* 0x007775E3: add ecx, 0x10 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00531820u); RECOMP_RETURN(); /* 0x007775E6: jmp 0x531820 */

}

void sub_007775EB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007775EBu);

    goto L_007775EB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007775EB:
    eax = 0x007E2B6Cu; /* 0x007775EB: mov eax, 0x7e2b6c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007775F0: jmp 0x75bf0e */

}

void sub_00777600(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777600u);

L_00777600:
    PUSH32(esp, 0); /* 0x00777600: push 0 */
    PUSH32(esp, 0x0079BD94u); /* 0x00777602: push 0x79bd94 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777607: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077760A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077760B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777610: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777613: ret  */

}

void sub_00777614(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777614u);

    goto L_00777614;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777614:
    eax = 0x007E2B90u; /* 0x00777614: mov eax, 0x7e2b90 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777619: jmp 0x75bf0e */

}

void sub_00777620(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777620u);

L_00777620:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777620: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x48u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x48u; /* 0x00777623: add ecx, 0x48 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00777626: jmp 0x5cde60 */

}

void sub_0077762B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077762Bu);

L_0077762B:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077762B: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x50u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x50u; /* 0x0077762E: add ecx, 0x50 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0040BE20u); RECOMP_RETURN(); /* 0x00777631: jmp 0x40be20 */

}

void sub_00777636(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777636u);

    goto L_00777636;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777636:
    eax = 0x007E2BBCu; /* 0x00777636: mov eax, 0x7e2bbc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077763B: jmp 0x75bf0e */

}

void sub_00777640(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777640u);

L_00777640:
    PUSH32(esp, 0); /* 0x00777640: push 0 */
    PUSH32(esp, 0x0079BE5Cu); /* 0x00777642: push 0x79be5c */
    eax = MEM32(ebp + 0x14); /* 0x00777647: mov eax, dword ptr [ebp + 0x14] */
    PUSH32(esp, eax); /* 0x0077764A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077764B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777650: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777653: ret  */

}

void sub_00777654(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777654u);

L_00777654:
    PUSH32(esp, 0); /* 0x00777654: push 0 */
    PUSH32(esp, 0x0079BE5Cu); /* 0x00777656: push 0x79be5c */
    eax = MEM32(ebp + 0x14); /* 0x0077765B: mov eax, dword ptr [ebp + 0x14] */
    PUSH32(esp, eax); /* 0x0077765E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077765F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777664: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777667: ret  */

}

void sub_00777668(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777668u);

    goto L_00777668;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777668:
    eax = 0x007E2BE8u; /* 0x00777668: mov eax, 0x7e2be8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077766D: jmp 0x75bf0e */

}

void sub_00777680(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777680u);

L_00777680:
    ecx = ebp + (-0x18); /* 0x00777680: lea ecx, [ebp - 0x18] */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00777683: jmp 0x5cde60 */

}

void sub_00777688(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777688u);

    goto L_00777688;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777688:
    eax = 0x007E2FBCu; /* 0x00777688: mov eax, 0x7e2fbc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077768D: jmp 0x75bf0e */

}

void sub_007776A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007776A0u);

L_007776A0:
    PUSH32(esp, 0); /* 0x007776A0: push 0 */
    PUSH32(esp, 0x0079BE70u); /* 0x007776A2: push 0x79be70 */
    eax = MEM32(ebp + (-0x10)); /* 0x007776A7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007776AA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007776AB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007776B0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007776B3: ret  */

}

void sub_007776B4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007776B4u);

L_007776B4:
    PUSH32(esp, 0); /* 0x007776B4: push 0 */
    PUSH32(esp, 0x0079BE70u); /* 0x007776B6: push 0x79be70 */
    eax = MEM32(ebp + (-0x10)); /* 0x007776BB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007776BE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007776BF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007776C4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007776C7: ret  */

}

void sub_007776C8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007776C8u);

L_007776C8:
    PUSH32(esp, 0); /* 0x007776C8: push 0 */
    PUSH32(esp, 0x0079BE70u); /* 0x007776CA: push 0x79be70 */
    eax = MEM32(ebp + (-0x10)); /* 0x007776CF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007776D2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007776D3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007776D8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007776DB: ret  */

}

void sub_007776DC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007776DCu);

L_007776DC:
    PUSH32(esp, 0); /* 0x007776DC: push 0 */
    PUSH32(esp, 0x0079BE70u); /* 0x007776DE: push 0x79be70 */
    eax = MEM32(ebp + (-0x10)); /* 0x007776E3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007776E6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007776E7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007776EC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007776EF: ret  */

}

void sub_007776F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007776F0u);

L_007776F0:
    PUSH32(esp, 0); /* 0x007776F0: push 0 */
    PUSH32(esp, 0x0079BE70u); /* 0x007776F2: push 0x79be70 */
    eax = MEM32(ebp + (-0x10)); /* 0x007776F7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007776FA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007776FB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777700: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777703: ret  */

}

void sub_00777704(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777704u);

L_00777704:
    PUSH32(esp, 0); /* 0x00777704: push 0 */
    PUSH32(esp, 0x0079BE70u); /* 0x00777706: push 0x79be70 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077770B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077770E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077770F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777714: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777717: ret  */

}

void sub_00777718(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777718u);

L_00777718:
    PUSH32(esp, 0); /* 0x00777718: push 0 */
    PUSH32(esp, 0x0079BE70u); /* 0x0077771A: push 0x79be70 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077771F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00777722: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00777723: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777728: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077772B: ret  */

}

void sub_0077772C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077772Cu);

L_0077772C:
    PUSH32(esp, 0); /* 0x0077772C: push 0 */
    PUSH32(esp, 0x0079BE70u); /* 0x0077772E: push 0x79be70 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777733: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00777736: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00777737: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077773C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077773F: ret  */

}

void sub_00777740(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777740u);

L_00777740:
    PUSH32(esp, 0); /* 0x00777740: push 0 */
    PUSH32(esp, 0x0079BE70u); /* 0x00777742: push 0x79be70 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777747: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077774A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077774B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777750: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777753: ret  */

}

void sub_00777754(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777754u);

L_00777754:
    PUSH32(esp, 0); /* 0x00777754: push 0 */
    PUSH32(esp, 0x0079BE70u); /* 0x00777756: push 0x79be70 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077775B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077775E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077775F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777764: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777767: ret  */

}

void sub_00777768(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777768u);

    goto L_00777768;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777768:
    eax = 0x007E2C54u; /* 0x00777768: mov eax, 0x7e2c54 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077776D: jmp 0x75bf0e */

}

void sub_00777780(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777780u);

L_00777780:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777780: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00777783: jmp 0x553a80 */

}

void sub_00777788(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777788u);

L_00777788:
    PUSH32(esp, 0x005CDE60u); /* 0x00777788: push 0x5cde60 */
    PUSH32(esp, 3); /* 0x0077778D: push 3 */
    PUSH32(esp, 0x14u); /* 0x0077778F: push 0x14 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777791: mov eax, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x64u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x64u; /* 0x00777794: add eax, 0x64 */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x00777797: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x00777798: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077779D: ret  */

}

void sub_0077779E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077779Eu);

    goto L_0077779E;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077779E:
    eax = 0x007E3254u; /* 0x0077779E: mov eax, 0x7e3254 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007777A3: jmp 0x75bf0e */

}

void sub_007777B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007777B0u);

L_007777B0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007777B0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x005101F0u); RECOMP_RETURN(); /* 0x007777B3: jmp 0x5101f0 */

}

void sub_007777B8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007777B8u);

    goto L_007777B8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007777B8:
    eax = 0x007E2C78u; /* 0x007777B8: mov eax, 0x7e2c78 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007777BD: jmp 0x75bf0e */

}

void sub_007777D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007777D0u);

L_007777D0:
    PUSH32(esp, 0); /* 0x007777D0: push 0 */
    PUSH32(esp, 0x0079BEE0u); /* 0x007777D2: push 0x79bee0 */
    eax = MEM32(ebp + (-0x28)); /* 0x007777D7: mov eax, dword ptr [ebp - 0x28] */
    PUSH32(esp, eax); /* 0x007777DA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007777DB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007777E0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007777E3: ret  */

}

void sub_007777E4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007777E4u);

    goto L_007777E4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007777E4:
    eax = 0x007E2C9Cu; /* 0x007777E4: mov eax, 0x7e2c9c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007777E9: jmp 0x75bf0e */

}

void sub_007777F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007777F0u);

L_007777F0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007777F0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x0051AA70u); RECOMP_RETURN(); /* 0x007777F3: jmp 0x51aa70 */

}

void sub_007777F8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007777F8u);

L_007777F8:
    PUSH32(esp, 0x00534A60u); /* 0x007777F8: push 0x534a60 */
    PUSH32(esp, 0x40u); /* 0x007777FD: push 0x40 */
    PUSH32(esp, 0x18u); /* 0x007777FF: push 0x18 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777801: mov eax, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0xCu; /* 0x00777804: add eax, 0xc */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x00777807: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x00777808: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077780D: ret  */

}

void sub_0077780E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077780Eu);

    goto L_0077780E;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077780E:
    eax = 0x007E2CC8u; /* 0x0077780E: mov eax, 0x7e2cc8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777813: jmp 0x75bf0e */

}

void sub_00777820(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777820u);

L_00777820:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777820: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x0051AA70u); RECOMP_RETURN(); /* 0x00777823: jmp 0x51aa70 */

}

void sub_00777828(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777828u);

L_00777828:
    PUSH32(esp, 0x005350D0u); /* 0x00777828: push 0x5350d0 */
    PUSH32(esp, 0x20u); /* 0x0077782D: push 0x20 */
    PUSH32(esp, 0x34u); /* 0x0077782F: push 0x34 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777831: mov eax, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0xCu; /* 0x00777834: add eax, 0xc */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x00777837: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x00777838: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077783D: ret  */

}

void sub_0077783E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077783Eu);

    goto L_0077783E;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077783E:
    eax = 0x007E2CF4u; /* 0x0077783E: mov eax, 0x7e2cf4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777843: jmp 0x75bf0e */

}

void sub_00777850(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777850u);

L_00777850:
    PUSH32(esp, 0x00525C80u); /* 0x00777850: push 0x525c80 */
    PUSH32(esp, 2); /* 0x00777855: push 2 */
    PUSH32(esp, 0xAB4Cu); /* 0x00777857: push 0xab4c */
    eax = MEM32(ebp + (-0x10)); /* 0x0077785C: mov eax, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x10u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x10u; /* 0x0077785F: add eax, 0x10 */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x00777862: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x00777863: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777868: ret  */

}

void sub_00777869(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777869u);

    goto L_00777869;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777869:
    eax = 0x007E2A98u; /* 0x00777869: mov eax, 0x7e2a98 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077786E: jmp 0x75bf0e */

}

void sub_00777880(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777880u);

L_00777880:
    ecx = ebp + (-0x8F0); /* 0x00777880: lea ecx, [ebp - 0x8f0] */
    RECOMP_ITAIL(0x00401830u); RECOMP_RETURN(); /* 0x00777886: jmp 0x401830 */

}

void sub_0077788B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077788Bu);

L_0077788B:
    ecx = ebp + (-0x900); /* 0x0077788B: lea ecx, [ebp - 0x900] */
    RECOMP_ITAIL(0x0040BE20u); RECOMP_RETURN(); /* 0x00777891: jmp 0x40be20 */

}

void sub_00777896(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777896u);

L_00777896:
    ecx = ebp + (-0x1240); /* 0x00777896: lea ecx, [ebp - 0x1240] */
    RECOMP_ITAIL(0x0050F700u); RECOMP_RETURN(); /* 0x0077789C: jmp 0x50f700 */

}

void sub_007778A1(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007778A1u);

    goto L_007778A1;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007778A1:
    eax = 0x007E2D5Cu; /* 0x007778A1: mov eax, 0x7e2d5c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007778A6: jmp 0x75bf0e */

}

void sub_007778B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007778B0u);

L_007778B0:
    ecx = ebp + (-0x18); /* 0x007778B0: lea ecx, [ebp - 0x18] */
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x007778B3: jmp 0x5ce0f0 */

}

void sub_007778B8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007778B8u);

    goto L_007778B8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007778B8:
    eax = 0x007E2D80u; /* 0x007778B8: mov eax, 0x7e2d80 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007778BD: jmp 0x75bf0e */

}

void sub_007778D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007778D0u);

L_007778D0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007778D0: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(8);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 8; /* 0x007778D3: add ecx, 8 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00490340u); RECOMP_RETURN(); /* 0x007778D6: jmp 0x490340 */

}

void sub_007778DB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007778DBu);

L_007778DB:
    ecx = MEM32(ebp + (-0x10)); /* 0x007778DB: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x10u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x10u; /* 0x007778DE: add ecx, 0x10 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00490340u); RECOMP_RETURN(); /* 0x007778E1: jmp 0x490340 */

}

void sub_007778E6(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007778E6u);

    goto L_007778E6;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007778E6:
    eax = 0x007E2DACu; /* 0x007778E6: mov eax, 0x7e2dac */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007778EB: jmp 0x75bf0e */

}

void sub_007778F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007778F0u);

L_007778F0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007778F0: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 4; /* 0x007778F3: add ecx, 4 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00490340u); RECOMP_RETURN(); /* 0x007778F6: jmp 0x490340 */

}

void sub_007778FB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007778FBu);

    goto L_007778FB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007778FB:
    eax = 0x007E2DD0u; /* 0x007778FB: mov eax, 0x7e2dd0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777900: jmp 0x75bf0e */

}

void sub_00777910(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777910u);

L_00777910:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777910: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004CBB20u); RECOMP_RETURN(); /* 0x00777913: jmp 0x4cbb20 */

}

void sub_00777918(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777918u);

    goto L_00777918;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777918:
    eax = 0x007E2DF4u; /* 0x00777918: mov eax, 0x7e2df4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077791D: jmp 0x75bf0e */

}

void sub_00777930(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777930u);

L_00777930:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777930: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 4; /* 0x00777933: add ecx, 4 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x00777936: jmp 0x5ce0f0 */

}

void sub_0077793B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077793Bu);

    goto L_0077793B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077793B:
    eax = 0x007E2E18u; /* 0x0077793B: mov eax, 0x7e2e18 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777940: jmp 0x75bf0e */

}

void sub_00777950(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777950u);

L_00777950:
    ecx = ebp + (-0x20); /* 0x00777950: lea ecx, [ebp - 0x20] */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00777953: jmp 0x5cde60 */

}

void sub_00777958(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777958u);

    goto L_00777958;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777958:
    eax = 0x007E2E3Cu; /* 0x00777958: mov eax, 0x7e2e3c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077795D: jmp 0x75bf0e */

}

void sub_00777970(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777970u);

L_00777970:
    ecx = ebp + (-0x1C); /* 0x00777970: lea ecx, [ebp - 0x1c] */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00777973: jmp 0x5cde60 */

}

void sub_00777978(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777978u);

    goto L_00777978;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777978:
    eax = 0x007E2E84u; /* 0x00777978: mov eax, 0x7e2e84 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077797D: jmp 0x75bf0e */

}

void sub_00777990(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777990u);

L_00777990:
    ecx = ebp + (-0x24); /* 0x00777990: lea ecx, [ebp - 0x24] */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00777993: jmp 0x5cde60 */

}

void sub_00777998(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777998u);

L_00777998:
    ecx = ebp + (-0x1C); /* 0x00777998: lea ecx, [ebp - 0x1c] */
    RECOMP_ITAIL(0x0050C9F0u); RECOMP_RETURN(); /* 0x0077799B: jmp 0x50c9f0 */

}

void sub_007779A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007779A0u);

L_007779A0:
    ecx = ebp + (-0x1C); /* 0x007779A0: lea ecx, [ebp - 0x1c] */
    RECOMP_ITAIL(0x0050C9F0u); RECOMP_RETURN(); /* 0x007779A3: jmp 0x50c9f0 */

}

void sub_007779A8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007779A8u);

L_007779A8:
    ecx = ebp + (-0x1C); /* 0x007779A8: lea ecx, [ebp - 0x1c] */
    RECOMP_ITAIL(0x0050C9F0u); RECOMP_RETURN(); /* 0x007779AB: jmp 0x50c9f0 */

}

void sub_007779B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007779B0u);

    goto L_007779B0;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007779B0:
    eax = 0x007E2EC0u; /* 0x007779B0: mov eax, 0x7e2ec0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007779B5: jmp 0x75bf0e */

}

void sub_007779C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007779C0u);

L_007779C0:
    ecx = ebp + (-0x30); /* 0x007779C0: lea ecx, [ebp - 0x30] */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x007779C3: jmp 0x5cde60 */

}

void sub_007779C8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007779C8u);

L_007779C8:
    ecx = ebp + (-0x3C); /* 0x007779C8: lea ecx, [ebp - 0x3c] */
    RECOMP_ITAIL(0x0050C9F0u); RECOMP_RETURN(); /* 0x007779CB: jmp 0x50c9f0 */

}

void sub_007779D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007779D0u);

L_007779D0:
    ecx = ebp + (-0x3C); /* 0x007779D0: lea ecx, [ebp - 0x3c] */
    RECOMP_ITAIL(0x0050C9F0u); RECOMP_RETURN(); /* 0x007779D3: jmp 0x50c9f0 */

}

void sub_007779D8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007779D8u);

    goto L_007779D8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007779D8:
    eax = 0x007E2EF4u; /* 0x007779D8: mov eax, 0x7e2ef4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007779DD: jmp 0x75bf0e */

}

void sub_007779F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007779F0u);

L_007779F0:
    PUSH32(esp, 0); /* 0x007779F0: push 0 */
    PUSH32(esp, 0x0079C568u); /* 0x007779F2: push 0x79c568 */
    eax = MEM32(ebp + 0x8); /* 0x007779F7: mov eax, dword ptr [ebp + 8] */
    PUSH32(esp, eax); /* 0x007779FA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007779FB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777A00: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777A03: ret  */

}

void sub_00777A04(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777A04u);

    goto L_00777A04;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777A04:
    eax = 0x007E2F18u; /* 0x00777A04: mov eax, 0x7e2f18 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777A09: jmp 0x75bf0e */

}

void sub_00777A10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777A10u);

L_00777A10:
    ecx = ebp + (-0xA8); /* 0x00777A10: lea ecx, [ebp - 0xa8] */
    RECOMP_ITAIL(0x0050C9F0u); RECOMP_RETURN(); /* 0x00777A16: jmp 0x50c9f0 */

}

void sub_00777A1B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777A1Bu);

L_00777A1B:
    ecx = ebp + (-0x6C); /* 0x00777A1B: lea ecx, [ebp - 0x6c] */
    RECOMP_ITAIL(0x0050C9F0u); RECOMP_RETURN(); /* 0x00777A1E: jmp 0x50c9f0 */

}

void sub_00777A23(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777A23u);

L_00777A23:
    ecx = ebp + (-0x90); /* 0x00777A23: lea ecx, [ebp - 0x90] */
    RECOMP_ITAIL(0x0050C9F0u); RECOMP_RETURN(); /* 0x00777A29: jmp 0x50c9f0 */

}

void sub_00777A2E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777A2Eu);

L_00777A2E:
    ecx = ebp + (-0xC0); /* 0x00777A2E: lea ecx, [ebp - 0xc0] */
    RECOMP_ITAIL(0x0050C9F0u); RECOMP_RETURN(); /* 0x00777A34: jmp 0x50c9f0 */

}

void sub_00777A39(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777A39u);

L_00777A39:
    ecx = ebp + (-0x78); /* 0x00777A39: lea ecx, [ebp - 0x78] */
    RECOMP_ITAIL(0x0050C9F0u); RECOMP_RETURN(); /* 0x00777A3C: jmp 0x50c9f0 */

}

void sub_00777A41(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777A41u);

L_00777A41:
    ecx = ebp + (-0xB4); /* 0x00777A41: lea ecx, [ebp - 0xb4] */
    RECOMP_ITAIL(0x0050C9F0u); RECOMP_RETURN(); /* 0x00777A47: jmp 0x50c9f0 */

}

void sub_00777A4C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777A4Cu);

L_00777A4C:
    ecx = ebp + (-0x9C); /* 0x00777A4C: lea ecx, [ebp - 0x9c] */
    RECOMP_ITAIL(0x0050C9F0u); RECOMP_RETURN(); /* 0x00777A52: jmp 0x50c9f0 */

}

void sub_00777A57(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777A57u);

L_00777A57:
    ecx = ebp + (-0x84); /* 0x00777A57: lea ecx, [ebp - 0x84] */
    RECOMP_ITAIL(0x0050C9F0u); RECOMP_RETURN(); /* 0x00777A5D: jmp 0x50c9f0 */

}

void sub_00777A62(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777A62u);

    goto L_00777A62;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777A62:
    eax = 0x007E2F74u; /* 0x00777A62: mov eax, 0x7e2f74 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777A67: jmp 0x75bf0e */

}

void sub_00777A70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777A70u);

L_00777A70:
    eax = MEM32(ebp + 0xC); /* 0x00777A70: mov eax, dword ptr [ebp + 0xc] */
    PUSH32(esp, eax); /* 0x00777A73: push eax */
    RECOMP_CALL(sub_004FDAB0); /* 0x00777A74: call 0x4fdab0 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00777A79: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777A7A: ret  */

}

void sub_00777A7B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777A7Bu);

    goto L_00777A7B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777A7B:
    eax = 0x007E2F98u; /* 0x00777A7B: mov eax, 0x7e2f98 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777A80: jmp 0x75bf0e */

}

void sub_00777A90(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777A90u);

L_00777A90:
    ecx = ebp + 0x4; /* 0x00777A90: lea ecx, [ebp + 4] */
    RECOMP_ITAIL(0x0050C9F0u); RECOMP_RETURN(); /* 0x00777A93: jmp 0x50c9f0 */

}

void sub_00777A98(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777A98u);

L_00777A98:
    ecx = ebp + (-0x14); /* 0x00777A98: lea ecx, [ebp - 0x14] */
    RECOMP_ITAIL(0x0050C9F0u); RECOMP_RETURN(); /* 0x00777A9B: jmp 0x50c9f0 */

}

void sub_00777AA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777AA0u);

L_00777AA0:
    ecx = ebp + (-0x10); /* 0x00777AA0: lea ecx, [ebp - 0x10] */
    RECOMP_ITAIL(0x0050C9F0u); RECOMP_RETURN(); /* 0x00777AA3: jmp 0x50c9f0 */

}

void sub_00777AA8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777AA8u);

    goto L_00777AA8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777AA8:
    eax = 0x007E2FF0u; /* 0x00777AA8: mov eax, 0x7e2ff0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777AAD: jmp 0x75bf0e */

}

void sub_00777AC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777AC0u);

L_00777AC0:
    PUSH32(esp, 0); /* 0x00777AC0: push 0 */
    PUSH32(esp, 0x0079C83Cu); /* 0x00777AC2: push 0x79c83c */
    eax = MEM32(ebp + (-0x10)); /* 0x00777AC7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00777ACA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00777ACB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777AD0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777AD3: ret  */

}

void sub_00777AD4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777AD4u);

    goto L_00777AD4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777AD4:
    eax = 0x007E3014u; /* 0x00777AD4: mov eax, 0x7e3014 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777AD9: jmp 0x75bf0e */

}

void sub_00777AE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777AE0u);

L_00777AE0:
    eax = MEM32(ebp + (-0x14)); /* 0x00777AE0: mov eax, dword ptr [ebp - 0x14] */
    PUSH32(esp, eax); /* 0x00777AE3: push eax */
    RECOMP_CALL(sub_00575590); /* 0x00777AE4: call 0x575590 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00777AE9: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777AEA: ret  */

}

void sub_00777AEB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777AEBu);

    goto L_00777AEB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777AEB:
    eax = 0x007E3038u; /* 0x00777AEB: mov eax, 0x7e3038 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777AF0: jmp 0x75bf0e */

}

void sub_00777B00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777B00u);

L_00777B00:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777B00: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x0051AA70u); RECOMP_RETURN(); /* 0x00777B03: jmp 0x51aa70 */

}

void sub_00777B08(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777B08u);

L_00777B08:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777B08: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x24u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x24u; /* 0x00777B0B: add ecx, 0x24 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004FE8D0u); RECOMP_RETURN(); /* 0x00777B0E: jmp 0x4fe8d0 */

}

void sub_00777B13(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777B13u);

    goto L_00777B13;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777B13:
    eax = 0x007E2AF0u; /* 0x00777B13: mov eax, 0x7e2af0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777B18: jmp 0x75bf0e */

}

void sub_00777B20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777B20u);

L_00777B20:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777B20: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00777B23: jmp 0x553a80 */

}

void sub_00777B28(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777B28u);

L_00777B28:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777B28: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4Cu; /* 0x00777B2B: add ecx, 0x4c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00490340u); RECOMP_RETURN(); /* 0x00777B2E: jmp 0x490340 */

}

void sub_00777B33(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777B33u);

L_00777B33:
    ecx = ebp + (-0x24); /* 0x00777B33: lea ecx, [ebp - 0x24] */
    RECOMP_ITAIL(0x0050C9F0u); RECOMP_RETURN(); /* 0x00777B36: jmp 0x50c9f0 */

}

void sub_00777B3B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777B3Bu);

L_00777B3B:
    ecx = ebp + (-0x30); /* 0x00777B3B: lea ecx, [ebp - 0x30] */
    RECOMP_ITAIL(0x0050C9F0u); RECOMP_RETURN(); /* 0x00777B3E: jmp 0x50c9f0 */

}

void sub_00777B43(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777B43u);

L_00777B43:
    eax = MEM32(ebp + (-0x18)); /* 0x00777B43: mov eax, dword ptr [ebp - 0x18] */
    PUSH32(esp, eax); /* 0x00777B46: push eax */
    RECOMP_CALL(sub_00575590); /* 0x00777B47: call 0x575590 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00777B4C: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777B4D: ret  */

}

void sub_00777B4E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777B4Eu);

    goto L_00777B4E;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777B4E:
    eax = 0x007E307Cu; /* 0x00777B4E: mov eax, 0x7e307c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777B53: jmp 0x75bf0e */

}

void sub_00777B60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777B60u);

L_00777B60:
    PUSH32(esp, 0x0079C938u); /* 0x00777B60: push 0x79c938 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777B65: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00777B68: push eax */
    RECOMP_CALL(sub_004FE290); /* 0x00777B69: call 0x4fe290 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(8);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 8; /* 0x00777B6E: add esp, 8 */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777B71: ret  */

}

void sub_00777B72(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777B72u);

    goto L_00777B72;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777B72:
    eax = 0x007E30A0u; /* 0x00777B72: mov eax, 0x7e30a0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777B77: jmp 0x75bf0e */

}

void sub_00777B80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777B80u);

L_00777B80:
    PUSH32(esp, 0); /* 0x00777B80: push 0 */
    PUSH32(esp, 0x0079C958u); /* 0x00777B82: push 0x79c958 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777B87: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00777B8A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00777B8B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777B90: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777B93: ret  */

}

void sub_00777B94(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777B94u);

    goto L_00777B94;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777B94:
    eax = 0x007E30C4u; /* 0x00777B94: mov eax, 0x7e30c4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777B99: jmp 0x75bf0e */

}

void sub_00777BA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777BA0u);

L_00777BA0:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777BA0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00777BA3: jmp 0x553a80 */

}

void sub_00777BA8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777BA8u);

L_00777BA8:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777BA8: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4Cu; /* 0x00777BAB: add ecx, 0x4c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004CBB20u); RECOMP_RETURN(); /* 0x00777BAE: jmp 0x4cbb20 */

}

void sub_00777BB3(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777BB3u);

    goto L_00777BB3;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777BB3:
    eax = 0x007E30F0u; /* 0x00777BB3: mov eax, 0x7e30f0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777BB8: jmp 0x75bf0e */

}

void sub_00777BC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777BC0u);

L_00777BC0:
    ecx = MEM32(ebp + (-0x5C)); /* 0x00777BC0: mov ecx, dword ptr [ebp - 0x5c] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00777BC3: jmp 0x553a80 */

}

void sub_00777BC8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777BC8u);

L_00777BC8:
    ecx = ebp + (-0x58); /* 0x00777BC8: lea ecx, [ebp - 0x58] */
    RECOMP_ITAIL(0x0050C9F0u); RECOMP_RETURN(); /* 0x00777BCB: jmp 0x50c9f0 */

}

void sub_00777BD0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777BD0u);

    goto L_00777BD0;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777BD0:
    eax = 0x007E311Cu; /* 0x00777BD0: mov eax, 0x7e311c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777BD5: jmp 0x75bf0e */

}

void sub_00777BE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777BE0u);

L_00777BE0:
    PUSH32(esp, 0); /* 0x00777BE0: push 0 */
    PUSH32(esp, 0x0079C9B8u); /* 0x00777BE2: push 0x79c9b8 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777BE7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00777BEA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00777BEB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777BF0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777BF3: ret  */

}