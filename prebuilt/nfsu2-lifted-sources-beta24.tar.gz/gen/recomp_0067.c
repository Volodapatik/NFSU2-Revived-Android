/* AUTO-GENERATED from SPEED2.analysis.exe by run_lift.py (pcrecomp lift32). DO NOT EDIT, DO NOT COMMIT. */
#define RECOMP_GENERATED_CODE
#include "recomp_types.h"
#include "recomp_funcs.h"
#include "guest_render_probe.h"
#include <math.h>
#include <string.h>

void sub_0077B9A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B9A0u);

L_0077B9A0:
    fp_push(*(float*)&MEM32(0x786FB4)); /* 0x0077B9A0: fld dword ptr [0x786fb4] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x0077B9A6: fmul dword ptr [0x784260] */
    fp_push(*(float*)&MEM32(0x786FC0)); /* 0x0077B9AC: fld dword ptr [0x786fc0] */
    _st[0] *= (double)*(float*)ADDR(0x7881FC); /* 0x0077B9B2: fmul dword ptr [0x7881fc] */
    _st[0] = _st[1] - _st[0]; /* 0x0077B9B8: fsubr st(1) */
    _st[0] -= _st[1]; /* 0x0077B9BA: fsub st(1) */
    RECOMP_CALL(sub_0075BE10); /* 0x0077B9BC: call 0x75be10 */
    RECOMP_FLAGS_IN();
    { _st[0] = _st[0]; g_st_i64[0] = g_st_i64[0]; fp_pop(); } /* 0x0077B9C1: fstp st(0) */
    MEM32(0x82A44C) = eax; /* 0x0077B9C3: mov dword ptr [0x82a44c], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B9C8: ret  */

}

void sub_0077B9D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077B9D0u);

L_0077B9D0:
    fp_push(*(float*)&MEM32(0x786FB4)); /* 0x0077B9D0: fld dword ptr [0x786fb4] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x0077B9D6: fmul dword ptr [0x784260] */
    fp_push(*(float*)&MEM32(0x786FC0)); /* 0x0077B9DC: fld dword ptr [0x786fc0] */
    _st[0] *= (double)*(float*)ADDR(0x787ADC); /* 0x0077B9E2: fmul dword ptr [0x787adc] */
    _st[0] = _st[1] - _st[0]; /* 0x0077B9E8: fsubr st(1) */
    _st[0] -= _st[1]; /* 0x0077B9EA: fsub st(1) */
    RECOMP_CALL(sub_0075BE10); /* 0x0077B9EC: call 0x75be10 */
    RECOMP_FLAGS_IN();
    { _st[0] = _st[0]; g_st_i64[0] = g_st_i64[0]; fp_pop(); } /* 0x0077B9F1: fstp st(0) */
    MEM32(0x8286F0) = eax; /* 0x0077B9F3: mov dword ptr [0x8286f0], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077B9F8: ret  */

}

void sub_0077BA00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BA00u);

L_0077BA00:
    fp_push(*(float*)&MEM32(0x786FC0)); /* 0x0077BA00: fld dword ptr [0x786fc0] */
    _st[0] *= (double)*(float*)ADDR(0x7881FC); /* 0x0077BA06: fmul dword ptr [0x7881fc] */
    _st[0] = (double)*(float*)ADDR(0x82A458) - _st[0]; /* 0x0077BA0C: fsubr dword ptr [0x82a458] */
    fp_push(*(float*)&MEM32(0x786FB4)); /* 0x0077BA12: fld dword ptr [0x786fb4] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x0077BA18: fmul dword ptr [0x784260] */
    { double _v = fp_pop(); _st[0] -= _v; } /* 0x0077BA1E: fsubp st(1) */
    RECOMP_CALL(sub_0075BE10); /* 0x0077BA20: call 0x75be10 */
    RECOMP_FLAGS_IN();
    MEM32(0x82A4D8) = eax; /* 0x0077BA25: mov dword ptr [0x82a4d8], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BA2A: ret  */

}

void sub_0077BA30(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BA30u);

L_0077BA30:
    fp_push(*(float*)&MEM32(0x786FC0)); /* 0x0077BA30: fld dword ptr [0x786fc0] */
    _st[0] *= (double)*(float*)ADDR(0x7881F8); /* 0x0077BA36: fmul dword ptr [0x7881f8] */
    _st[0] = (double)*(float*)ADDR(0x82A458) - _st[0]; /* 0x0077BA3C: fsubr dword ptr [0x82a458] */
    fp_push(*(float*)&MEM32(0x786FB4)); /* 0x0077BA42: fld dword ptr [0x786fb4] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x0077BA48: fmul dword ptr [0x784260] */
    { double _v = fp_pop(); _st[0] -= _v; } /* 0x0077BA4E: fsubp st(1) */
    RECOMP_CALL(sub_0075BE10); /* 0x0077BA50: call 0x75be10 */
    RECOMP_FLAGS_IN();
    MEM32(0x82A474) = eax; /* 0x0077BA55: mov dword ptr [0x82a474], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BA5A: ret  */

}

void sub_0077BA60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BA60u);

L_0077BA60:
    fp_push(*(float*)&MEM32(0x786FC4)); /* 0x0077BA60: fld dword ptr [0x786fc4] */
    _st[0] *= (double)*(float*)ADDR(0x788200); /* 0x0077BA66: fmul dword ptr [0x788200] */
    RECOMP_CALL(sub_0075BE10); /* 0x0077BA6C: call 0x75be10 */
    RECOMP_FLAGS_IN();
    MEM32(0x828738) = eax; /* 0x0077BA71: mov dword ptr [0x828738], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BA76: ret  */

}

void sub_0077BA80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BA80u);

L_0077BA80:
    fp_push(*(float*)&MEM32(0x786FC0)); /* 0x0077BA80: fld dword ptr [0x786fc0] */
    _st[0] *= (double)*(float*)ADDR(0x788204); /* 0x0077BA86: fmul dword ptr [0x788204] */
    RECOMP_CALL(sub_0075BE10); /* 0x0077BA8C: call 0x75be10 */
    RECOMP_FLAGS_IN();
    MEM32(0x828728) = eax; /* 0x0077BA91: mov dword ptr [0x828728], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BA96: ret  */

}

void sub_0077BAA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BAA0u);

L_0077BAA0:
    fp_push(*(float*)&MEM32(0x786FC0)); /* 0x0077BAA0: fld dword ptr [0x786fc0] */
    _st[0] *= (double)*(float*)ADDR(0x7D7D4C); /* 0x0077BAA6: fmul dword ptr [0x7d7d4c] */
    RECOMP_CALL(sub_0075BE10); /* 0x0077BAAC: call 0x75be10 */
    RECOMP_FLAGS_IN();
    MEM32(0x828758) = eax; /* 0x0077BAB1: mov dword ptr [0x828758], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BAB6: ret  */

}

void sub_0077BAC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BAC0u);

L_0077BAC0:
    fp_push(*(float*)&MEM32(0x786FC0)); /* 0x0077BAC0: fld dword ptr [0x786fc0] */
    _st[0] *= (double)*(float*)ADDR(0x7881F8); /* 0x0077BAC6: fmul dword ptr [0x7881f8] */
    RECOMP_CALL(sub_0075BE10); /* 0x0077BACC: call 0x75be10 */
    RECOMP_FLAGS_IN();
    MEM32(0x828748) = eax; /* 0x0077BAD1: mov dword ptr [0x828748], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BAD6: ret  */

}

void sub_0077BAE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BAE0u);

L_0077BAE0:
    fp_push(*(float*)&MEM32(0x786FC4)); /* 0x0077BAE0: fld dword ptr [0x786fc4] */
    _st[0] *= (double)*(float*)ADDR(0x788208); /* 0x0077BAE6: fmul dword ptr [0x788208] */
    RECOMP_CALL(sub_0075BE10); /* 0x0077BAEC: call 0x75be10 */
    RECOMP_FLAGS_IN();
    MEM32(0x828754) = eax; /* 0x0077BAF1: mov dword ptr [0x828754], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BAF6: ret  */

}

void sub_0077BB00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BB00u);

L_0077BB00:
    fp_push(*(float*)&MEM32(0x786FC0)); /* 0x0077BB00: fld dword ptr [0x786fc0] */
    _st[0] *= (double)*(float*)ADDR(0x78820C); /* 0x0077BB06: fmul dword ptr [0x78820c] */
    RECOMP_CALL(sub_0075BE10); /* 0x0077BB0C: call 0x75be10 */
    RECOMP_FLAGS_IN();
    MEM32(0x82A470) = eax; /* 0x0077BB11: mov dword ptr [0x82a470], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BB16: ret  */

}

void sub_0077BB20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BB20u);

L_0077BB20:
    fp_push(*(float*)&MEM32(0x786FC0)); /* 0x0077BB20: fld dword ptr [0x786fc0] */
    _st[0] *= (double)*(float*)ADDR(0x7843E8); /* 0x0077BB26: fmul dword ptr [0x7843e8] */
    RECOMP_CALL(sub_0075BE10); /* 0x0077BB2C: call 0x75be10 */
    RECOMP_FLAGS_IN();
    MEM32(0x82A460) = eax; /* 0x0077BB31: mov dword ptr [0x82a460], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BB36: ret  */

}

void sub_0077BB40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BB40u);

L_0077BB40:
    fp_push(*(float*)&MEM32(0x786FC0)); /* 0x0077BB40: fld dword ptr [0x786fc0] */
    _st[0] *= (double)*(float*)ADDR(0x788210); /* 0x0077BB46: fmul dword ptr [0x788210] */
    RECOMP_CALL(sub_0075BE10); /* 0x0077BB4C: call 0x75be10 */
    RECOMP_FLAGS_IN();
    MEM32(0x82872C) = eax; /* 0x0077BB51: mov dword ptr [0x82872c], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BB56: ret  */

}

void sub_0077BB60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BB60u);

L_0077BB60:
    fp_push(*(float*)&MEM32(0x786FC0)); /* 0x0077BB60: fld dword ptr [0x786fc0] */
    _st[0] *= (double)*(float*)ADDR(0x7881F8); /* 0x0077BB66: fmul dword ptr [0x7881f8] */
    RECOMP_CALL(sub_0075BE10); /* 0x0077BB6C: call 0x75be10 */
    RECOMP_FLAGS_IN();
    MEM32(0x82A46C) = eax; /* 0x0077BB71: mov dword ptr [0x82a46c], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BB76: ret  */

}

void sub_0077BB80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BB80u);

L_0077BB80:
    fp_push(*(float*)&MEM32(0x786FC4)); /* 0x0077BB80: fld dword ptr [0x786fc4] */
    _st[0] *= (double)*(float*)ADDR(0x787ADC); /* 0x0077BB86: fmul dword ptr [0x787adc] */
    RECOMP_CALL(sub_0075BE10); /* 0x0077BB8C: call 0x75be10 */
    RECOMP_FLAGS_IN();
    MEM32(0x82A45C) = eax; /* 0x0077BB91: mov dword ptr [0x82a45c], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BB96: ret  */

}

void sub_0077BBA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BBA0u);

L_0077BBA0:
    fp_push(*(float*)&MEM32(0x786FC0)); /* 0x0077BBA0: fld dword ptr [0x786fc0] */
    _st[0] *= (double)*(float*)ADDR(0x7881F4); /* 0x0077BBA6: fmul dword ptr [0x7881f4] */
    RECOMP_CALL(sub_0075BE10); /* 0x0077BBAC: call 0x75be10 */
    RECOMP_FLAGS_IN();
    MEM32(0x8286F8) = eax; /* 0x0077BBB1: mov dword ptr [0x8286f8], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BBB6: ret  */

}

void sub_0077BBC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BBC0u);

L_0077BBC0:
    fp_push(*(float*)&MEM32(0x786FC4)); /* 0x0077BBC0: fld dword ptr [0x786fc4] */
    _st[0] *= (double)*(float*)ADDR(0x7D7D4C); /* 0x0077BBC6: fmul dword ptr [0x7d7d4c] */
    RECOMP_CALL(sub_0075BE10); /* 0x0077BBCC: call 0x75be10 */
    RECOMP_FLAGS_IN();
    MEM32(0x8286E4) = eax; /* 0x0077BBD1: mov dword ptr [0x8286e4], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BBD6: ret  */

}

void sub_0077BBE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BBE0u);

L_0077BBE0:
    fp_push(*(float*)&MEM32(0x786FC0)); /* 0x0077BBE0: fld dword ptr [0x786fc0] */
    _st[0] *= (double)*(float*)ADDR(0x788214); /* 0x0077BBE6: fmul dword ptr [0x788214] */
    RECOMP_CALL(sub_0075BE10); /* 0x0077BBEC: call 0x75be10 */
    RECOMP_FLAGS_IN();
    MEM32(0x828740) = eax; /* 0x0077BBF1: mov dword ptr [0x828740], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BBF6: ret  */

}

void sub_0077BC00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BC00u);

L_0077BC00:
    fp_push(*(float*)&MEM32(0x786FC0)); /* 0x0077BC00: fld dword ptr [0x786fc0] */
    _st[0] *= (double)*(float*)ADDR(0x788218); /* 0x0077BC06: fmul dword ptr [0x788218] */
    RECOMP_CALL(sub_0075BE10); /* 0x0077BC0C: call 0x75be10 */
    RECOMP_FLAGS_IN();
    MEM32(0x828714) = eax; /* 0x0077BC11: mov dword ptr [0x828714], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BC16: ret  */

}

void sub_0077BC20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BC20u);

L_0077BC20:
    fp_push(*(float*)&MEM32(0x786FC0)); /* 0x0077BC20: fld dword ptr [0x786fc0] */
    _st[0] *= (double)*(float*)ADDR(0x78821C); /* 0x0077BC26: fmul dword ptr [0x78821c] */
    RECOMP_CALL(sub_0075BE10); /* 0x0077BC2C: call 0x75be10 */
    RECOMP_FLAGS_IN();
    MEM32(0x828720) = eax; /* 0x0077BC31: mov dword ptr [0x828720], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BC36: ret  */

}

void sub_0077BC40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BC40u);

L_0077BC40:
    fp_push(*(float*)&MEM32(0x786FC0)); /* 0x0077BC40: fld dword ptr [0x786fc0] */
    _st[0] *= (double)*(float*)ADDR(0x788220); /* 0x0077BC46: fmul dword ptr [0x788220] */
    RECOMP_CALL(sub_0075BE10); /* 0x0077BC4C: call 0x75be10 */
    RECOMP_FLAGS_IN();
    MEM32(0x82A4D4) = eax; /* 0x0077BC51: mov dword ptr [0x82a4d4], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BC56: ret  */

}

void sub_0077BC60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BC60u);

L_0077BC60:
    fp_push(*(float*)&MEM32(0x786FC0)); /* 0x0077BC60: fld dword ptr [0x786fc0] */
    RECOMP_CALL(sub_0075BE10); /* 0x0077BC66: call 0x75be10 */
    RECOMP_FLAGS_IN();
    MEM32(0x8286EC) = eax; /* 0x0077BC6B: mov dword ptr [0x8286ec], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BC70: ret  */

}

void sub_0077BC80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BC80u);

L_0077BC80:
    fp_push(*(float*)&MEM32(0x786FC4)); /* 0x0077BC80: fld dword ptr [0x786fc4] */
    _st[0] *= (double)*(float*)ADDR(0x784D28); /* 0x0077BC86: fmul dword ptr [0x784d28] */
    RECOMP_CALL(sub_0075BE10); /* 0x0077BC8C: call 0x75be10 */
    RECOMP_FLAGS_IN();
    MEM32(0x82A478) = eax; /* 0x0077BC91: mov dword ptr [0x82a478], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BC96: ret  */

}

void sub_0077BCA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BCA0u);

L_0077BCA0:
    fp_push(*(float*)&MEM32(0x786FC4)); /* 0x0077BCA0: fld dword ptr [0x786fc4] */
    _st[0] *= (double)*(float*)ADDR(0x784D28); /* 0x0077BCA6: fmul dword ptr [0x784d28] */
    RECOMP_CALL(sub_0075BE10); /* 0x0077BCAC: call 0x75be10 */
    RECOMP_FLAGS_IN();
    MEM32(0x828744) = eax; /* 0x0077BCB1: mov dword ptr [0x828744], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BCB6: ret  */

}

void sub_0077BCC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BCC0u);

L_0077BCC0:
    ecx = 0x00828770u; /* 0x0077BCC0: mov ecx, 0x828770 */
    RECOMP_CALL(sub_00447C30); /* 0x0077BCC5: call 0x447c30 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781AF0u); /* 0x0077BCCA: push 0x781af0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077BCCF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077BCD4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BCD5: ret  */

}

void sub_0077BCE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BCE0u);

L_0077BCE0:
    fp_push(*(float*)&MEM32(0x78706C)); /* 0x0077BCE0: fld dword ptr [0x78706c] */
    _st[0] += _st[0]; /* 0x0077BCE6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x828768) = _v; } /* 0x0077BCE8: fstp dword ptr [0x828768] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BCEE: ret  */

}

void sub_0077BCF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BCF0u);

L_0077BCF0:
    fp_push(*(float*)&MEM32(0x78706C)); /* 0x0077BCF0: fld dword ptr [0x78706c] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x0077BCF6: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x82A448) = _v; } /* 0x0077BCFC: fstp dword ptr [0x82a448] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BD02: ret  */

}

void sub_0077BD10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BD10u);

L_0077BD10:
    fp_push(*(double*)ADDR(0x787070)); /* 0x0077BD10: fld qword ptr [0x787070] */
    _st[0] += _st[0]; /* 0x0077BD16: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x82A450) = _v; } /* 0x0077BD18: fstp qword ptr [0x82a450] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BD1E: ret  */

}

void sub_0077BD20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BD20u);

L_0077BD20:
    fp_push(*(double*)ADDR(0x787070)); /* 0x0077BD20: fld qword ptr [0x787070] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x0077BD26: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x828760) = _v; } /* 0x0077BD2C: fstp qword ptr [0x828760] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BD32: ret  */

}

void sub_0077BD40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BD40u);

L_0077BD40:
    PUSH32(esp, 2); /* 0x0077BD40: push 2 */
    PUSH32(esp, 0x007EC420u); /* 0x0077BD42: push 0x7ec420 */
    ecx = 0x0082A4E0u; /* 0x0077BD47: mov ecx, 0x82a4e0 */
    RECOMP_CALL(sub_005766E0); /* 0x0077BD4C: call 0x5766e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BD51: ret  */

}

void sub_0077BD60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BD60u);

L_0077BD60:
    fp_push(*(float*)&MEM32(0x786F60)); /* 0x0077BD60: fld dword ptr [0x786f60] */
    PUSH32(esp, 0x3DCCCCCDu); /* 0x0077BD66: push 0x3dcccccd */
    _st[0] *= (double)*(float*)ADDR(0x787B5C); /* 0x0077BD6B: fmul dword ptr [0x787b5c] */
    PUSH32(esp, 0x3CF5C28Fu); /* 0x0077BD71: push 0x3cf5c28f */
    PUSH32(esp, 0); /* 0x0077BD76: push 0 */
    PUSH32(esp, ecx); /* 0x0077BD78: push ecx */
    ecx = 0x008286FCu; /* 0x0077BD79: mov ecx, 0x8286fc */
    { float _v = (float)fp_pop(); *(float*)ADDR(esp) = _v; } /* 0x0077BD7E: fstp dword ptr [esp] */
    RECOMP_CALL(sub_00446680); /* 0x0077BD81: call 0x446680 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781AE0u); /* 0x0077BD86: push 0x781ae0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077BD8B: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077BD90: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BD91: ret  */

}

void sub_0077BDA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BDA0u);

L_0077BDA0:
    MEM16(0x8286E8) = (uint16_t)(0x38Eu); /* 0x0077BDA0: mov word ptr [0x8286e8], 0x38e */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BDA9: ret  */

}

void sub_0077BDB0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BDB0u);

L_0077BDB0:
    MEM16(0x82A4D0) = (uint16_t)(0xBBBu); /* 0x0077BDB0: mov word ptr [0x82a4d0], 0xbbb */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BDB9: ret  */

}

void sub_0077BDC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BDC0u);

L_0077BDC0:
    MEM16(0x82A4DC) = (uint16_t)(0x38Eu); /* 0x0077BDC0: mov word ptr [0x82a4dc], 0x38e */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BDC9: ret  */

}

void sub_0077BDD0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BDD0u);

L_0077BDD0:
    PUSH32(esp, 0x00781BD0u); /* 0x0077BDD0: push 0x781bd0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077BDD5: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077BDDA: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BDDB: ret  */

}

void sub_0077BDE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BDE0u);

L_0077BDE0:
    eax = MEM32(0x7ED908); /* 0x0077BDE0: mov eax, dword ptr [0x7ed908] */
    ecx = MEM32(0x7ED91C); /* 0x0077BDE5: mov ecx, dword ptr [0x7ed91c] */
    edx = ecx + eax * 2; /* 0x0077BDEB: lea edx, [ecx + eax*2] */
    ecx = MEM32(0x7ED918); /* 0x0077BDEE: mov ecx, dword ptr [0x7ed918] */
    eax = MEM32(0x7ED8F8); /* 0x0077BDF4: mov eax, dword ptr [0x7ed8f8] */
    _flag_a = (uint32_t)(edx); _flag_b = (uint32_t)(ecx);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    edx = edx + ecx; /* 0x0077BDF9: add edx, ecx */
    _flag_k = FK_ADD;
    ecx = MEM32(0x7ED914); /* 0x0077BDFB: mov ecx, dword ptr [0x7ed914] */
    _flag_a = (uint32_t)(edx); _flag_b = (uint32_t)(eax);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    edx = edx + eax; /* 0x0077BE01: add edx, eax */
    _flag_k = FK_ADD;
    eax = MEM32(0x7ED8FC); /* 0x0077BE03: mov eax, dword ptr [0x7ed8fc] */
    _flag_a = (uint32_t)(edx); _flag_b = (uint32_t)(ecx);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    edx = edx + ecx; /* 0x0077BE08: add edx, ecx */
    _flag_k = FK_ADD;
    ecx = MEM32(0x7ED900); /* 0x0077BE0A: mov ecx, dword ptr [0x7ed900] */
    _flag_a = (uint32_t)(edx); _flag_b = (uint32_t)(eax);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    edx = edx + eax; /* 0x0077BE10: add edx, eax */
    _flag_k = FK_ADD;
    eax = MEM32(0x7ED904); /* 0x0077BE12: mov eax, dword ptr [0x7ed904] */
    _flag_a = (uint32_t)(edx); _flag_b = (uint32_t)(ecx);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    edx = edx + ecx; /* 0x0077BE17: add edx, ecx */
    _flag_k = FK_ADD;
    ecx = MEM32(0x7ED90C); /* 0x0077BE19: mov ecx, dword ptr [0x7ed90c] */
    _flag_a = (uint32_t)(edx); _flag_b = (uint32_t)(eax);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    edx = edx + eax; /* 0x0077BE1F: add edx, eax */
    _flag_k = FK_ADD;
    eax = MEM32(0x7ED910); /* 0x0077BE21: mov eax, dword ptr [0x7ed910] */
    _flag_a = (uint32_t)(edx); _flag_b = (uint32_t)(ecx);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    edx = edx + ecx; /* 0x0077BE26: add edx, ecx */
    _flag_k = FK_ADD;
    _flag_a = (uint32_t)(edx); _flag_b = (uint32_t)(eax);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    edx = edx + eax; /* 0x0077BE28: add edx, eax */
    _flag_k = FK_ADD;
    MEM32(0x82BF30) = edx; /* 0x0077BE2A: mov dword ptr [0x82bf30], edx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BE30: ret  */

}

void sub_0077BE40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BE40u);

L_0077BE40:
    fp_push(*(float*)&MEM32(0x784250)); /* 0x0077BE40: fld dword ptr [0x784250] */
    _st[0] /= (double)*(float*)ADDR(0x788480); /* 0x0077BE46: fdiv dword ptr [0x788480] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x82BF44) = _v; } /* 0x0077BE4C: fstp dword ptr [0x82bf44] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BE52: ret  */

}

void sub_0077BE60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BE60u);

L_0077BE60:
    PUSH32(esp, 5); /* 0x0077BE60: push 5 */
    ecx = 0x0082C6E8u; /* 0x0077BE62: mov ecx, 0x82c6e8 */
    RECOMP_CALL(sub_00579E90); /* 0x0077BE67: call 0x579e90 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781B00u); /* 0x0077BE6C: push 0x781b00 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077BE71: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077BE76: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BE77: ret  */

}

void sub_0077BE80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BE80u);

L_0077BE80:
    fp_push(*(double*)ADDR(0x786E68)); /* 0x0077BE80: fld qword ptr [0x786e68] */
    _st[0] = fabs(_st[0]); /* 0x0077BE86: fabs  */
    _fpu_cmp = FPU_CMP(_st[0], (double)*(float*)ADDR(0x787594)); /* 0x0077BE88: fcomp dword ptr [0x787594] */
    fp_pop();
    _flag_a = (uint32_t)_fpu_cmp; _flag_b = 0;
    _flag_k = FK_FCOM;
    eax = (eax & 0xFFFF0000u) | (((_fpu_cmp >= 0x10000) ? (uint32_t)(_fpu_cmp & 0x4700) : _fpu_cmp == 2 ? 0x4500u : _fpu_cmp < 0 ? 0x0100u : _fpu_cmp == 0 ? 0x4000u : 0x0000u) | ((((uint32_t)-_fp_top) & 7u) << 11)); /* 0x0077BE8E: fnstsw ax */
    /* test HI8(eax), 5 */ /* 0x0077BE90: test ah, 5 */
    _flag_a = (uint32_t)(HI8(eax)) << 24; _flag_b = (uint32_t)(5) << 24;
    _cf = 0;
    _flag_k = FK_NARROW(FK_TEST, 24);
    if (RECOMP_PF((_flag_a & _flag_b), 24)) goto L_0077BE9F; /* 0x0077BE93: jp 0x77be9f */

L_0077BE95:
    MEM32(0x7F0008) = 0x3F800008u; /* 0x0077BE95: mov dword ptr [0x7f0008], 0x3f800008 */

L_0077BE9F:
    PUSH32(esp, 0x00781BE0u); /* 0x0077BE9F: push 0x781be0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077BEA4: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077BEA9: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BEAA: ret  */

}

void sub_0077BEB0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BEB0u);

L_0077BEB0:
    fp_push(*(double*)ADDR(0x78C240)); /* 0x0077BEB0: fld qword ptr [0x78c240] */
    _st[0] = fabs(_st[0]); /* 0x0077BEB6: fabs  */
    _fpu_cmp = FPU_CMP(_st[0], (double)*(float*)ADDR(0x787594)); /* 0x0077BEB8: fcomp dword ptr [0x787594] */
    fp_pop();
    _flag_a = (uint32_t)_fpu_cmp; _flag_b = 0;
    _flag_k = FK_FCOM;
    eax = (eax & 0xFFFF0000u) | (((_fpu_cmp >= 0x10000) ? (uint32_t)(_fpu_cmp & 0x4700) : _fpu_cmp == 2 ? 0x4500u : _fpu_cmp < 0 ? 0x0100u : _fpu_cmp == 0 ? 0x4000u : 0x0000u) | ((((uint32_t)-_fp_top) & 7u) << 11)); /* 0x0077BEBE: fnstsw ax */
    /* test HI8(eax), 5 */ /* 0x0077BEC0: test ah, 5 */
    _flag_a = (uint32_t)(HI8(eax)) << 24; _flag_b = (uint32_t)(5) << 24;
    _cf = 0;
    _flag_k = FK_NARROW(FK_TEST, 24);
    if (RECOMP_PF((_flag_a & _flag_b), 24)) goto L_0077BECF; /* 0x0077BEC3: jp 0x77becf */

L_0077BEC5:
    MEM32(0x7F0024) = 0x42C80000u; /* 0x0077BEC5: mov dword ptr [0x7f0024], 0x42c80000 */

L_0077BECF:
    PUSH32(esp, 0x00781BF0u); /* 0x0077BECF: push 0x781bf0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077BED4: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077BED9: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BEDA: ret  */

}

void sub_0077BEE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BEE0u);

L_0077BEE0:
    fp_push(*(float*)&MEM32(0x78848C)); /* 0x0077BEE0: fld dword ptr [0x78848c] */
    eax = MEM32(0x78848C); /* 0x0077BEE6: mov eax, dword ptr [0x78848c] */
    _st[0] /= (double)*(float*)ADDR(0x788490); /* 0x0077BEEB: fdiv dword ptr [0x788490] */
    MEM32(0x7F0038) = eax; /* 0x0077BEF1: mov dword ptr [0x7f0038], eax */
    { float _v = (float)_st[0]; *(float*)ADDR(0x7F0034) = _v; } /* 0x0077BEF6: fst dword ptr [0x7f0034] */
    fp_push(*(double*)ADDR(0x78C248)); /* 0x0077BEFC: fld qword ptr [0x78c248] */
    _st[0] = fabs(_st[0]); /* 0x0077BF02: fabs  */
    _fpu_cmp = FPU_CMP(_st[0], (double)*(float*)ADDR(0x787594)); /* 0x0077BF04: fcomp dword ptr [0x787594] */
    fp_pop();
    _flag_a = (uint32_t)_fpu_cmp; _flag_b = 0;
    _flag_k = FK_FCOM;
    eax = (eax & 0xFFFF0000u) | (((_fpu_cmp >= 0x10000) ? (uint32_t)(_fpu_cmp & 0x4700) : _fpu_cmp == 2 ? 0x4500u : _fpu_cmp < 0 ? 0x0100u : _fpu_cmp == 0 ? 0x4000u : 0x0000u) | ((((uint32_t)-_fp_top) & 7u) << 11)); /* 0x0077BF0A: fnstsw ax */
    /* test HI8(eax), 5 */ /* 0x0077BF0C: test ah, 5 */
    _flag_a = (uint32_t)(HI8(eax)) << 24; _flag_b = (uint32_t)(5) << 24;
    _cf = 0;
    _flag_k = FK_NARROW(FK_TEST, 24);
    if (RECOMP_PF((_flag_a & _flag_b), 24)) goto L_0077BF1B; /* 0x0077BF0F: jp 0x77bf1b */

L_0077BF11:
    MEM32(0x7F0040) = 0x42FE0000u; /* 0x0077BF11: mov dword ptr [0x7f0040], 0x42fe0000 */

L_0077BF1B:
    PUSH32(esp, 0x00781C00u); /* 0x0077BF1B: push 0x781c00 */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x7F0048) = _v; } /* 0x0077BF20: fstp dword ptr [0x7f0048] */
    RECOMP_CALL(sub_0075C51D); /* 0x0077BF26: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077BF2B: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BF2C: ret  */

}

void sub_0077BF30(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BF30u);

L_0077BF30:
    eax = MEM32(0x788494); /* 0x0077BF30: mov eax, dword ptr [0x788494] */
    edx = MEM32(0x78849C); /* 0x0077BF35: mov edx, dword ptr [0x78849c] */
    ecx = MEM32(0x788498); /* 0x0077BF3B: mov ecx, dword ptr [0x788498] */
    MEM32(0x82BCD0) = eax; /* 0x0077BF41: mov dword ptr [0x82bcd0], eax */
    eax = MEM32(0x7884A0); /* 0x0077BF46: mov eax, dword ptr [0x7884a0] */
    MEM32(0x82BCDC) = eax; /* 0x0077BF4B: mov dword ptr [0x82bcdc], eax */
    fp_push(*(float*)&MEM32(0x82BCDC)); /* 0x0077BF50: fld dword ptr [0x82bcdc] */
    MEM32(0x82BCD8) = edx; /* 0x0077BF56: mov dword ptr [0x82bcd8], edx */
    _st[0] -= (double)*(float*)ADDR(0x82BCD8); /* 0x0077BF5C: fsub dword ptr [0x82bcd8] */
    MEM32(0x82BCD4) = ecx; /* 0x0077BF62: mov dword ptr [0x82bcd4], ecx */
    _st[0] = fabs(_st[0]); /* 0x0077BF68: fabs  */
    _fpu_cmp = FPU_CMP(_st[0], (double)*(float*)ADDR(0x787594)); /* 0x0077BF6A: fcomp dword ptr [0x787594] */
    fp_pop();
    _flag_a = (uint32_t)_fpu_cmp; _flag_b = 0;
    _flag_k = FK_FCOM;
    eax = (eax & 0xFFFF0000u) | (((_fpu_cmp >= 0x10000) ? (uint32_t)(_fpu_cmp & 0x4700) : _fpu_cmp == 2 ? 0x4500u : _fpu_cmp < 0 ? 0x0100u : _fpu_cmp == 0 ? 0x4000u : 0x0000u) | ((((uint32_t)-_fp_top) & 7u) << 11)); /* 0x0077BF70: fnstsw ax */
    /* test HI8(eax), 5 */ /* 0x0077BF72: test ah, 5 */
    _flag_a = (uint32_t)(HI8(eax)) << 24; _flag_b = (uint32_t)(5) << 24;
    _cf = 0;
    _flag_k = FK_NARROW(FK_TEST, 24);
    if (RECOMP_PF((_flag_a & _flag_b), 24)) goto L_0077BF89; /* 0x0077BF75: jp 0x77bf89 */

L_0077BF77:
    fp_push(*(float*)&MEM32(0x82BCDC)); /* 0x0077BF77: fld dword ptr [0x82bcdc] */
    _st[0] += (double)*(float*)ADDR(0x787594); /* 0x0077BF7D: fadd dword ptr [0x787594] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x82BCDC) = _v; } /* 0x0077BF83: fstp dword ptr [0x82bcdc] */

L_0077BF89:
    ecx = MEM32(0x788494); /* 0x0077BF89: mov ecx, dword ptr [0x788494] */
    PUSH32(esp, 0x00781C10u); /* 0x0077BF8F: push 0x781c10 */
    MEM32(0x82BCE4) = ecx; /* 0x0077BF94: mov dword ptr [0x82bce4], ecx */
    RECOMP_CALL(sub_0075C51D); /* 0x0077BF9A: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077BF9F: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BFA0: ret  */

}

void sub_0077BFB0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BFB0u);

L_0077BFB0:
    PUSH32(esp, 0x00781C20u); /* 0x0077BFB0: push 0x781c20 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077BFB5: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077BFBA: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BFBB: ret  */

}

void sub_0077BFC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BFC0u);

L_0077BFC0:
    PUSH32(esp, 0x00781C30u); /* 0x0077BFC0: push 0x781c30 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077BFC5: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077BFCA: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BFCB: ret  */

}

void sub_0077BFD0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BFD0u);

L_0077BFD0:
    PUSH32(esp, 0x00781C40u); /* 0x0077BFD0: push 0x781c40 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077BFD5: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077BFDA: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BFDB: ret  */

}

void sub_0077BFE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BFE0u);

L_0077BFE0:
    PUSH32(esp, 0x00781C50u); /* 0x0077BFE0: push 0x781c50 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077BFE5: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077BFEA: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BFEB: ret  */

}

void sub_0077BFF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077BFF0u);

L_0077BFF0:
    PUSH32(esp, 0x00781C60u); /* 0x0077BFF0: push 0x781c60 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077BFF5: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077BFFA: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077BFFB: ret  */

}

void sub_0077C000(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C000u);

L_0077C000:
    ecx = 0x0082C694u; /* 0x0077C000: mov ecx, 0x82c694 */
    RECOMP_CALL(sub_00468F50); /* 0x0077C005: call 0x468f50 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781B10u); /* 0x0077C00A: push 0x781b10 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077C00F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077C014: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077C015: ret  */

}

void sub_0077C020(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C020u);

L_0077C020:
    PUSH32(esp, esi); /* 0x0077C020: push esi */
    PUSH32(esp, edi); /* 0x0077C021: push edi */
    esi = 0x0082BF48u; /* 0x0077C022: mov esi, 0x82bf48 */
    edi = 0xDu; /* 0x0077C027: mov edi, 0xd */
    esp = esp; /* 0x0077C02C: lea esp, [esp] */

L_0077C030:
    ecx = esi; /* 0x0077C030: mov ecx, esi */
    RECOMP_CALL(sub_00458FB0); /* 0x0077C032: call 0x458fb0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esi); _flag_b = (uint32_t)(0x70u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esi = esi + 0x70u; /* 0x0077C037: add esi, 0x70 */
    _flag_k = FK_ADD;
    _flag_a = (uint32_t)(edi); _flag_b = (uint32_t)(1);
    edi = edi - 1; /* 0x0077C03A: dec edi */
    _flag_k = FK_DEC;
    RECOMP_BACKEDGE();
    if (/* dec result */ CMP_NE(_flag_a, _flag_b)) goto L_0077C030; /* 0x0077C03B: jne 0x77c030 */

L_0077C03D:
    edi = POP32_VAL(esp); /* 0x0077C03D: pop edi */
    esi = POP32_VAL(esp); /* 0x0077C03E: pop esi */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077C03F: ret  */

}

void sub_0077C040(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C040u);

L_0077C040:
    PUSH32(esp, 0x0078C250u); /* 0x0077C040: push 0x78c250 */
    ecx = 0x0082C710u; /* 0x0077C045: mov ecx, 0x82c710 */
    RECOMP_CALL(sub_0060B780); /* 0x0077C04A: call 0x60b780 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781B20u); /* 0x0077C04F: push 0x781b20 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077C054: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077C059: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077C05A: ret  */

}

void sub_0077C060(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C060u);

L_0077C060:
    PUSH32(esp, 0x0078C25Cu); /* 0x0077C060: push 0x78c25c */
    ecx = 0x0082BEA0u; /* 0x0077C065: mov ecx, 0x82bea0 */
    RECOMP_CALL(sub_0060B780); /* 0x0077C06A: call 0x60b780 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781B30u); /* 0x0077C06F: push 0x781b30 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077C074: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077C079: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077C07A: ret  */

}

void sub_0077C080(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C080u);

    goto L_0077C080;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C080:
    ecx = 0x0082C570u; /* 0x0077C080: mov ecx, 0x82c570 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C085: jmp 0x734d70 */

}

void sub_0077C090(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C090u);

    goto L_0077C090;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C090:
    ecx = 0x0082C578u; /* 0x0077C090: mov ecx, 0x82c578 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C095: jmp 0x734d70 */

}

void sub_0077C0A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C0A0u);

    goto L_0077C0A0;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C0A0:
    ecx = 0x0082C528u; /* 0x0077C0A0: mov ecx, 0x82c528 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C0A5: jmp 0x734d70 */

}

void sub_0077C0B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C0B0u);

    goto L_0077C0B0;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C0B0:
    ecx = 0x0082C518u; /* 0x0077C0B0: mov ecx, 0x82c518 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C0B5: jmp 0x734d70 */

}

void sub_0077C0C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C0C0u);

    goto L_0077C0C0;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C0C0:
    ecx = 0x0082C6ACu; /* 0x0077C0C0: mov ecx, 0x82c6ac */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C0C5: jmp 0x734d70 */

}

void sub_0077C0D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C0D0u);

    goto L_0077C0D0;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C0D0:
    ecx = 0x0082C560u; /* 0x0077C0D0: mov ecx, 0x82c560 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C0D5: jmp 0x734d70 */

}

void sub_0077C0E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C0E0u);

    goto L_0077C0E0;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C0E0:
    ecx = 0x0082C588u; /* 0x0077C0E0: mov ecx, 0x82c588 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C0E5: jmp 0x734d70 */

}

void sub_0077C0F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C0F0u);

    goto L_0077C0F0;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C0F0:
    ecx = 0x0082C650u; /* 0x0077C0F0: mov ecx, 0x82c650 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C0F5: jmp 0x734d70 */

}

void sub_0077C100(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C100u);

    goto L_0077C100;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C100:
    ecx = 0x0082C5B8u; /* 0x0077C100: mov ecx, 0x82c5b8 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C105: jmp 0x734d70 */

}

void sub_0077C110(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C110u);

    goto L_0077C110;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C110:
    ecx = 0x0082C658u; /* 0x0077C110: mov ecx, 0x82c658 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C115: jmp 0x734d70 */

}

void sub_0077C120(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C120u);

    goto L_0077C120;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C120:
    ecx = 0x0082C604u; /* 0x0077C120: mov ecx, 0x82c604 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C125: jmp 0x734d70 */

}

void sub_0077C130(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C130u);

    goto L_0077C130;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C130:
    ecx = 0x0082C580u; /* 0x0077C130: mov ecx, 0x82c580 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C135: jmp 0x734d70 */

}

void sub_0077C140(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C140u);

    goto L_0077C140;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C140:
    ecx = 0x0082C5C0u; /* 0x0077C140: mov ecx, 0x82c5c0 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C145: jmp 0x734d70 */

}

void sub_0077C150(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C150u);

    goto L_0077C150;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C150:
    ecx = 0x0082C640u; /* 0x0077C150: mov ecx, 0x82c640 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C155: jmp 0x734d70 */

}

void sub_0077C160(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C160u);

L_0077C160:
    eax = MEM32(0x78859C); /* 0x0077C160: mov eax, dword ptr [0x78859c] */
    edx = MEM32(0x788594); /* 0x0077C165: mov edx, dword ptr [0x788594] */
    ecx = eax; /* 0x0077C16B: mov ecx, eax */
    MEM32(0x7F38A8) = eax; /* 0x0077C16D: mov dword ptr [0x7f38a8], eax */
    MEM32(0x7F38AC) = ecx; /* 0x0077C172: mov dword ptr [0x7f38ac], ecx */
    ecx = MEM32(0x788598); /* 0x0077C178: mov ecx, dword ptr [0x788598] */
    eax = edx; /* 0x0077C17E: mov eax, edx */
    MEM32(0x7F38E0) = edx; /* 0x0077C180: mov dword ptr [0x7f38e0], edx */
    edx = ecx; /* 0x0077C186: mov edx, ecx */
    MEM32(0x7F38E4) = eax; /* 0x0077C188: mov dword ptr [0x7f38e4], eax */
    MEM32(0x7F38E8) = ecx; /* 0x0077C18D: mov dword ptr [0x7f38e8], ecx */
    SET_LO8(ecx, 0x80u); /* 0x0077C193: mov cl, 0x80 */
    SET_LO8(eax, 0x25u); /* 0x0077C195: mov al, 0x25 */
    MEM8(0x7F3908) = (uint8_t)(LO8(eax)); /* 0x0077C197: mov byte ptr [0x7f3908], al */
    MEM8(0x7F3909) = (uint8_t)(LO8(eax)); /* 0x0077C19C: mov byte ptr [0x7f3909], al */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0077C1A1: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    MEM8(0x7F390E) = (uint8_t)(LO8(ecx)); /* 0x0077C1A3: mov byte ptr [0x7f390e], cl */
    MEM8(0x7F390F) = (uint8_t)(LO8(ecx)); /* 0x0077C1A9: mov byte ptr [0x7f390f], cl */
    MEM8(0x7F3910) = (uint8_t)(LO8(ecx)); /* 0x0077C1AF: mov byte ptr [0x7f3910], cl */
    MEM8(0x7F3911) = (uint8_t)(LO8(ecx)); /* 0x0077C1B5: mov byte ptr [0x7f3911], cl */
    MEM8(0x7F3912) = (uint8_t)(LO8(ecx)); /* 0x0077C1BB: mov byte ptr [0x7f3912], cl */
    MEM8(0x7F3913) = (uint8_t)(LO8(ecx)); /* 0x0077C1C1: mov byte ptr [0x7f3913], cl */
    SET_LO8(ecx, 0x32u); /* 0x0077C1C7: mov cl, 0x32 */
    MEM32(0x7F38B0) = 0; /* 0x0077C1C9: mov dword ptr [0x7f38b0], 0 */
    MEM32(0x7F38B4) = 0x41200000u; /* 0x0077C1D3: mov dword ptr [0x7f38b4], 0x41200000 */
    MEM32(0x7F38B8) = 0x40000000u; /* 0x0077C1DD: mov dword ptr [0x7f38b8], 0x40000000 */
    MEM32(0x7F38BC) = 0; /* 0x0077C1E7: mov dword ptr [0x7f38bc], 0 */
    MEM32(0x7F38C0) = 0x41200000u; /* 0x0077C1F1: mov dword ptr [0x7f38c0], 0x41200000 */
    MEM32(0x7F38C4) = 0x40000000u; /* 0x0077C1FB: mov dword ptr [0x7f38c4], 0x40000000 */
    MEM32(0x7F38C8) = 0; /* 0x0077C205: mov dword ptr [0x7f38c8], 0 */
    MEM32(0x7F38CC) = 0; /* 0x0077C20F: mov dword ptr [0x7f38cc], 0 */
    MEM32(0x7F38D0) = 0; /* 0x0077C219: mov dword ptr [0x7f38d0], 0 */
    MEM32(0x7F38D4) = 0; /* 0x0077C223: mov dword ptr [0x7f38d4], 0 */
    MEM32(0x7F38D8) = 0; /* 0x0077C22D: mov dword ptr [0x7f38d8], 0 */
    MEM32(0x7F38DC) = 0; /* 0x0077C237: mov dword ptr [0x7f38dc], 0 */
    MEM32(0x7F38EC) = edx; /* 0x0077C241: mov dword ptr [0x7f38ec], edx */
    MEM32(0x7F38F0) = 0; /* 0x0077C247: mov dword ptr [0x7f38f0], 0 */
    MEM32(0x7F38F4) = 0; /* 0x0077C251: mov dword ptr [0x7f38f4], 0 */
    MEM32(0x7F38F8) = 0; /* 0x0077C25B: mov dword ptr [0x7f38f8], 0 */
    MEM32(0x7F38FC) = 0; /* 0x0077C265: mov dword ptr [0x7f38fc], 0 */
    MEM32(0x7F3900) = 0; /* 0x0077C26F: mov dword ptr [0x7f3900], 0 */
    MEM32(0x7F3904) = 0; /* 0x0077C279: mov dword ptr [0x7f3904], 0 */
    MEM8(0x7F390A) = (uint8_t)(LO8(eax)); /* 0x0077C283: mov byte ptr [0x7f390a], al */
    MEM8(0x7F390B) = (uint8_t)(LO8(eax)); /* 0x0077C288: mov byte ptr [0x7f390b], al */
    MEM8(0x7F390C) = (uint8_t)(LO8(eax)); /* 0x0077C28D: mov byte ptr [0x7f390c], al */
    MEM8(0x7F390D) = (uint8_t)(LO8(eax)); /* 0x0077C292: mov byte ptr [0x7f390d], al */
    MEM8(0x7F3914) = (uint8_t)(LO8(eax)); /* 0x0077C297: mov byte ptr [0x7f3914], al */
    MEM8(0x7F3915) = (uint8_t)(LO8(ecx)); /* 0x0077C29C: mov byte ptr [0x7f3915], cl */
    MEM8(0x7F3916) = (uint8_t)(LO8(eax)); /* 0x0077C2A2: mov byte ptr [0x7f3916], al */
    MEM8(0x7F3917) = (uint8_t)(LO8(ecx)); /* 0x0077C2A7: mov byte ptr [0x7f3917], cl */
    MEM8(0x7F3918) = (uint8_t)(LO8(eax)); /* 0x0077C2AD: mov byte ptr [0x7f3918], al */
    MEM8(0x7F3919) = (uint8_t)(LO8(eax)); /* 0x0077C2B2: mov byte ptr [0x7f3919], al */
    MEM32(0x7F391C) = eax; /* 0x0077C2B7: mov dword ptr [0x7f391c], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077C2BC: ret  */

}

void sub_0077C2C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C2C0u);

L_0077C2C0:
    eax = MEM32(0x788604); /* 0x0077C2C0: mov eax, dword ptr [0x788604] */
    MEM32(0x7F005C) = eax; /* 0x0077C2C5: mov dword ptr [0x7f005c], eax */
    fp_push(*(float*)&MEM32(0x7F005C)); /* 0x0077C2CA: fld dword ptr [0x7f005c] */
    _st[0] -= (double)*(float*)ADDR(0x784250); /* 0x0077C2D0: fsub dword ptr [0x784250] */
    _st[0] = fabs(_st[0]); /* 0x0077C2D6: fabs  */
    _fpu_cmp = FPU_CMP(_st[0], (double)*(float*)ADDR(0x787594)); /* 0x0077C2D8: fcomp dword ptr [0x787594] */
    fp_pop();
    _flag_a = (uint32_t)_fpu_cmp; _flag_b = 0;
    _flag_k = FK_FCOM;
    eax = (eax & 0xFFFF0000u) | (((_fpu_cmp >= 0x10000) ? (uint32_t)(_fpu_cmp & 0x4700) : _fpu_cmp == 2 ? 0x4500u : _fpu_cmp < 0 ? 0x0100u : _fpu_cmp == 0 ? 0x4000u : 0x0000u) | ((((uint32_t)-_fp_top) & 7u) << 11)); /* 0x0077C2DE: fnstsw ax */
    /* test HI8(eax), 5 */ /* 0x0077C2E0: test ah, 5 */
    _flag_a = (uint32_t)(HI8(eax)) << 24; _flag_b = (uint32_t)(5) << 24;
    _cf = 0;
    _flag_k = FK_NARROW(FK_TEST, 24);
    if (RECOMP_PF((_flag_a & _flag_b), 24)) goto L_0077C2F7; /* 0x0077C2E3: jp 0x77c2f7 */

L_0077C2E5:
    fp_push(*(float*)&MEM32(0x7F005C)); /* 0x0077C2E5: fld dword ptr [0x7f005c] */
    _st[0] += (double)*(float*)ADDR(0x787594); /* 0x0077C2EB: fadd dword ptr [0x787594] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x7F005C) = _v; } /* 0x0077C2F1: fstp dword ptr [0x7f005c] */

L_0077C2F7:
    PUSH32(esp, 0x00781B40u); /* 0x0077C2F7: push 0x781b40 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077C2FC: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077C301: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077C302: ret  */

}

void sub_0077C310(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C310u);

L_0077C310:
    fp_push(*(double*)ADDR(0x78C268)); /* 0x0077C310: fld qword ptr [0x78c268] */
    _st[0] = fabs(_st[0]); /* 0x0077C316: fabs  */
    _fpu_cmp = FPU_CMP(_st[0], (double)*(float*)ADDR(0x787594)); /* 0x0077C318: fcomp dword ptr [0x787594] */
    fp_pop();
    _flag_a = (uint32_t)_fpu_cmp; _flag_b = 0;
    _flag_k = FK_FCOM;
    eax = (eax & 0xFFFF0000u) | (((_fpu_cmp >= 0x10000) ? (uint32_t)(_fpu_cmp & 0x4700) : _fpu_cmp == 2 ? 0x4500u : _fpu_cmp < 0 ? 0x0100u : _fpu_cmp == 0 ? 0x4000u : 0x0000u) | ((((uint32_t)-_fp_top) & 7u) << 11)); /* 0x0077C31E: fnstsw ax */
    /* test HI8(eax), 5 */ /* 0x0077C320: test ah, 5 */
    _flag_a = (uint32_t)(HI8(eax)) << 24; _flag_b = (uint32_t)(5) << 24;
    _cf = 0;
    _flag_k = FK_NARROW(FK_TEST, 24);
    if (RECOMP_PF((_flag_a & _flag_b), 24)) goto L_0077C32F; /* 0x0077C323: jp 0x77c32f */

L_0077C325:
    MEM32(0x7F0968) = 0x45DAC000u; /* 0x0077C325: mov dword ptr [0x7f0968], 0x45dac000 */

L_0077C32F:
    PUSH32(esp, 0x00781B50u); /* 0x0077C32F: push 0x781b50 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077C334: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077C339: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077C33A: ret  */

}

void sub_0077C340(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C340u);

L_0077C340:
    fp_push(*(double*)ADDR(0x78C270)); /* 0x0077C340: fld qword ptr [0x78c270] */
    _st[0] = fabs(_st[0]); /* 0x0077C346: fabs  */
    _fpu_cmp = FPU_CMP(_st[0], (double)*(float*)ADDR(0x787594)); /* 0x0077C348: fcomp dword ptr [0x787594] */
    fp_pop();
    _flag_a = (uint32_t)_fpu_cmp; _flag_b = 0;
    _flag_k = FK_FCOM;
    eax = (eax & 0xFFFF0000u) | (((_fpu_cmp >= 0x10000) ? (uint32_t)(_fpu_cmp & 0x4700) : _fpu_cmp == 2 ? 0x4500u : _fpu_cmp < 0 ? 0x0100u : _fpu_cmp == 0 ? 0x4000u : 0x0000u) | ((((uint32_t)-_fp_top) & 7u) << 11)); /* 0x0077C34E: fnstsw ax */
    /* test HI8(eax), 5 */ /* 0x0077C350: test ah, 5 */
    _flag_a = (uint32_t)(HI8(eax)) << 24; _flag_b = (uint32_t)(5) << 24;
    _cf = 0;
    _flag_k = FK_NARROW(FK_TEST, 24);
    if (RECOMP_PF((_flag_a & _flag_b), 24)) goto L_0077C35F; /* 0x0077C353: jp 0x77c35f */

L_0077C355:
    MEM32(0x7F0984) = 0x42700000u; /* 0x0077C355: mov dword ptr [0x7f0984], 0x42700000 */

L_0077C35F:
    PUSH32(esp, 0x00781B60u); /* 0x0077C35F: push 0x781b60 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077C364: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077C369: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077C36A: ret  */

}

void sub_0077C370(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C370u);

L_0077C370:
    fp_push(*(double*)ADDR(0x78C270)); /* 0x0077C370: fld qword ptr [0x78c270] */
    _st[0] = fabs(_st[0]); /* 0x0077C376: fabs  */
    _fpu_cmp = FPU_CMP(_st[0], (double)*(float*)ADDR(0x787594)); /* 0x0077C378: fcomp dword ptr [0x787594] */
    fp_pop();
    _flag_a = (uint32_t)_fpu_cmp; _flag_b = 0;
    _flag_k = FK_FCOM;
    eax = (eax & 0xFFFF0000u) | (((_fpu_cmp >= 0x10000) ? (uint32_t)(_fpu_cmp & 0x4700) : _fpu_cmp == 2 ? 0x4500u : _fpu_cmp < 0 ? 0x0100u : _fpu_cmp == 0 ? 0x4000u : 0x0000u) | ((((uint32_t)-_fp_top) & 7u) << 11)); /* 0x0077C37E: fnstsw ax */
    /* test HI8(eax), 5 */ /* 0x0077C380: test ah, 5 */
    _flag_a = (uint32_t)(HI8(eax)) << 24; _flag_b = (uint32_t)(5) << 24;
    _cf = 0;
    _flag_k = FK_NARROW(FK_TEST, 24);
    if (RECOMP_PF((_flag_a & _flag_b), 24)) goto L_0077C38F; /* 0x0077C383: jp 0x77c38f */

L_0077C385:
    MEM32(0x7F09A0) = 0x42700000u; /* 0x0077C385: mov dword ptr [0x7f09a0], 0x42700000 */

L_0077C38F:
    PUSH32(esp, 0x00781B70u); /* 0x0077C38F: push 0x781b70 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077C394: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077C399: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077C39A: ret  */

}

void sub_0077C3A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C3A0u);

L_0077C3A0:
    PUSH32(esp, 5); /* 0x0077C3A0: push 5 */
    PUSH32(esp, 0x007F09B0u); /* 0x0077C3A2: push 0x7f09b0 */
    ecx = 0x0082C69Cu; /* 0x0077C3A7: mov ecx, 0x82c69c */
    RECOMP_CALL(sub_005766E0); /* 0x0077C3AC: call 0x5766e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077C3B1: ret  */

}

void sub_0077C3C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C3C0u);

L_0077C3C0:
    fp_push(*(double*)ADDR(0x78C278)); /* 0x0077C3C0: fld qword ptr [0x78c278] */
    eax = MEM32(0x788818); /* 0x0077C3C6: mov eax, dword ptr [0x788818] */
    ecx = MEM32(0x78881C); /* 0x0077C3CB: mov ecx, dword ptr [0x78881c] */
    _st[0] = fabs(_st[0]); /* 0x0077C3D1: fabs  */
    _fpu_cmp = FPU_CMP(_st[0], (double)*(float*)ADDR(0x787594)); /* 0x0077C3D3: fcomp dword ptr [0x787594] */
    fp_pop();
    _flag_a = (uint32_t)_fpu_cmp; _flag_b = 0;
    _flag_k = FK_FCOM;
    MEM32(0x7F09D8) = eax; /* 0x0077C3D9: mov dword ptr [0x7f09d8], eax */
    MEM32(0x7F09DC) = ecx; /* 0x0077C3DE: mov dword ptr [0x7f09dc], ecx */
    eax = (eax & 0xFFFF0000u) | (((_fpu_cmp >= 0x10000) ? (uint32_t)(_fpu_cmp & 0x4700) : _fpu_cmp == 2 ? 0x4500u : _fpu_cmp < 0 ? 0x0100u : _fpu_cmp == 0 ? 0x4000u : 0x0000u) | ((((uint32_t)-_fp_top) & 7u) << 11)); /* 0x0077C3E4: fnstsw ax */
    /* test HI8(eax), 5 */ /* 0x0077C3E6: test ah, 5 */
    _flag_a = (uint32_t)(HI8(eax)) << 24; _flag_b = (uint32_t)(5) << 24;
    _cf = 0;
    _flag_k = FK_NARROW(FK_TEST, 24);
    if (RECOMP_PF((_flag_a & _flag_b), 24)) goto L_0077C3F5; /* 0x0077C3E9: jp 0x77c3f5 */

L_0077C3EB:
    MEM32(0x7F09E4) = 0x42C80000u; /* 0x0077C3EB: mov dword ptr [0x7f09e4], 0x42c80000 */

L_0077C3F5:
    edx = MEM32(0x788818); /* 0x0077C3F5: mov edx, dword ptr [0x788818] */
    PUSH32(esp, 0x00781B80u); /* 0x0077C3FB: push 0x781b80 */
    MEM32(0x7F09EC) = edx; /* 0x0077C400: mov dword ptr [0x7f09ec], edx */
    RECOMP_CALL(sub_0075C51D); /* 0x0077C406: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077C40B: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077C40C: ret  */

}

void sub_0077C410(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C410u);

L_0077C410:
    eax = MEM32(0x78885C); /* 0x0077C410: mov eax, dword ptr [0x78885c] */
    MEM32(0x7F0A00) = eax; /* 0x0077C415: mov dword ptr [0x7f0a00], eax */
    fp_push(*(float*)&MEM32(0x7F0A00)); /* 0x0077C41A: fld dword ptr [0x7f0a00] */
    _st[0] = fabs(_st[0]); /* 0x0077C420: fabs  */
    _fpu_cmp = FPU_CMP(_st[0], (double)*(float*)ADDR(0x787594)); /* 0x0077C422: fcomp dword ptr [0x787594] */
    fp_pop();
    _flag_a = (uint32_t)_fpu_cmp; _flag_b = 0;
    _flag_k = FK_FCOM;
    eax = (eax & 0xFFFF0000u) | (((_fpu_cmp >= 0x10000) ? (uint32_t)(_fpu_cmp & 0x4700) : _fpu_cmp == 2 ? 0x4500u : _fpu_cmp < 0 ? 0x0100u : _fpu_cmp == 0 ? 0x4000u : 0x0000u) | ((((uint32_t)-_fp_top) & 7u) << 11)); /* 0x0077C428: fnstsw ax */
    /* test HI8(eax), 5 */ /* 0x0077C42A: test ah, 5 */
    _flag_a = (uint32_t)(HI8(eax)) << 24; _flag_b = (uint32_t)(5) << 24;
    _cf = 0;
    _flag_k = FK_NARROW(FK_TEST, 24);
    if (RECOMP_PF((_flag_a & _flag_b), 24)) goto L_0077C441; /* 0x0077C42D: jp 0x77c441 */

L_0077C42F:
    fp_push(*(float*)&MEM32(0x7F0A00)); /* 0x0077C42F: fld dword ptr [0x7f0a00] */
    _st[0] += (double)*(float*)ADDR(0x787594); /* 0x0077C435: fadd dword ptr [0x787594] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x7F0A00) = _v; } /* 0x0077C43B: fstp dword ptr [0x7f0a00] */

L_0077C441:
    PUSH32(esp, 0x00781B90u); /* 0x0077C441: push 0x781b90 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077C446: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077C44B: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077C44C: ret  */

}

void sub_0077C450(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C450u);

L_0077C450:
    PUSH32(esp, 0x0078C298u); /* 0x0077C450: push 0x78c298 */
    PUSH32(esp, 0x007F0A1Cu); /* 0x0077C455: push 0x7f0a1c */
    RECOMP_CALL(sub_0043DC40); /* 0x0077C45A: call 0x43dc40 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x0078C28Cu); /* 0x0077C45F: push 0x78c28c */
    PUSH32(esp, 0x007F0A68u); /* 0x0077C464: push 0x7f0a68 */
    MEM32(0x7F0A5C) = 0x42280000u; /* 0x0077C469: mov dword ptr [0x7f0a5c], 0x42280000 */
    MEM32(0x7F0A60) = 0x20u; /* 0x0077C473: mov dword ptr [0x7f0a60], 0x20 */
    MEM32(0x7F0A64) = 0x41B80000u; /* 0x0077C47D: mov dword ptr [0x7f0a64], 0x41b80000 */
    RECOMP_CALL(sub_0043DC40); /* 0x0077C487: call 0x43dc40 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x0078C280u); /* 0x0077C48C: push 0x78c280 */
    PUSH32(esp, 0x007F0AB4u); /* 0x0077C491: push 0x7f0ab4 */
    MEM32(0x7F0AA8) = 0x42280000u; /* 0x0077C496: mov dword ptr [0x7f0aa8], 0x42280000 */
    MEM32(0x7F0AAC) = 0x20u; /* 0x0077C4A0: mov dword ptr [0x7f0aac], 0x20 */
    MEM32(0x7F0AB0) = 0x41B80000u; /* 0x0077C4AA: mov dword ptr [0x7f0ab0], 0x41b80000 */
    RECOMP_CALL(sub_0043DC40); /* 0x0077C4B4: call 0x43dc40 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x0078C280u); /* 0x0077C4B9: push 0x78c280 */
    PUSH32(esp, 0x007F0B00u); /* 0x0077C4BE: push 0x7f0b00 */
    MEM32(0x7F0AF4) = 0x42280000u; /* 0x0077C4C3: mov dword ptr [0x7f0af4], 0x42280000 */
    MEM32(0x7F0AF8) = 0x20u; /* 0x0077C4CD: mov dword ptr [0x7f0af8], 0x20 */
    MEM32(0x7F0AFC) = 0x41B80000u; /* 0x0077C4D7: mov dword ptr [0x7f0afc], 0x41b80000 */
    RECOMP_CALL(sub_0043DC40); /* 0x0077C4E1: call 0x43dc40 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0077C4E6: add esp, 0x20 */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077C4E9: ret  */

}

void sub_0077C4F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C4F0u);

L_0077C4F0:
    ecx = MEM32(0x788864); /* 0x0077C4F0: mov ecx, dword ptr [0x788864] */
    eax = MEM32(0x788868); /* 0x0077C4F6: mov eax, dword ptr [0x788868] */
    MEM32(0x7F0B4C) = ecx; /* 0x0077C4FB: mov dword ptr [0x7f0b4c], ecx */
    fp_push(*(float*)&MEM32(0x7F0B4C)); /* 0x0077C501: fld dword ptr [0x7f0b4c] */
    MEM32(0x7F0B48) = eax; /* 0x0077C507: mov dword ptr [0x7f0b48], eax */
    _st[0] -= (double)*(float*)ADDR(0x7F0B48); /* 0x0077C50C: fsub dword ptr [0x7f0b48] */
    _st[0] = fabs(_st[0]); /* 0x0077C512: fabs  */
    _fpu_cmp = FPU_CMP(_st[0], (double)*(float*)ADDR(0x787594)); /* 0x0077C514: fcomp dword ptr [0x787594] */
    fp_pop();
    _flag_a = (uint32_t)_fpu_cmp; _flag_b = 0;
    _flag_k = FK_FCOM;
    eax = (eax & 0xFFFF0000u) | (((_fpu_cmp >= 0x10000) ? (uint32_t)(_fpu_cmp & 0x4700) : _fpu_cmp == 2 ? 0x4500u : _fpu_cmp < 0 ? 0x0100u : _fpu_cmp == 0 ? 0x4000u : 0x0000u) | ((((uint32_t)-_fp_top) & 7u) << 11)); /* 0x0077C51A: fnstsw ax */
    /* test HI8(eax), 5 */ /* 0x0077C51C: test ah, 5 */
    _flag_a = (uint32_t)(HI8(eax)) << 24; _flag_b = (uint32_t)(5) << 24;
    _cf = 0;
    _flag_k = FK_NARROW(FK_TEST, 24);
    if (RECOMP_PF((_flag_a & _flag_b), 24)) goto L_0077C533; /* 0x0077C51F: jp 0x77c533 */

L_0077C521:
    fp_push(*(float*)&MEM32(0x7F0B4C)); /* 0x0077C521: fld dword ptr [0x7f0b4c] */
    _st[0] += (double)*(float*)ADDR(0x787594); /* 0x0077C527: fadd dword ptr [0x787594] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x7F0B4C) = _v; } /* 0x0077C52D: fstp dword ptr [0x7f0b4c] */

L_0077C533:
    PUSH32(esp, 0x00781BA0u); /* 0x0077C533: push 0x781ba0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077C538: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077C53D: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077C53E: ret  */

}

void sub_0077C540(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C540u);

L_0077C540:
    fp_push(*(double*)ADDR(0x78C2A8)); /* 0x0077C540: fld qword ptr [0x78c2a8] */
    _st[0] = fabs(_st[0]); /* 0x0077C546: fabs  */
    _fpu_cmp = FPU_CMP(_st[0], (double)*(float*)ADDR(0x787594)); /* 0x0077C548: fcomp dword ptr [0x787594] */
    fp_pop();
    _flag_a = (uint32_t)_fpu_cmp; _flag_b = 0;
    _flag_k = FK_FCOM;
    eax = (eax & 0xFFFF0000u) | (((_fpu_cmp >= 0x10000) ? (uint32_t)(_fpu_cmp & 0x4700) : _fpu_cmp == 2 ? 0x4500u : _fpu_cmp < 0 ? 0x0100u : _fpu_cmp == 0 ? 0x4000u : 0x0000u) | ((((uint32_t)-_fp_top) & 7u) << 11)); /* 0x0077C54E: fnstsw ax */
    /* test HI8(eax), 5 */ /* 0x0077C550: test ah, 5 */
    _flag_a = (uint32_t)(HI8(eax)) << 24; _flag_b = (uint32_t)(5) << 24;
    _cf = 0;
    _flag_k = FK_NARROW(FK_TEST, 24);
    if (RECOMP_PF((_flag_a & _flag_b), 24)) goto L_0077C55F; /* 0x0077C553: jp 0x77c55f */

L_0077C555:
    MEM32(0x7F0B68) = 0x3F800008u; /* 0x0077C555: mov dword ptr [0x7f0b68], 0x3f800008 */

L_0077C55F:
    PUSH32(esp, 0x00781BB0u); /* 0x0077C55F: push 0x781bb0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077C564: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077C569: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077C56A: ret  */

}

void sub_0077C570(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C570u);

L_0077C570:
    PUSH32(esp, 0x0078C2B0u); /* 0x0077C570: push 0x78c2b0 */
    ecx = 0x0082C5E8u; /* 0x0077C575: mov ecx, 0x82c5e8 */
    RECOMP_CALL(sub_0060B780); /* 0x0077C57A: call 0x60b780 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781BC0u); /* 0x0077C57F: push 0x781bc0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077C584: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077C589: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077C58A: ret  */

}

void sub_0077C590(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C590u);

L_0077C590:
    ecx = 0x0082C6A4u; /* 0x0077C590: mov ecx, 0x82c6a4 */
    RECOMP_CALL(sub_004EC6D0); /* 0x0077C595: call 0x4ec6d0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781C80u); /* 0x0077C59A: push 0x781c80 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077C59F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077C5A4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077C5A5: ret  */

}

void sub_0077C5B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C5B0u);

L_0077C5B0:
    ecx = 0x0082BEBCu; /* 0x0077C5B0: mov ecx, 0x82bebc */
    RECOMP_CALL(sub_004EC6D0); /* 0x0077C5B5: call 0x4ec6d0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781C70u); /* 0x0077C5BA: push 0x781c70 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077C5BF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077C5C4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077C5C5: ret  */

}

void sub_0077C5D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C5D0u);

L_0077C5D0:
    ecx = 0x0082BEC4u; /* 0x0077C5D0: mov ecx, 0x82bec4 */
    RECOMP_CALL(sub_004EC6D0); /* 0x0077C5D5: call 0x4ec6d0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781C90u); /* 0x0077C5DA: push 0x781c90 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077C5DF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077C5E4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077C5E5: ret  */

}

void sub_0077C5F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C5F0u);

    goto L_0077C5F0;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C5F0:
    ecx = 0x0082C540u; /* 0x0077C5F0: mov ecx, 0x82c540 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C5F5: jmp 0x734d70 */

}

void sub_0077C600(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C600u);

    goto L_0077C600;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C600:
    ecx = 0x0082C6B4u; /* 0x0077C600: mov ecx, 0x82c6b4 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C605: jmp 0x734d70 */

}

void sub_0077C610(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C610u);

    goto L_0077C610;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C610:
    ecx = 0x0082C510u; /* 0x0077C610: mov ecx, 0x82c510 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C615: jmp 0x734d70 */

}

void sub_0077C620(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C620u);

    goto L_0077C620;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C620:
    ecx = 0x0082C548u; /* 0x0077C620: mov ecx, 0x82c548 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C625: jmp 0x734d70 */

}

void sub_0077C630(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C630u);

    goto L_0077C630;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C630:
    ecx = 0x0082C530u; /* 0x0077C630: mov ecx, 0x82c530 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C635: jmp 0x734d70 */

}

void sub_0077C640(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C640u);

    goto L_0077C640;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C640:
    ecx = 0x0082C4F8u; /* 0x0077C640: mov ecx, 0x82c4f8 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C645: jmp 0x734d70 */

}

void sub_0077C650(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C650u);

    goto L_0077C650;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C650:
    ecx = 0x0082C668u; /* 0x0077C650: mov ecx, 0x82c668 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C655: jmp 0x734d70 */

}

void sub_0077C660(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C660u);

    goto L_0077C660;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C660:
    ecx = 0x0082C5A8u; /* 0x0077C660: mov ecx, 0x82c5a8 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C665: jmp 0x734d70 */

}

void sub_0077C670(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C670u);

    goto L_0077C670;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C670:
    ecx = 0x0082C660u; /* 0x0077C670: mov ecx, 0x82c660 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C675: jmp 0x734d70 */

}

void sub_0077C680(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C680u);

    goto L_0077C680;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C680:
    ecx = 0x0082C590u; /* 0x0077C680: mov ecx, 0x82c590 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C685: jmp 0x734d70 */

}

void sub_0077C690(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C690u);

    goto L_0077C690;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C690:
    ecx = 0x0082C520u; /* 0x0077C690: mov ecx, 0x82c520 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C695: jmp 0x734d70 */

}

void sub_0077C6A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C6A0u);

    goto L_0077C6A0;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C6A0:
    ecx = 0x0082C6BCu; /* 0x0077C6A0: mov ecx, 0x82c6bc */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C6A5: jmp 0x734d70 */

}

void sub_0077C6B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C6B0u);

    goto L_0077C6B0;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C6B0:
    ecx = 0x0082C5B0u; /* 0x0077C6B0: mov ecx, 0x82c5b0 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C6B5: jmp 0x734d70 */

}

void sub_0077C6C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C6C0u);

    goto L_0077C6C0;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C6C0:
    ecx = 0x0082C5A0u; /* 0x0077C6C0: mov ecx, 0x82c5a0 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C6C5: jmp 0x734d70 */

}

void sub_0077C6D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C6D0u);

    goto L_0077C6D0;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C6D0:
    ecx = 0x0082C5C8u; /* 0x0077C6D0: mov ecx, 0x82c5c8 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C6D5: jmp 0x734d70 */

}

void sub_0077C6E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C6E0u);

    goto L_0077C6E0;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C6E0:
    ecx = 0x0082C500u; /* 0x0077C6E0: mov ecx, 0x82c500 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C6E5: jmp 0x734d70 */

}

void sub_0077C6F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C6F0u);

    goto L_0077C6F0;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C6F0:
    ecx = 0x0082C558u; /* 0x0077C6F0: mov ecx, 0x82c558 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C6F5: jmp 0x734d70 */

}

void sub_0077C700(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C700u);

    goto L_0077C700;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C700:
    ecx = 0x0082C550u; /* 0x0077C700: mov ecx, 0x82c550 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C705: jmp 0x734d70 */

}

void sub_0077C710(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C710u);

    goto L_0077C710;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C710:
    ecx = 0x0082C508u; /* 0x0077C710: mov ecx, 0x82c508 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C715: jmp 0x734d70 */

}

void sub_0077C720(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C720u);

    goto L_0077C720;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C720:
    ecx = 0x0082C72Cu; /* 0x0077C720: mov ecx, 0x82c72c */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C725: jmp 0x734d70 */

}

void sub_0077C730(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C730u);

    goto L_0077C730;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C730:
    ecx = 0x0082C5D8u; /* 0x0077C730: mov ecx, 0x82c5d8 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C735: jmp 0x734d70 */

}

void sub_0077C740(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C740u);

    goto L_0077C740;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C740:
    ecx = 0x0082C5E0u; /* 0x0077C740: mov ecx, 0x82c5e0 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C745: jmp 0x734d70 */

}

void sub_0077C750(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C750u);

    goto L_0077C750;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C750:
    ecx = 0x0082C5D0u; /* 0x0077C750: mov ecx, 0x82c5d0 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C755: jmp 0x734d70 */

}

void sub_0077C760(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C760u);

    goto L_0077C760;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C760:
    ecx = 0x0082C6E0u; /* 0x0077C760: mov ecx, 0x82c6e0 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C765: jmp 0x734d70 */

}

void sub_0077C770(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C770u);

    goto L_0077C770;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C770:
    ecx = 0x0082C598u; /* 0x0077C770: mov ecx, 0x82c598 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C775: jmp 0x734d70 */

}

void sub_0077C780(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C780u);

    goto L_0077C780;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C780:
    ecx = 0x0082C538u; /* 0x0077C780: mov ecx, 0x82c538 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C785: jmp 0x734d70 */

}

void sub_0077C790(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C790u);

    goto L_0077C790;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C790:
    ecx = 0x0082C680u; /* 0x0077C790: mov ecx, 0x82c680 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C795: jmp 0x734d70 */

}

void sub_0077C7A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C7A0u);

    goto L_0077C7A0;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C7A0:
    ecx = 0x0082C568u; /* 0x0077C7A0: mov ecx, 0x82c568 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C7A5: jmp 0x734d70 */

}

void sub_0077C7B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C7B0u);

    goto L_0077C7B0;

L_00734D70:
    eax = ecx; /* 0x00734D70: mov eax, ecx */
    MEM32(eax + 0x4) = 0xFFFFFFFDu; /* 0x00734D72: mov dword ptr [eax + 4], 0xfffffffd */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00734D79: ret  */

L_0077C7B0:
    ecx = 0x0082C648u; /* 0x0077C7B0: mov ecx, 0x82c648 */
    RECOMP_BACKEDGE();
    goto L_00734D70; /* 0x0077C7B5: jmp 0x734d70 */

}

void sub_0077C7C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C7C0u);

L_0077C7C0:
    fp_push(*(float*)&MEM32(0x784250)); /* 0x0077C7C0: fld dword ptr [0x784250] */
    _st[0] /= (double)*(float*)ADDR(0x78D764); /* 0x0077C7C6: fdiv dword ptr [0x78d764] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x830D10) = _v; } /* 0x0077C7CC: fstp dword ptr [0x830d10] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077C7D2: ret  */

}

void sub_0077C7E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C7E0u);

L_0077C7E0:
    ecx = 0x00830D08u; /* 0x0077C7E0: mov ecx, 0x830d08 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077C7E5: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781CE0u); /* 0x0077C7EA: push 0x781ce0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077C7EF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077C7F4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077C7F5: ret  */

}

void sub_0077C800(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C800u);

L_0077C800:
    ecx = 0x00835860u; /* 0x0077C800: mov ecx, 0x835860 */
    RECOMP_CALL(sub_00494610); /* 0x0077C805: call 0x494610 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781DC0u); /* 0x0077C80A: push 0x781dc0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077C80F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077C814: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077C815: ret  */

}

void sub_0077C820(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C820u);

L_0077C820:
    ecx = 0x008357E0u; /* 0x0077C820: mov ecx, 0x8357e0 */
    RECOMP_CALL(sub_00494610); /* 0x0077C825: call 0x494610 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781D60u); /* 0x0077C82A: push 0x781d60 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077C82F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077C834: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077C835: ret  */

}

void sub_0077C840(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C840u);

L_0077C840:
    eax = MEM32(0x78D778); /* 0x0077C840: mov eax, dword ptr [0x78d778] */
    edx = MEM32(0x78D770); /* 0x0077C845: mov edx, dword ptr [0x78d770] */
    ecx = eax; /* 0x0077C84B: mov ecx, eax */
    MEM32(0x7F4240) = eax; /* 0x0077C84D: mov dword ptr [0x7f4240], eax */
    MEM32(0x7F4244) = ecx; /* 0x0077C852: mov dword ptr [0x7f4244], ecx */
    ecx = MEM32(0x78D774); /* 0x0077C858: mov ecx, dword ptr [0x78d774] */
    eax = edx; /* 0x0077C85E: mov eax, edx */
    MEM32(0x7F4278) = edx; /* 0x0077C860: mov dword ptr [0x7f4278], edx */
    edx = ecx; /* 0x0077C866: mov edx, ecx */
    MEM32(0x7F427C) = eax; /* 0x0077C868: mov dword ptr [0x7f427c], eax */
    MEM32(0x7F4280) = ecx; /* 0x0077C86D: mov dword ptr [0x7f4280], ecx */
    SET_LO8(ecx, 0x80u); /* 0x0077C873: mov cl, 0x80 */
    SET_LO8(eax, 0x25u); /* 0x0077C875: mov al, 0x25 */
    MEM8(0x7F42A0) = (uint8_t)(LO8(eax)); /* 0x0077C877: mov byte ptr [0x7f42a0], al */
    MEM8(0x7F42A1) = (uint8_t)(LO8(eax)); /* 0x0077C87C: mov byte ptr [0x7f42a1], al */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0077C881: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    MEM8(0x7F42A6) = (uint8_t)(LO8(ecx)); /* 0x0077C883: mov byte ptr [0x7f42a6], cl */
    MEM8(0x7F42A7) = (uint8_t)(LO8(ecx)); /* 0x0077C889: mov byte ptr [0x7f42a7], cl */
    MEM8(0x7F42A8) = (uint8_t)(LO8(ecx)); /* 0x0077C88F: mov byte ptr [0x7f42a8], cl */
    MEM8(0x7F42A9) = (uint8_t)(LO8(ecx)); /* 0x0077C895: mov byte ptr [0x7f42a9], cl */
    MEM8(0x7F42AA) = (uint8_t)(LO8(ecx)); /* 0x0077C89B: mov byte ptr [0x7f42aa], cl */
    MEM8(0x7F42AB) = (uint8_t)(LO8(ecx)); /* 0x0077C8A1: mov byte ptr [0x7f42ab], cl */
    SET_LO8(ecx, 0x32u); /* 0x0077C8A7: mov cl, 0x32 */
    MEM32(0x7F4248) = 0; /* 0x0077C8A9: mov dword ptr [0x7f4248], 0 */
    MEM32(0x7F424C) = 0x41200000u; /* 0x0077C8B3: mov dword ptr [0x7f424c], 0x41200000 */
    MEM32(0x7F4250) = 0x40000000u; /* 0x0077C8BD: mov dword ptr [0x7f4250], 0x40000000 */
    MEM32(0x7F4254) = 0; /* 0x0077C8C7: mov dword ptr [0x7f4254], 0 */
    MEM32(0x7F4258) = 0x41200000u; /* 0x0077C8D1: mov dword ptr [0x7f4258], 0x41200000 */
    MEM32(0x7F425C) = 0x40000000u; /* 0x0077C8DB: mov dword ptr [0x7f425c], 0x40000000 */
    MEM32(0x7F4260) = 0; /* 0x0077C8E5: mov dword ptr [0x7f4260], 0 */
    MEM32(0x7F4264) = 0; /* 0x0077C8EF: mov dword ptr [0x7f4264], 0 */
    MEM32(0x7F4268) = 0; /* 0x0077C8F9: mov dword ptr [0x7f4268], 0 */
    MEM32(0x7F426C) = 0; /* 0x0077C903: mov dword ptr [0x7f426c], 0 */
    MEM32(0x7F4270) = 0; /* 0x0077C90D: mov dword ptr [0x7f4270], 0 */
    MEM32(0x7F4274) = 0; /* 0x0077C917: mov dword ptr [0x7f4274], 0 */
    MEM32(0x7F4284) = edx; /* 0x0077C921: mov dword ptr [0x7f4284], edx */
    MEM32(0x7F4288) = 0; /* 0x0077C927: mov dword ptr [0x7f4288], 0 */
    MEM32(0x7F428C) = 0; /* 0x0077C931: mov dword ptr [0x7f428c], 0 */
    MEM32(0x7F4290) = 0; /* 0x0077C93B: mov dword ptr [0x7f4290], 0 */
    MEM32(0x7F4294) = 0; /* 0x0077C945: mov dword ptr [0x7f4294], 0 */
    MEM32(0x7F4298) = 0; /* 0x0077C94F: mov dword ptr [0x7f4298], 0 */
    MEM32(0x7F429C) = 0; /* 0x0077C959: mov dword ptr [0x7f429c], 0 */
    MEM8(0x7F42A2) = (uint8_t)(LO8(eax)); /* 0x0077C963: mov byte ptr [0x7f42a2], al */
    MEM8(0x7F42A3) = (uint8_t)(LO8(eax)); /* 0x0077C968: mov byte ptr [0x7f42a3], al */
    MEM8(0x7F42A4) = (uint8_t)(LO8(eax)); /* 0x0077C96D: mov byte ptr [0x7f42a4], al */
    MEM8(0x7F42A5) = (uint8_t)(LO8(eax)); /* 0x0077C972: mov byte ptr [0x7f42a5], al */
    MEM8(0x7F42AC) = (uint8_t)(LO8(eax)); /* 0x0077C977: mov byte ptr [0x7f42ac], al */
    MEM8(0x7F42AD) = (uint8_t)(LO8(ecx)); /* 0x0077C97C: mov byte ptr [0x7f42ad], cl */
    MEM8(0x7F42AE) = (uint8_t)(LO8(eax)); /* 0x0077C982: mov byte ptr [0x7f42ae], al */
    MEM8(0x7F42AF) = (uint8_t)(LO8(ecx)); /* 0x0077C987: mov byte ptr [0x7f42af], cl */
    MEM8(0x7F42B0) = (uint8_t)(LO8(eax)); /* 0x0077C98D: mov byte ptr [0x7f42b0], al */
    MEM8(0x7F42B1) = (uint8_t)(LO8(eax)); /* 0x0077C992: mov byte ptr [0x7f42b1], al */
    MEM32(0x7F42B4) = eax; /* 0x0077C997: mov dword ptr [0x7f42b4], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077C99C: ret  */

}

void sub_0077C9A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C9A0u);

L_0077C9A0:
    ecx = 0x0082DBC0u; /* 0x0077C9A0: mov ecx, 0x82dbc0 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077C9A5: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781D70u); /* 0x0077C9AA: push 0x781d70 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077C9AF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077C9B4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077C9B5: ret  */

}

void sub_0077C9C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C9C0u);

L_0077C9C0:
    ecx = 0x00832DA4u; /* 0x0077C9C0: mov ecx, 0x832da4 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077C9C5: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781D80u); /* 0x0077C9CA: push 0x781d80 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077C9CF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077C9D4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077C9D5: ret  */

}

void sub_0077C9E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077C9E0u);

L_0077C9E0:
    ecx = 0x00830D1Cu; /* 0x0077C9E0: mov ecx, 0x830d1c */
    RECOMP_CALL(sub_00570FA0); /* 0x0077C9E5: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781DF0u); /* 0x0077C9EA: push 0x781df0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077C9EF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077C9F4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077C9F5: ret  */

}

void sub_0077CA00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CA00u);

L_0077CA00:
    ecx = 0x00835858u; /* 0x0077CA00: mov ecx, 0x835858 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077CA05: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781E00u); /* 0x0077CA0A: push 0x781e00 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077CA0F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077CA14: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CA15: ret  */

}

void sub_0077CA20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CA20u);

L_0077CA20:
    ecx = 0x00835794u; /* 0x0077CA20: mov ecx, 0x835794 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077CA25: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781E10u); /* 0x0077CA2A: push 0x781e10 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077CA2F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077CA34: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CA35: ret  */

}

void sub_0077CA40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CA40u);

L_0077CA40:
    PUSH32(esp, 0x004940A0u); /* 0x0077CA40: push 0x4940a0 */
    PUSH32(esp, 0x00494020u); /* 0x0077CA45: push 0x494020 */
    PUSH32(esp, 0x80134000u); /* 0x0077CA4A: push 0x80134000 */
    ecx = 0x00835840u; /* 0x0077CA4F: mov ecx, 0x835840 */
    RECOMP_CALL(sub_0043C110); /* 0x0077CA54: call 0x43c110 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CA59: ret  */

}

void sub_0077CA60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CA60u);

L_0077CA60:
    PUSH32(esp, 0x004941D0u); /* 0x0077CA60: push 0x4941d0 */
    PUSH32(esp, 0x0048D990u); /* 0x0077CA65: push 0x48d990 */
    PUSH32(esp, 0x00489310u); /* 0x0077CA6A: push 0x489310 */
    PUSH32(esp, 0x00494150u); /* 0x0077CA6F: push 0x494150 */
    PUSH32(esp, 0x00494100u); /* 0x0077CA74: push 0x494100 */
    PUSH32(esp, 0x80u); /* 0x0077CA79: push 0x80 */
    ecx = 0x0082DBC8u; /* 0x0077CA7E: mov ecx, 0x82dbc8 */
    RECOMP_CALL(sub_00493350); /* 0x0077CA83: call 0x493350 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781CF0u); /* 0x0077CA88: push 0x781cf0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077CA8D: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077CA92: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CA93: ret  */

}

void sub_0077CAA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CAA0u);

L_0077CAA0:
    ecx = 0x00830C78u; /* 0x0077CAA0: mov ecx, 0x830c78 */
    RECOMP_CALL(sub_00494920); /* 0x0077CAA5: call 0x494920 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781DD0u); /* 0x0077CAAA: push 0x781dd0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077CAAF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077CAB4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CAB5: ret  */

}

void sub_0077CAC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CAC0u);

L_0077CAC0:
    PUSH32(esp, 0x00781CA0u); /* 0x0077CAC0: push 0x781ca0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077CAC5: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077CACA: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CACB: ret  */

}

void sub_0077CAD0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CAD0u);

L_0077CAD0:
    ecx = 0x00830D30u; /* 0x0077CAD0: mov ecx, 0x830d30 */
    RECOMP_CALL(sub_004941F0); /* 0x0077CAD5: call 0x4941f0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781D90u); /* 0x0077CADA: push 0x781d90 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077CADF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077CAE4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CAE5: ret  */

}

void sub_0077CAF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CAF0u);

L_0077CAF0:
    ecx = 0x00830AE8u; /* 0x0077CAF0: mov ecx, 0x830ae8 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077CAF5: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781DE0u); /* 0x0077CAFA: push 0x781de0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077CAFF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077CB04: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CB05: ret  */

}

void sub_0077CB10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CB10u);

L_0077CB10:
    ecx = 0x00830D14u; /* 0x0077CB10: mov ecx, 0x830d14 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077CB15: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781DA0u); /* 0x0077CB1A: push 0x781da0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077CB1F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077CB24: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CB25: ret  */

}

void sub_0077CB30(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CB30u);

L_0077CB30:
    ecx = 0x008358C0u; /* 0x0077CB30: mov ecx, 0x8358c0 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077CB35: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781D00u); /* 0x0077CB3A: push 0x781d00 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077CB3F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077CB44: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CB45: ret  */

}

void sub_0077CB50(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CB50u);

L_0077CB50:
    PUSH32(esp, 0x00781CB0u); /* 0x0077CB50: push 0x781cb0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077CB55: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077CB5A: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CB5B: ret  */

}

void sub_0077CB60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CB60u);

L_0077CB60:
    PUSH32(esp, 0x0048E200u); /* 0x0077CB60: push 0x48e200 */
    PUSH32(esp, 0x0048E000u); /* 0x0077CB65: push 0x48e000 */
    PUSH32(esp, 0x00135200u); /* 0x0077CB6A: push 0x135200 */
    ecx = 0x00835784u; /* 0x0077CB6F: mov ecx, 0x835784 */
    RECOMP_CALL(sub_0043C110); /* 0x0077CB74: call 0x43c110 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CB79: ret  */

}

void sub_0077CB80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CB80u);

L_0077CB80:
    PUSH32(esp, 0x0048E200u); /* 0x0077CB80: push 0x48e200 */
    PUSH32(esp, 0x0048E000u); /* 0x0077CB85: push 0x48e000 */
    PUSH32(esp, 0x80135100u); /* 0x0077CB8A: push 0x80135100 */
    ecx = 0x00830AF8u; /* 0x0077CB8F: mov ecx, 0x830af8 */
    RECOMP_CALL(sub_0043C110); /* 0x0077CB94: call 0x43c110 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CB99: ret  */

}

void sub_0077CBA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CBA0u);

L_0077CBA0:
    PUSH32(esp, 0x0048E200u); /* 0x0077CBA0: push 0x48e200 */
    PUSH32(esp, 0x0048E000u); /* 0x0077CBA5: push 0x48e000 */
    PUSH32(esp, 0x80135000u); /* 0x0077CBAA: push 0x80135000 */
    ecx = 0x0082DBB0u; /* 0x0077CBAF: mov ecx, 0x82dbb0 */
    RECOMP_CALL(sub_0043C110); /* 0x0077CBB4: call 0x43c110 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CBB9: ret  */

}

void sub_0077CBC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CBC0u);

L_0077CBC0:
    ecx = 0x00835850u; /* 0x0077CBC0: mov ecx, 0x835850 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077CBC5: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781E20u); /* 0x0077CBCA: push 0x781e20 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077CBCF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077CBD4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CBD5: ret  */

}

void sub_0077CBE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CBE0u);

L_0077CBE0:
    PUSH32(esp, 0x004022D0u); /* 0x0077CBE0: push 0x4022d0 */
    PUSH32(esp, 0x005D7D30u); /* 0x0077CBE5: push 0x5d7d30 */
    PUSH32(esp, 0xFAu); /* 0x0077CBEA: push 0xfa */
    PUSH32(esp, 0x30u); /* 0x0077CBEF: push 0x30 */
    PUSH32(esp, 0x0082DC08u); /* 0x0077CBF1: push 0x82dc08 */
    RECOMP_CALL(sub_0075C39D); /* 0x0077CBF6: call 0x75c39d */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781CC0u); /* 0x0077CBFB: push 0x781cc0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077CC00: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077CC05: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CC06: ret  */

}

void sub_0077CC10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CC10u);

L_0077CC10:
    PUSH32(esp, 0x00491990u); /* 0x0077CC10: push 0x491990 */
    PUSH32(esp, 0x00491900u); /* 0x0077CC15: push 0x491900 */
    PUSH32(esp, 0x16u); /* 0x0077CC1A: push 0x16 */
    PUSH32(esp, 0x70u); /* 0x0077CC1C: push 0x70 */
    PUSH32(esp, 0x00832DE0u); /* 0x0077CC1E: push 0x832de0 */
    RECOMP_CALL(sub_0075C39D); /* 0x0077CC23: call 0x75c39d */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781D10u); /* 0x0077CC28: push 0x781d10 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077CC2D: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077CC32: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CC33: ret  */

}

void sub_0077CC40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CC40u);

L_0077CC40:
    ecx = 0x00830AF0u; /* 0x0077CC40: mov ecx, 0x830af0 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077CC45: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781D30u); /* 0x0077CC4A: push 0x781d30 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077CC4F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077CC54: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CC55: ret  */

}

void sub_0077CC60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CC60u);

L_0077CC60:
    ecx = 0x0082DC00u; /* 0x0077CC60: mov ecx, 0x82dc00 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077CC65: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781D40u); /* 0x0077CC6A: push 0x781d40 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077CC6F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077CC74: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CC75: ret  */

}

void sub_0077CC80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CC80u);

L_0077CC80:
    ecx = 0x008358C8u; /* 0x0077CC80: mov ecx, 0x8358c8 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077CC85: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781DB0u); /* 0x0077CC8A: push 0x781db0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077CC8F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077CC94: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CC95: ret  */

}

void sub_0077CCA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CCA0u);

L_0077CCA0:
    PUSH32(esp, 0x00495000u); /* 0x0077CCA0: push 0x495000 */
    PUSH32(esp, 0x00494E60u); /* 0x0077CCA5: push 0x494e60 */
    PUSH32(esp, 0xB3300000u); /* 0x0077CCAA: push 0xb3300000 */
    ecx = 0x0082DBA0u; /* 0x0077CCAF: mov ecx, 0x82dba0 */
    RECOMP_CALL(sub_0043C110); /* 0x0077CCB4: call 0x43c110 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CCB9: ret  */

}

void sub_0077CCC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CCC0u);

L_0077CCC0:
    PUSH32(esp, 0x00495000u); /* 0x0077CCC0: push 0x495000 */
    PUSH32(esp, 0x00494E60u); /* 0x0077CCC5: push 0x494e60 */
    PUSH32(esp, 0xB3320000u); /* 0x0077CCCA: push 0xb3320000 */
    ecx = 0x008358D0u; /* 0x0077CCCF: mov ecx, 0x8358d0 */
    RECOMP_CALL(sub_0043C110); /* 0x0077CCD4: call 0x43c110 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CCD9: ret  */

}

void sub_0077CCE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CCE0u);

L_0077CCE0:
    PUSH32(esp, 0x00495000u); /* 0x0077CCE0: push 0x495000 */
    PUSH32(esp, 0x00494E60u); /* 0x0077CCE5: push 0x494e60 */
    PUSH32(esp, 0xB0300100u); /* 0x0077CCEA: push 0xb0300100 */
    ecx = 0x00830B08u; /* 0x0077CCEF: mov ecx, 0x830b08 */
    RECOMP_CALL(sub_0043C110); /* 0x0077CCF4: call 0x43c110 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CCF9: ret  */

}

void sub_0077CD00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CD00u);

L_0077CD00:
    PUSH32(esp, 0x00495090u); /* 0x0077CD00: push 0x495090 */
    PUSH32(esp, 0x004944C0u); /* 0x0077CD05: push 0x4944c0 */
    PUSH32(esp, 0x00489310u); /* 0x0077CD0A: push 0x489310 */
    PUSH32(esp, 0x00494C40u); /* 0x0077CD0F: push 0x494c40 */
    PUSH32(esp, 0x00494BD0u); /* 0x0077CD14: push 0x494bd0 */
    PUSH32(esp, 0x80u); /* 0x0077CD19: push 0x80 */
    ecx = 0x0083579Cu; /* 0x0077CD1E: mov ecx, 0x83579c */
    RECOMP_CALL(sub_00493350); /* 0x0077CD23: call 0x493350 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781D50u); /* 0x0077CD28: push 0x781d50 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077CD2D: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077CD32: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CD33: ret  */

}

void sub_0077CD40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CD40u);

L_0077CD40:
    fp_push(*(float*)&MEM32(0x784250)); /* 0x0077CD40: fld dword ptr [0x784250] */
    _st[0] /= (double)*(float*)ADDR(0x78DBB4); /* 0x0077CD46: fdiv dword ptr [0x78dbb4] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x83654C) = _v; } /* 0x0077CD4C: fstp dword ptr [0x83654c] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CD52: ret  */

}

void sub_0077CD60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CD60u);

L_0077CD60:
    PUSH32(esp, 0x004FF410u); /* 0x0077CD60: push 0x4ff410 */
    PUSH32(esp, 0x004FF420u); /* 0x0077CD65: push 0x4ff420 */
    PUSH32(esp, 7); /* 0x0077CD6A: push 7 */
    PUSH32(esp, 0x44u); /* 0x0077CD6C: push 0x44 */
    PUSH32(esp, 0x00836568u); /* 0x0077CD6E: push 0x836568 */
    RECOMP_CALL(sub_0075C39D); /* 0x0077CD73: call 0x75c39d */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781E30u); /* 0x0077CD78: push 0x781e30 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077CD7D: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077CD82: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CD83: ret  */

}

void sub_0077CD90(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CD90u);

L_0077CD90:
    PUSH32(esp, 0xC8CFE9F2u); /* 0x0077CD90: push 0xc8cfe9f2 */
    ecx = 0x00837188u; /* 0x0077CD95: mov ecx, 0x837188 */
    RECOMP_CALL(sub_005053E0); /* 0x0077CD9A: call 0x5053e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CD9F: ret  */

}

void sub_0077CDA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CDA0u);

L_0077CDA0:
    PUSH32(esp, 0xFFFFFFFFu); /* 0x0077CDA0: push -1 */
    ecx = 0x00837198u; /* 0x0077CDA2: mov ecx, 0x837198 */
    RECOMP_CALL(sub_005053E0); /* 0x0077CDA7: call 0x5053e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CDAC: ret  */

}

void sub_0077CDB0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CDB0u);

L_0077CDB0:
    PUSH32(esp, 0x50549AC0u); /* 0x0077CDB0: push 0x50549ac0 */
    ecx = 0x00836550u; /* 0x0077CDB5: mov ecx, 0x836550 */
    RECOMP_CALL(sub_005053E0); /* 0x0077CDBA: call 0x5053e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CDBF: ret  */

}

void sub_0077CDC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CDC0u);

L_0077CDC0:
    PUSH32(esp, 0xFF323232u); /* 0x0077CDC0: push 0xff323232 */
    ecx = 0x00837178u; /* 0x0077CDC5: mov ecx, 0x837178 */
    RECOMP_CALL(sub_005053E0); /* 0x0077CDCA: call 0x5053e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CDCF: ret  */

}

void sub_0077CDD0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CDD0u);

L_0077CDD0:
    ecx = 0x008364F4u; /* 0x0077CDD0: mov ecx, 0x8364f4 */
    RECOMP_CALL(sub_00510860); /* 0x0077CDD5: call 0x510860 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781E50u); /* 0x0077CDDA: push 0x781e50 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077CDDF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077CDE4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CDE5: ret  */

}

void sub_0077CDF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CDF0u);

L_0077CDF0:
    eax = MEM32(0x78DFFC); /* 0x0077CDF0: mov eax, dword ptr [0x78dffc] */
    edx = MEM32(0x78DFF4); /* 0x0077CDF5: mov edx, dword ptr [0x78dff4] */
    ecx = eax; /* 0x0077CDFB: mov ecx, eax */
    MEM32(0x7F6900) = eax; /* 0x0077CDFD: mov dword ptr [0x7f6900], eax */
    MEM32(0x7F6904) = ecx; /* 0x0077CE02: mov dword ptr [0x7f6904], ecx */
    ecx = MEM32(0x78DFF8); /* 0x0077CE08: mov ecx, dword ptr [0x78dff8] */
    eax = edx; /* 0x0077CE0E: mov eax, edx */
    MEM32(0x7F6938) = edx; /* 0x0077CE10: mov dword ptr [0x7f6938], edx */
    edx = ecx; /* 0x0077CE16: mov edx, ecx */
    MEM32(0x7F693C) = eax; /* 0x0077CE18: mov dword ptr [0x7f693c], eax */
    MEM32(0x7F6940) = ecx; /* 0x0077CE1D: mov dword ptr [0x7f6940], ecx */
    SET_LO8(ecx, 0x80u); /* 0x0077CE23: mov cl, 0x80 */
    SET_LO8(eax, 0x25u); /* 0x0077CE25: mov al, 0x25 */
    MEM8(0x7F6960) = (uint8_t)(LO8(eax)); /* 0x0077CE27: mov byte ptr [0x7f6960], al */
    MEM8(0x7F6961) = (uint8_t)(LO8(eax)); /* 0x0077CE2C: mov byte ptr [0x7f6961], al */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0077CE31: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    MEM8(0x7F6966) = (uint8_t)(LO8(ecx)); /* 0x0077CE33: mov byte ptr [0x7f6966], cl */
    MEM8(0x7F6967) = (uint8_t)(LO8(ecx)); /* 0x0077CE39: mov byte ptr [0x7f6967], cl */
    MEM8(0x7F6968) = (uint8_t)(LO8(ecx)); /* 0x0077CE3F: mov byte ptr [0x7f6968], cl */
    MEM8(0x7F6969) = (uint8_t)(LO8(ecx)); /* 0x0077CE45: mov byte ptr [0x7f6969], cl */
    MEM8(0x7F696A) = (uint8_t)(LO8(ecx)); /* 0x0077CE4B: mov byte ptr [0x7f696a], cl */
    MEM8(0x7F696B) = (uint8_t)(LO8(ecx)); /* 0x0077CE51: mov byte ptr [0x7f696b], cl */
    SET_LO8(ecx, 0x32u); /* 0x0077CE57: mov cl, 0x32 */
    MEM32(0x7F6908) = 0; /* 0x0077CE59: mov dword ptr [0x7f6908], 0 */
    MEM32(0x7F690C) = 0x41200000u; /* 0x0077CE63: mov dword ptr [0x7f690c], 0x41200000 */
    MEM32(0x7F6910) = 0x40000000u; /* 0x0077CE6D: mov dword ptr [0x7f6910], 0x40000000 */
    MEM32(0x7F6914) = 0; /* 0x0077CE77: mov dword ptr [0x7f6914], 0 */
    MEM32(0x7F6918) = 0x41200000u; /* 0x0077CE81: mov dword ptr [0x7f6918], 0x41200000 */
    MEM32(0x7F691C) = 0x40000000u; /* 0x0077CE8B: mov dword ptr [0x7f691c], 0x40000000 */
    MEM32(0x7F6920) = 0; /* 0x0077CE95: mov dword ptr [0x7f6920], 0 */
    MEM32(0x7F6924) = 0; /* 0x0077CE9F: mov dword ptr [0x7f6924], 0 */
    MEM32(0x7F6928) = 0; /* 0x0077CEA9: mov dword ptr [0x7f6928], 0 */
    MEM32(0x7F692C) = 0; /* 0x0077CEB3: mov dword ptr [0x7f692c], 0 */
    MEM32(0x7F6930) = 0; /* 0x0077CEBD: mov dword ptr [0x7f6930], 0 */
    MEM32(0x7F6934) = 0; /* 0x0077CEC7: mov dword ptr [0x7f6934], 0 */
    MEM32(0x7F6944) = edx; /* 0x0077CED1: mov dword ptr [0x7f6944], edx */
    MEM32(0x7F6948) = 0; /* 0x0077CED7: mov dword ptr [0x7f6948], 0 */
    MEM32(0x7F694C) = 0; /* 0x0077CEE1: mov dword ptr [0x7f694c], 0 */
    MEM32(0x7F6950) = 0; /* 0x0077CEEB: mov dword ptr [0x7f6950], 0 */
    MEM32(0x7F6954) = 0; /* 0x0077CEF5: mov dword ptr [0x7f6954], 0 */
    MEM32(0x7F6958) = 0; /* 0x0077CEFF: mov dword ptr [0x7f6958], 0 */
    MEM32(0x7F695C) = 0; /* 0x0077CF09: mov dword ptr [0x7f695c], 0 */
    MEM8(0x7F6962) = (uint8_t)(LO8(eax)); /* 0x0077CF13: mov byte ptr [0x7f6962], al */
    MEM8(0x7F6963) = (uint8_t)(LO8(eax)); /* 0x0077CF18: mov byte ptr [0x7f6963], al */
    MEM8(0x7F6964) = (uint8_t)(LO8(eax)); /* 0x0077CF1D: mov byte ptr [0x7f6964], al */
    MEM8(0x7F6965) = (uint8_t)(LO8(eax)); /* 0x0077CF22: mov byte ptr [0x7f6965], al */
    MEM8(0x7F696C) = (uint8_t)(LO8(eax)); /* 0x0077CF27: mov byte ptr [0x7f696c], al */
    MEM8(0x7F696D) = (uint8_t)(LO8(ecx)); /* 0x0077CF2C: mov byte ptr [0x7f696d], cl */
    MEM8(0x7F696E) = (uint8_t)(LO8(eax)); /* 0x0077CF32: mov byte ptr [0x7f696e], al */
    MEM8(0x7F696F) = (uint8_t)(LO8(ecx)); /* 0x0077CF37: mov byte ptr [0x7f696f], cl */
    MEM8(0x7F6970) = (uint8_t)(LO8(eax)); /* 0x0077CF3D: mov byte ptr [0x7f6970], al */
    MEM8(0x7F6971) = (uint8_t)(LO8(eax)); /* 0x0077CF42: mov byte ptr [0x7f6971], al */
    MEM32(0x7F6974) = eax; /* 0x0077CF47: mov dword ptr [0x7f6974], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077CF4C: ret  */

}

void sub_0077CF50(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077CF50u);

L_0077CF50:
    eax = MEM32(0x78E024); /* 0x0077CF50: mov eax, dword ptr [0x78e024] */
    ecx = 1; /* 0x0077CF55: mov ecx, 1 */
    MEM32(0x7F6BB0) = eax; /* 0x0077CF5A: mov dword ptr [0x7f6bb0], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0077CF5F: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    MEM32(0x7F6BB4) = 0x3E800000u; /* 0x0077CF61: mov dword ptr [0x7f6bb4], 0x3e800000 */
    MEM32(0x7F6BB8) = 0xBDCCCCCDu; /* 0x0077CF6B: mov dword ptr [0x7f6bb8], 0xbdcccccd */
    MEM32(0x7F6BBC) = 0x41200000u; /* 0x0077CF75: mov dword ptr [0x7f6bbc], 0x41200000 */
    MEM32(0x7F6BC0) = ecx; /* 0x0077CF7F: mov dword ptr [0x7f6bc0], ecx */
    MEM32(0x7F6BC4) = ecx; /* 0x0077CF85: mov dword ptr [0x7f6bc4], ecx */
    MEM32(0x7F6BC8) = 0x3F000000u; /* 0x0077CF8B: mov dword ptr [0x7f6bc8], 0x3f000000 */
    MEM32(0x7F6BCC) = 0x40100000u; /* 0x0077CF95: mov dword ptr [0x7f6bcc], 0x40100000 */
    MEM32(0x7F6BD0) = 0; /* 0x0077CF9F: mov dword ptr [0x7f6bd0], 0 */
    MEM32(0x7F6BD4) = 0x3ECCCCCDu; /* 0x0077CFA9: mov dword ptr [0x7f6bd4], 0x3ecccccd */
    MEM32(0x7F6BD8) = eax; /* 0x0077CFB3: mov dword ptr [0x7f6bd8], eax */
    MEM32(0x7F6BDC) = 0x3F800000u; /* 0x0077CFB8: mov dword ptr [0x7f6bdc], 0x3f800000 */
    MEM32(0x7F6BE0) = 0x40533333u; /* 0x0077CFC2: mov dword ptr [0x7f6be0], 0x40533333 */
    MEM32(0x7F6BE4) = 0x42200000u; /* 0x0077CFCC: mov dword ptr [0x7f6be4], 0x42200000 */
    MEM32(0x7F6BE8) = eax; /* 0x0077CFD6: mov dword ptr [0x7f6be8], eax */
    MEM32(0x7F6BEC) = eax; /* 0x0077CFDB: mov dword ptr [0x7f6bec], eax */
    MEM32(0x7F6BF0) = 0x3F800000u; /* 0x0077CFE0: mov dword ptr [0x7f6bf0], 0x3f800000 */
    MEM32(0x7F6BF4) = 0x3ECCCCCDu; /* 0x0077CFEA: mov dword ptr [0x7f6bf4], 0x3ecccccd */
    MEM32(0x7F6BF8) = eax; /* 0x0077CFF4: mov dword ptr [0x7f6bf8], eax */
    MEM32(0x7F6BFC) = 0xBF800000u; /* 0x0077CFF9: mov dword ptr [0x7f6bfc], 0xbf800000 */
    MEM32(0x7F6C00) = ecx; /* 0x0077D003: mov dword ptr [0x7f6c00], ecx */
    MEM32(0x7F6C04) = 0x3F000000u; /* 0x0077D009: mov dword ptr [0x7f6c04], 0x3f000000 */
    MEM32(0x7F6C08) = 0x40100000u; /* 0x0077D013: mov dword ptr [0x7f6c08], 0x40100000 */
    MEM32(0x7F6C0C) = 0x41880000u; /* 0x0077D01D: mov dword ptr [0x7f6c0c], 0x41880000 */
    MEM32(0x7F6C10) = 0x3ECCCCCDu; /* 0x0077D027: mov dword ptr [0x7f6c10], 0x3ecccccd */
    MEM32(0x7F6C14) = eax; /* 0x0077D031: mov dword ptr [0x7f6c14], eax */
    MEM32(0x7F6C18) = 0x3F800000u; /* 0x0077D036: mov dword ptr [0x7f6c18], 0x3f800000 */
    MEM32(0x7F6C1C) = 0x40000000u; /* 0x0077D040: mov dword ptr [0x7f6c1c], 0x40000000 */
    MEM32(0x7F6C20) = eax; /* 0x0077D04A: mov dword ptr [0x7f6c20], eax */
    MEM32(0x7F6C24) = eax; /* 0x0077D04F: mov dword ptr [0x7f6c24], eax */
    MEM32(0x7F6C28) = eax; /* 0x0077D054: mov dword ptr [0x7f6c28], eax */
    MEM32(0x7F6C2C) = 0x3F800000u; /* 0x0077D059: mov dword ptr [0x7f6c2c], 0x3f800000 */
    MEM32(0x7F6C30) = 0x3ECCCCCDu; /* 0x0077D063: mov dword ptr [0x7f6c30], 0x3ecccccd */
    MEM32(0x7F6C34) = eax; /* 0x0077D06D: mov dword ptr [0x7f6c34], eax */
    MEM32(0x7F6C38) = 0xBF800000u; /* 0x0077D072: mov dword ptr [0x7f6c38], 0xbf800000 */
    MEM32(0x7F6C3C) = eax; /* 0x0077D07C: mov dword ptr [0x7f6c3c], eax */
    MEM32(0x7F6C40) = 0x3F000000u; /* 0x0077D081: mov dword ptr [0x7f6c40], 0x3f000000 */
    MEM32(0x7F6C44) = 0x40100000u; /* 0x0077D08B: mov dword ptr [0x7f6c44], 0x40100000 */
    MEM32(0x7F6C48) = eax; /* 0x0077D095: mov dword ptr [0x7f6c48], eax */
    MEM32(0x7F6C4C) = 0x3ECCCCCDu; /* 0x0077D09A: mov dword ptr [0x7f6c4c], 0x3ecccccd */
    MEM32(0x7F6C50) = eax; /* 0x0077D0A4: mov dword ptr [0x7f6c50], eax */
    MEM32(0x7F6C54) = 0x3F800000u; /* 0x0077D0A9: mov dword ptr [0x7f6c54], 0x3f800000 */
    MEM32(0x7F6C58) = 0x4007DF3Bu; /* 0x0077D0B3: mov dword ptr [0x7f6c58], 0x4007df3b */
    MEM32(0x7F6C5C) = 0x42200000u; /* 0x0077D0BD: mov dword ptr [0x7f6c5c], 0x42200000 */
    MEM32(0x7F6C60) = eax; /* 0x0077D0C7: mov dword ptr [0x7f6c60], eax */
    MEM32(0x7F6C64) = eax; /* 0x0077D0CC: mov dword ptr [0x7f6c64], eax */
    MEM32(0x7F6C68) = 0xBF800000u; /* 0x0077D0D1: mov dword ptr [0x7f6c68], 0xbf800000 */
    MEM32(0x7F6C6C) = 0x3ECCCCCDu; /* 0x0077D0DB: mov dword ptr [0x7f6c6c], 0x3ecccccd */
    MEM32(0x7F6C70) = eax; /* 0x0077D0E5: mov dword ptr [0x7f6c70], eax */
    MEM32(0x7F6C74) = 0xBF800000u; /* 0x0077D0EA: mov dword ptr [0x7f6c74], 0xbf800000 */
    MEM32(0x7F6C78) = eax; /* 0x0077D0F4: mov dword ptr [0x7f6c78], eax */
    MEM32(0x7F6C7C) = 0x3F000000u; /* 0x0077D0F9: mov dword ptr [0x7f6c7c], 0x3f000000 */
    MEM32(0x7F6C80) = 0x40100000u; /* 0x0077D103: mov dword ptr [0x7f6c80], 0x40100000 */
    MEM32(0x7F6C84) = 0x41880000u; /* 0x0077D10D: mov dword ptr [0x7f6c84], 0x41880000 */
    MEM32(0x7F6C88) = 0x3ECCCCCDu; /* 0x0077D117: mov dword ptr [0x7f6c88], 0x3ecccccd */
    MEM32(0x7F6C8C) = eax; /* 0x0077D121: mov dword ptr [0x7f6c8c], eax */
    MEM32(0x7F6C90) = 0x3F800000u; /* 0x0077D126: mov dword ptr [0x7f6c90], 0x3f800000 */
    MEM32(0x7F6C94) = 0x40000000u; /* 0x0077D130: mov dword ptr [0x7f6c94], 0x40000000 */
    MEM32(0x7F6C98) = eax; /* 0x0077D13A: mov dword ptr [0x7f6c98], eax */
    MEM32(0x7F6C9C) = eax; /* 0x0077D13F: mov dword ptr [0x7f6c9c], eax */
    MEM32(0x7F6CA0) = eax; /* 0x0077D144: mov dword ptr [0x7f6ca0], eax */
    MEM32(0x7F6CA4) = 0xBF800000u; /* 0x0077D149: mov dword ptr [0x7f6ca4], 0xbf800000 */
    MEM32(0x7F6CA8) = 0x3ECCCCCDu; /* 0x0077D153: mov dword ptr [0x7f6ca8], 0x3ecccccd */
    MEM32(0x7F6CAC) = eax; /* 0x0077D15D: mov dword ptr [0x7f6cac], eax */
    MEM32(0x7F6CB0) = 0xBF800000u; /* 0x0077D162: mov dword ptr [0x7f6cb0], 0xbf800000 */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D16C: ret  */

}

void sub_0077D170(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D170u);

L_0077D170:
    ecx = 0x008371B0u; /* 0x0077D170: mov ecx, 0x8371b0 */
    RECOMP_CALL(sub_0040C950); /* 0x0077D175: call 0x40c950 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781E60u); /* 0x0077D17A: push 0x781e60 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D17F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D184: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D185: ret  */

}

void sub_0077D190(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D190u);

L_0077D190:
    ecx = 0x00836750u; /* 0x0077D190: mov ecx, 0x836750 */
    RECOMP_CALL(sub_0040C950); /* 0x0077D195: call 0x40c950 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781E70u); /* 0x0077D19A: push 0x781e70 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D19F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D1A4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D1A5: ret  */

}

void sub_0077D1B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D1B0u);

L_0077D1B0:
    PUSH32(esp, ebx); /* 0x0077D1B0: push ebx */
    PUSH32(esp, esi); /* 0x0077D1B1: push esi */
    PUSH32(esp, edi); /* 0x0077D1B2: push edi */
    esi = 0x00837048u; /* 0x0077D1B3: mov esi, 0x837048 */
    ebx = 6; /* 0x0077D1B8: mov ebx, 6 */
    _flag_a = (uint32_t)((edi | 0xFFFFFFFFu)); _flag_b = (uint32_t)((edi | 0xFFFFFFFFu));
    edi = edi | 0xFFFFFFFFu; /* 0x0077D1BD: or edi, 0xffffffff */
    _cf = 0;
    _flag_k = FK_TEST;

L_0077D1C0:
    PUSH32(esp, 0x00783FE5u); /* 0x0077D1C0: push 0x783fe5 */
    MEM32(esi) = 0; /* 0x0077D1C5: mov dword ptr [esi], 0 */
    eax = esi + 0x4; /* 0x0077D1CB: lea eax, [esi + 4] */
    PUSH32(esp, 0x20u); /* 0x0077D1CE: push 0x20 */
    PUSH32(esp, eax); /* 0x0077D1D0: push eax */
    MEM32(esi + (-0x8)) = edi; /* 0x0077D1D1: mov dword ptr [esi - 8], edi */
    MEM32(esi + (-0x4)) = edi; /* 0x0077D1D4: mov dword ptr [esi - 4], edi */
    MEM32(esi) = 0; /* 0x0077D1D7: mov dword ptr [esi], 0 */
    RECOMP_CALL(sub_0050C8A0); /* 0x0077D1DD: call 0x50c8a0 */
    RECOMP_FLAGS_IN();
    MEM32(esi + 0x28) = 0; /* 0x0077D1E2: mov dword ptr [esi + 0x28], 0 */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077D1E9: add esp, 0xc */
    _flag_k = FK_ADD;
    _flag_a = (uint32_t)(esi); _flag_b = (uint32_t)(0x34u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esi = esi + 0x34u; /* 0x0077D1EC: add esi, 0x34 */
    _flag_k = FK_ADD;
    _flag_a = (uint32_t)(ebx); _flag_b = (uint32_t)(1);
    ebx = ebx - 1; /* 0x0077D1EF: dec ebx */
    _flag_k = FK_DEC;
    RECOMP_BACKEDGE();
    if (/* dec result */ CMP_NE(_flag_a, _flag_b)) goto L_0077D1C0; /* 0x0077D1F0: jne 0x77d1c0 */

L_0077D1F2:
    edi = POP32_VAL(esp); /* 0x0077D1F2: pop edi */
    esi = POP32_VAL(esp); /* 0x0077D1F3: pop esi */
    ebx = POP32_VAL(esp); /* 0x0077D1F4: pop ebx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D1F5: ret  */

}

void sub_0077D200(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D200u);

L_0077D200:
    ecx = 0x00836560u; /* 0x0077D200: mov ecx, 0x836560 */
    RECOMP_CALL(sub_004EC6D0); /* 0x0077D205: call 0x4ec6d0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781E80u); /* 0x0077D20A: push 0x781e80 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D20F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D214: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D215: ret  */

}

void sub_0077D220(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D220u);

L_0077D220:
    ecx = 0x00863760u; /* 0x0077D220: mov ecx, 0x863760 */
    RECOMP_CALL(sub_004FE340); /* 0x0077D225: call 0x4fe340 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781E90u); /* 0x0077D22A: push 0x781e90 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D22F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D234: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D235: ret  */

}

void sub_0077D240(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D240u);

L_0077D240:
    PUSH32(esp, 0x00781ED0u); /* 0x0077D240: push 0x781ed0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D245: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D24A: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D24B: ret  */

}

void sub_0077D250(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D250u);

L_0077D250:
    fp_push(*(float*)&MEM32(0x784250)); /* 0x0077D250: fld dword ptr [0x784250] */
    _st[0] /= (double)*(float*)ADDR(0x7992F0); /* 0x0077D256: fdiv dword ptr [0x7992f0] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x86375C) = _v; } /* 0x0077D25C: fstp dword ptr [0x86375c] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D262: ret  */

}

void sub_0077D270(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D270u);

L_0077D270:
    ecx = 0x00838640u; /* 0x0077D270: mov ecx, 0x838640 */
    RECOMP_ITAIL(0x004FF230u); RECOMP_RETURN(); /* 0x0077D275: jmp 0x4ff230 */

}

void sub_0077D280(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D280u);

L_0077D280:
    eax = MEM32(0x7FA2B0); /* 0x0077D280: mov eax, dword ptr [0x7fa2b0] */
    ecx = MEM32(0x7FA2B4); /* 0x0077D285: mov ecx, dword ptr [0x7fa2b4] */
    edx = MEM32(0x7FA2B8); /* 0x0077D28B: mov edx, dword ptr [0x7fa2b8] */
    MEM32(0x839BE0) = eax; /* 0x0077D291: mov dword ptr [0x839be0], eax */
    eax = MEM32(0x7FA2BC); /* 0x0077D296: mov eax, dword ptr [0x7fa2bc] */
    MEM32(0x839BE4) = ecx; /* 0x0077D29B: mov dword ptr [0x839be4], ecx */
    MEM32(0x839BE8) = edx; /* 0x0077D2A1: mov dword ptr [0x839be8], edx */
    MEM32(0x839BEC) = eax; /* 0x0077D2A7: mov dword ptr [0x839bec], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D2AC: ret  */

}

void sub_0077D2B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D2B0u);

L_0077D2B0:
    ecx = 0x0085AD40u; /* 0x0077D2B0: mov ecx, 0x85ad40 */
    RECOMP_CALL(sub_00532690); /* 0x0077D2B5: call 0x532690 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781EE0u); /* 0x0077D2BA: push 0x781ee0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D2BF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D2C4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D2C5: ret  */

}

void sub_0077D2D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D2D0u);

L_0077D2D0:
    ecx = 0x0083A9D0u; /* 0x0077D2D0: mov ecx, 0x83a9d0 */
    RECOMP_CALL(sub_0053EC80); /* 0x0077D2D5: call 0x53ec80 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781F20u); /* 0x0077D2DA: push 0x781f20 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D2DF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D2E4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D2E5: ret  */

}

void sub_0077D2F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D2F0u);

L_0077D2F0:
    PUSH32(esp, 0x0079DA1Cu); /* 0x0077D2F0: push 0x79da1c */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077D2F5: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x0079DA04u); /* 0x0077D2FA: push 0x79da04 */
    MEM32(0x8641AC) = eax; /* 0x0077D2FF: mov dword ptr [0x8641ac], eax */
    MEM32(0x8641B0) = 4; /* 0x0077D304: mov dword ptr [0x8641b0], 4 */
    MEM32(0x8641B4) = 1; /* 0x0077D30E: mov dword ptr [0x8641b4], 1 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077D318: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x0079D9F0u); /* 0x0077D31D: push 0x79d9f0 */
    MEM32(0x8641B8) = eax; /* 0x0077D322: mov dword ptr [0x8641b8], eax */
    MEM32(0x8641BC) = 1; /* 0x0077D327: mov dword ptr [0x8641bc], 1 */
    MEM32(0x8641C0) = 2; /* 0x0077D331: mov dword ptr [0x8641c0], 2 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077D33B: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    MEM32(0x8641C4) = eax; /* 0x0077D340: mov dword ptr [0x8641c4], eax */
    eax = 3; /* 0x0077D345: mov eax, 3 */
    PUSH32(esp, 0x0079D9DCu); /* 0x0077D34A: push 0x79d9dc */
    MEM32(0x8641C8) = eax; /* 0x0077D34F: mov dword ptr [0x8641c8], eax */
    MEM32(0x8641CC) = eax; /* 0x0077D354: mov dword ptr [0x8641cc], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077D359: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x0079D9C8u); /* 0x0077D35E: push 0x79d9c8 */
    MEM32(0x8641D0) = eax; /* 0x0077D363: mov dword ptr [0x8641d0], eax */
    MEM32(0x8641D4) = 2; /* 0x0077D368: mov dword ptr [0x8641d4], 2 */
    MEM32(0x8641D8) = 4; /* 0x0077D372: mov dword ptr [0x8641d8], 4 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077D37C: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x0079D9ACu); /* 0x0077D381: push 0x79d9ac */
    MEM32(0x8641DC) = eax; /* 0x0077D386: mov dword ptr [0x8641dc], eax */
    MEM32(0x8641E0) = 0; /* 0x0077D38B: mov dword ptr [0x8641e0], 0 */
    MEM32(0x8641E4) = 0xAu; /* 0x0077D395: mov dword ptr [0x8641e4], 0xa */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077D39F: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x18u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x18u; /* 0x0077D3A4: add esp, 0x18 */
    _flag_k = FK_ADD;
    MEM32(0x8641E8) = eax; /* 0x0077D3A7: mov dword ptr [0x8641e8], eax */
    MEM32(0x8641EC) = 1; /* 0x0077D3AC: mov dword ptr [0x8641ec], 1 */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D3B6: ret  */

}

void sub_0077D3C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D3C0u);

L_0077D3C0:
    ecx = 0x008637A0u; /* 0x0077D3C0: mov ecx, 0x8637a0 */
    RECOMP_CALL(sub_0052C200); /* 0x0077D3C5: call 0x52c200 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781F30u); /* 0x0077D3CA: push 0x781f30 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D3CF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D3D4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D3D5: ret  */

}

void sub_0077D3E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D3E0u);

L_0077D3E0:
    ecx = 0x00863770u; /* 0x0077D3E0: mov ecx, 0x863770 */
    RECOMP_CALL(sub_0052C200); /* 0x0077D3E5: call 0x52c200 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781F40u); /* 0x0077D3EA: push 0x781f40 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D3EF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D3F4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D3F5: ret  */

}

void sub_0077D400(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D400u);

L_0077D400:
    ecx = 0x00839C30u; /* 0x0077D400: mov ecx, 0x839c30 */
    RECOMP_CALL(sub_0052C200); /* 0x0077D405: call 0x52c200 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781F50u); /* 0x0077D40A: push 0x781f50 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D40F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D414: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D415: ret  */

}

void sub_0077D420(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D420u);

L_0077D420:
    ecx = 0x00839BD0u; /* 0x0077D420: mov ecx, 0x839bd0 */
    RECOMP_CALL(sub_0052C200); /* 0x0077D425: call 0x52c200 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781F60u); /* 0x0077D42A: push 0x781f60 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D42F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D434: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D435: ret  */

}

void sub_0077D440(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D440u);

L_0077D440:
    PUSH32(esp, 0x00525BE0u); /* 0x0077D440: push 0x525be0 */
    PUSH32(esp, 0x004EC6D0u); /* 0x0077D445: push 0x4ec6d0 */
    PUSH32(esp, 0x100u); /* 0x0077D44A: push 0x100 */
    PUSH32(esp, 8); /* 0x0077D44F: push 8 */
    PUSH32(esp, 0x008639A0u); /* 0x0077D451: push 0x8639a0 */
    RECOMP_CALL(sub_0075C39D); /* 0x0077D456: call 0x75c39d */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781EF0u); /* 0x0077D45B: push 0x781ef0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D460: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D465: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D466: ret  */

}

void sub_0077D470(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D470u);

L_0077D470:
    ecx = 0x008637B0u; /* 0x0077D470: mov ecx, 0x8637b0 */
    RECOMP_CALL(sub_0052CBD0); /* 0x0077D475: call 0x52cbd0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781F10u); /* 0x0077D47A: push 0x781f10 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D47F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D484: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D485: ret  */

}

void sub_0077D490(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D490u);

L_0077D490:
    ecx = 0x00863768u; /* 0x0077D490: mov ecx, 0x863768 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077D495: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781F70u); /* 0x0077D49A: push 0x781f70 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D49F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D4A4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D4A5: ret  */

}

void sub_0077D4B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D4B0u);

L_0077D4B0:
    ecx = 0x008637BCu; /* 0x0077D4B0: mov ecx, 0x8637bc */
    RECOMP_CALL(sub_004EC6D0); /* 0x0077D4B5: call 0x4ec6d0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781F90u); /* 0x0077D4BA: push 0x781f90 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D4BF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D4C4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D4C5: ret  */

}

void sub_0077D4D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D4D0u);

L_0077D4D0:
    ecx = 0x00838980u; /* 0x0077D4D0: mov ecx, 0x838980 */
    RECOMP_CALL(sub_0053AD50); /* 0x0077D4D5: call 0x53ad50 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781F80u); /* 0x0077D4DA: push 0x781f80 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D4DF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D4E4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D4E5: ret  */

}

void sub_0077D4F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D4F0u);

L_0077D4F0:
    ecx = 0x00839C40u; /* 0x0077D4F0: mov ecx, 0x839c40 */
    RECOMP_CALL(sub_00522370); /* 0x0077D4F5: call 0x522370 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781EA0u); /* 0x0077D4FA: push 0x781ea0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D4FF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D504: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D505: ret  */

}

void sub_0077D510(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D510u);

L_0077D510:
    fp_push(*(float*)&MEM32(0x799398)); /* 0x0077D510: fld dword ptr [0x799398] */
    _st[0] *= (double)*(float*)ADDR(0x79DA34); /* 0x0077D516: fmul dword ptr [0x79da34] */
    _st[0] -= (double)*(float*)ADDR(0x7993A0); /* 0x0077D51C: fsub dword ptr [0x7993a0] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8637C4) = _v; } /* 0x0077D522: fstp dword ptr [0x8637c4] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D528: ret  */

}

void sub_0077D530(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D530u);

L_0077D530:
    ecx = 0x008637D0u; /* 0x0077D530: mov ecx, 0x8637d0 */
    RECOMP_CALL(sub_00531530); /* 0x0077D535: call 0x531530 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781EC0u); /* 0x0077D53A: push 0x781ec0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D53F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D544: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D545: ret  */

}

void sub_0077D550(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D550u);

L_0077D550:
    PUSH32(esp, 0x00781EB0u); /* 0x0077D550: push 0x781eb0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D555: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D55A: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D55B: ret  */

}

void sub_0077D560(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D560u);

L_0077D560:
    fp_push(*(float*)&MEM32(0x784250)); /* 0x0077D560: fld dword ptr [0x784250] */
    _st[0] /= (double)*(float*)ADDR(0x79DA40); /* 0x0077D566: fdiv dword ptr [0x79da40] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x864638) = _v; } /* 0x0077D56C: fstp dword ptr [0x864638] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D572: ret  */

}

void sub_0077D580(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D580u);

L_0077D580:
    PUSH32(esp, 0x004022D0u); /* 0x0077D580: push 0x4022d0 */
    PUSH32(esp, 0x0056D6D0u); /* 0x0077D585: push 0x56d6d0 */
    PUSH32(esp, 6); /* 0x0077D58A: push 6 */
    PUSH32(esp, 0x20u); /* 0x0077D58C: push 0x20 */
    PUSH32(esp, 0x00864640u); /* 0x0077D58E: push 0x864640 */
    RECOMP_CALL(sub_0075C39D); /* 0x0077D593: call 0x75c39d */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781FA0u); /* 0x0077D598: push 0x781fa0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D59D: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D5A2: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D5A3: ret  */

}

void sub_0077D5B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D5B0u);

L_0077D5B0:
    ecx = 0x00864630u; /* 0x0077D5B0: mov ecx, 0x864630 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077D5B5: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00781FC0u); /* 0x0077D5BA: push 0x781fc0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D5BF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D5C4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D5C5: ret  */

}

void sub_0077D5D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D5D0u);

L_0077D5D0:
    ecx = 0x00865210u; /* 0x0077D5D0: mov ecx, 0x865210 */
    RECOMP_CALL(sub_004EC6D0); /* 0x0077D5D5: call 0x4ec6d0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007821C0u); /* 0x0077D5DA: push 0x7821c0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D5DF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D5E4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D5E5: ret  */

}

void sub_0077D5F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D5F0u);

L_0077D5F0:
    fp_push(*(float*)&MEM32(0x784250)); /* 0x0077D5F0: fld dword ptr [0x784250] */
    _st[0] /= (double)*(float*)ADDR(0x79DC44); /* 0x0077D5F6: fdiv dword ptr [0x79dc44] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x86554C) = _v; } /* 0x0077D5FC: fstp dword ptr [0x86554c] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D602: ret  */

}

void sub_0077D610(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D610u);

L_0077D610:
    eax = MEM32(0x79DC50); /* 0x0077D610: mov eax, dword ptr [0x79dc50] */
    edx = MEM32(0x79DC48); /* 0x0077D615: mov edx, dword ptr [0x79dc48] */
    ecx = eax; /* 0x0077D61B: mov ecx, eax */
    MEM32(0x7FB8E8) = eax; /* 0x0077D61D: mov dword ptr [0x7fb8e8], eax */
    MEM32(0x7FB8EC) = ecx; /* 0x0077D622: mov dword ptr [0x7fb8ec], ecx */
    ecx = MEM32(0x79DC4C); /* 0x0077D628: mov ecx, dword ptr [0x79dc4c] */
    eax = edx; /* 0x0077D62E: mov eax, edx */
    MEM32(0x7FB920) = edx; /* 0x0077D630: mov dword ptr [0x7fb920], edx */
    edx = ecx; /* 0x0077D636: mov edx, ecx */
    MEM32(0x7FB924) = eax; /* 0x0077D638: mov dword ptr [0x7fb924], eax */
    MEM32(0x7FB928) = ecx; /* 0x0077D63D: mov dword ptr [0x7fb928], ecx */
    SET_LO8(ecx, 0x80u); /* 0x0077D643: mov cl, 0x80 */
    SET_LO8(eax, 0x25u); /* 0x0077D645: mov al, 0x25 */
    MEM8(0x7FB948) = (uint8_t)(LO8(eax)); /* 0x0077D647: mov byte ptr [0x7fb948], al */
    MEM8(0x7FB949) = (uint8_t)(LO8(eax)); /* 0x0077D64C: mov byte ptr [0x7fb949], al */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0077D651: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    MEM8(0x7FB94E) = (uint8_t)(LO8(ecx)); /* 0x0077D653: mov byte ptr [0x7fb94e], cl */
    MEM8(0x7FB94F) = (uint8_t)(LO8(ecx)); /* 0x0077D659: mov byte ptr [0x7fb94f], cl */
    MEM8(0x7FB950) = (uint8_t)(LO8(ecx)); /* 0x0077D65F: mov byte ptr [0x7fb950], cl */
    MEM8(0x7FB951) = (uint8_t)(LO8(ecx)); /* 0x0077D665: mov byte ptr [0x7fb951], cl */
    MEM8(0x7FB952) = (uint8_t)(LO8(ecx)); /* 0x0077D66B: mov byte ptr [0x7fb952], cl */
    MEM8(0x7FB953) = (uint8_t)(LO8(ecx)); /* 0x0077D671: mov byte ptr [0x7fb953], cl */
    SET_LO8(ecx, 0x32u); /* 0x0077D677: mov cl, 0x32 */
    MEM32(0x7FB8F0) = 0; /* 0x0077D679: mov dword ptr [0x7fb8f0], 0 */
    MEM32(0x7FB8F4) = 0x41200000u; /* 0x0077D683: mov dword ptr [0x7fb8f4], 0x41200000 */
    MEM32(0x7FB8F8) = 0x40000000u; /* 0x0077D68D: mov dword ptr [0x7fb8f8], 0x40000000 */
    MEM32(0x7FB8FC) = 0; /* 0x0077D697: mov dword ptr [0x7fb8fc], 0 */
    MEM32(0x7FB900) = 0x41200000u; /* 0x0077D6A1: mov dword ptr [0x7fb900], 0x41200000 */
    MEM32(0x7FB904) = 0x40000000u; /* 0x0077D6AB: mov dword ptr [0x7fb904], 0x40000000 */
    MEM32(0x7FB908) = 0; /* 0x0077D6B5: mov dword ptr [0x7fb908], 0 */
    MEM32(0x7FB90C) = 0; /* 0x0077D6BF: mov dword ptr [0x7fb90c], 0 */
    MEM32(0x7FB910) = 0; /* 0x0077D6C9: mov dword ptr [0x7fb910], 0 */
    MEM32(0x7FB914) = 0; /* 0x0077D6D3: mov dword ptr [0x7fb914], 0 */
    MEM32(0x7FB918) = 0; /* 0x0077D6DD: mov dword ptr [0x7fb918], 0 */
    MEM32(0x7FB91C) = 0; /* 0x0077D6E7: mov dword ptr [0x7fb91c], 0 */
    MEM32(0x7FB92C) = edx; /* 0x0077D6F1: mov dword ptr [0x7fb92c], edx */
    MEM32(0x7FB930) = 0; /* 0x0077D6F7: mov dword ptr [0x7fb930], 0 */
    MEM32(0x7FB934) = 0; /* 0x0077D701: mov dword ptr [0x7fb934], 0 */
    MEM32(0x7FB938) = 0; /* 0x0077D70B: mov dword ptr [0x7fb938], 0 */
    MEM32(0x7FB93C) = 0; /* 0x0077D715: mov dword ptr [0x7fb93c], 0 */
    MEM32(0x7FB940) = 0; /* 0x0077D71F: mov dword ptr [0x7fb940], 0 */
    MEM32(0x7FB944) = 0; /* 0x0077D729: mov dword ptr [0x7fb944], 0 */
    MEM8(0x7FB94A) = (uint8_t)(LO8(eax)); /* 0x0077D733: mov byte ptr [0x7fb94a], al */
    MEM8(0x7FB94B) = (uint8_t)(LO8(eax)); /* 0x0077D738: mov byte ptr [0x7fb94b], al */
    MEM8(0x7FB94C) = (uint8_t)(LO8(eax)); /* 0x0077D73D: mov byte ptr [0x7fb94c], al */
    MEM8(0x7FB94D) = (uint8_t)(LO8(eax)); /* 0x0077D742: mov byte ptr [0x7fb94d], al */
    MEM8(0x7FB954) = (uint8_t)(LO8(eax)); /* 0x0077D747: mov byte ptr [0x7fb954], al */
    MEM8(0x7FB955) = (uint8_t)(LO8(ecx)); /* 0x0077D74C: mov byte ptr [0x7fb955], cl */
    MEM8(0x7FB956) = (uint8_t)(LO8(eax)); /* 0x0077D752: mov byte ptr [0x7fb956], al */
    MEM8(0x7FB957) = (uint8_t)(LO8(ecx)); /* 0x0077D757: mov byte ptr [0x7fb957], cl */
    MEM8(0x7FB958) = (uint8_t)(LO8(eax)); /* 0x0077D75D: mov byte ptr [0x7fb958], al */
    MEM8(0x7FB959) = (uint8_t)(LO8(eax)); /* 0x0077D762: mov byte ptr [0x7fb959], al */
    MEM32(0x7FB95C) = eax; /* 0x0077D767: mov dword ptr [0x7fb95c], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D76C: ret  */

}

void sub_0077D770(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D770u);

L_0077D770:
    ecx = 0x008651A4u; /* 0x0077D770: mov ecx, 0x8651a4 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077D775: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782130u); /* 0x0077D77A: push 0x782130 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D77F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D784: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D785: ret  */

}

void sub_0077D790(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D790u);

L_0077D790:
    eax = MEM32(0x7FA99C); /* 0x0077D790: mov eax, dword ptr [0x7fa99c] */
    ecx = MEM32(0x7FA9A0); /* 0x0077D795: mov ecx, dword ptr [0x7fa9a0] */
    edx = MEM32(0x7FA97C); /* 0x0077D79B: mov edx, dword ptr [0x7fa97c] */
    MEM32(0x86658C) = eax; /* 0x0077D7A1: mov dword ptr [0x86658c], eax */
    eax = MEM32(0x7FA980); /* 0x0077D7A6: mov eax, dword ptr [0x7fa980] */
    MEM32(0x866590) = ecx; /* 0x0077D7AB: mov dword ptr [0x866590], ecx */
    ecx = MEM32(0x7FA984); /* 0x0077D7B1: mov ecx, dword ptr [0x7fa984] */
    MEM32(0x866594) = edx; /* 0x0077D7B7: mov dword ptr [0x866594], edx */
    edx = MEM32(0x7FA988); /* 0x0077D7BD: mov edx, dword ptr [0x7fa988] */
    MEM32(0x866598) = eax; /* 0x0077D7C3: mov dword ptr [0x866598], eax */
    eax = MEM32(0x7FA98C); /* 0x0077D7C8: mov eax, dword ptr [0x7fa98c] */
    MEM32(0x86659C) = ecx; /* 0x0077D7CD: mov dword ptr [0x86659c], ecx */
    ecx = MEM32(0x7FA990); /* 0x0077D7D3: mov ecx, dword ptr [0x7fa990] */
    MEM32(0x8665A0) = edx; /* 0x0077D7D9: mov dword ptr [0x8665a0], edx */
    edx = MEM32(0x7FA994); /* 0x0077D7DF: mov edx, dword ptr [0x7fa994] */
    MEM32(0x8665A4) = eax; /* 0x0077D7E5: mov dword ptr [0x8665a4], eax */
    eax = MEM32(0x7FA998); /* 0x0077D7EA: mov eax, dword ptr [0x7fa998] */
    MEM32(0x8665A8) = ecx; /* 0x0077D7EF: mov dword ptr [0x8665a8], ecx */
    ecx = MEM32(0x7FA978); /* 0x0077D7F5: mov ecx, dword ptr [0x7fa978] */
    MEM32(0x8665AC) = edx; /* 0x0077D7FB: mov dword ptr [0x8665ac], edx */
    MEM32(0x8665B0) = eax; /* 0x0077D801: mov dword ptr [0x8665b0], eax */
    MEM32(0x8665B4) = ecx; /* 0x0077D806: mov dword ptr [0x8665b4], ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D80C: ret  */

}

void sub_0077D810(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D810u);

L_0077D810:
    PUSH32(esp, 0x00781FD0u); /* 0x0077D810: push 0x781fd0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D815: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D81A: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D81B: ret  */

}

void sub_0077D820(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D820u);

L_0077D820:
    PUSH32(esp, 0x0078C13Cu); /* 0x0077D820: push 0x78c13c */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077D825: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077D82A: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x865598) = eax; /* 0x0077D82D: mov dword ptr [0x865598], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D832: ret  */

}

void sub_0077D840(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D840u);

L_0077D840:
    ecx = 0x0086519Cu; /* 0x0077D840: mov ecx, 0x86519c */
    RECOMP_CALL(sub_00570FA0); /* 0x0077D845: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782140u); /* 0x0077D84A: push 0x782140 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D84F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D854: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D855: ret  */

}

void sub_0077D860(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D860u);

L_0077D860:
    ecx = 0x0086555Cu; /* 0x0077D860: mov ecx, 0x86555c */
    RECOMP_CALL(sub_00570FA0); /* 0x0077D865: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782160u); /* 0x0077D86A: push 0x782160 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D86F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D874: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D875: ret  */

}

void sub_0077D880(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D880u);

L_0077D880:
    ecx = 0x00865564u; /* 0x0077D880: mov ecx, 0x865564 */
    RECOMP_CALL(sub_0057AEE0); /* 0x0077D885: call 0x57aee0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782170u); /* 0x0077D88A: push 0x782170 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D88F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D894: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D895: ret  */

}

void sub_0077D8A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D8A0u);

L_0077D8A0:
    PUSH32(esp, 0x005792C0u); /* 0x0077D8A0: push 0x5792c0 */
    PUSH32(esp, 0x005792B0u); /* 0x0077D8A5: push 0x5792b0 */
    PUSH32(esp, 0x00039100u); /* 0x0077D8AA: push 0x39100 */
    ecx = 0x0086596Cu; /* 0x0077D8AF: mov ecx, 0x86596c */
    RECOMP_CALL(sub_0043C110); /* 0x0077D8B4: call 0x43c110 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D8B9: ret  */

}

void sub_0077D8C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D8C0u);

L_0077D8C0:
    PUSH32(esp, 0x005792C0u); /* 0x0077D8C0: push 0x5792c0 */
    PUSH32(esp, 0x005792B0u); /* 0x0077D8C5: push 0x5792b0 */
    PUSH32(esp, 0x00039101u); /* 0x0077D8CA: push 0x39101 */
    ecx = 0x008653A0u; /* 0x0077D8CF: mov ecx, 0x8653a0 */
    RECOMP_CALL(sub_0043C110); /* 0x0077D8D4: call 0x43c110 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D8D9: ret  */

}

void sub_0077D8E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D8E0u);

L_0077D8E0:
    PUSH32(esp, 0x005792C0u); /* 0x0077D8E0: push 0x5792c0 */
    PUSH32(esp, 0x005792B0u); /* 0x0077D8E5: push 0x5792b0 */
    PUSH32(esp, 0x00039102u); /* 0x0077D8EA: push 0x39102 */
    ecx = 0x00865470u; /* 0x0077D8EF: mov ecx, 0x865470 */
    RECOMP_CALL(sub_0043C110); /* 0x0077D8F4: call 0x43c110 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D8F9: ret  */

}

void sub_0077D900(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D900u);

L_0077D900:
    PUSH32(esp, 0x0057C250u); /* 0x0077D900: push 0x57c250 */
    PUSH32(esp, 0x0057C170u); /* 0x0077D905: push 0x57c170 */
    PUSH32(esp, 2); /* 0x0077D90A: push 2 */
    PUSH32(esp, 0x1C8u); /* 0x0077D90C: push 0x1c8 */
    PUSH32(esp, 0x008655A0u); /* 0x0077D911: push 0x8655a0 */
    RECOMP_CALL(sub_0075C39D); /* 0x0077D916: call 0x75c39d */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007821D0u); /* 0x0077D91B: push 0x7821d0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D920: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D925: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D926: ret  */

}

void sub_0077D930(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D930u);

L_0077D930:
    PUSH32(esp, 0x00781FE0u); /* 0x0077D930: push 0x781fe0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D935: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D93A: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D93B: ret  */

}

void sub_0077D940(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D940u);

L_0077D940:
    PUSH32(esp, 0x00781FF0u); /* 0x0077D940: push 0x781ff0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D945: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D94A: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D94B: ret  */

}

void sub_0077D950(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D950u);

L_0077D950:
    PUSH32(esp, 0x00782000u); /* 0x0077D950: push 0x782000 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D955: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D95A: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D95B: ret  */

}

void sub_0077D960(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D960u);

L_0077D960:
    PUSH32(esp, 0x00782010u); /* 0x0077D960: push 0x782010 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D965: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D96A: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D96B: ret  */

}

void sub_0077D970(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D970u);

L_0077D970:
    PUSH32(esp, 0x00782020u); /* 0x0077D970: push 0x782020 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D975: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D97A: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D97B: ret  */

}

void sub_0077D980(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D980u);

L_0077D980:
    PUSH32(esp, 0x00782030u); /* 0x0077D980: push 0x782030 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D985: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D98A: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D98B: ret  */

}

void sub_0077D990(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D990u);

L_0077D990:
    PUSH32(esp, 0x00782040u); /* 0x0077D990: push 0x782040 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D995: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D99A: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D99B: ret  */

}

void sub_0077D9A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D9A0u);

L_0077D9A0:
    PUSH32(esp, 0x00782050u); /* 0x0077D9A0: push 0x782050 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D9A5: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D9AA: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D9AB: ret  */

}

void sub_0077D9B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D9B0u);

L_0077D9B0:
    PUSH32(esp, 0x00782060u); /* 0x0077D9B0: push 0x782060 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D9B5: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D9BA: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D9BB: ret  */

}

void sub_0077D9C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D9C0u);

L_0077D9C0:
    PUSH32(esp, 0x00782070u); /* 0x0077D9C0: push 0x782070 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D9C5: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D9CA: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D9CB: ret  */

}

void sub_0077D9D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D9D0u);

L_0077D9D0:
    PUSH32(esp, 0x00782080u); /* 0x0077D9D0: push 0x782080 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D9D5: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D9DA: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D9DB: ret  */

}

void sub_0077D9E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D9E0u);

L_0077D9E0:
    PUSH32(esp, 0x00782090u); /* 0x0077D9E0: push 0x782090 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D9E5: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D9EA: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D9EB: ret  */

}

void sub_0077D9F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077D9F0u);

L_0077D9F0:
    PUSH32(esp, 0x007820A0u); /* 0x0077D9F0: push 0x7820a0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077D9F5: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077D9FA: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077D9FB: ret  */

}

void sub_0077DA00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DA00u);

L_0077DA00:
    PUSH32(esp, 0x007820B0u); /* 0x0077DA00: push 0x7820b0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077DA05: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077DA0A: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DA0B: ret  */

}

void sub_0077DA10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DA10u);

L_0077DA10:
    PUSH32(esp, 0x007820C0u); /* 0x0077DA10: push 0x7820c0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077DA15: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077DA1A: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DA1B: ret  */

}

void sub_0077DA20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DA20u);

L_0077DA20:
    PUSH32(esp, edi); /* 0x0077DA20: push edi */
    ecx = 0x18u; /* 0x0077DA21: mov ecx, 0x18 */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0077DA26: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    edi = 0x008651B0u; /* 0x0077DA28: mov edi, 0x8651b0 */
    { uint32_t _n = ecx, _b = _n * 4u; /* 0x0077DA2D: rep stosd dword ptr es:[edi], eax */ if (_df > 0) { MEMSET32((void*)ADDR(edi), eax, _n); edi += _b; } else { MEMSET32((void*)ADDR(edi - _b + 4u), eax, _n); edi -= _b; } ecx = 0; }
    edi = POP32_VAL(esp); /* 0x0077DA2F: pop edi */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DA30: ret  */

}

void sub_0077DA40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DA40u);

L_0077DA40:
    PUSH32(esp, 0x004022D0u); /* 0x0077DA40: push 0x4022d0 */
    PUSH32(esp, 0x00572290u); /* 0x0077DA45: push 0x572290 */
    PUSH32(esp, 4); /* 0x0077DA4A: push 4 */
    PUSH32(esp, 0x30u); /* 0x0077DA4C: push 0x30 */
    PUSH32(esp, 0x008653B0u); /* 0x0077DA4E: push 0x8653b0 */
    RECOMP_CALL(sub_0075C39D); /* 0x0077DA53: call 0x75c39d */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007820D0u); /* 0x0077DA58: push 0x7820d0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077DA5D: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077DA62: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DA63: ret  */

}

void sub_0077DA70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DA70u);

L_0077DA70:
    PUSH32(esp, 0x004022D0u); /* 0x0077DA70: push 0x4022d0 */
    PUSH32(esp, 0x00579640u); /* 0x0077DA75: push 0x579640 */
    PUSH32(esp, 2); /* 0x0077DA7A: push 2 */
    PUSH32(esp, 0x20u); /* 0x0077DA7C: push 0x20 */
    PUSH32(esp, 0x00865360u); /* 0x0077DA7E: push 0x865360 */
    RECOMP_CALL(sub_0075C39D); /* 0x0077DA83: call 0x75c39d */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007820F0u); /* 0x0077DA88: push 0x7820f0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077DA8D: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077DA92: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DA93: ret  */

}

void sub_0077DAA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DAA0u);

L_0077DAA0:
    ecx = 0x00865220u; /* 0x0077DAA0: mov ecx, 0x865220 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077DAA5: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782180u); /* 0x0077DAAA: push 0x782180 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077DAAF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077DAB4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DAB5: ret  */

}

void sub_0077DAC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DAC0u);

L_0077DAC0:
    ecx = 0x00865550u; /* 0x0077DAC0: mov ecx, 0x865550 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077DAC5: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782190u); /* 0x0077DACA: push 0x782190 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077DACF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077DAD4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DAD5: ret  */

}

void sub_0077DAE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DAE0u);

L_0077DAE0:
    ecx = 0x00865218u; /* 0x0077DAE0: mov ecx, 0x865218 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077DAE5: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007821F0u); /* 0x0077DAEA: push 0x7821f0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077DAEF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077DAF4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DAF5: ret  */

}

void sub_0077DB00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DB00u);

L_0077DB00:
    ecx = 0x00866584u; /* 0x0077DB00: mov ecx, 0x866584 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077DB05: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782150u); /* 0x0077DB0A: push 0x782150 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077DB0F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077DB14: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DB15: ret  */

}

void sub_0077DB20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DB20u);

L_0077DB20:
    ecx = 0x008652F0u; /* 0x0077DB20: mov ecx, 0x8652f0 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077DB25: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007821A0u); /* 0x0077DB2A: push 0x7821a0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077DB2F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077DB34: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DB35: ret  */

}

void sub_0077DB40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DB40u);

L_0077DB40:
    ecx = 0x00865190u; /* 0x0077DB40: mov ecx, 0x865190 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077DB45: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007821B0u); /* 0x0077DB4A: push 0x7821b0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077DB4F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077DB54: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DB55: ret  */

}

void sub_0077DB60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DB60u);

L_0077DB60:
    eax = MEM32(0x79DD48); /* 0x0077DB60: mov eax, dword ptr [0x79dd48] */
    ecx = MEM32(0x79DD4C); /* 0x0077DB65: mov ecx, dword ptr [0x79dd4c] */
    edx = MEM32(0x79DD50); /* 0x0077DB6B: mov edx, dword ptr [0x79dd50] */
    MEM32(0x7FB8A0) = eax; /* 0x0077DB71: mov dword ptr [0x7fb8a0], eax */
    eax = 3; /* 0x0077DB76: mov eax, 3 */
    MEM32(0x7FB8A4) = eax; /* 0x0077DB7B: mov dword ptr [0x7fb8a4], eax */
    MEM32(0x7FB8B0) = eax; /* 0x0077DB80: mov dword ptr [0x7fb8b0], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0077DB85: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    MEM32(0x7FB8A8) = 0x008A3B24u; /* 0x0077DB87: mov dword ptr [0x7fb8a8], 0x8a3b24 */
    MEM32(0x7FB8AC) = ecx; /* 0x0077DB91: mov dword ptr [0x7fb8ac], ecx */
    MEM32(0x7FB8B4) = 0x008A3B38u; /* 0x0077DB97: mov dword ptr [0x7fb8b4], 0x8a3b38 */
    MEM32(0x7FB8B8) = edx; /* 0x0077DBA1: mov dword ptr [0x7fb8b8], edx */
    MEM32(0x7FB8BC) = 6; /* 0x0077DBA7: mov dword ptr [0x7fb8bc], 6 */
    MEM32(0x7FB8C0) = 0x007FB624u; /* 0x0077DBB1: mov dword ptr [0x7fb8c0], 0x7fb624 */
    MEM32(0x7FB8C4) = eax; /* 0x0077DBBB: mov dword ptr [0x7fb8c4], eax */
    MEM32(0x7FB8C8) = 7; /* 0x0077DBC0: mov dword ptr [0x7fb8c8], 7 */
    MEM32(0x7FB8CC) = eax; /* 0x0077DBCA: mov dword ptr [0x7fb8cc], eax */
    MEM32(0x7FB8D0) = eax; /* 0x0077DBCF: mov dword ptr [0x7fb8d0], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DBD4: ret  */

}

void sub_0077DBE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DBE0u);

L_0077DBE0:
    ecx = 0x00865930u; /* 0x0077DBE0: mov ecx, 0x865930 */
    RECOMP_CALL(sub_005756E0); /* 0x0077DBE5: call 0x5756e0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782110u); /* 0x0077DBEA: push 0x782110 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077DBEF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077DBF4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DBF5: ret  */

}

void sub_0077DC00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DC00u);

L_0077DC00:
    fp_push((double)(int32_t)MEM32(0x7FB70C)); /* 0x0077DC00: fild dword ptr [0x7fb70c] */
    _st[0] *= (double)*(float*)ADDR(0x786460); /* 0x0077DC06: fmul dword ptr [0x786460] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x865198) = _v; } /* 0x0077DC0C: fstp dword ptr [0x865198] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DC12: ret  */

}

void sub_0077DC20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DC20u);

L_0077DC20:
    eax = MEM32(0x7FB710); /* 0x0077DC20: mov eax, dword ptr [0x7fb710] */
    MEM32(0x865558) = eax; /* 0x0077DC25: mov dword ptr [0x865558], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DC2A: ret  */

}

void sub_0077DC30(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DC30u);

L_0077DC30:
    ecx = 0x008652F8u; /* 0x0077DC30: mov ecx, 0x8652f8 */
    RECOMP_CALL(sub_005773A0); /* 0x0077DC35: call 0x5773a0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782120u); /* 0x0077DC3A: push 0x782120 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077DC3F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077DC44: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DC45: ret  */

}

void sub_0077DC50(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DC50u);

L_0077DC50:
    eax = 0x008698DCu; /* 0x0077DC50: mov eax, 0x8698dc */

L_0077DC55:
    MEM8(eax) = (uint8_t)(0); /* 0x0077DC55: mov byte ptr [eax], 0 */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x10u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x10u; /* 0x0077DC58: add eax, 0x10 */
    _flag_k = FK_ADD;
    /* cmp eax, 0x0086993Cu */ /* 0x0077DC5B: cmp eax, 0x86993c */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x0086993Cu);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    _flag_k = FK_CMP;
    RECOMP_BACKEDGE();
    if (CMP_L(_flag_a, _flag_b)) goto L_0077DC55; /* 0x0077DC60: jl 0x77dc55 */

L_0077DC62:
    PUSH32(esp, 0x00782200u); /* 0x0077DC62: push 0x782200 */
    MEM8(0x86993C) = (uint8_t)(0); /* 0x0077DC67: mov byte ptr [0x86993c], 0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077DC6E: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077DC73: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DC74: ret  */

}

void sub_0077DC80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DC80u);

L_0077DC80:
    eax = MEM32(0x7FBDFC); /* 0x0077DC80: mov eax, dword ptr [0x7fbdfc] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(1);
    eax = eax + 1; /* 0x0077DC85: inc eax */
    _flag_k = FK_INC;
    MEM16(0x869674) = (uint16_t)(LO16(eax)); /* 0x0077DC86: mov word ptr [0x869674], ax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DC8C: ret  */

}

void sub_0077DC90(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DC90u);

L_0077DC90:
    PUSH32(esp, 0x00782220u); /* 0x0077DC90: push 0x782220 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077DC95: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077DC9A: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DC9B: ret  */

}

void sub_0077DCA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DCA0u);

L_0077DCA0:
    PUSH32(esp, 0x00782230u); /* 0x0077DCA0: push 0x782230 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077DCA5: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077DCAA: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DCAB: ret  */

}

void sub_0077DCB0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DCB0u);

L_0077DCB0:
    eax = 0x008691E0u; /* 0x0077DCB0: mov eax, 0x8691e0 */
    ecx = 5; /* 0x0077DCB5: mov ecx, 5 */
    ebx = ebx; /* 0x0077DCBA: lea ebx, [ebx] */

L_0077DCC0:
    MEM32(eax) = 0; /* 0x0077DCC0: mov dword ptr [eax], 0 */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x14u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x14u; /* 0x0077DCC6: add eax, 0x14 */
    _flag_k = FK_ADD;
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(1);
    ecx = ecx - 1; /* 0x0077DCC9: dec ecx */
    _flag_k = FK_DEC;
    RECOMP_BACKEDGE();
    if (/* dec result */ CMP_NE(_flag_a, _flag_b)) goto L_0077DCC0; /* 0x0077DCCA: jne 0x77dcc0 */

L_0077DCCC:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DCCC: ret  */

}

void sub_0077DCD0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DCD0u);

L_0077DCD0:
    PUSH32(esp, 0x00782240u); /* 0x0077DCD0: push 0x782240 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077DCD5: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077DCDA: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DCDB: ret  */

}

void sub_0077DCE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DCE0u);

L_0077DCE0:
    PUSH32(esp, 0x00782250u); /* 0x0077DCE0: push 0x782250 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077DCE5: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077DCEA: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DCEB: ret  */

}

void sub_0077DCF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DCF0u);

L_0077DCF0:
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0077DCF0: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    MEM32(0x869074) = eax; /* 0x0077DCF2: mov dword ptr [0x869074], eax */
    MEM32(0x869078) = eax; /* 0x0077DCF7: mov dword ptr [0x869078], eax */
    MEM32(0x86907C) = eax; /* 0x0077DCFC: mov dword ptr [0x86907c], eax */
    MEM32(0x869080) = eax; /* 0x0077DD01: mov dword ptr [0x869080], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DD06: ret  */

}

void sub_0077DD10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DD10u);

L_0077DD10:
    PUSH32(esp, 0x00783FE5u); /* 0x0077DD10: push 0x783fe5 */
    PUSH32(esp, 0x00869088u); /* 0x0077DD15: push 0x869088 */
    RECOMP_CALL(sub_0043DC40); /* 0x0077DD1A: call 0x43dc40 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782260u); /* 0x0077DD1F: push 0x782260 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077DD24: call 0x75c51d */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077DD29: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DD2C: ret  */

}

void sub_0077DD30(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DD30u);

L_0077DD30:
    PUSH32(esp, 0x00782270u); /* 0x0077DD30: push 0x782270 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077DD35: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077DD3A: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DD3B: ret  */

}

void sub_0077DD40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DD40u);

L_0077DD40:
    eax = 0x00866C20u; /* 0x0077DD40: mov eax, 0x866c20 */
    edx = 0x12u; /* 0x0077DD45: mov edx, 0x12 */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    ecx = 0; /* 0x0077DD4A: xor ecx, ecx */
    _cf = 0;
    _flag_k = FK_TEST;
    esp = esp; /* 0x0077DD4C: lea esp, [esp] */

L_0077DD50:
    MEM8(eax + (-0x1F8)) = (uint8_t)(LO8(ecx)); /* 0x0077DD50: mov byte ptr [eax - 0x1f8], cl */
    MEM32(eax + (-0x4)) = ecx; /* 0x0077DD56: mov dword ptr [eax - 4], ecx */
    MEM32(eax) = ecx; /* 0x0077DD59: mov dword ptr [eax], ecx */
    MEM32(eax + 0x4) = ecx; /* 0x0077DD5B: mov dword ptr [eax + 4], ecx */
    MEM32(eax + 0x8) = ecx; /* 0x0077DD5E: mov dword ptr [eax + 8], ecx */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x204u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x204u; /* 0x0077DD61: add eax, 0x204 */
    _flag_k = FK_ADD;
    _flag_a = (uint32_t)(edx); _flag_b = (uint32_t)(1);
    edx = edx - 1; /* 0x0077DD66: dec edx */
    _flag_k = FK_DEC;
    RECOMP_BACKEDGE();
    if (/* dec result */ CMP_NE(_flag_a, _flag_b)) goto L_0077DD50; /* 0x0077DD67: jne 0x77dd50 */

L_0077DD69:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DD69: ret  */

}

void sub_0077DD70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DD70u);

L_0077DD70:
    PUSH32(esp, 0x004022D0u); /* 0x0077DD70: push 0x4022d0 */
    PUSH32(esp, 0x005880A0u); /* 0x0077DD75: push 0x5880a0 */
    PUSH32(esp, 5); /* 0x0077DD7A: push 5 */
    PUSH32(esp, 0x20u); /* 0x0077DD7C: push 0x20 */
    PUSH32(esp, 0x008693C8u); /* 0x0077DD7E: push 0x8693c8 */
    RECOMP_CALL(sub_0075C39D); /* 0x0077DD83: call 0x75c39d */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782280u); /* 0x0077DD88: push 0x782280 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077DD8D: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077DD92: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DD93: ret  */

}

void sub_0077DDA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DDA0u);

L_0077DDA0:
    fp_push(*(float*)&MEM32(0x784250)); /* 0x0077DDA0: fld dword ptr [0x784250] */
    _st[0] /= (double)*(float*)ADDR(0x7A17C4); /* 0x0077DDA6: fdiv dword ptr [0x7a17c4] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x86B4BC) = _v; } /* 0x0077DDAC: fstp dword ptr [0x86b4bc] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DDB2: ret  */

}

void sub_0077DDC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DDC0u);

L_0077DDC0:
    PUSH32(esp, 4); /* 0x0077DDC0: push 4 */
    PUSH32(esp, 0x007FC880u); /* 0x0077DDC2: push 0x7fc880 */
    ecx = 0x0086B3C0u; /* 0x0077DDC7: mov ecx, 0x86b3c0 */
    RECOMP_CALL(sub_005766E0); /* 0x0077DDCC: call 0x5766e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DDD1: ret  */

}

void sub_0077DDE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DDE0u);

L_0077DDE0:
    PUSH32(esp, 4); /* 0x0077DDE0: push 4 */
    PUSH32(esp, 0x007FC8A0u); /* 0x0077DDE2: push 0x7fc8a0 */
    ecx = 0x0086B590u; /* 0x0077DDE7: mov ecx, 0x86b590 */
    RECOMP_CALL(sub_005766E0); /* 0x0077DDEC: call 0x5766e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DDF1: ret  */

}

void sub_0077DE00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DE00u);

L_0077DE00:
    ecx = 0x0086B4C8u; /* 0x0077DE00: mov ecx, 0x86b4c8 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077DE05: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782320u); /* 0x0077DE0A: push 0x782320 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077DE0F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077DE14: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DE15: ret  */

}

void sub_0077DE20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DE20u);

L_0077DE20:
    ecx = 0x0086B490u; /* 0x0077DE20: mov ecx, 0x86b490 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077DE25: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782330u); /* 0x0077DE2A: push 0x782330 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077DE2F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077DE34: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DE35: ret  */

}

void sub_0077DE40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DE40u);

L_0077DE40:
    ecx = 0x0086B5A0u; /* 0x0077DE40: mov ecx, 0x86b5a0 */
    RECOMP_CALL(sub_004EC6D0); /* 0x0077DE45: call 0x4ec6d0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782350u); /* 0x0077DE4A: push 0x782350 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077DE4F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077DE54: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DE55: ret  */

}

void sub_0077DE60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DE60u);

L_0077DE60:
    ecx = 0x0086B598u; /* 0x0077DE60: mov ecx, 0x86b598 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077DE65: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782340u); /* 0x0077DE6A: push 0x782340 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077DE6F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077DE74: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DE75: ret  */

}

void sub_0077DE80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DE80u);

L_0077DE80:
    PUSH32(esp, 3); /* 0x0077DE80: push 3 */
    PUSH32(esp, 0x007FC8C8u); /* 0x0077DE82: push 0x7fc8c8 */
    ecx = 0x0086B578u; /* 0x0077DE87: mov ecx, 0x86b578 */
    RECOMP_CALL(sub_005766E0); /* 0x0077DE8C: call 0x5766e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DE91: ret  */

}

void sub_0077DEA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DEA0u);

L_0077DEA0:
    PUSH32(esp, 3); /* 0x0077DEA0: push 3 */
    PUSH32(esp, 0x007FC8E0u); /* 0x0077DEA2: push 0x7fc8e0 */
    ecx = 0x0086B498u; /* 0x0077DEA7: mov ecx, 0x86b498 */
    RECOMP_CALL(sub_005766E0); /* 0x0077DEAC: call 0x5766e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DEB1: ret  */

}

void sub_0077DEC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DEC0u);

L_0077DEC0:
    MEM32(0x86B4A8) = 0x3DB2B8C2u; /* 0x0077DEC0: mov dword ptr [0x86b4a8], 0x3db2b8c2 */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DECA: ret  */

}

void sub_0077DED0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DED0u);

L_0077DED0:
    PUSH32(esp, 3); /* 0x0077DED0: push 3 */
    PUSH32(esp, 0x007FC8F8u); /* 0x0077DED2: push 0x7fc8f8 */
    ecx = 0x0086B4A0u; /* 0x0077DED7: mov ecx, 0x86b4a0 */
    RECOMP_CALL(sub_005766E0); /* 0x0077DEDC: call 0x5766e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DEE1: ret  */

}

void sub_0077DEF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DEF0u);

L_0077DEF0:
    MEM32(0x86B5E8) = 0; /* 0x0077DEF0: mov dword ptr [0x86b5e8], 0 */
    MEM32(0x86B5EC) = 0; /* 0x0077DEFA: mov dword ptr [0x86b5ec], 0 */
    MEM32(0x86B5F0) = 0x3E860A92u; /* 0x0077DF04: mov dword ptr [0x86b5f0], 0x3e860a92 */
    MEM32(0x86B5F4) = 0x3DCCCCCDu; /* 0x0077DF0E: mov dword ptr [0x86b5f4], 0x3dcccccd */
    MEM32(0x86B5F8) = 0x3F060A92u; /* 0x0077DF18: mov dword ptr [0x86b5f8], 0x3f060a92 */
    MEM32(0x86B5FC) = 0x3EE66666u; /* 0x0077DF22: mov dword ptr [0x86b5fc], 0x3ee66666 */
    MEM32(0x86B600) = 0x3F490FDBu; /* 0x0077DF2C: mov dword ptr [0x86b600], 0x3f490fdb */
    MEM32(0x86B604) = 0x3F59999Au; /* 0x0077DF36: mov dword ptr [0x86b604], 0x3f59999a */
    MEM32(0x86B608) = 0x3F860A92u; /* 0x0077DF40: mov dword ptr [0x86b608], 0x3f860a92 */
    MEM32(0x86B60C) = 0x3F733333u; /* 0x0077DF4A: mov dword ptr [0x86b60c], 0x3f733333 */
    MEM32(0x86B610) = 0x3FC6D3F2u; /* 0x0077DF54: mov dword ptr [0x86b610], 0x3fc6d3f2 */
    MEM32(0x86B614) = 0x3F933333u; /* 0x0077DF5E: mov dword ptr [0x86b614], 0x3f933333 */
    MEM32(0x86B618) = 0x3FC90FDBu; /* 0x0077DF68: mov dword ptr [0x86b618], 0x3fc90fdb */
    MEM32(0x86B61C) = 0x3F800000u; /* 0x0077DF72: mov dword ptr [0x86b61c], 0x3f800000 */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077DF7C: ret  */

}

void sub_0077DF80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077DF80u);

L_0077DF80:
    MEM32(0x86B5B0) = 0; /* 0x0077DF80: mov dword ptr [0x86b5b0], 0 */
    MEM32(0x86B5B4) = 0; /* 0x0077DF8A: mov dword ptr [0x86b5b4], 0 */
    MEM32(0x86B5B8) = 0x3E860A92u; /* 0x0077DF94: mov dword ptr [0x86b5b8], 0x3e860a92 */
    MEM32(0x86B5BC) = 0x3DCCCCCDu; /* 0x0077DF9E: mov dword ptr [0x86b5bc], 0x3dcccccd */
    MEM32(0x86B5C0) = 0x3F060A92u; /* 0x0077DFA8: mov dword ptr [0x86b5c0], 0x3f060a92 */
    MEM32(0x86B5C4) = 0x3EE66666u; /* 0x0077DFB2: mov dword ptr [0x86b5c4], 0x3ee66666 */
    MEM32(0x86B5C8) = 0x3F490FDBu; /* 0x0077DFBC: mov dword ptr [0x86b5c8], 0x3f490fdb */
    MEM32(0x86B5CC) = 0x3F59999Au; /* 0x0077DFC6: mov dword ptr [0x86b5cc], 0x3f59999a */
    MEM32(0x86B5D0) = 0x3F860A92u; /* 0x0077DFD0: mov dword ptr [0x86b5d0], 0x3f860a92 */
    MEM32(0x86B5D4) = 0x3F733333u; /* 0x0077DFDA: mov dword ptr [0x86b5d4], 0x3f733333 */
    MEM32(0x86B5D8) = 0x3FC6D3F2u; /* 0x0077DFE4: mov dword ptr [0x86b5d8], 0x3fc6d3f2 */
    MEM32(0x86B5DC) = 0x3F933333u; /* 0x0077DFEE: mov dword ptr [0x86b5dc], 0x3f933333 */
    MEM32(0x86B5E0) = 0x3FC90FDBu; /* 0x0077DFF8: mov dword ptr [0x86b5e0], 0x3fc90fdb */
    MEM32(0x86B5E4) = 0; /* 0x0077E002: mov dword ptr [0x86b5e4], 0 */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E00C: ret  */

}

void sub_0077E010(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E010u);

L_0077E010:
    MEM32(0x86B570) = 0x0086B5E8u; /* 0x0077E010: mov dword ptr [0x86b570], 0x86b5e8 */
    MEM32(0x86B574) = 7; /* 0x0077E01A: mov dword ptr [0x86b574], 7 */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E024: ret  */

}

void sub_0077E030(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E030u);

L_0077E030:
    MEM32(0x86B3C8) = 0x0086B5B0u; /* 0x0077E030: mov dword ptr [0x86b3c8], 0x86b5b0 */
    MEM32(0x86B3CC) = 7; /* 0x0077E03A: mov dword ptr [0x86b3cc], 7 */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E044: ret  */

}

void sub_0077E050(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E050u);

L_0077E050:
    ecx = 0x0086B3D0u; /* 0x0077E050: mov ecx, 0x86b3d0 */
    RECOMP_ITAIL(0x00591130u); RECOMP_RETURN(); /* 0x0077E055: jmp 0x591130 */

}

void sub_0077E060(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E060u);

L_0077E060:
    MEM32(0x86B510) = 0x3E64C388u; /* 0x0077E060: mov dword ptr [0x86b510], 0x3e64c388 */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E06A: ret  */

}

void sub_0077E070(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E070u);

L_0077E070:
    eax = MEM32(0x86B510); /* 0x0077E070: mov eax, dword ptr [0x86b510] */
    MEM32(0x7FC95C) = eax; /* 0x0077E075: mov dword ptr [0x7fc95c], eax */
    fp_push(*(float*)&MEM32(0x7FC95C)); /* 0x0077E07A: fld dword ptr [0x7fc95c] */
    _st[0] = (double)*(float*)ADDR(0x7859D0) / _st[0]; /* 0x0077E080: fdivr dword ptr [0x7859d0] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x7FC960) = _v; } /* 0x0077E086: fstp dword ptr [0x7fc960] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E08C: ret  */

}

void sub_0077E090(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E090u);

L_0077E090:
    ecx = 0x0086B5A8u; /* 0x0077E090: mov ecx, 0x86b5a8 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077E095: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782370u); /* 0x0077E09A: push 0x782370 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E09F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E0A4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E0A5: ret  */

}

void sub_0077E0B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E0B0u);

L_0077E0B0:
    ecx = 0x0086B4C0u; /* 0x0077E0B0: mov ecx, 0x86b4c0 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077E0B5: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782360u); /* 0x0077E0BA: push 0x782360 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E0BF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E0C4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E0C5: ret  */

}

void sub_0077E0D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E0D0u);

L_0077E0D0:
    PUSH32(esp, 0x005A8B00u); /* 0x0077E0D0: push 0x5a8b00 */
    PUSH32(esp, 0x005B0DD0u); /* 0x0077E0D5: push 0x5b0dd0 */
    PUSH32(esp, 0x00034026u); /* 0x0077E0DA: push 0x34026 */
    ecx = 0x0086B580u; /* 0x0077E0DF: mov ecx, 0x86b580 */
    RECOMP_CALL(sub_0043C110); /* 0x0077E0E4: call 0x43c110 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E0E9: ret  */

}

void sub_0077E0F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E0F0u);

L_0077E0F0:
    PUSH32(esp, 0x005A8B00u); /* 0x0077E0F0: push 0x5a8b00 */
    PUSH32(esp, 0x005B0DD0u); /* 0x0077E0F5: push 0x5b0dd0 */
    PUSH32(esp, 0x00034027u); /* 0x0077E0FA: push 0x34027 */
    ecx = 0x0086B4ACu; /* 0x0077E0FF: mov ecx, 0x86b4ac */
    RECOMP_CALL(sub_0043C110); /* 0x0077E104: call 0x43c110 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E109: ret  */

}

void sub_0077E110(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E110u);

L_0077E110:
    fp_push(*(float*)&MEM32(0x784250)); /* 0x0077E110: fld dword ptr [0x784250] */
    _st[0] /= (double)*(float*)ADDR(0x7A279C); /* 0x0077E116: fdiv dword ptr [0x7a279c] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x872B40) = _v; } /* 0x0077E11C: fstp dword ptr [0x872b40] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E122: ret  */

}

void sub_0077E130(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E130u);

L_0077E130:
    PUSH32(esp, 0x005B7FA0u); /* 0x0077E130: push 0x5b7fa0 */
    PUSH32(esp, 0x005C0F70u); /* 0x0077E135: push 0x5c0f70 */
    PUSH32(esp, 6); /* 0x0077E13A: push 6 */
    PUSH32(esp, 0x370u); /* 0x0077E13C: push 0x370 */
    PUSH32(esp, 0x00874C40u); /* 0x0077E141: push 0x874c40 */
    RECOMP_CALL(sub_0075C39D); /* 0x0077E146: call 0x75c39d */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007823B0u); /* 0x0077E14B: push 0x7823b0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E150: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E155: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E156: ret  */

}

void sub_0077E160(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E160u);

L_0077E160:
    ecx = 0x00872B4Cu; /* 0x0077E160: mov ecx, 0x872b4c */
    RECOMP_CALL(sub_00570FA0); /* 0x0077E165: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007823E0u); /* 0x0077E16A: push 0x7823e0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E16F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E174: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E175: ret  */

}

void sub_0077E180(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E180u);

L_0077E180:
    ecx = 0x008763B0u; /* 0x0077E180: mov ecx, 0x8763b0 */
    RECOMP_CALL(sub_004EC6D0); /* 0x0077E185: call 0x4ec6d0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007823F0u); /* 0x0077E18A: push 0x7823f0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E18F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E194: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E195: ret  */

}

void sub_0077E1A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E1A0u);

L_0077E1A0:
    ecx = 0x00872C00u; /* 0x0077E1A0: mov ecx, 0x872c00 */
    RECOMP_ITAIL(0x0044F590u); RECOMP_RETURN(); /* 0x0077E1A5: jmp 0x44f590 */

}

void sub_0077E1B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E1B0u);

L_0077E1B0:
    ecx = 0x008760E0u; /* 0x0077E1B0: mov ecx, 0x8760e0 */
    RECOMP_ITAIL(0x0044F590u); RECOMP_RETURN(); /* 0x0077E1B5: jmp 0x44f590 */

}

void sub_0077E1C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E1C0u);

L_0077E1C0:
    ecx = 0x00872F20u; /* 0x0077E1C0: mov ecx, 0x872f20 */
    RECOMP_ITAIL(0x0044F590u); RECOMP_RETURN(); /* 0x0077E1C5: jmp 0x44f590 */

}

void sub_0077E1D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E1D0u);

L_0077E1D0:
    ecx = 0x008718C0u; /* 0x0077E1D0: mov ecx, 0x8718c0 */
    RECOMP_ITAIL(0x0044F590u); RECOMP_RETURN(); /* 0x0077E1D5: jmp 0x44f590 */

}

void sub_0077E1E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E1E0u);

L_0077E1E0:
    ecx = 0x00870A20u; /* 0x0077E1E0: mov ecx, 0x870a20 */
    RECOMP_ITAIL(0x0044F590u); RECOMP_RETURN(); /* 0x0077E1E5: jmp 0x44f590 */

}

void sub_0077E1F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E1F0u);

L_0077E1F0:
    PUSH32(esp, esi); /* 0x0077E1F0: push esi */
    PUSH32(esp, edi); /* 0x0077E1F1: push edi */
    esi = 0x00871BE0u; /* 0x0077E1F2: mov esi, 0x871be0 */
    edi = 6; /* 0x0077E1F7: mov edi, 6 */
    esp = esp; /* 0x0077E1FC: lea esp, [esp] */

L_0077E200:
    ecx = esi; /* 0x0077E200: mov ecx, esi */
    RECOMP_CALL(sub_0044F590); /* 0x0077E202: call 0x44f590 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esi); _flag_b = (uint32_t)(0x290u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esi = esi + 0x290u; /* 0x0077E207: add esi, 0x290 */
    _flag_k = FK_ADD;
    _flag_a = (uint32_t)(edi); _flag_b = (uint32_t)(1);
    edi = edi - 1; /* 0x0077E20D: dec edi */
    _flag_k = FK_DEC;
    RECOMP_BACKEDGE();
    if (/* dec result */ CMP_NE(_flag_a, _flag_b)) goto L_0077E200; /* 0x0077E20E: jne 0x77e200 */

L_0077E210:
    edi = POP32_VAL(esp); /* 0x0077E210: pop edi */
    esi = POP32_VAL(esp); /* 0x0077E211: pop esi */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E212: ret  */

}

void sub_0077E220(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E220u);

L_0077E220:
    MEM16(0x871B90) = (uint16_t)(0x4000u); /* 0x0077E220: mov word ptr [0x871b90], 0x4000 */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E229: ret  */

}

void sub_0077E230(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E230u);

L_0077E230:
    fp_push(*(float*)&MEM32(0x784250)); /* 0x0077E230: fld dword ptr [0x784250] */
    _st[0] /= (double)*(float*)ADDR(0x7A27D0); /* 0x0077E236: fdiv dword ptr [0x7a27d0] */
    fp_push(*(float*)&MEM32(0x784560)); /* 0x0077E23C: fld dword ptr [0x784560] */
    _st[0] *= _st[1]; /* 0x0077E242: fmul st(1) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x876540) = _v; } /* 0x0077E244: fstp dword ptr [0x876540] */
    fp_push(*(float*)&MEM32(0x7A2388)); /* 0x0077E24A: fld dword ptr [0x7a2388] */
    _st[0] *= _st[1]; /* 0x0077E250: fmul st(1) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x876544) = _v; } /* 0x0077E252: fstp dword ptr [0x876544] */
    fp_push(*(float*)&MEM32(0x78821C)); /* 0x0077E258: fld dword ptr [0x78821c] */
    _st[0] *= _st[1]; /* 0x0077E25E: fmul st(1) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x876548) = _v; } /* 0x0077E260: fstp dword ptr [0x876548] */
    fp_push(*(float*)&MEM32(0x7881FC)); /* 0x0077E266: fld dword ptr [0x7881fc] */
    _st[0] *= _st[1]; /* 0x0077E26C: fmul st(1) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x87654C) = _v; } /* 0x0077E26E: fstp dword ptr [0x87654c] */
    fp_push(*(float*)&MEM32(0x7A45F8)); /* 0x0077E274: fld dword ptr [0x7a45f8] */
    _st[0] *= _st[1]; /* 0x0077E27A: fmul st(1) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x876550) = _v; } /* 0x0077E27C: fstp dword ptr [0x876550] */
    fp_push(*(float*)&MEM32(0x787AF4)); /* 0x0077E282: fld dword ptr [0x787af4] */
    _st[0] *= _st[1]; /* 0x0077E288: fmul st(1) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x876554) = _v; } /* 0x0077E28A: fstp dword ptr [0x876554] */
    fp_push(*(float*)&MEM32(0x79C684)); /* 0x0077E290: fld dword ptr [0x79c684] */
    _st[0] *= _st[1]; /* 0x0077E296: fmul st(1) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x876558) = _v; } /* 0x0077E298: fstp dword ptr [0x876558] */
    fp_push(*(float*)&MEM32(0x7A45F4)); /* 0x0077E29E: fld dword ptr [0x7a45f4] */
    _st[0] *= _st[1]; /* 0x0077E2A4: fmul st(1) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x87655C) = _v; } /* 0x0077E2A6: fstp dword ptr [0x87655c] */
    fp_push(*(float*)&MEM32(0x78F9DC)); /* 0x0077E2AC: fld dword ptr [0x78f9dc] */
    _st[0] *= _st[1]; /* 0x0077E2B2: fmul st(1) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x876560) = _v; } /* 0x0077E2B4: fstp dword ptr [0x876560] */
    fp_push(*(float*)&MEM32(0x7A45F0)); /* 0x0077E2BA: fld dword ptr [0x7a45f0] */
    _st[0] *= _st[1]; /* 0x0077E2C0: fmul st(1) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x876564) = _v; } /* 0x0077E2C2: fstp dword ptr [0x876564] */
    fp_push(*(float*)&MEM32(0x7850D8)); /* 0x0077E2C8: fld dword ptr [0x7850d8] */
    _st[0] *= _st[1]; /* 0x0077E2CE: fmul st(1) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x876568) = _v; } /* 0x0077E2D0: fstp dword ptr [0x876568] */
    fp_push(*(float*)&MEM32(0x7A45EC)); /* 0x0077E2D6: fld dword ptr [0x7a45ec] */
    _st[0] *= _st[1]; /* 0x0077E2DC: fmul st(1) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x87656C) = _v; } /* 0x0077E2DE: fstp dword ptr [0x87656c] */
    fp_push(*(float*)&MEM32(0x7881F8)); /* 0x0077E2E4: fld dword ptr [0x7881f8] */
    _st[0] *= _st[1]; /* 0x0077E2EA: fmul st(1) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x876570) = _v; } /* 0x0077E2EC: fstp dword ptr [0x876570] */
    fp_push(*(float*)&MEM32(0x7844E0)); /* 0x0077E2F2: fld dword ptr [0x7844e0] */
    _st[0] *= _st[1]; /* 0x0077E2F8: fmul st(1) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x876574) = _v; } /* 0x0077E2FA: fstp dword ptr [0x876574] */
    fp_push(*(float*)&MEM32(0x7881F0)); /* 0x0077E300: fld dword ptr [0x7881f0] */
    _st[0] *= _st[1]; /* 0x0077E306: fmul st(1) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x876578) = _v; } /* 0x0077E308: fstp dword ptr [0x876578] */
    fp_push(*(float*)&MEM32(0x78B018)); /* 0x0077E30E: fld dword ptr [0x78b018] */
    _st[0] *= _st[1]; /* 0x0077E314: fmul st(1) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x87657C) = _v; } /* 0x0077E316: fstp dword ptr [0x87657c] */
    fp_push(*(float*)&MEM32(0x7843E8)); /* 0x0077E31C: fld dword ptr [0x7843e8] */
    _st[0] *= _st[1]; /* 0x0077E322: fmul st(1) */
    { float _v = (float)_st[0]; *(float*)ADDR(0x876580) = _v; } /* 0x0077E324: fst dword ptr [0x876580] */
    fp_push(_st[1]); /* 0x0077E32A: fld st(1) */
    _st[0] *= (double)*(float*)ADDR(0x7859D0); /* 0x0077E32C: fmul dword ptr [0x7859d0] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x876584) = _v; } /* 0x0077E332: fstp dword ptr [0x876584] */
    fp_push(_st[1]); /* 0x0077E338: fld st(1) */
    _st[0] *= (double)*(float*)ADDR(0x788220); /* 0x0077E33A: fmul dword ptr [0x788220] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x876588) = _v; } /* 0x0077E340: fstp dword ptr [0x876588] */
    fp_push(_st[1]); /* 0x0077E346: fld st(1) */
    _st[0] *= (double)*(float*)ADDR(0x7881F4); /* 0x0077E348: fmul dword ptr [0x7881f4] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x87658C) = _v; } /* 0x0077E34E: fstp dword ptr [0x87658c] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x876590) = _v; } /* 0x0077E354: fstp dword ptr [0x876590] */
    fp_push(*(float*)&MEM32(0x7844F8)); /* 0x0077E35A: fld dword ptr [0x7844f8] */
    _st[0] *= _st[1]; /* 0x0077E360: fmul st(1) */
    { float _v = (float)_st[0]; *(float*)ADDR(0x876594) = _v; } /* 0x0077E362: fst dword ptr [0x876594] */
    fp_push(_st[1]); /* 0x0077E368: fld st(1) */
    _st[0] *= (double)*(float*)ADDR(0x787ADC); /* 0x0077E36A: fmul dword ptr [0x787adc] */
    { float _v = (float)_st[0]; *(float*)ADDR(0x876598) = _v; } /* 0x0077E370: fst dword ptr [0x876598] */
    fp_push(_st[2]); /* 0x0077E376: fld st(2) */
    _st[0] += _st[0]; /* 0x0077E378: fadd st(0), st(0) */
    { float _v = (float)_st[0]; *(float*)ADDR(0x87659C) = _v; } /* 0x0077E37A: fst dword ptr [0x87659c] */
    fp_push(_st[3]); /* 0x0077E380: fld st(3) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8765A0) = _v; } /* 0x0077E382: fstp dword ptr [0x8765a0] */
    fp_xch(3); /* 0x0077E388: fxch st(3) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8765A4) = _v; } /* 0x0077E38A: fstp dword ptr [0x8765a4] */
    fp_xch(2); /* 0x0077E390: fxch st(2) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8765A8) = _v; } /* 0x0077E392: fstp dword ptr [0x8765a8] */
    fp_xch(1); /* 0x0077E398: fxch st(1) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8765AC) = _v; } /* 0x0077E39A: fstp dword ptr [0x8765ac] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8765B0) = _v; } /* 0x0077E3A0: fstp dword ptr [0x8765b0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E3A6: ret  */

}

void sub_0077E3B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E3B0u);

L_0077E3B0:
    PUSH32(esp, 0x00782380u); /* 0x0077E3B0: push 0x782380 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E3B5: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E3BA: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E3BB: ret  */

}

void sub_0077E3C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E3C0u);

L_0077E3C0:
    ecx = 0x00872ED0u; /* 0x0077E3C0: mov ecx, 0x872ed0 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077E3C5: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782400u); /* 0x0077E3CA: push 0x782400 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E3CF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E3D4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E3D5: ret  */

}

void sub_0077E3E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E3E0u);

L_0077E3E0:
    ecx = 0x00872B44u; /* 0x0077E3E0: mov ecx, 0x872b44 */
    RECOMP_CALL(sub_004EC6D0); /* 0x0077E3E5: call 0x4ec6d0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782410u); /* 0x0077E3EA: push 0x782410 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E3EF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E3F4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E3F5: ret  */

}

void sub_0077E400(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E400u);

L_0077E400:
    ecx = 0x00870D28u; /* 0x0077E400: mov ecx, 0x870d28 */
    RECOMP_CALL(sub_004EC6D0); /* 0x0077E405: call 0x4ec6d0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782420u); /* 0x0077E40A: push 0x782420 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E40F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E414: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E415: ret  */

}

void sub_0077E420(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E420u);

L_0077E420:
    PUSH32(esp, 0x007A45FCu); /* 0x0077E420: push 0x7a45fc */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077E425: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077E42A: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x870A18) = eax; /* 0x0077E42D: mov dword ptr [0x870a18], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E432: ret  */

}

void sub_0077E440(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E440u);

L_0077E440:
    PUSH32(esp, 0x007A460Cu); /* 0x0077E440: push 0x7a460c */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077E445: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077E44A: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x8764C0) = eax; /* 0x0077E44D: mov dword ptr [0x8764c0], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E452: ret  */

}

void sub_0077E460(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E460u);

L_0077E460:
    PUSH32(esp, 0x005CF3C0u); /* 0x0077E460: push 0x5cf3c0 */
    PUSH32(esp, 0x005CF3A0u); /* 0x0077E465: push 0x5cf3a0 */
    PUSH32(esp, 0x10u); /* 0x0077E46A: push 0x10 */
    PUSH32(esp, 0xB8u); /* 0x0077E46C: push 0xb8 */
    PUSH32(esp, 0x00870D30u); /* 0x0077E471: push 0x870d30 */
    RECOMP_CALL(sub_0075C39D); /* 0x0077E476: call 0x75c39d */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782430u); /* 0x0077E47B: push 0x782430 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E480: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E485: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E486: ret  */

}

void sub_0077E490(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E490u);

L_0077E490:
    ecx = 0x00870CB0u; /* 0x0077E490: mov ecx, 0x870cb0 */
    RECOMP_ITAIL(0x005B75A0u); RECOMP_RETURN(); /* 0x0077E495: jmp 0x5b75a0 */

}

void sub_0077E4A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E4A0u);

L_0077E4A0:
    ecx = 0x008764C8u; /* 0x0077E4A0: mov ecx, 0x8764c8 */
    RECOMP_ITAIL(0x005B75A0u); RECOMP_RETURN(); /* 0x0077E4A5: jmp 0x5b75a0 */

}

void sub_0077E4B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E4B0u);

L_0077E4B0:
    PUSH32(esp, 0x00782390u); /* 0x0077E4B0: push 0x782390 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E4B5: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E4BA: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E4BB: ret  */

}

void sub_0077E4C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E4C0u);

L_0077E4C0:
    ecx = 0x008763D0u; /* 0x0077E4C0: mov ecx, 0x8763d0 */
    RECOMP_CALL(sub_005C8550); /* 0x0077E4C5: call 0x5c8550 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007823A0u); /* 0x0077E4CA: push 0x7823a0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E4CF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E4D4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E4D5: ret  */

}

void sub_0077E4E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E4E0u);

L_0077E4E0:
    ecx = 0x00871B94u; /* 0x0077E4E0: mov ecx, 0x871b94 */
    RECOMP_CALL(sub_0048B720); /* 0x0077E4E5: call 0x48b720 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007823D0u); /* 0x0077E4EA: push 0x7823d0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E4EF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E4F4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E4F5: ret  */

}

void sub_0077E500(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E500u);

L_0077E500:
    fp_push(*(float*)&MEM32(0x784250)); /* 0x0077E500: fld dword ptr [0x784250] */
    _st[0] /= (double)*(float*)ADDR(0x7A4628); /* 0x0077E506: fdiv dword ptr [0x7a4628] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x88EA70) = _v; } /* 0x0077E50C: fstp dword ptr [0x88ea70] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E512: ret  */

}

void sub_0077E520(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E520u);

L_0077E520:
    ecx = 0x0088EA68u; /* 0x0077E520: mov ecx, 0x88ea68 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077E525: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007824C0u); /* 0x0077E52A: push 0x7824c0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E52F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E534: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E535: ret  */

}

void sub_0077E540(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E540u);

L_0077E540:
    ecx = 0x0088FF98u; /* 0x0077E540: mov ecx, 0x88ff98 */
    RECOMP_CALL(sub_004EC6D0); /* 0x0077E545: call 0x4ec6d0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782540u); /* 0x0077E54A: push 0x782540 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E54F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E554: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E555: ret  */

}

void sub_0077E560(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E560u);

L_0077E560:
    ecx = 0x0088F270u; /* 0x0077E560: mov ecx, 0x88f270 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077E565: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782550u); /* 0x0077E56A: push 0x782550 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E56F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E574: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E575: ret  */

}

void sub_0077E580(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E580u);

L_0077E580:
    ecx = 0x0088F1BCu; /* 0x0077E580: mov ecx, 0x88f1bc */
    RECOMP_CALL(sub_00570FA0); /* 0x0077E585: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007825D0u); /* 0x0077E58A: push 0x7825d0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E58F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E594: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E595: ret  */

}

void sub_0077E5A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E5A0u);

L_0077E5A0:
    ecx = 0x0088F748u; /* 0x0077E5A0: mov ecx, 0x88f748 */
    RECOMP_CALL(sub_004EC6D0); /* 0x0077E5A5: call 0x4ec6d0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782450u); /* 0x0077E5AA: push 0x782450 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E5AF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E5B4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E5B5: ret  */

}

void sub_0077E5C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E5C0u);

L_0077E5C0:
    ecx = 0x0088EA8Cu; /* 0x0077E5C0: mov ecx, 0x88ea8c */
    RECOMP_CALL(sub_00570FA0); /* 0x0077E5C5: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007824D0u); /* 0x0077E5CA: push 0x7824d0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E5CF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E5D4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E5D5: ret  */

}

void sub_0077E5E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E5E0u);

L_0077E5E0:
    ecx = 0x0088F768u; /* 0x0077E5E0: mov ecx, 0x88f768 */
    RECOMP_CALL(sub_005E81C0); /* 0x0077E5E5: call 0x5e81c0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782600u); /* 0x0077E5EA: push 0x782600 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E5EF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E5F4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E5F5: ret  */

}

void sub_0077E600(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E600u);

L_0077E600:
    PUSH32(esp, 0x005E8650u); /* 0x0077E600: push 0x5e8650 */
    PUSH32(esp, 0x005E81B0u); /* 0x0077E605: push 0x5e81b0 */
    PUSH32(esp, 0x80034130u); /* 0x0077E60A: push 0x80034130 */
    ecx = 0x0088A2ACu; /* 0x0077E60F: mov ecx, 0x88a2ac */
    RECOMP_CALL(sub_0043C110); /* 0x0077E614: call 0x43c110 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E619: ret  */

}

void sub_0077E620(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E620u);

L_0077E620:
    PUSH32(esp, 0x005E8650u); /* 0x0077E620: push 0x5e8650 */
    PUSH32(esp, 0x005E81B0u); /* 0x0077E625: push 0x5e81b0 */
    PUSH32(esp, 0x0003412Fu); /* 0x0077E62A: push 0x3412f */
    ecx = 0x0088E9ECu; /* 0x0077E62F: mov ecx, 0x88e9ec */
    RECOMP_CALL(sub_0043C110); /* 0x0077E634: call 0x43c110 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E639: ret  */

}

void sub_0077E640(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E640u);

L_0077E640:
    ecx = 0x0088F740u; /* 0x0077E640: mov ecx, 0x88f740 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077E645: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782560u); /* 0x0077E64A: push 0x782560 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E64F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E654: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E655: ret  */

}

void sub_0077E660(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E660u);

L_0077E660:
    PUSH32(esp, 0x005D84C0u); /* 0x0077E660: push 0x5d84c0 */
    PUSH32(esp, 0x005D8460u); /* 0x0077E665: push 0x5d8460 */
    PUSH32(esp, 0x00034146u); /* 0x0077E66A: push 0x34146 */
    ecx = 0x0088EAC4u; /* 0x0077E66F: mov ecx, 0x88eac4 */
    RECOMP_CALL(sub_0043C110); /* 0x0077E674: call 0x43c110 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E679: ret  */

}

void sub_0077E680(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E680u);

L_0077E680:
    PUSH32(esp, 0x005D3EC0u); /* 0x0077E680: push 0x5d3ec0 */
    PUSH32(esp, 0x005D3E80u); /* 0x0077E685: push 0x5d3e80 */
    PUSH32(esp, 0x00034201u); /* 0x0077E68A: push 0x34201 */
    ecx = 0x0088F750u; /* 0x0077E68F: mov ecx, 0x88f750 */
    RECOMP_CALL(sub_0043C110); /* 0x0077E694: call 0x43c110 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E699: ret  */

}

void sub_0077E6A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E6A0u);

L_0077E6A0:
    ecx = 0x0088A320u; /* 0x0077E6A0: mov ecx, 0x88a320 */
    RECOMP_CALL(sub_005E3F80); /* 0x0077E6A5: call 0x5e3f80 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007825E0u); /* 0x0077E6AA: push 0x7825e0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E6AF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E6B4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E6B5: ret  */

}

void sub_0077E6C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E6C0u);

L_0077E6C0:
    ecx = 0x0088F298u; /* 0x0077E6C0: mov ecx, 0x88f298 */
    RECOMP_CALL(sub_005E08A0); /* 0x0077E6C5: call 0x5e08a0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782570u); /* 0x0077E6CA: push 0x782570 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E6CF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E6D4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E6D5: ret  */

}

void sub_0077E6E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E6E0u);

L_0077E6E0:
    PUSH32(esp, 0x005DEDF0u); /* 0x0077E6E0: push 0x5dedf0 */
    PUSH32(esp, 0x005DA480u); /* 0x0077E6E5: push 0x5da480 */
    PUSH32(esp, 0x80034147u); /* 0x0077E6EA: push 0x80034147 */
    ecx = 0x0088E9CCu; /* 0x0077E6EF: mov ecx, 0x88e9cc */
    RECOMP_CALL(sub_0043C110); /* 0x0077E6F4: call 0x43c110 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E6F9: ret  */

}

void sub_0077E700(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E700u);

L_0077E700:
    ecx = 0x0088EB00u; /* 0x0077E700: mov ecx, 0x88eb00 */
    RECOMP_ITAIL(0x005DEF30u); RECOMP_RETURN(); /* 0x0077E705: jmp 0x5def30 */

}

void sub_0077E710(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E710u);

L_0077E710:
    PUSH32(esp, 0x005E4E50u); /* 0x0077E710: push 0x5e4e50 */
    PUSH32(esp, 0x005DEF20u); /* 0x0077E715: push 0x5def20 */
    PUSH32(esp, 0x00034110u); /* 0x0077E71A: push 0x34110 */
    ecx = 0x0088EAB4u; /* 0x0077E71F: mov ecx, 0x88eab4 */
    RECOMP_CALL(sub_0043C110); /* 0x0077E724: call 0x43c110 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E729: ret  */

}

void sub_0077E730(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E730u);

L_0077E730:
    PUSH32(esp, 0x005E4E50u); /* 0x0077E730: push 0x5e4e50 */
    PUSH32(esp, 0x005DEF20u); /* 0x0077E735: push 0x5def20 */
    PUSH32(esp, 0x00034113u); /* 0x0077E73A: push 0x34113 */
    ecx = 0x0088E9DCu; /* 0x0077E73F: mov ecx, 0x88e9dc */
    RECOMP_CALL(sub_0043C110); /* 0x0077E744: call 0x43c110 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E749: ret  */

}

void sub_0077E750(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E750u);

L_0077E750:
    PUSH32(esp, 0x005E4E50u); /* 0x0077E750: push 0x5e4e50 */
    PUSH32(esp, 0x005DEF20u); /* 0x0077E755: push 0x5def20 */
    PUSH32(esp, 0x00034111u); /* 0x0077E75A: push 0x34111 */
    ecx = 0x0088F27Cu; /* 0x0077E75F: mov ecx, 0x88f27c */
    RECOMP_CALL(sub_0043C110); /* 0x0077E764: call 0x43c110 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E769: ret  */

}

void sub_0077E770(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E770u);

L_0077E770:
    PUSH32(esp, 0x005E4E50u); /* 0x0077E770: push 0x5e4e50 */
    PUSH32(esp, 0x005DEF20u); /* 0x0077E775: push 0x5def20 */
    PUSH32(esp, 0x00034112u); /* 0x0077E77A: push 0x34112 */
    ecx = 0x0088EA74u; /* 0x0077E77F: mov ecx, 0x88ea74 */
    RECOMP_CALL(sub_0043C110); /* 0x0077E784: call 0x43c110 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E789: ret  */

}

void sub_0077E790(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E790u);

L_0077E790:
    ecx = 0x0088EAD4u; /* 0x0077E790: mov ecx, 0x88ead4 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077E795: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782580u); /* 0x0077E79A: push 0x782580 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E79F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E7A4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E7A5: ret  */

}

void sub_0077E7B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E7B0u);

L_0077E7B0:
    ecx = 0x0088F760u; /* 0x0077E7B0: mov ecx, 0x88f760 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077E7B5: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782510u); /* 0x0077E7BA: push 0x782510 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E7BF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E7C4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E7C5: ret  */

}

void sub_0077E7D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E7D0u);

L_0077E7D0:
    PUSH32(esp, 0x005D6410u); /* 0x0077E7D0: push 0x5d6410 */
    PUSH32(esp, 0x005DB2D0u); /* 0x0077E7D5: push 0x5db2d0 */
    PUSH32(esp, 0x00034108u); /* 0x0077E7DA: push 0x34108 */
    ecx = 0x0088EAA4u; /* 0x0077E7DF: mov ecx, 0x88eaa4 */
    RECOMP_CALL(sub_0043C110); /* 0x0077E7E4: call 0x43c110 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E7E9: ret  */

}

void sub_0077E7F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E7F0u);

L_0077E7F0:
    PUSH32(esp, 0x005DFB90u); /* 0x0077E7F0: push 0x5dfb90 */
    PUSH32(esp, 0x005DF890u); /* 0x0077E7F5: push 0x5df890 */
    PUSH32(esp, 0x80034100u); /* 0x0077E7FA: push 0x80034100 */
    ecx = 0x0088E9B4u; /* 0x0077E7FF: mov ecx, 0x88e9b4 */
    RECOMP_CALL(sub_0043C110); /* 0x0077E804: call 0x43c110 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E809: ret  */

}

void sub_0077E810(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E810u);

L_0077E810:
    PUSH32(esp, 0x005DFB90u); /* 0x0077E810: push 0x5dfb90 */
    PUSH32(esp, 0x005DF890u); /* 0x0077E815: push 0x5df890 */
    PUSH32(esp, 0x00034107u); /* 0x0077E81A: push 0x34107 */
    ecx = 0x0088EA94u; /* 0x0077E81F: mov ecx, 0x88ea94 */
    RECOMP_CALL(sub_0043C110); /* 0x0077E824: call 0x43c110 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E829: ret  */

}

void sub_0077E830(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E830u);

L_0077E830:
    ecx = 0x00883E70u; /* 0x0077E830: mov ecx, 0x883e70 */
    RECOMP_CALL(sub_005E6350); /* 0x0077E835: call 0x5e6350 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007825F0u); /* 0x0077E83A: push 0x7825f0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E83F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E844: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E845: ret  */

}

void sub_0077E850(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E850u);

L_0077E850:
    PUSH32(esp, 0x005CDE60u); /* 0x0077E850: push 0x5cde60 */
    PUSH32(esp, 0x00570FA0u); /* 0x0077E855: push 0x570fa0 */
    PUSH32(esp, 8); /* 0x0077E85A: push 8 */
    PUSH32(esp, 8); /* 0x0077E85C: push 8 */
    PUSH32(esp, 0x0088F1C8u); /* 0x0077E85E: push 0x88f1c8 */
    RECOMP_CALL(sub_0075C39D); /* 0x0077E863: call 0x75c39d */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782590u); /* 0x0077E868: push 0x782590 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E86D: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E872: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E873: ret  */

}

void sub_0077E880(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E880u);

L_0077E880:
    PUSH32(esp, 0x007A5354u); /* 0x0077E880: push 0x7a5354 */
    ecx = 0x0088A2C0u; /* 0x0077E885: mov ecx, 0x88a2c0 */
    RECOMP_CALL(sub_0060B7E0); /* 0x0077E88A: call 0x60b7e0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A5354u); /* 0x0077E88F: push 0x7a5354 */
    ecx = 0x0088A2F0u; /* 0x0077E894: mov ecx, 0x88a2f0 */
    RECOMP_CALL(sub_0060B7E0); /* 0x0077E899: call 0x60b7e0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782460u); /* 0x0077E89E: push 0x782460 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E8A3: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E8A8: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E8A9: ret  */

}

void sub_0077E8B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E8B0u);

L_0077E8B0:
    PUSH32(esp, 0x007A536Cu); /* 0x0077E8B0: push 0x7a536c */
    ecx = 0x0088EA08u; /* 0x0077E8B5: mov ecx, 0x88ea08 */
    RECOMP_CALL(sub_0060B7E0); /* 0x0077E8BA: call 0x60b7e0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A536Cu); /* 0x0077E8BF: push 0x7a536c */
    ecx = 0x0088EA38u; /* 0x0077E8C4: mov ecx, 0x88ea38 */
    RECOMP_CALL(sub_0060B7E0); /* 0x0077E8C9: call 0x60b7e0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782480u); /* 0x0077E8CE: push 0x782480 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E8D3: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E8D8: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E8D9: ret  */

}

void sub_0077E8E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E8E0u);

L_0077E8E0:
    PUSH32(esp, 0x007A5380u); /* 0x0077E8E0: push 0x7a5380 */
    ecx = 0x0088F210u; /* 0x0077E8E5: mov ecx, 0x88f210 */
    RECOMP_CALL(sub_0060B7E0); /* 0x0077E8EA: call 0x60b7e0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A5380u); /* 0x0077E8EF: push 0x7a5380 */
    ecx = 0x0088F240u; /* 0x0077E8F4: mov ecx, 0x88f240 */
    RECOMP_CALL(sub_0060B7E0); /* 0x0077E8F9: call 0x60b7e0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007824A0u); /* 0x0077E8FE: push 0x7824a0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E903: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E908: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E909: ret  */

}

void sub_0077E910(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E910u);

L_0077E910:
    ecx = 0x0088F28Cu; /* 0x0077E910: mov ecx, 0x88f28c */
    RECOMP_CALL(sub_00570FA0); /* 0x0077E915: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007825B0u); /* 0x0077E91A: push 0x7825b0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E91F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E924: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E925: ret  */

}

void sub_0077E930(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E930u);

L_0077E930:
    ecx = 0x0088FFA0u; /* 0x0077E930: mov ecx, 0x88ffa0 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077E935: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007825C0u); /* 0x0077E93A: push 0x7825c0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E93F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E944: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E945: ret  */

}

void sub_0077E950(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E950u);

L_0077E950:
    ecx = 0x0088E9C4u; /* 0x0077E950: mov ecx, 0x88e9c4 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077E955: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782520u); /* 0x0077E95A: push 0x782520 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E95F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E964: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E965: ret  */

}

void sub_0077E970(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E970u);

L_0077E970:
    ecx = 0x0088F208u; /* 0x0077E970: mov ecx, 0x88f208 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077E975: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782530u); /* 0x0077E97A: push 0x782530 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E97F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E984: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E985: ret  */

}

void sub_0077E990(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E990u);

L_0077E990:
    ecx = 0x0088F278u; /* 0x0077E990: mov ecx, 0x88f278 */
    RECOMP_ITAIL(0x005D7B60u); RECOMP_RETURN(); /* 0x0077E995: jmp 0x5d7b60 */

}

void sub_0077E9A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E9A0u);

L_0077E9A0:
    ecx = 0x0088E9FCu; /* 0x0077E9A0: mov ecx, 0x88e9fc */
    RECOMP_CALL(sub_00570FA0); /* 0x0077E9A5: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007824E0u); /* 0x0077E9AA: push 0x7824e0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E9AF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E9B4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E9B5: ret  */

}

void sub_0077E9C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E9C0u);

L_0077E9C0:
    ecx = 0x0088EA84u; /* 0x0077E9C0: mov ecx, 0x88ea84 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077E9C5: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007824F0u); /* 0x0077E9CA: push 0x7824f0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E9CF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E9D4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E9D5: ret  */

}

void sub_0077E9E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077E9E0u);

L_0077E9E0:
    ecx = 0x0088EADCu; /* 0x0077E9E0: mov ecx, 0x88eadc */
    RECOMP_CALL(sub_00570FA0); /* 0x0077E9E5: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782500u); /* 0x0077E9EA: push 0x782500 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077E9EF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077E9F4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077E9F5: ret  */

}

void sub_0077EA00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077EA00u);

L_0077EA00:
    eax = MEM32(0x7A4824); /* 0x0077EA00: mov eax, dword ptr [0x7a4824] */
    fp_push(*(float*)&MEM32(0x7A4824)); /* 0x0077EA05: fld dword ptr [0x7a4824] */
    _st[0] = -_st[0]; /* 0x0077EA0B: fchs  */
    ecx = eax; /* 0x0077EA0D: mov ecx, eax */
    edx = eax; /* 0x0077EA0F: mov edx, eax */
    { float _v = (float)_st[0]; *(float*)ADDR(0x88FFB8) = _v; } /* 0x0077EA11: fst dword ptr [0x88ffb8] */
    { float _v = (float)_st[0]; *(float*)ADDR(0x88FFC0) = _v; } /* 0x0077EA17: fst dword ptr [0x88ffc0] */
    MEM32(0x88FFB0) = eax; /* 0x0077EA1D: mov dword ptr [0x88ffb0], eax */
    { float _v = (float)_st[0]; *(float*)ADDR(0x88FFC4) = _v; } /* 0x0077EA22: fst dword ptr [0x88ffc4] */
    MEM32(0x88FFB4) = ecx; /* 0x0077EA28: mov dword ptr [0x88ffb4], ecx */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x88FFCC) = _v; } /* 0x0077EA2E: fstp dword ptr [0x88ffcc] */
    MEM32(0x88FFBC) = edx; /* 0x0077EA34: mov dword ptr [0x88ffbc], edx */
    MEM32(0x88FFC8) = eax; /* 0x0077EA3A: mov dword ptr [0x88ffc8], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077EA3F: ret  */

}

void sub_0077EA40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077EA40u);

L_0077EA40:
    fp_push(*(float*)&MEM32(0x784250)); /* 0x0077EA40: fld dword ptr [0x784250] */
    _st[0] /= (double)*(float*)ADDR(0x7A5478); /* 0x0077EA46: fdiv dword ptr [0x7a5478] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x89CF08) = _v; } /* 0x0077EA4C: fstp dword ptr [0x89cf08] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077EA52: ret  */

}

void sub_0077EA60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077EA60u);

L_0077EA60:
    eax = MEM32(0x7A5490); /* 0x0077EA60: mov eax, dword ptr [0x7a5490] */
    edx = MEM32(0x7A5488); /* 0x0077EA65: mov edx, dword ptr [0x7a5488] */
    ecx = eax; /* 0x0077EA6B: mov ecx, eax */
    MEM32(0x8025E4) = ecx; /* 0x0077EA6D: mov dword ptr [0x8025e4], ecx */
    ecx = MEM32(0x7A548C); /* 0x0077EA73: mov ecx, dword ptr [0x7a548c] */
    MEM32(0x8025E0) = eax; /* 0x0077EA79: mov dword ptr [0x8025e0], eax */
    eax = edx; /* 0x0077EA7E: mov eax, edx */
    MEM32(0x802618) = edx; /* 0x0077EA80: mov dword ptr [0x802618], edx */
    edx = ecx; /* 0x0077EA86: mov edx, ecx */
    MEM32(0x80261C) = eax; /* 0x0077EA88: mov dword ptr [0x80261c], eax */
    MEM32(0x802620) = ecx; /* 0x0077EA8D: mov dword ptr [0x802620], ecx */
    MEM32(0x802624) = edx; /* 0x0077EA93: mov dword ptr [0x802624], edx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077EA99: ret  */

}

void sub_0077EAA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077EAA0u);

L_0077EAA0:
    PUSH32(esp, 0x007864E8u); /* 0x0077EAA0: push 0x7864e8 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EAA5: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077EAAA: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x89CF2C) = eax; /* 0x0077EAAD: mov dword ptr [0x89cf2c], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077EAB2: ret  */

}

void sub_0077EAC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077EAC0u);

L_0077EAC0:
    PUSH32(esp, 0x007864FCu); /* 0x0077EAC0: push 0x7864fc */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EAC5: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077EACA: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x89CCEC) = eax; /* 0x0077EACD: mov dword ptr [0x89ccec], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077EAD2: ret  */

}

void sub_0077EAE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077EAE0u);

L_0077EAE0:
    PUSH32(esp, 0x00786510u); /* 0x0077EAE0: push 0x786510 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EAE5: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077EAEA: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x89CCF0) = eax; /* 0x0077EAED: mov dword ptr [0x89ccf0], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077EAF2: ret  */

}

void sub_0077EB00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077EB00u);

L_0077EB00:
    PUSH32(esp, 0x00786520u); /* 0x0077EB00: push 0x786520 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EB05: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077EB0A: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x89CCE0) = eax; /* 0x0077EB0D: mov dword ptr [0x89cce0], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077EB12: ret  */

}

void sub_0077EB20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077EB20u);

L_0077EB20:
    PUSH32(esp, 0x00786530u); /* 0x0077EB20: push 0x786530 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EB25: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077EB2A: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x89E78C) = eax; /* 0x0077EB2D: mov dword ptr [0x89e78c], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077EB32: ret  */

}

void sub_0077EB40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077EB40u);

L_0077EB40:
    PUSH32(esp, 0x00786548u); /* 0x0077EB40: push 0x786548 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EB45: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077EB4A: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x89CF20) = eax; /* 0x0077EB4D: mov dword ptr [0x89cf20], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077EB52: ret  */

}

void sub_0077EB60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077EB60u);

L_0077EB60:
    PUSH32(esp, 0x00786560u); /* 0x0077EB60: push 0x786560 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EB65: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077EB6A: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x890158) = eax; /* 0x0077EB6D: mov dword ptr [0x890158], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077EB72: ret  */

}

void sub_0077EB80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077EB80u);

L_0077EB80:
    PUSH32(esp, 0x0078657Cu); /* 0x0077EB80: push 0x78657c */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EB85: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077EB8A: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x89E820) = eax; /* 0x0077EB8D: mov dword ptr [0x89e820], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077EB92: ret  */

}

void sub_0077EBA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077EBA0u);

L_0077EBA0:
    PUSH32(esp, 0x00786598u); /* 0x0077EBA0: push 0x786598 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EBA5: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077EBAA: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x89CF14) = eax; /* 0x0077EBAD: mov dword ptr [0x89cf14], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077EBB2: ret  */

}

void sub_0077EBC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077EBC0u);

L_0077EBC0:
    PUSH32(esp, 4); /* 0x0077EBC0: push 4 */
    PUSH32(esp, 0x008023A0u); /* 0x0077EBC2: push 0x8023a0 */
    ecx = 0x0089CF24u; /* 0x0077EBC7: mov ecx, 0x89cf24 */
    RECOMP_CALL(sub_005766E0); /* 0x0077EBCC: call 0x5766e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077EBD1: ret  */

}

void sub_0077EBE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077EBE0u);

L_0077EBE0:
    PUSH32(esp, 4); /* 0x0077EBE0: push 4 */
    PUSH32(esp, 0x008023D0u); /* 0x0077EBE2: push 0x8023d0 */
    ecx = 0x0089CF30u; /* 0x0077EBE7: mov ecx, 0x89cf30 */
    RECOMP_CALL(sub_005766E0); /* 0x0077EBEC: call 0x5766e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077EBF1: ret  */

}

void sub_0077EC00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077EC00u);

L_0077EC00:
    PUSH32(esp, 2); /* 0x0077EC00: push 2 */
    PUSH32(esp, 0x00802404u); /* 0x0077EC02: push 0x802404 */
    ecx = 0x0089E790u; /* 0x0077EC07: mov ecx, 0x89e790 */
    RECOMP_CALL(sub_005766E0); /* 0x0077EC0C: call 0x5766e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077EC11: ret  */

}

void sub_0077EC20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077EC20u);

L_0077EC20:
    PUSH32(esp, 2); /* 0x0077EC20: push 2 */
    PUSH32(esp, 0x00802414u); /* 0x0077EC22: push 0x802414 */
    ecx = 0x0089E824u; /* 0x0077EC27: mov ecx, 0x89e824 */
    RECOMP_CALL(sub_005766E0); /* 0x0077EC2C: call 0x5766e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077EC31: ret  */

}

void sub_0077EC40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077EC40u);

L_0077EC40:
    PUSH32(esp, 2); /* 0x0077EC40: push 2 */
    PUSH32(esp, 0x00802424u); /* 0x0077EC42: push 0x802424 */
    ecx = 0x0089CF18u; /* 0x0077EC47: mov ecx, 0x89cf18 */
    RECOMP_CALL(sub_005766E0); /* 0x0077EC4C: call 0x5766e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077EC51: ret  */

}

void sub_0077EC60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077EC60u);

L_0077EC60:
    PUSH32(esp, 2); /* 0x0077EC60: push 2 */
    PUSH32(esp, 0x00802434u); /* 0x0077EC62: push 0x802434 */
    ecx = 0x00890150u; /* 0x0077EC67: mov ecx, 0x890150 */
    RECOMP_CALL(sub_005766E0); /* 0x0077EC6C: call 0x5766e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077EC71: ret  */

}

void sub_0077EC80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077EC80u);

L_0077EC80:
    PUSH32(esp, 2); /* 0x0077EC80: push 2 */
    PUSH32(esp, 0x00802444u); /* 0x0077EC82: push 0x802444 */
    ecx = 0x0089E798u; /* 0x0077EC87: mov ecx, 0x89e798 */
    RECOMP_CALL(sub_005766E0); /* 0x0077EC8C: call 0x5766e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077EC91: ret  */

}

void sub_0077ECA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077ECA0u);

L_0077ECA0:
    PUSH32(esp, 4); /* 0x0077ECA0: push 4 */
    PUSH32(esp, 0x00802570u); /* 0x0077ECA2: push 0x802570 */
    ecx = 0x0089CCE4u; /* 0x0077ECA7: mov ecx, 0x89cce4 */
    RECOMP_CALL(sub_005766E0); /* 0x0077ECAC: call 0x5766e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077ECB1: ret  */

}

void sub_0077ECC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077ECC0u);

L_0077ECC0:
    PUSH32(esp, 3); /* 0x0077ECC0: push 3 */
    PUSH32(esp, 0x00802590u); /* 0x0077ECC2: push 0x802590 */
    ecx = 0x0089CF0Cu; /* 0x0077ECC7: mov ecx, 0x89cf0c */
    RECOMP_CALL(sub_005766E0); /* 0x0077ECCC: call 0x5766e0 */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077ECD1: ret  */

}

void sub_0077ECE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077ECE0u);

L_0077ECE0:
    ecx = 0x0089E7A0u; /* 0x0077ECE0: mov ecx, 0x89e7a0 */
    RECOMP_ITAIL(0x005ED5F0u); RECOMP_RETURN(); /* 0x0077ECE5: jmp 0x5ed5f0 */

}

void sub_0077ECF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077ECF0u);

L_0077ECF0:
    PUSH32(esp, 0x0050F700u); /* 0x0077ECF0: push 0x50f700 */
    PUSH32(esp, 0x005F0D00u); /* 0x0077ECF5: push 0x5f0d00 */
    PUSH32(esp, 0x16u); /* 0x0077ECFA: push 0x16 */
    PUSH32(esp, 0x940u); /* 0x0077ECFC: push 0x940 */
    PUSH32(esp, 0x00890160u); /* 0x0077ED01: push 0x890160 */
    RECOMP_CALL(sub_0075C39D); /* 0x0077ED06: call 0x75c39d */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782610u); /* 0x0077ED0B: push 0x782610 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077ED10: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077ED15: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077ED16: ret  */

}

void sub_0077ED20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077ED20u);

L_0077ED20:
    ecx = 0x0089CF48u; /* 0x0077ED20: mov ecx, 0x89cf48 */
    RECOMP_CALL(sub_005F9050); /* 0x0077ED25: call 0x5f9050 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782630u); /* 0x0077ED2A: push 0x782630 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077ED2F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077ED34: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077ED35: ret  */

}

void sub_0077ED40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077ED40u);

L_0077ED40:
    ecx = 0x008A2B50u; /* 0x0077ED40: mov ecx, 0x8a2b50 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077ED45: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782780u); /* 0x0077ED4A: push 0x782780 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077ED4F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077ED54: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077ED55: ret  */

}

void sub_0077ED60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077ED60u);

L_0077ED60:
    fp_push(*(float*)&MEM32(0x784250)); /* 0x0077ED60: fld dword ptr [0x784250] */
    _st[0] /= (double)*(float*)ADDR(0x7A65D0); /* 0x0077ED66: fdiv dword ptr [0x7a65d0] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A2CE0) = _v; } /* 0x0077ED6C: fstp dword ptr [0x8a2ce0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077ED72: ret  */

}

void sub_0077ED80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077ED80u);

L_0077ED80:
    fp_push(*(float*)&MEM32(0x7A65D4)); /* 0x0077ED80: fld dword ptr [0x7a65d4] */
    _st[0] += _st[0]; /* 0x0077ED86: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A3160) = _v; } /* 0x0077ED88: fstp dword ptr [0x8a3160] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077ED8E: ret  */

}

void sub_0077ED90(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077ED90u);

L_0077ED90:
    fp_push(*(float*)&MEM32(0x7A65D4)); /* 0x0077ED90: fld dword ptr [0x7a65d4] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x0077ED96: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A3164) = _v; } /* 0x0077ED9C: fstp dword ptr [0x8a3164] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077EDA2: ret  */

}

void sub_0077EDB0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077EDB0u);

L_0077EDB0:
    fp_push(*(double*)ADDR(0x7A65D8)); /* 0x0077EDB0: fld qword ptr [0x7a65d8] */
    _st[0] += _st[0]; /* 0x0077EDB6: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8A3158) = _v; } /* 0x0077EDB8: fstp qword ptr [0x8a3158] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077EDBE: ret  */

}

void sub_0077EDC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077EDC0u);

L_0077EDC0:
    fp_push(*(double*)ADDR(0x7A65D8)); /* 0x0077EDC0: fld qword ptr [0x7a65d8] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x0077EDC6: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8A3150) = _v; } /* 0x0077EDCC: fstp qword ptr [0x8a3150] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077EDD2: ret  */

}

void sub_0077EDE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077EDE0u);

L_0077EDE0:
    PUSH32(esp, 0x007A8DB0u); /* 0x0077EDE0: push 0x7a8db0 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EDE5: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077EDEA: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x8A31E0) = eax; /* 0x0077EDED: mov dword ptr [0x8a31e0], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077EDF2: ret  */

}

void sub_0077EE00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077EE00u);

L_0077EE00:
    PUSH32(esp, 0x007A8DC0u); /* 0x0077EE00: push 0x7a8dc0 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EE05: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077EE0A: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x8A3B00) = eax; /* 0x0077EE0D: mov dword ptr [0x8a3b00], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077EE12: ret  */

}

void sub_0077EE20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077EE20u);

L_0077EE20:
    PUSH32(esp, 0x007A8DD0u); /* 0x0077EE20: push 0x7a8dd0 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EE25: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 4; /* 0x0077EE2A: add esp, 4 */
    _flag_k = FK_ADD;
    MEM32(0x8A1D90) = eax; /* 0x0077EE2D: mov dword ptr [0x8a1d90], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077EE32: ret  */

}

void sub_0077EE40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077EE40u);

L_0077EE40:
    ecx = 0x008A2CA4u; /* 0x0077EE40: mov ecx, 0x8a2ca4 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077EE45: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007827E0u); /* 0x0077EE4A: push 0x7827e0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077EE4F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077EE54: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077EE55: ret  */

}

void sub_0077EE60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077EE60u);

L_0077EE60:
    PUSH32(esp, 0x007A911Cu); /* 0x0077EE60: push 0x7a911c */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EE65: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9108u); /* 0x0077EE6A: push 0x7a9108 */
    MEM32(0x8A4358) = eax; /* 0x0077EE6F: mov dword ptr [0x8a4358], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EE74: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A90F4u); /* 0x0077EE79: push 0x7a90f4 */
    MEM32(0x8A435C) = eax; /* 0x0077EE7E: mov dword ptr [0x8a435c], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EE83: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A90E8u); /* 0x0077EE88: push 0x7a90e8 */
    MEM32(0x8A4360) = eax; /* 0x0077EE8D: mov dword ptr [0x8a4360], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EE92: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A90D8u); /* 0x0077EE97: push 0x7a90d8 */
    MEM32(0x8A4364) = eax; /* 0x0077EE9C: mov dword ptr [0x8a4364], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EEA1: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A90CCu); /* 0x0077EEA6: push 0x7a90cc */
    MEM32(0x8A4368) = eax; /* 0x0077EEAB: mov dword ptr [0x8a4368], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EEB0: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A90B4u); /* 0x0077EEB5: push 0x7a90b4 */
    MEM32(0x8A436C) = eax; /* 0x0077EEBA: mov dword ptr [0x8a436c], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EEBF: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A90A4u); /* 0x0077EEC4: push 0x7a90a4 */
    MEM32(0x8A4370) = eax; /* 0x0077EEC9: mov dword ptr [0x8a4370], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EECE: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9090u); /* 0x0077EED3: push 0x7a9090 */
    MEM32(0x8A4374) = eax; /* 0x0077EED8: mov dword ptr [0x8a4374], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EEDD: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A907Cu); /* 0x0077EEE2: push 0x7a907c */
    MEM32(0x8A4378) = eax; /* 0x0077EEE7: mov dword ptr [0x8a4378], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EEEC: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9064u); /* 0x0077EEF1: push 0x7a9064 */
    MEM32(0x8A437C) = eax; /* 0x0077EEF6: mov dword ptr [0x8a437c], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EEFB: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9050u); /* 0x0077EF00: push 0x7a9050 */
    MEM32(0x8A4380) = eax; /* 0x0077EF05: mov dword ptr [0x8a4380], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EF0A: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A903Cu); /* 0x0077EF0F: push 0x7a903c */
    MEM32(0x8A4384) = eax; /* 0x0077EF14: mov dword ptr [0x8a4384], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EF19: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9030u); /* 0x0077EF1E: push 0x7a9030 */
    MEM32(0x8A4388) = eax; /* 0x0077EF23: mov dword ptr [0x8a4388], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EF28: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9018u); /* 0x0077EF2D: push 0x7a9018 */
    MEM32(0x8A438C) = eax; /* 0x0077EF32: mov dword ptr [0x8a438c], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EF37: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9004u); /* 0x0077EF3C: push 0x7a9004 */
    MEM32(0x8A4390) = eax; /* 0x0077EF41: mov dword ptr [0x8a4390], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EF46: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x40u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x40u; /* 0x0077EF4B: add esp, 0x40 */
    _flag_k = FK_ADD;
    PUSH32(esp, 0x007A8FF0u); /* 0x0077EF4E: push 0x7a8ff0 */
    MEM32(0x8A4394) = eax; /* 0x0077EF53: mov dword ptr [0x8a4394], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EF58: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A8FDCu); /* 0x0077EF5D: push 0x7a8fdc */
    MEM32(0x8A4398) = eax; /* 0x0077EF62: mov dword ptr [0x8a4398], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EF67: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A8FC4u); /* 0x0077EF6C: push 0x7a8fc4 */
    MEM32(0x8A439C) = eax; /* 0x0077EF71: mov dword ptr [0x8a439c], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EF76: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A8FB0u); /* 0x0077EF7B: push 0x7a8fb0 */
    MEM32(0x8A43A0) = eax; /* 0x0077EF80: mov dword ptr [0x8a43a0], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EF85: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A8FA4u); /* 0x0077EF8A: push 0x7a8fa4 */
    MEM32(0x8A43A4) = eax; /* 0x0077EF8F: mov dword ptr [0x8a43a4], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EF94: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A8F90u); /* 0x0077EF99: push 0x7a8f90 */
    MEM32(0x8A43A8) = eax; /* 0x0077EF9E: mov dword ptr [0x8a43a8], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EFA3: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A8F7Cu); /* 0x0077EFA8: push 0x7a8f7c */
    MEM32(0x8A43AC) = eax; /* 0x0077EFAD: mov dword ptr [0x8a43ac], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EFB2: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A8F64u); /* 0x0077EFB7: push 0x7a8f64 */
    MEM32(0x8A43B0) = eax; /* 0x0077EFBC: mov dword ptr [0x8a43b0], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EFC1: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A8F4Cu); /* 0x0077EFC6: push 0x7a8f4c */
    MEM32(0x8A43B4) = eax; /* 0x0077EFCB: mov dword ptr [0x8a43b4], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EFD0: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A8F30u); /* 0x0077EFD5: push 0x7a8f30 */
    MEM32(0x8A43B8) = eax; /* 0x0077EFDA: mov dword ptr [0x8a43b8], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EFDF: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A8F18u); /* 0x0077EFE4: push 0x7a8f18 */
    MEM32(0x8A43BC) = eax; /* 0x0077EFE9: mov dword ptr [0x8a43bc], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077EFEE: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x2Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x2Cu; /* 0x0077EFF3: add esp, 0x2c */
    _flag_k = FK_ADD;
    MEM32(0x8A43C0) = eax; /* 0x0077EFF6: mov dword ptr [0x8a43c0], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077EFFB: ret  */

}

void sub_0077F000(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F000u);

L_0077F000:
    PUSH32(esp, 0x007A9210u); /* 0x0077F000: push 0x7a9210 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F005: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A91FCu); /* 0x0077F00A: push 0x7a91fc */
    MEM32(0x8A4324) = eax; /* 0x0077F00F: mov dword ptr [0x8a4324], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F014: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A91E8u); /* 0x0077F019: push 0x7a91e8 */
    MEM32(0x8A4328) = eax; /* 0x0077F01E: mov dword ptr [0x8a4328], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F023: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A91D4u); /* 0x0077F028: push 0x7a91d4 */
    MEM32(0x8A432C) = eax; /* 0x0077F02D: mov dword ptr [0x8a432c], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F032: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A91C0u); /* 0x0077F037: push 0x7a91c0 */
    MEM32(0x8A4330) = eax; /* 0x0077F03C: mov dword ptr [0x8a4330], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F041: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A91ACu); /* 0x0077F046: push 0x7a91ac */
    MEM32(0x8A4334) = eax; /* 0x0077F04B: mov dword ptr [0x8a4334], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F050: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9198u); /* 0x0077F055: push 0x7a9198 */
    MEM32(0x8A4338) = eax; /* 0x0077F05A: mov dword ptr [0x8a4338], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F05F: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9184u); /* 0x0077F064: push 0x7a9184 */
    MEM32(0x8A433C) = eax; /* 0x0077F069: mov dword ptr [0x8a433c], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F06E: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9170u); /* 0x0077F073: push 0x7a9170 */
    MEM32(0x8A4340) = eax; /* 0x0077F078: mov dword ptr [0x8a4340], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F07D: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A915Cu); /* 0x0077F082: push 0x7a915c */
    MEM32(0x8A4344) = eax; /* 0x0077F087: mov dword ptr [0x8a4344], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F08C: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9144u); /* 0x0077F091: push 0x7a9144 */
    MEM32(0x8A4348) = eax; /* 0x0077F096: mov dword ptr [0x8a4348], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F09B: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A912Cu); /* 0x0077F0A0: push 0x7a912c */
    MEM32(0x8A434C) = eax; /* 0x0077F0A5: mov dword ptr [0x8a434c], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F0AA: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x30u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x30u; /* 0x0077F0AF: add esp, 0x30 */
    _flag_k = FK_ADD;
    MEM32(0x8A4350) = eax; /* 0x0077F0B2: mov dword ptr [0x8a4350], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F0B7: ret  */

}

void sub_0077F0C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F0C0u);

L_0077F0C0:
    PUSH32(esp, 0x00782660u); /* 0x0077F0C0: push 0x782660 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077F0C5: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077F0CA: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F0CB: ret  */

}

void sub_0077F0D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F0D0u);

L_0077F0D0:
    ecx = 0x008A1DE4u; /* 0x0077F0D0: mov ecx, 0x8a1de4 */
    RECOMP_CALL(sub_004AF9F0); /* 0x0077F0D5: call 0x4af9f0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782720u); /* 0x0077F0DA: push 0x782720 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077F0DF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077F0E4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F0E5: ret  */

}

void sub_0077F0F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F0F0u);

L_0077F0F0:
    ecx = 0x008A3168u; /* 0x0077F0F0: mov ecx, 0x8a3168 */
    RECOMP_CALL(sub_004AF9F0); /* 0x0077F0F5: call 0x4af9f0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782730u); /* 0x0077F0FA: push 0x782730 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077F0FF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077F104: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F105: ret  */

}

void sub_0077F110(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F110u);

L_0077F110:
    ecx = 0x008A30F0u; /* 0x0077F110: mov ecx, 0x8a30f0 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077F115: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007827F0u); /* 0x0077F11A: push 0x7827f0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077F11F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077F124: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F125: ret  */

}

void sub_0077F130(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F130u);

L_0077F130:
    ecx = 0x008A1DFCu; /* 0x0077F130: mov ecx, 0x8a1dfc */
    RECOMP_CALL(sub_004AF9F0); /* 0x0077F135: call 0x4af9f0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782740u); /* 0x0077F13A: push 0x782740 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077F13F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077F144: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F145: ret  */

}

void sub_0077F150(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F150u);

L_0077F150:
    ecx = 0x008A1F10u; /* 0x0077F150: mov ecx, 0x8a1f10 */
    RECOMP_CALL(sub_004AF9F0); /* 0x0077F155: call 0x4af9f0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782750u); /* 0x0077F15A: push 0x782750 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077F15F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077F164: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F165: ret  */

}

void sub_0077F170(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F170u);

L_0077F170:
    eax = 0x008A2CB4u; /* 0x0077F170: mov eax, 0x8a2cb4 */
    edx = 2; /* 0x0077F175: mov edx, 2 */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    ecx = 0; /* 0x0077F17A: xor ecx, ecx */
    _cf = 0;
    _flag_k = FK_TEST;
    esp = esp; /* 0x0077F17C: lea esp, [esp] */

L_0077F180:
    MEM32(eax + (-0x8)) = ecx; /* 0x0077F180: mov dword ptr [eax - 8], ecx */
    MEM32(eax + (-0x4)) = ecx; /* 0x0077F183: mov dword ptr [eax - 4], ecx */
    MEM32(eax) = ecx; /* 0x0077F186: mov dword ptr [eax], ecx */
    MEM32(eax + 0x4) = ecx; /* 0x0077F188: mov dword ptr [eax + 4], ecx */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x10u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x10u; /* 0x0077F18B: add eax, 0x10 */
    _flag_k = FK_ADD;
    _flag_a = (uint32_t)(edx); _flag_b = (uint32_t)(1);
    edx = edx - 1; /* 0x0077F18E: dec edx */
    _flag_k = FK_DEC;
    RECOMP_BACKEDGE();
    if (/* dec result */ CMP_NE(_flag_a, _flag_b)) goto L_0077F180; /* 0x0077F18F: jne 0x77f180 */

L_0077F191:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F191: ret  */

}

void sub_0077F1A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F1A0u);

L_0077F1A0:
    eax = 0x008A3130u; /* 0x0077F1A0: mov eax, 0x8a3130 */
    edx = 2; /* 0x0077F1A5: mov edx, 2 */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    ecx = 0; /* 0x0077F1AA: xor ecx, ecx */
    _cf = 0;
    _flag_k = FK_TEST;
    esp = esp; /* 0x0077F1AC: lea esp, [esp] */

L_0077F1B0:
    MEM32(eax + (-0x8)) = ecx; /* 0x0077F1B0: mov dword ptr [eax - 8], ecx */
    MEM32(eax + (-0x4)) = ecx; /* 0x0077F1B3: mov dword ptr [eax - 4], ecx */
    MEM32(eax) = ecx; /* 0x0077F1B6: mov dword ptr [eax], ecx */
    MEM32(eax + 0x4) = ecx; /* 0x0077F1B8: mov dword ptr [eax + 4], ecx */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x10u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x10u; /* 0x0077F1BB: add eax, 0x10 */
    _flag_k = FK_ADD;
    _flag_a = (uint32_t)(edx); _flag_b = (uint32_t)(1);
    edx = edx - 1; /* 0x0077F1BE: dec edx */
    _flag_k = FK_DEC;
    RECOMP_BACKEDGE();
    if (/* dec result */ CMP_NE(_flag_a, _flag_b)) goto L_0077F1B0; /* 0x0077F1BF: jne 0x77f1b0 */

L_0077F1C1:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F1C1: ret  */

}

void sub_0077F1D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F1D0u);

L_0077F1D0:
    ecx = 0x008A2B68u; /* 0x0077F1D0: mov ecx, 0x8a2b68 */
    RECOMP_CALL(sub_00636AC0); /* 0x0077F1D5: call 0x636ac0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782790u); /* 0x0077F1DA: push 0x782790 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077F1DF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077F1E4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F1E5: ret  */

}

void sub_0077F1F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F1F0u);

L_0077F1F0:
    ecx = 0x008A31E4u; /* 0x0077F1F0: mov ecx, 0x8a31e4 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077F1F5: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007827A0u); /* 0x0077F1FA: push 0x7827a0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077F1FF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077F204: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F205: ret  */

}

void sub_0077F210(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F210u);

L_0077F210:
    PUSH32(esp, esi); /* 0x0077F210: push esi */
    PUSH32(esp, edi); /* 0x0077F211: push edi */
    PUSH32(esp, 0x007A9348u); /* 0x0077F212: push 0x7a9348 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F217: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    edi = 5; /* 0x0077F21C: mov edi, 5 */
    PUSH32(esp, 0x007A9348u); /* 0x0077F221: push 0x7a9348 */
    MEM32(0x8A4418) = eax; /* 0x0077F226: mov dword ptr [0x8a4418], eax */
    MEM32(0x8A441C) = edi; /* 0x0077F22B: mov dword ptr [0x8a441c], edi */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F231: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9334u); /* 0x0077F236: push 0x7a9334 */
    MEM32(0x8A4420) = eax; /* 0x0077F23B: mov dword ptr [0x8a4420], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F240: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9320u); /* 0x0077F245: push 0x7a9320 */
    MEM32(0x8A4424) = eax; /* 0x0077F24A: mov dword ptr [0x8a4424], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F24F: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A930Cu); /* 0x0077F254: push 0x7a930c */
    MEM32(0x8A4428) = eax; /* 0x0077F259: mov dword ptr [0x8a4428], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F25E: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A92F8u); /* 0x0077F263: push 0x7a92f8 */
    MEM32(0x8A442C) = eax; /* 0x0077F268: mov dword ptr [0x8a442c], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F26D: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    esi = 0; /* 0x0077F272: xor esi, esi */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, 0x007A92E4u); /* 0x0077F274: push 0x7a92e4 */
    MEM32(0x8A4430) = eax; /* 0x0077F279: mov dword ptr [0x8a4430], eax */
    MEM32(0x8A4434) = esi; /* 0x0077F27E: mov dword ptr [0x8a4434], esi */
    MEM32(0x8A4438) = esi; /* 0x0077F284: mov dword ptr [0x8a4438], esi */
    MEM32(0x8A443C) = esi; /* 0x0077F28A: mov dword ptr [0x8a443c], esi */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F290: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A92E4u); /* 0x0077F295: push 0x7a92e4 */
    MEM32(0x8A4440) = eax; /* 0x0077F29A: mov dword ptr [0x8a4440], eax */
    MEM32(0x8A4444) = edi; /* 0x0077F29F: mov dword ptr [0x8a4444], edi */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F2A5: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9348u); /* 0x0077F2AA: push 0x7a9348 */
    MEM32(0x8A4448) = eax; /* 0x0077F2AF: mov dword ptr [0x8a4448], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F2B4: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A92D0u); /* 0x0077F2B9: push 0x7a92d0 */
    MEM32(0x8A444C) = eax; /* 0x0077F2BE: mov dword ptr [0x8a444c], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F2C3: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A92BCu); /* 0x0077F2C8: push 0x7a92bc */
    MEM32(0x8A4450) = eax; /* 0x0077F2CD: mov dword ptr [0x8a4450], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F2D2: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A92ACu); /* 0x0077F2D7: push 0x7a92ac */
    MEM32(0x8A4454) = eax; /* 0x0077F2DC: mov dword ptr [0x8a4454], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F2E1: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A92D0u); /* 0x0077F2E6: push 0x7a92d0 */
    MEM32(0x8A4458) = eax; /* 0x0077F2EB: mov dword ptr [0x8a4458], eax */
    MEM32(0x8A445C) = esi; /* 0x0077F2F0: mov dword ptr [0x8a445c], esi */
    MEM32(0x8A4460) = esi; /* 0x0077F2F6: mov dword ptr [0x8a4460], esi */
    MEM32(0x8A4464) = esi; /* 0x0077F2FC: mov dword ptr [0x8a4464], esi */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F302: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A92D0u); /* 0x0077F307: push 0x7a92d0 */
    MEM32(0x8A4468) = eax; /* 0x0077F30C: mov dword ptr [0x8a4468], eax */
    MEM32(0x8A446C) = edi; /* 0x0077F311: mov dword ptr [0x8a446c], edi */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F317: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9320u); /* 0x0077F31C: push 0x7a9320 */
    MEM32(0x8A4470) = eax; /* 0x0077F321: mov dword ptr [0x8a4470], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F326: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A930Cu); /* 0x0077F32B: push 0x7a930c */
    MEM32(0x8A4474) = eax; /* 0x0077F330: mov dword ptr [0x8a4474], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F335: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x40u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x40u; /* 0x0077F33A: add esp, 0x40 */
    _flag_k = FK_ADD;
    PUSH32(esp, 0x007A9298u); /* 0x0077F33D: push 0x7a9298 */
    MEM32(0x8A4478) = eax; /* 0x0077F342: mov dword ptr [0x8a4478], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F347: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9284u); /* 0x0077F34C: push 0x7a9284 */
    MEM32(0x8A447C) = eax; /* 0x0077F351: mov dword ptr [0x8a447c], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F356: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9270u); /* 0x0077F35B: push 0x7a9270 */
    MEM32(0x8A4480) = eax; /* 0x0077F360: mov dword ptr [0x8a4480], eax */
    MEM32(0x8A4484) = esi; /* 0x0077F365: mov dword ptr [0x8a4484], esi */
    MEM32(0x8A4488) = esi; /* 0x0077F36B: mov dword ptr [0x8a4488], esi */
    MEM32(0x8A448C) = esi; /* 0x0077F371: mov dword ptr [0x8a448c], esi */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F377: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9270u); /* 0x0077F37C: push 0x7a9270 */
    MEM32(0x8A4490) = eax; /* 0x0077F381: mov dword ptr [0x8a4490], eax */
    MEM32(0x8A4494) = edi; /* 0x0077F386: mov dword ptr [0x8a4494], edi */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F38C: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9348u); /* 0x0077F391: push 0x7a9348 */
    MEM32(0x8A4498) = eax; /* 0x0077F396: mov dword ptr [0x8a4498], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F39B: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    MEM32(0x8A449C) = eax; /* 0x0077F3A0: mov dword ptr [0x8a449c], eax */
    PUSH32(esp, 0x007A925Cu); /* 0x0077F3A5: push 0x7a925c */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F3AA: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A92D0u); /* 0x0077F3AF: push 0x7a92d0 */
    MEM32(0x8A44A0) = eax; /* 0x0077F3B4: mov dword ptr [0x8a44a0], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F3B9: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A930Cu); /* 0x0077F3BE: push 0x7a930c */
    MEM32(0x8A44A4) = eax; /* 0x0077F3C3: mov dword ptr [0x8a44a4], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F3C8: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9248u); /* 0x0077F3CD: push 0x7a9248 */
    MEM32(0x8A44A8) = eax; /* 0x0077F3D2: mov dword ptr [0x8a44a8], eax */
    MEM32(0x8A44AC) = esi; /* 0x0077F3D7: mov dword ptr [0x8a44ac], esi */
    MEM32(0x8A44B0) = esi; /* 0x0077F3DD: mov dword ptr [0x8a44b0], esi */
    MEM32(0x8A44B4) = esi; /* 0x0077F3E3: mov dword ptr [0x8a44b4], esi */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F3E9: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9248u); /* 0x0077F3EE: push 0x7a9248 */
    MEM32(0x8A44B8) = eax; /* 0x0077F3F3: mov dword ptr [0x8a44b8], eax */
    MEM32(0x8A44BC) = edi; /* 0x0077F3F8: mov dword ptr [0x8a44bc], edi */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F3FE: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9348u); /* 0x0077F403: push 0x7a9348 */
    MEM32(0x8A44C0) = eax; /* 0x0077F408: mov dword ptr [0x8a44c0], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F40D: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9334u); /* 0x0077F412: push 0x7a9334 */
    MEM32(0x8A44C4) = eax; /* 0x0077F417: mov dword ptr [0x8a44c4], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F41C: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9234u); /* 0x0077F421: push 0x7a9234 */
    MEM32(0x8A44C8) = eax; /* 0x0077F426: mov dword ptr [0x8a44c8], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F42B: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9224u); /* 0x0077F430: push 0x7a9224 */
    MEM32(0x8A44CC) = eax; /* 0x0077F435: mov dword ptr [0x8a44cc], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F43A: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x38u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x38u; /* 0x0077F43F: add esp, 0x38 */
    _flag_k = FK_ADD;
    edi = POP32_VAL(esp); /* 0x0077F442: pop edi */
    MEM32(0x8A44D4) = esi; /* 0x0077F443: mov dword ptr [0x8a44d4], esi */
    MEM32(0x8A44D8) = esi; /* 0x0077F449: mov dword ptr [0x8a44d8], esi */
    MEM32(0x8A44DC) = esi; /* 0x0077F44F: mov dword ptr [0x8a44dc], esi */
    MEM32(0x8A44D0) = eax; /* 0x0077F455: mov dword ptr [0x8a44d0], eax */
    esi = POP32_VAL(esp); /* 0x0077F45A: pop esi */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F45B: ret  */

}

void sub_0077F460(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F460u);

L_0077F460:
    PUSH32(esp, 0x007A8CA0u); /* 0x0077F460: push 0x7a8ca0 */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F465: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A8CC8u); /* 0x0077F46A: push 0x7a8cc8 */
    MEM32(0x8A43C8) = eax; /* 0x0077F46F: mov dword ptr [0x8a43c8], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F474: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A8CB4u); /* 0x0077F479: push 0x7a8cb4 */
    MEM32(0x8A43CC) = eax; /* 0x0077F47E: mov dword ptr [0x8a43cc], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F483: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A8CDCu); /* 0x0077F488: push 0x7a8cdc */
    MEM32(0x8A43D0) = eax; /* 0x0077F48D: mov dword ptr [0x8a43d0], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F492: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A8CA0u); /* 0x0077F497: push 0x7a8ca0 */
    MEM32(0x8A43D4) = eax; /* 0x0077F49C: mov dword ptr [0x8a43d4], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F4A1: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A8CC8u); /* 0x0077F4A6: push 0x7a8cc8 */
    MEM32(0x8A43D8) = eax; /* 0x0077F4AB: mov dword ptr [0x8a43d8], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F4B0: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A93FCu); /* 0x0077F4B5: push 0x7a93fc */
    MEM32(0x8A43DC) = eax; /* 0x0077F4BA: mov dword ptr [0x8a43dc], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F4BF: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A93E8u); /* 0x0077F4C4: push 0x7a93e8 */
    MEM32(0x8A43E0) = eax; /* 0x0077F4C9: mov dword ptr [0x8a43e0], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F4CE: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A8CC8u); /* 0x0077F4D3: push 0x7a8cc8 */
    MEM32(0x8A43E4) = eax; /* 0x0077F4D8: mov dword ptr [0x8a43e4], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F4DD: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A93FCu); /* 0x0077F4E2: push 0x7a93fc */
    MEM32(0x8A43E8) = eax; /* 0x0077F4E7: mov dword ptr [0x8a43e8], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F4EC: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A93E8u); /* 0x0077F4F1: push 0x7a93e8 */
    MEM32(0x8A43EC) = eax; /* 0x0077F4F6: mov dword ptr [0x8a43ec], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F4FB: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A93D4u); /* 0x0077F500: push 0x7a93d4 */
    MEM32(0x8A43F0) = eax; /* 0x0077F505: mov dword ptr [0x8a43f0], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F50A: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A8CC8u); /* 0x0077F50F: push 0x7a8cc8 */
    MEM32(0x8A43F4) = eax; /* 0x0077F514: mov dword ptr [0x8a43f4], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F519: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A93C0u); /* 0x0077F51E: push 0x7a93c0 */
    MEM32(0x8A43F8) = eax; /* 0x0077F523: mov dword ptr [0x8a43f8], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F528: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A93ACu); /* 0x0077F52D: push 0x7a93ac */
    MEM32(0x8A43FC) = eax; /* 0x0077F532: mov dword ptr [0x8a43fc], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F537: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9398u); /* 0x0077F53C: push 0x7a9398 */
    MEM32(0x8A4400) = eax; /* 0x0077F541: mov dword ptr [0x8a4400], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F546: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x40u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x40u; /* 0x0077F54B: add esp, 0x40 */
    _flag_k = FK_ADD;
    PUSH32(esp, 0x007A8CC8u); /* 0x0077F54E: push 0x7a8cc8 */
    MEM32(0x8A4404) = eax; /* 0x0077F553: mov dword ptr [0x8a4404], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F558: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9384u); /* 0x0077F55D: push 0x7a9384 */
    MEM32(0x8A4408) = eax; /* 0x0077F562: mov dword ptr [0x8a4408], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F567: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9370u); /* 0x0077F56C: push 0x7a9370 */
    MEM32(0x8A440C) = eax; /* 0x0077F571: mov dword ptr [0x8a440c], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F576: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A935Cu); /* 0x0077F57B: push 0x7a935c */
    MEM32(0x8A4410) = eax; /* 0x0077F580: mov dword ptr [0x8a4410], eax */
    RECOMP_CALL(sub_0043DBC0); /* 0x0077F585: call 0x43dbc0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x10u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x10u; /* 0x0077F58A: add esp, 0x10 */
    _flag_k = FK_ADD;
    MEM32(0x8A4414) = eax; /* 0x0077F58D: mov dword ptr [0x8a4414], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F592: ret  */

}

void sub_0077F5A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F5A0u);

L_0077F5A0:
    ecx = 0x008A3288u; /* 0x0077F5A0: mov ecx, 0x8a3288 */
    RECOMP_CALL(sub_00637940); /* 0x0077F5A5: call 0x637940 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007827B0u); /* 0x0077F5AA: push 0x7827b0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077F5AF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077F5B4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F5B5: ret  */

}

void sub_0077F5C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F5C0u);

L_0077F5C0:
    ecx = 0x008A3148u; /* 0x0077F5C0: mov ecx, 0x8a3148 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077F5C5: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007827C0u); /* 0x0077F5CA: push 0x7827c0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077F5CF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077F5D4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F5D5: ret  */

}

void sub_0077F5E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F5E0u);

L_0077F5E0:
    ecx = 0x008A2C9Cu; /* 0x0077F5E0: mov ecx, 0x8a2c9c */
    RECOMP_CALL(sub_00570FA0); /* 0x0077F5E5: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782800u); /* 0x0077F5EA: push 0x782800 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077F5EF: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077F5F4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F5F5: ret  */

}

void sub_0077F600(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F600u);

L_0077F600:
    fp_push(*(float*)&MEM32(0x803940)); /* 0x0077F600: fld dword ptr [0x803940] */
    _st[0] += (double)*(float*)ADDR(0x784250); /* 0x0077F606: fadd dword ptr [0x784250] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A1DE0) = _v; } /* 0x0077F60C: fstp dword ptr [0x8a1de0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F612: ret  */

}

void sub_0077F620(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F620u);

L_0077F620:
    ecx = 0x008A4260u; /* 0x0077F620: mov ecx, 0x8a4260 */
    RECOMP_CALL(sub_00570FA0); /* 0x0077F625: call 0x570fa0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007827D0u); /* 0x0077F62A: push 0x7827d0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077F62F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077F634: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F635: ret  */

}

void sub_0077F640(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F640u);

L_0077F640:
    PUSH32(esp, 0x007A9410u); /* 0x0077F640: push 0x7a9410 */
    ecx = 0x008A1F28u; /* 0x0077F645: mov ecx, 0x8a1f28 */
    RECOMP_CALL(sub_0060B780); /* 0x0077F64A: call 0x60b780 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782670u); /* 0x0077F64F: push 0x782670 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077F654: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077F659: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F65A: ret  */

}

void sub_0077F660(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F660u);

L_0077F660:
    PUSH32(esp, 0x004022D0u); /* 0x0077F660: push 0x4022d0 */
    PUSH32(esp, 0x005D7D30u); /* 0x0077F665: push 0x5d7d30 */
    PUSH32(esp, 1); /* 0x0077F66A: push 1 */
    PUSH32(esp, 0x64u); /* 0x0077F66C: push 0x64 */
    PUSH32(esp, 0x008A42C0u); /* 0x0077F66E: push 0x8a42c0 */
    RECOMP_CALL(sub_0075C39D); /* 0x0077F673: call 0x75c39d */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782760u); /* 0x0077F678: push 0x782760 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077F67D: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077F682: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F683: ret  */

}

void sub_0077F690(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F690u);

L_0077F690:
    PUSH32(esp, 0x007A9418u); /* 0x0077F690: push 0x7a9418 */
    ecx = 0x008A3180u; /* 0x0077F695: mov ecx, 0x8a3180 */
    RECOMP_CALL(sub_0060B7E0); /* 0x0077F69A: call 0x60b7e0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9418u); /* 0x0077F69F: push 0x7a9418 */
    ecx = 0x008A31B0u; /* 0x0077F6A4: mov ecx, 0x8a31b0 */
    RECOMP_CALL(sub_0060B7E0); /* 0x0077F6A9: call 0x60b7e0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782680u); /* 0x0077F6AE: push 0x782680 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077F6B3: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077F6B8: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F6B9: ret  */

}

void sub_0077F6C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F6C0u);

L_0077F6C0:
    PUSH32(esp, 0x007A9420u); /* 0x0077F6C0: push 0x7a9420 */
    ecx = 0x008A1E90u; /* 0x0077F6C5: mov ecx, 0x8a1e90 */
    RECOMP_CALL(sub_0060B7E0); /* 0x0077F6CA: call 0x60b7e0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9420u); /* 0x0077F6CF: push 0x7a9420 */
    ecx = 0x008A1EC0u; /* 0x0077F6D4: mov ecx, 0x8a1ec0 */
    RECOMP_CALL(sub_0060B7E0); /* 0x0077F6D9: call 0x60b7e0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007826A0u); /* 0x0077F6DE: push 0x7826a0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077F6E3: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077F6E8: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F6E9: ret  */

}

void sub_0077F6F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F6F0u);

L_0077F6F0:
    PUSH32(esp, 0x007A942Cu); /* 0x0077F6F0: push 0x7a942c */
    ecx = 0x008A31F0u; /* 0x0077F6F5: mov ecx, 0x8a31f0 */
    RECOMP_CALL(sub_0060B7E0); /* 0x0077F6FA: call 0x60b7e0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A942Cu); /* 0x0077F6FF: push 0x7a942c */
    ecx = 0x008A3220u; /* 0x0077F704: mov ecx, 0x8a3220 */
    RECOMP_CALL(sub_0060B7E0); /* 0x0077F709: call 0x60b7e0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007826C0u); /* 0x0077F70E: push 0x7826c0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077F713: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077F718: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F719: ret  */

}

void sub_0077F720(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F720u);

L_0077F720:
    PUSH32(esp, 0x007A9440u); /* 0x0077F720: push 0x7a9440 */
    ecx = 0x008A1E30u; /* 0x0077F725: mov ecx, 0x8a1e30 */
    RECOMP_CALL(sub_0060B7E0); /* 0x0077F72A: call 0x60b7e0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9440u); /* 0x0077F72F: push 0x7a9440 */
    ecx = 0x008A1E60u; /* 0x0077F734: mov ecx, 0x8a1e60 */
    RECOMP_CALL(sub_0060B7E0); /* 0x0077F739: call 0x60b7e0 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007826E0u); /* 0x0077F73E: push 0x7826e0 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077F743: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077F748: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F749: ret  */

}

void sub_0077F750(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F750u);

L_0077F750:
    PUSH32(esp, 0x007A9454u); /* 0x0077F750: push 0x7a9454 */
    ecx = 0x008A3250u; /* 0x0077F755: mov ecx, 0x8a3250 */
    RECOMP_CALL(sub_0060B780); /* 0x0077F75A: call 0x60b780 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x007A9454u); /* 0x0077F75F: push 0x7a9454 */
    ecx = 0x008A326Cu; /* 0x0077F764: mov ecx, 0x8a326c */
    RECOMP_CALL(sub_0060B780); /* 0x0077F769: call 0x60b780 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782700u); /* 0x0077F76E: push 0x782700 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077F773: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077F778: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F779: ret  */

}

void sub_0077F780(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F780u);

L_0077F780:
    fp_push(*(float*)&MEM32(0x7BFE08)); /* 0x0077F780: fld dword ptr [0x7bfe08] */
    _st[0] += _st[0]; /* 0x0077F786: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A710C) = _v; } /* 0x0077F788: fstp dword ptr [0x8a710c] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F78E: ret  */

}

void sub_0077F790(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F790u);

L_0077F790:
    fp_push(*(float*)&MEM32(0x7BFE08)); /* 0x0077F790: fld dword ptr [0x7bfe08] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x0077F796: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A7108) = _v; } /* 0x0077F79C: fstp dword ptr [0x8a7108] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F7A2: ret  */

}

void sub_0077F7B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F7B0u);

L_0077F7B0:
    fp_push(*(double*)ADDR(0x7BFE10)); /* 0x0077F7B0: fld qword ptr [0x7bfe10] */
    _st[0] += _st[0]; /* 0x0077F7B6: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8A7100) = _v; } /* 0x0077F7B8: fstp qword ptr [0x8a7100] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F7BE: ret  */

}

void sub_0077F7C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F7C0u);

L_0077F7C0:
    fp_push(*(double*)ADDR(0x7BFE10)); /* 0x0077F7C0: fld qword ptr [0x7bfe10] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x0077F7C6: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8A70F8) = _v; } /* 0x0077F7CC: fstp qword ptr [0x8a70f8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F7D2: ret  */

}

void sub_0077F7E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F7E0u);

L_0077F7E0:
    fp_push(*(float*)&MEM32(0x7BFE18)); /* 0x0077F7E0: fld dword ptr [0x7bfe18] */
    _st[0] += _st[0]; /* 0x0077F7E6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A713C) = _v; } /* 0x0077F7E8: fstp dword ptr [0x8a713c] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F7EE: ret  */

}

void sub_0077F7F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F7F0u);

L_0077F7F0:
    fp_push(*(float*)&MEM32(0x7BFE18)); /* 0x0077F7F0: fld dword ptr [0x7bfe18] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x0077F7F6: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A7138) = _v; } /* 0x0077F7FC: fstp dword ptr [0x8a7138] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F802: ret  */

}

void sub_0077F810(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F810u);

L_0077F810:
    fp_push(*(double*)ADDR(0x7BFE20)); /* 0x0077F810: fld qword ptr [0x7bfe20] */
    _st[0] += _st[0]; /* 0x0077F816: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8A7130) = _v; } /* 0x0077F818: fstp qword ptr [0x8a7130] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F81E: ret  */

}

void sub_0077F820(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F820u);

L_0077F820:
    fp_push(*(double*)ADDR(0x7BFE20)); /* 0x0077F820: fld qword ptr [0x7bfe20] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x0077F826: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8A7128) = _v; } /* 0x0077F82C: fstp qword ptr [0x8a7128] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F832: ret  */

}

void sub_0077F840(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F840u);

L_0077F840:
    ecx = 0x008A7114u; /* 0x0077F840: mov ecx, 0x8a7114 */
    RECOMP_CALL(sub_006D8340); /* 0x0077F845: call 0x6d8340 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782810u); /* 0x0077F84A: push 0x782810 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077F84F: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077F854: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F855: ret  */

}

void sub_0077F860(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F860u);

L_0077F860:
    ecx = 0x008A7168u; /* 0x0077F860: mov ecx, 0x8a7168 */
    RECOMP_CALL(sub_006D8340); /* 0x0077F865: call 0x6d8340 */
    RECOMP_FLAGS_IN();
    ecx = 0x008A717Cu; /* 0x0077F86A: mov ecx, 0x8a717c */
    RECOMP_CALL(sub_006D8340); /* 0x0077F86F: call 0x6d8340 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782820u); /* 0x0077F874: push 0x782820 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077F879: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077F87E: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F87F: ret  */

}

void sub_0077F880(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F880u);

L_0077F880:
    ecx = 0x008A7140u; /* 0x0077F880: mov ecx, 0x8a7140 */
    RECOMP_CALL(sub_006D8340); /* 0x0077F885: call 0x6d8340 */
    RECOMP_FLAGS_IN();
    ecx = 0x008A7154u; /* 0x0077F88A: mov ecx, 0x8a7154 */
    RECOMP_CALL(sub_006D8340); /* 0x0077F88F: call 0x6d8340 */
    RECOMP_FLAGS_IN();
    PUSH32(esp, 0x00782830u); /* 0x0077F894: push 0x782830 */
    RECOMP_CALL(sub_0075C51D); /* 0x0077F899: call 0x75c51d */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077F89E: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F89F: ret  */

}

void sub_0077F8A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F8A0u);

L_0077F8A0:
    fp_push(*(float*)&MEM32(0x7C05D0)); /* 0x0077F8A0: fld dword ptr [0x7c05d0] */
    _st[0] += _st[0]; /* 0x0077F8A6: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A71AC) = _v; } /* 0x0077F8A8: fstp dword ptr [0x8a71ac] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F8AE: ret  */

}

void sub_0077F8B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F8B0u);

L_0077F8B0:
    fp_push(*(float*)&MEM32(0x7C05D0)); /* 0x0077F8B0: fld dword ptr [0x7c05d0] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x0077F8B6: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A71A8) = _v; } /* 0x0077F8BC: fstp dword ptr [0x8a71a8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F8C2: ret  */

}

void sub_0077F8D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F8D0u);

L_0077F8D0:
    fp_push(*(double*)ADDR(0x7C05D8)); /* 0x0077F8D0: fld qword ptr [0x7c05d8] */
    _st[0] += _st[0]; /* 0x0077F8D6: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8A71A0) = _v; } /* 0x0077F8D8: fstp qword ptr [0x8a71a0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F8DE: ret  */

}

void sub_0077F8E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F8E0u);

L_0077F8E0:
    fp_push(*(double*)ADDR(0x7C05D8)); /* 0x0077F8E0: fld qword ptr [0x7c05d8] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x0077F8E6: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8A7198) = _v; } /* 0x0077F8EC: fstp qword ptr [0x8a7198] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F8F2: ret  */

}

void sub_0077F900(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F900u);

L_0077F900:
    fp_push(*(float*)&MEM32(0x7C05E8)); /* 0x0077F900: fld dword ptr [0x7c05e8] */
    _st[0] += _st[0]; /* 0x0077F906: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A71CC) = _v; } /* 0x0077F908: fstp dword ptr [0x8a71cc] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F90E: ret  */

}

void sub_0077F910(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F910u);

L_0077F910:
    fp_push(*(float*)&MEM32(0x7C05E8)); /* 0x0077F910: fld dword ptr [0x7c05e8] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x0077F916: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A71C8) = _v; } /* 0x0077F91C: fstp dword ptr [0x8a71c8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F922: ret  */

}

void sub_0077F930(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F930u);

L_0077F930:
    fp_push(*(double*)ADDR(0x7C05F0)); /* 0x0077F930: fld qword ptr [0x7c05f0] */
    _st[0] += _st[0]; /* 0x0077F936: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8A71C0) = _v; } /* 0x0077F938: fstp qword ptr [0x8a71c0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F93E: ret  */

}

void sub_0077F940(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F940u);

L_0077F940:
    fp_push(*(double*)ADDR(0x7C05F0)); /* 0x0077F940: fld qword ptr [0x7c05f0] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x0077F946: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8A71B8) = _v; } /* 0x0077F94C: fstp qword ptr [0x8a71b8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F952: ret  */

}

void sub_0077F960(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F960u);

L_0077F960:
    fp_push(*(float*)&MEM32(0x7C0600)); /* 0x0077F960: fld dword ptr [0x7c0600] */
    _st[0] += _st[0]; /* 0x0077F966: fadd st(0), st(0) */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A71E4) = _v; } /* 0x0077F968: fstp dword ptr [0x8a71e4] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F96E: ret  */

}

void sub_0077F970(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F970u);

L_0077F970:
    fp_push(*(float*)&MEM32(0x7C0600)); /* 0x0077F970: fld dword ptr [0x7c0600] */
    _st[0] *= (double)*(float*)ADDR(0x784260); /* 0x0077F976: fmul dword ptr [0x784260] */
    { float _v = (float)fp_pop(); *(float*)ADDR(0x8A71E0) = _v; } /* 0x0077F97C: fstp dword ptr [0x8a71e0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F982: ret  */

}

void sub_0077F990(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F990u);

L_0077F990:
    fp_push(*(double*)ADDR(0x7C0608)); /* 0x0077F990: fld qword ptr [0x7c0608] */
    _st[0] += _st[0]; /* 0x0077F996: fadd st(0), st(0) */
    { double _v = fp_pop(); *(double*)ADDR(0x8A71D8) = _v; } /* 0x0077F998: fstp qword ptr [0x8a71d8] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F99E: ret  */

}

void sub_0077F9A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077F9A0u);

L_0077F9A0:
    fp_push(*(double*)ADDR(0x7C0608)); /* 0x0077F9A0: fld qword ptr [0x7c0608] */
    _st[0] *= *(double*)ADDR(0x7864E0); /* 0x0077F9A6: fmul qword ptr [0x7864e0] */
    { double _v = fp_pop(); *(double*)ADDR(0x8A71D0) = _v; } /* 0x0077F9AC: fstp qword ptr [0x8a71d0] */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077F9B2: ret  */

}