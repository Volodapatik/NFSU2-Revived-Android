/* AUTO-GENERATED from SPEED2.analysis.exe by run_lift.py (pcrecomp lift32). DO NOT EDIT, DO NOT COMMIT. */
#define RECOMP_GENERATED_CODE
#include "recomp_types.h"
#include "recomp_funcs.h"
#include "guest_render_probe.h"
#include <math.h>
#include <string.h>

void sub_00777BF4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777BF4u);

    goto L_00777BF4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777BF4:
    eax = 0x007E3140u; /* 0x00777BF4: mov eax, 0x7e3140 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777BF9: jmp 0x75bf0e */

}

void sub_00777C00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777C00u);

L_00777C00:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777C00: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00777C03: jmp 0x553a80 */

}

void sub_00777C08(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777C08u);

L_00777C08:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777C08: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4Cu; /* 0x00777C0B: add ecx, 0x4c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00490340u); RECOMP_RETURN(); /* 0x00777C0E: jmp 0x490340 */

}

void sub_00777C13(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777C13u);

    goto L_00777C13;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777C13:
    eax = 0x007E316Cu; /* 0x00777C13: mov eax, 0x7e316c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777C18: jmp 0x75bf0e */

}

void sub_00777C20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777C20u);

L_00777C20:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777C20: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00777C23: jmp 0x553a80 */

}

void sub_00777C28(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777C28u);

L_00777C28:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777C28: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4Cu; /* 0x00777C2B: add ecx, 0x4c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00777C2E: jmp 0x5cde60 */

}

void sub_00777C33(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777C33u);

L_00777C33:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777C33: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x58u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x58u; /* 0x00777C36: add ecx, 0x58 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00777C39: jmp 0x5cde60 */

}

void sub_00777C3E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777C3Eu);

L_00777C3E:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777C3E: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x64u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x64u; /* 0x00777C41: add ecx, 0x64 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00777C44: jmp 0x5cde60 */

}

void sub_00777C49(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777C49u);

L_00777C49:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777C49: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x70u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x70u; /* 0x00777C4C: add ecx, 0x70 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00777C4F: jmp 0x5cde60 */

}

void sub_00777C54(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777C54u);

L_00777C54:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777C54: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x7Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x7Cu; /* 0x00777C57: add ecx, 0x7c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x00777C5A: jmp 0x5ce0f0 */

}

void sub_00777C5F(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777C5Fu);

    goto L_00777C5F;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777C5F:
    eax = 0x007E31B8u; /* 0x00777C5F: mov eax, 0x7e31b8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777C64: jmp 0x75bf0e */

}

void sub_00777C70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777C70u);

L_00777C70:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777C70: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00777C73: jmp 0x553a80 */

}

void sub_00777C78(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777C78u);

L_00777C78:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777C78: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4Cu; /* 0x00777C7B: add ecx, 0x4c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00777C7E: jmp 0x5cde60 */

}

void sub_00777C83(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777C83u);

L_00777C83:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777C83: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x58u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x58u; /* 0x00777C86: add ecx, 0x58 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00777C89: jmp 0x5cde60 */

}

void sub_00777C8E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777C8Eu);

L_00777C8E:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777C8E: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x64u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x64u; /* 0x00777C91: add ecx, 0x64 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00777C94: jmp 0x5cde60 */

}

void sub_00777C99(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777C99u);

L_00777C99:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777C99: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x70u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x70u; /* 0x00777C9C: add ecx, 0x70 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00777C9F: jmp 0x5cde60 */

}

void sub_00777CA4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777CA4u);

    goto L_00777CA4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777CA4:
    eax = 0x007E31FCu; /* 0x00777CA4: mov eax, 0x7e31fc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777CA9: jmp 0x75bf0e */

}

void sub_00777CB0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777CB0u);

L_00777CB0:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777CB0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004DEF50u); RECOMP_RETURN(); /* 0x00777CB3: jmp 0x4def50 */

}

void sub_00777CB8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777CB8u);

    goto L_00777CB8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777CB8:
    eax = 0x007E3B48u; /* 0x00777CB8: mov eax, 0x7e3b48 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777CBD: jmp 0x75bf0e */

}

void sub_00777CD0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777CD0u);

L_00777CD0:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777CD0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004CBB50u); RECOMP_RETURN(); /* 0x00777CD3: jmp 0x4cbb50 */

}

void sub_00777CD8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777CD8u);

    goto L_00777CD8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777CD8:
    eax = 0x007E3854u; /* 0x00777CD8: mov eax, 0x7e3854 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777CDD: jmp 0x75bf0e */

}

void sub_00777CF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777CF0u);

L_00777CF0:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777CF0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00777CF3: jmp 0x553a80 */

}

void sub_00777CF8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777CF8u);

L_00777CF8:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777CF8: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x50u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x50u; /* 0x00777CFB: add ecx, 0x50 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0052E930u); RECOMP_RETURN(); /* 0x00777CFE: jmp 0x52e930 */

}

void sub_00777D03(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777D03u);

    goto L_00777D03;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777D03:
    eax = 0x007E3228u; /* 0x00777D03: mov eax, 0x7e3228 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777D08: jmp 0x75bf0e */

}

void sub_00777D10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777D10u);

L_00777D10:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777D10: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00777D13: jmp 0x553a80 */

}

void sub_00777D18(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777D18u);

L_00777D18:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777D18: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x54u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x54u; /* 0x00777D1B: add ecx, 0x54 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00579D30u); RECOMP_RETURN(); /* 0x00777D1E: jmp 0x579d30 */

}

void sub_00777D23(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777D23u);

    goto L_00777D23;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777D23:
    eax = 0x007E3280u; /* 0x00777D23: mov eax, 0x7e3280 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777D28: jmp 0x75bf0e */

}

void sub_00777D30(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777D30u);

L_00777D30:
    PUSH32(esp, 0); /* 0x00777D30: push 0 */
    PUSH32(esp, 0x0079CB54u); /* 0x00777D32: push 0x79cb54 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777D37: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00777D3A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00777D3B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777D40: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777D43: ret  */

}

void sub_00777D44(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777D44u);

    goto L_00777D44;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777D44:
    eax = 0x007E32A4u; /* 0x00777D44: mov eax, 0x7e32a4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777D49: jmp 0x75bf0e */

}

void sub_00777D50(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777D50u);

L_00777D50:
    ecx = MEM32(ebp + (-0x1C)); /* 0x00777D50: mov ecx, dword ptr [ebp - 0x1c] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00777D53: jmp 0x553a80 */

}

void sub_00777D58(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777D58u);

L_00777D58:
    ecx = MEM32(ebp + (-0x1C)); /* 0x00777D58: mov ecx, dword ptr [ebp - 0x1c] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4Cu; /* 0x00777D5B: add ecx, 0x4c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004CBAA0u); RECOMP_RETURN(); /* 0x00777D5E: jmp 0x4cbaa0 */

}

void sub_00777D63(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777D63u);

L_00777D63:
    ecx = ebp + (-0x18); /* 0x00777D63: lea ecx, [ebp - 0x18] */
    RECOMP_ITAIL(0x0050C9F0u); RECOMP_RETURN(); /* 0x00777D66: jmp 0x50c9f0 */

}

void sub_00777D6B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777D6Bu);

    goto L_00777D6B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777D6B:
    eax = 0x007E32D8u; /* 0x00777D6B: mov eax, 0x7e32d8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777D70: jmp 0x75bf0e */

}

void sub_00777D80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777D80u);

L_00777D80:
    PUSH32(esp, 0); /* 0x00777D80: push 0 */
    PUSH32(esp, 0x0079CB9Cu); /* 0x00777D82: push 0x79cb9c */
    eax = MEM32(ebp + (-0x10)); /* 0x00777D87: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00777D8A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00777D8B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777D90: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777D93: ret  */

}

void sub_00777D94(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777D94u);

    goto L_00777D94;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777D94:
    eax = 0x007E32FCu; /* 0x00777D94: mov eax, 0x7e32fc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777D99: jmp 0x75bf0e */

}

void sub_00777DA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777DA0u);

L_00777DA0:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777DA0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x0051AA70u); RECOMP_RETURN(); /* 0x00777DA3: jmp 0x51aa70 */

}

void sub_00777DA8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777DA8u);

L_00777DA8:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777DA8: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x34u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x34u; /* 0x00777DAB: add ecx, 0x34 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00525C10u); RECOMP_RETURN(); /* 0x00777DAE: jmp 0x525c10 */

}

void sub_00777DB3(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777DB3u);

L_00777DB3:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777DB3: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x44u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x44u; /* 0x00777DB6: add ecx, 0x44 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00525C10u); RECOMP_RETURN(); /* 0x00777DB9: jmp 0x525c10 */

}

void sub_00777DBE(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777DBEu);

L_00777DBE:
    eax = MEM32(ebp + 0x4); /* 0x00777DBE: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00777DC1: push eax */
    RECOMP_CALL(sub_0052B950); /* 0x00777DC2: call 0x52b950 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00777DC7: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777DC8: ret  */

}

void sub_00777DC9(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777DC9u);

    goto L_00777DC9;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777DC9:
    eax = 0x007E3338u; /* 0x00777DC9: mov eax, 0x7e3338 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777DCE: jmp 0x75bf0e */

}

void sub_00777DE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777DE0u);

L_00777DE0:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777DE0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x0052AF20u); RECOMP_RETURN(); /* 0x00777DE3: jmp 0x52af20 */

}

void sub_00777DE8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777DE8u);

L_00777DE8:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777DE8: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x5Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x5Cu; /* 0x00777DEB: add ecx, 0x5c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00525C10u); RECOMP_RETURN(); /* 0x00777DEE: jmp 0x525c10 */

}

void sub_00777DF3(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777DF3u);

    goto L_00777DF3;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777DF3:
    eax = 0x007E3388u; /* 0x00777DF3: mov eax, 0x7e3388 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777DF8: jmp 0x75bf0e */

}

void sub_00777E00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777E00u);

L_00777E00:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777E00: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x0052AF20u); RECOMP_RETURN(); /* 0x00777E03: jmp 0x52af20 */

}

void sub_00777E08(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777E08u);

L_00777E08:
    ecx = MEM32(ebp + (-0x10)); /* 0x00777E08: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x64u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x64u; /* 0x00777E0B: add ecx, 0x64 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0050D2D0u); RECOMP_RETURN(); /* 0x00777E0E: jmp 0x50d2d0 */

}

void sub_00777E13(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777E13u);

    goto L_00777E13;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777E13:
    eax = 0x007E33B4u; /* 0x00777E13: mov eax, 0x7e33b4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777E18: jmp 0x75bf0e */

}

void sub_00777E20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777E20u);

L_00777E20:
    PUSH32(esp, 0); /* 0x00777E20: push 0 */
    PUSH32(esp, 0x0079CBACu); /* 0x00777E22: push 0x79cbac */
    eax = MEM32(ebp + (-0x10)); /* 0x00777E27: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00777E2A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00777E2B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777E30: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777E33: ret  */

}

void sub_00777E34(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777E34u);

    goto L_00777E34;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777E34:
    eax = 0x007E33D8u; /* 0x00777E34: mov eax, 0x7e33d8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777E39: jmp 0x75bf0e */

}

void sub_00777E40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777E40u);

L_00777E40:
    PUSH32(esp, 0); /* 0x00777E40: push 0 */
    PUSH32(esp, 0x0079CBC4u); /* 0x00777E42: push 0x79cbc4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777E47: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00777E4A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00777E4B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777E50: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777E53: ret  */

}

void sub_00777E54(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777E54u);

    goto L_00777E54;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777E54:
    eax = 0x007E33FCu; /* 0x00777E54: mov eax, 0x7e33fc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777E59: jmp 0x75bf0e */

}

void sub_00777E60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777E60u);

L_00777E60:
    PUSH32(esp, 0); /* 0x00777E60: push 0 */
    PUSH32(esp, 0x0079CBD4u); /* 0x00777E62: push 0x79cbd4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777E67: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00777E6A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00777E6B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777E70: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777E73: ret  */

}

void sub_00777E74(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777E74u);

    goto L_00777E74;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777E74:
    eax = 0x007E3420u; /* 0x00777E74: mov eax, 0x7e3420 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777E79: jmp 0x75bf0e */

}

void sub_00777E80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777E80u);

L_00777E80:
    PUSH32(esp, 0); /* 0x00777E80: push 0 */
    PUSH32(esp, 0x0079CBE8u); /* 0x00777E82: push 0x79cbe8 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777E87: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00777E8A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00777E8B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777E90: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777E93: ret  */

}

void sub_00777E94(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777E94u);

    goto L_00777E94;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777E94:
    eax = 0x007E3444u; /* 0x00777E94: mov eax, 0x7e3444 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777E99: jmp 0x75bf0e */

}

void sub_00777EA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777EA0u);

L_00777EA0:
    PUSH32(esp, 0); /* 0x00777EA0: push 0 */
    PUSH32(esp, 0x0079CBF8u); /* 0x00777EA2: push 0x79cbf8 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777EA7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00777EAA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00777EAB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777EB0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777EB3: ret  */

}

void sub_00777EB4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777EB4u);

    goto L_00777EB4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777EB4:
    eax = 0x007E3468u; /* 0x00777EB4: mov eax, 0x7e3468 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777EB9: jmp 0x75bf0e */

}

void sub_00777EC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777EC0u);

L_00777EC0:
    PUSH32(esp, 0); /* 0x00777EC0: push 0 */
    PUSH32(esp, 0x0079CC0Cu); /* 0x00777EC2: push 0x79cc0c */
    eax = MEM32(ebp + (-0x10)); /* 0x00777EC7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00777ECA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00777ECB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777ED0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777ED3: ret  */

}

void sub_00777ED4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777ED4u);

    goto L_00777ED4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777ED4:
    eax = 0x007E348Cu; /* 0x00777ED4: mov eax, 0x7e348c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777ED9: jmp 0x75bf0e */

}

void sub_00777EE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777EE0u);

L_00777EE0:
    PUSH32(esp, 0); /* 0x00777EE0: push 0 */
    PUSH32(esp, 0x0079CC20u); /* 0x00777EE2: push 0x79cc20 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777EE7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00777EEA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00777EEB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777EF0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777EF3: ret  */

}

void sub_00777EF4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777EF4u);

    goto L_00777EF4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777EF4:
    eax = 0x007E34B0u; /* 0x00777EF4: mov eax, 0x7e34b0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777EF9: jmp 0x75bf0e */

}

void sub_00777F00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777F00u);

L_00777F00:
    PUSH32(esp, 0); /* 0x00777F00: push 0 */
    PUSH32(esp, 0x0079CC50u); /* 0x00777F02: push 0x79cc50 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777F07: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00777F0A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00777F0B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777F10: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777F13: ret  */

}

void sub_00777F14(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777F14u);

    goto L_00777F14;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777F14:
    eax = 0x007E34D4u; /* 0x00777F14: mov eax, 0x7e34d4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777F19: jmp 0x75bf0e */

}

void sub_00777F20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777F20u);

L_00777F20:
    PUSH32(esp, 0); /* 0x00777F20: push 0 */
    PUSH32(esp, 0x0079CC60u); /* 0x00777F22: push 0x79cc60 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777F27: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00777F2A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00777F2B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777F30: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777F33: ret  */

}

void sub_00777F34(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777F34u);

    goto L_00777F34;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777F34:
    eax = 0x007E34F8u; /* 0x00777F34: mov eax, 0x7e34f8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777F39: jmp 0x75bf0e */

}

void sub_00777F40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777F40u);

L_00777F40:
    PUSH32(esp, 0); /* 0x00777F40: push 0 */
    PUSH32(esp, 0x0079CC70u); /* 0x00777F42: push 0x79cc70 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777F47: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00777F4A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00777F4B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777F50: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777F53: ret  */

}

void sub_00777F54(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777F54u);

    goto L_00777F54;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777F54:
    eax = 0x007E351Cu; /* 0x00777F54: mov eax, 0x7e351c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777F59: jmp 0x75bf0e */

}

void sub_00777F60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777F60u);

L_00777F60:
    PUSH32(esp, 0); /* 0x00777F60: push 0 */
    PUSH32(esp, 0x0079CC80u); /* 0x00777F62: push 0x79cc80 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777F67: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00777F6A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00777F6B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777F70: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777F73: ret  */

}

void sub_00777F74(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777F74u);

    goto L_00777F74;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777F74:
    eax = 0x007E3540u; /* 0x00777F74: mov eax, 0x7e3540 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777F79: jmp 0x75bf0e */

}

void sub_00777F80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777F80u);

L_00777F80:
    PUSH32(esp, 0); /* 0x00777F80: push 0 */
    PUSH32(esp, 0x0079CC90u); /* 0x00777F82: push 0x79cc90 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777F87: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00777F8A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00777F8B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777F90: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777F93: ret  */

}

void sub_00777F94(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777F94u);

    goto L_00777F94;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777F94:
    eax = 0x007E3564u; /* 0x00777F94: mov eax, 0x7e3564 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777F99: jmp 0x75bf0e */

}

void sub_00777FA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777FA0u);

L_00777FA0:
    eax = MEM32(ebp + (-0x10)); /* 0x00777FA0: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00777FA3: push eax */
    RECOMP_CALL(sub_00575590); /* 0x00777FA4: call 0x575590 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00777FA9: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777FAA: ret  */

}

void sub_00777FAB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777FABu);

    goto L_00777FAB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777FAB:
    eax = 0x007E3588u; /* 0x00777FAB: mov eax, 0x7e3588 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777FB0: jmp 0x75bf0e */

}

void sub_00777FC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777FC0u);

L_00777FC0:
    eax = MEM32(ebp + 0x8); /* 0x00777FC0: mov eax, dword ptr [ebp + 8] */
    PUSH32(esp, eax); /* 0x00777FC3: push eax */
    RECOMP_CALL(sub_00575590); /* 0x00777FC4: call 0x575590 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00777FC9: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777FCA: ret  */

}

void sub_00777FCB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777FCBu);

    goto L_00777FCB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777FCB:
    eax = 0x007E35ACu; /* 0x00777FCB: mov eax, 0x7e35ac */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777FD0: jmp 0x75bf0e */

}

void sub_00777FE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777FE0u);

L_00777FE0:
    PUSH32(esp, 0); /* 0x00777FE0: push 0 */
    PUSH32(esp, 0x0079CCA0u); /* 0x00777FE2: push 0x79cca0 */
    eax = MEM32(ebp + (-0x10)); /* 0x00777FE7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00777FEA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00777FEB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00777FF0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00777FF3: ret  */

}

void sub_00777FF4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00777FF4u);

    goto L_00777FF4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00777FF4:
    eax = 0x007E35D0u; /* 0x00777FF4: mov eax, 0x7e35d0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00777FF9: jmp 0x75bf0e */

}

void sub_00778000(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778000u);

L_00778000:
    PUSH32(esp, 0); /* 0x00778000: push 0 */
    PUSH32(esp, 0x0079CD50u); /* 0x00778002: push 0x79cd50 */
    eax = MEM32(ebp + (-0x10)); /* 0x00778007: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077800A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077800B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00778010: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778013: ret  */

}

void sub_00778014(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778014u);

    goto L_00778014;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778014:
    eax = 0x007E3618u; /* 0x00778014: mov eax, 0x7e3618 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778019: jmp 0x75bf0e */

}

void sub_00778020(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778020u);

L_00778020:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778020: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004DEF50u); RECOMP_RETURN(); /* 0x00778023: jmp 0x4def50 */

}

void sub_00778028(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778028u);

L_00778028:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778028: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x154u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x154u; /* 0x0077802B: add ecx, 0x154 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0049D820u); RECOMP_RETURN(); /* 0x00778031: jmp 0x49d820 */

}

void sub_00778036(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778036u);

    goto L_00778036;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778036:
    eax = 0x007E3644u; /* 0x00778036: mov eax, 0x7e3644 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077803B: jmp 0x75bf0e */

}

void sub_00778040(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778040u);

L_00778040:
    ecx = MEM32(ebp + (-0x904)); /* 0x00778040: mov ecx, dword ptr [ebp - 0x904] */
    RECOMP_ITAIL(0x004DEF50u); RECOMP_RETURN(); /* 0x00778046: jmp 0x4def50 */

}

void sub_0077804B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077804Bu);

L_0077804B:
    ecx = ebp + (-0x900); /* 0x0077804B: lea ecx, [ebp - 0x900] */
    RECOMP_ITAIL(0x0040BE20u); RECOMP_RETURN(); /* 0x00778051: jmp 0x40be20 */

}

void sub_00778056(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778056u);

    goto L_00778056;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778056:
    eax = 0x007E3670u; /* 0x00778056: mov eax, 0x7e3670 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077805B: jmp 0x75bf0e */

}

void sub_00778060(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778060u);

L_00778060:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778060: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00778063: jmp 0x553a80 */

}

void sub_00778068(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778068u);

L_00778068:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778068: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x54u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x54u; /* 0x0077806B: add ecx, 0x54 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004FF410u); RECOMP_RETURN(); /* 0x0077806E: jmp 0x4ff410 */

}

void sub_00778073(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778073u);

L_00778073:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778073: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x98u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x98u; /* 0x00778076: add ecx, 0x98 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004FF410u); RECOMP_RETURN(); /* 0x0077807C: jmp 0x4ff410 */

}

void sub_00778081(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778081u);

L_00778081:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778081: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0xDCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0xDCu; /* 0x00778084: add ecx, 0xdc */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004FF410u); RECOMP_RETURN(); /* 0x0077808A: jmp 0x4ff410 */

}

void sub_0077808F(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077808Fu);

    goto L_0077808F;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077808F:
    eax = 0x007E36ACu; /* 0x0077808F: mov eax, 0x7e36ac */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778094: jmp 0x75bf0e */

}

void sub_007780A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007780A0u);

L_007780A0:
    PUSH32(esp, 0); /* 0x007780A0: push 0 */
    PUSH32(esp, 0x0079D278u); /* 0x007780A2: push 0x79d278 */
    eax = MEM32(ebp + (-0x10)); /* 0x007780A7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007780AA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007780AB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007780B0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007780B3: ret  */

}

void sub_007780B4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007780B4u);

    goto L_007780B4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007780B4:
    eax = 0x007E36D0u; /* 0x007780B4: mov eax, 0x7e36d0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007780B9: jmp 0x75bf0e */

}

void sub_007780C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007780C0u);

L_007780C0:
    PUSH32(esp, 0); /* 0x007780C0: push 0 */
    PUSH32(esp, 0x0079BE5Cu); /* 0x007780C2: push 0x79be5c */
    eax = MEM32(ebp + (-0x10)); /* 0x007780C7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007780CA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007780CB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007780D0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007780D3: ret  */

}

void sub_007780D4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007780D4u);

L_007780D4:
    PUSH32(esp, 0); /* 0x007780D4: push 0 */
    PUSH32(esp, 0x0079D2A8u); /* 0x007780D6: push 0x79d2a8 */
    eax = MEM32(ebp + (-0x10)); /* 0x007780DB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007780DE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007780DF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007780E4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007780E7: ret  */

}

void sub_007780E8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007780E8u);

L_007780E8:
    PUSH32(esp, 0); /* 0x007780E8: push 0 */
    PUSH32(esp, 0x0079BE5Cu); /* 0x007780EA: push 0x79be5c */
    eax = MEM32(ebp + (-0x10)); /* 0x007780EF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007780F2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007780F3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007780F8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007780FB: ret  */

}

void sub_007780FC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007780FCu);

L_007780FC:
    PUSH32(esp, 0); /* 0x007780FC: push 0 */
    PUSH32(esp, 0x0079BE5Cu); /* 0x007780FE: push 0x79be5c */
    eax = MEM32(ebp + (-0x10)); /* 0x00778103: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00778106: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00778107: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077810C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077810F: ret  */

}

void sub_00778110(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778110u);

L_00778110:
    PUSH32(esp, 0); /* 0x00778110: push 0 */
    PUSH32(esp, 0x0079D2A8u); /* 0x00778112: push 0x79d2a8 */
    eax = MEM32(ebp + (-0x10)); /* 0x00778117: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077811A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077811B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00778120: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778123: ret  */

}

void sub_00778124(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778124u);

L_00778124:
    PUSH32(esp, 0); /* 0x00778124: push 0 */
    PUSH32(esp, 0x0079BE5Cu); /* 0x00778126: push 0x79be5c */
    eax = MEM32(ebp + (-0x10)); /* 0x0077812B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077812E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077812F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00778134: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778137: ret  */

}

void sub_00778138(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778138u);

L_00778138:
    PUSH32(esp, 0); /* 0x00778138: push 0 */
    PUSH32(esp, 0x0079BE5Cu); /* 0x0077813A: push 0x79be5c */
    eax = MEM32(ebp + (-0x10)); /* 0x0077813F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00778142: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00778143: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00778148: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077814B: ret  */

}

void sub_0077814C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077814Cu);

L_0077814C:
    PUSH32(esp, 0); /* 0x0077814C: push 0 */
    PUSH32(esp, 0x0079BE5Cu); /* 0x0077814E: push 0x79be5c */
    eax = MEM32(ebp + (-0x10)); /* 0x00778153: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00778156: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00778157: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077815C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077815F: ret  */

}

void sub_00778160(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778160u);

L_00778160:
    PUSH32(esp, 0); /* 0x00778160: push 0 */
    PUSH32(esp, 0x0079BE5Cu); /* 0x00778162: push 0x79be5c */
    eax = MEM32(ebp + (-0x10)); /* 0x00778167: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077816A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077816B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00778170: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778173: ret  */

}

void sub_00778174(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778174u);

L_00778174:
    PUSH32(esp, 0); /* 0x00778174: push 0 */
    PUSH32(esp, 0x0079D290u); /* 0x00778176: push 0x79d290 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077817B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077817E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077817F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00778184: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778187: ret  */

}

void sub_00778188(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778188u);

L_00778188:
    PUSH32(esp, 0); /* 0x00778188: push 0 */
    PUSH32(esp, 0x0079BE5Cu); /* 0x0077818A: push 0x79be5c */
    eax = MEM32(ebp + (-0x10)); /* 0x0077818F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00778192: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00778193: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00778198: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077819B: ret  */

}

void sub_0077819C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077819Cu);

L_0077819C:
    PUSH32(esp, 0); /* 0x0077819C: push 0 */
    PUSH32(esp, 0x0079BE5Cu); /* 0x0077819E: push 0x79be5c */
    eax = MEM32(ebp + (-0x10)); /* 0x007781A3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007781A6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007781A7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007781AC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007781AF: ret  */

}

void sub_007781B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007781B0u);

L_007781B0:
    PUSH32(esp, 0); /* 0x007781B0: push 0 */
    PUSH32(esp, 0x0079BE5Cu); /* 0x007781B2: push 0x79be5c */
    eax = MEM32(ebp + (-0x10)); /* 0x007781B7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007781BA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007781BB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007781C0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007781C3: ret  */

}

void sub_007781C4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007781C4u);

    goto L_007781C4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007781C4:
    eax = 0x007E37A4u; /* 0x007781C4: mov eax, 0x7e37a4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007781C9: jmp 0x75bf0e */

}

void sub_007781D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007781D0u);

L_007781D0:
    PUSH32(esp, 0); /* 0x007781D0: push 0 */
    PUSH32(esp, 0x0079D2BCu); /* 0x007781D2: push 0x79d2bc */
    eax = MEM32(ebp + (-0x10)); /* 0x007781D7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007781DA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007781DB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007781E0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007781E3: ret  */

}

void sub_007781E4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007781E4u);

    goto L_007781E4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007781E4:
    eax = 0x007E37C8u; /* 0x007781E4: mov eax, 0x7e37c8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007781E9: jmp 0x75bf0e */

}

void sub_007781F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007781F0u);

L_007781F0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007781F0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004DEF50u); RECOMP_RETURN(); /* 0x007781F3: jmp 0x4def50 */

}

void sub_007781F8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007781F8u);

L_007781F8:
    ecx = MEM32(ebp + (-0x10)); /* 0x007781F8: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x150u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x150u; /* 0x007781FB: add ecx, 0x150 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00490340u); RECOMP_RETURN(); /* 0x00778201: jmp 0x490340 */

}

void sub_00778206(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778206u);

L_00778206:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778206: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x164u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x164u; /* 0x00778209: add ecx, 0x164 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004FF410u); RECOMP_RETURN(); /* 0x0077820F: jmp 0x4ff410 */

}

void sub_00778214(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778214u);

L_00778214:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778214: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x1B0u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x1B0u; /* 0x00778217: add ecx, 0x1b0 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004FF410u); RECOMP_RETURN(); /* 0x0077821D: jmp 0x4ff410 */

}

void sub_00778222(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778222u);

L_00778222:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778222: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x1FCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x1FCu; /* 0x00778225: add ecx, 0x1fc */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004FF410u); RECOMP_RETURN(); /* 0x0077822B: jmp 0x4ff410 */

}

void sub_00778230(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778230u);

    goto L_00778230;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778230:
    eax = 0x007E380Cu; /* 0x00778230: mov eax, 0x7e380c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778235: jmp 0x75bf0e */

}

void sub_00778240(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778240u);

L_00778240:
    PUSH32(esp, 0); /* 0x00778240: push 0 */
    PUSH32(esp, 0x0079D2F4u); /* 0x00778242: push 0x79d2f4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00778247: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077824A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077824B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00778250: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778253: ret  */

}

void sub_00778254(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778254u);

    goto L_00778254;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778254:
    eax = 0x007E3830u; /* 0x00778254: mov eax, 0x7e3830 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778259: jmp 0x75bf0e */

}

void sub_00778260(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778260u);

L_00778260:
    PUSH32(esp, 0); /* 0x00778260: push 0 */
    PUSH32(esp, 0x0079D384u); /* 0x00778262: push 0x79d384 */
    eax = MEM32(ebp + (-0x10)); /* 0x00778267: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077826A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077826B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00778270: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778273: ret  */

}

void sub_00778274(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778274u);

    goto L_00778274;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778274:
    eax = 0x007E3878u; /* 0x00778274: mov eax, 0x7e3878 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778279: jmp 0x75bf0e */

}

void sub_00778280(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778280u);

L_00778280:
    PUSH32(esp, 0); /* 0x00778280: push 0 */
    PUSH32(esp, 0x0079D398u); /* 0x00778282: push 0x79d398 */
    eax = MEM32(ebp + (-0x10)); /* 0x00778287: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077828A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077828B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00778290: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778293: ret  */

}

void sub_00778294(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778294u);

    goto L_00778294;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778294:
    eax = 0x007E389Cu; /* 0x00778294: mov eax, 0x7e389c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778299: jmp 0x75bf0e */

}

void sub_007782A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007782A0u);

L_007782A0:
    PUSH32(esp, 0); /* 0x007782A0: push 0 */
    PUSH32(esp, 0x0079D3CCu); /* 0x007782A2: push 0x79d3cc */
    eax = MEM32(ebp + (-0x10)); /* 0x007782A7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007782AA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007782AB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007782B0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007782B3: ret  */

}

void sub_007782B4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007782B4u);

    goto L_007782B4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007782B4:
    eax = 0x007E38C0u; /* 0x007782B4: mov eax, 0x7e38c0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007782B9: jmp 0x75bf0e */

}

void sub_007782C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007782C0u);

L_007782C0:
    PUSH32(esp, 0); /* 0x007782C0: push 0 */
    PUSH32(esp, 0x0079D690u); /* 0x007782C2: push 0x79d690 */
    eax = MEM32(ebp + (-0x10)); /* 0x007782C7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007782CA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007782CB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007782D0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007782D3: ret  */

}

void sub_007782D4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007782D4u);

    goto L_007782D4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007782D4:
    eax = 0x007E38E4u; /* 0x007782D4: mov eax, 0x7e38e4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007782D9: jmp 0x75bf0e */

}

void sub_007782E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007782E0u);

L_007782E0:
    PUSH32(esp, 0); /* 0x007782E0: push 0 */
    PUSH32(esp, 0x0079D6B4u); /* 0x007782E2: push 0x79d6b4 */
    eax = MEM32(ebp + (-0x10)); /* 0x007782E7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007782EA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007782EB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007782F0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007782F3: ret  */

}

void sub_007782F4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007782F4u);

    goto L_007782F4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007782F4:
    eax = 0x007E3908u; /* 0x007782F4: mov eax, 0x7e3908 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007782F9: jmp 0x75bf0e */

}

void sub_00778300(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778300u);

L_00778300:
    PUSH32(esp, 0); /* 0x00778300: push 0 */
    PUSH32(esp, 0x0079D6C8u); /* 0x00778302: push 0x79d6c8 */
    eax = MEM32(ebp + (-0x10)); /* 0x00778307: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077830A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077830B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00778310: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778313: ret  */

}

void sub_00778314(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778314u);

    goto L_00778314;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778314:
    eax = 0x007E392Cu; /* 0x00778314: mov eax, 0x7e392c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778319: jmp 0x75bf0e */

}

void sub_00778320(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778320u);

L_00778320:
    PUSH32(esp, 0); /* 0x00778320: push 0 */
    PUSH32(esp, 0x0079D6DCu); /* 0x00778322: push 0x79d6dc */
    eax = MEM32(ebp + (-0x10)); /* 0x00778327: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077832A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077832B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00778330: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778333: ret  */

}

void sub_00778334(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778334u);

    goto L_00778334;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778334:
    eax = 0x007E3950u; /* 0x00778334: mov eax, 0x7e3950 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778339: jmp 0x75bf0e */

}

void sub_00778340(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778340u);

L_00778340:
    PUSH32(esp, 0); /* 0x00778340: push 0 */
    PUSH32(esp, 0x0079D6F4u); /* 0x00778342: push 0x79d6f4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00778347: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077834A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077834B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00778350: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778353: ret  */

}

void sub_00778354(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778354u);

    goto L_00778354;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778354:
    eax = 0x007E3974u; /* 0x00778354: mov eax, 0x7e3974 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778359: jmp 0x75bf0e */

}

void sub_00778360(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778360u);

L_00778360:
    PUSH32(esp, 0); /* 0x00778360: push 0 */
    PUSH32(esp, 0x0079D708u); /* 0x00778362: push 0x79d708 */
    eax = MEM32(ebp + (-0x10)); /* 0x00778367: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077836A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077836B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00778370: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778373: ret  */

}

void sub_00778374(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778374u);

    goto L_00778374;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778374:
    eax = 0x007E3998u; /* 0x00778374: mov eax, 0x7e3998 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778379: jmp 0x75bf0e */

}

void sub_00778380(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778380u);

L_00778380:
    ecx = MEM32(ebp + (-0x904)); /* 0x00778380: mov ecx, dword ptr [ebp - 0x904] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00778386: jmp 0x553a80 */

}

void sub_0077838B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077838Bu);

L_0077838B:
    ecx = MEM32(ebp + (-0x904)); /* 0x0077838B: mov ecx, dword ptr [ebp - 0x904] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4Cu; /* 0x00778391: add ecx, 0x4c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0052E930u); RECOMP_RETURN(); /* 0x00778394: jmp 0x52e930 */

}

void sub_00778399(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778399u);

L_00778399:
    ecx = MEM32(ebp + (-0x904)); /* 0x00778399: mov ecx, dword ptr [ebp - 0x904] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0xB0u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0xB0u; /* 0x0077839F: add ecx, 0xb0 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0052E930u); RECOMP_RETURN(); /* 0x007783A5: jmp 0x52e930 */

}

void sub_007783AA(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007783AAu);

L_007783AA:
    ecx = ebp + (-0x900); /* 0x007783AA: lea ecx, [ebp - 0x900] */
    RECOMP_ITAIL(0x0040BE20u); RECOMP_RETURN(); /* 0x007783B0: jmp 0x40be20 */

}

void sub_007783B5(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007783B5u);

    goto L_007783B5;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007783B5:
    eax = 0x007E39D4u; /* 0x007783B5: mov eax, 0x7e39d4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007783BA: jmp 0x75bf0e */

}

void sub_007783C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007783C0u);

L_007783C0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007783C0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x007783C3: jmp 0x553a80 */

}

void sub_007783C8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007783C8u);

L_007783C8:
    ecx = MEM32(ebp + (-0x10)); /* 0x007783C8: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4Cu; /* 0x007783CB: add ecx, 0x4c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0052E930u); RECOMP_RETURN(); /* 0x007783CE: jmp 0x52e930 */

}

void sub_007783D3(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007783D3u);

    goto L_007783D3;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007783D3:
    eax = 0x007E3A00u; /* 0x007783D3: mov eax, 0x7e3a00 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007783D8: jmp 0x75bf0e */

}

void sub_007783E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007783E0u);

L_007783E0:
    PUSH32(esp, 0); /* 0x007783E0: push 0 */
    PUSH32(esp, 0x0079D7B8u); /* 0x007783E2: push 0x79d7b8 */
    eax = MEM32(ebp + (-0x10)); /* 0x007783E7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007783EA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007783EB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007783F0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007783F3: ret  */

}

void sub_007783F4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007783F4u);

    goto L_007783F4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007783F4:
    eax = 0x007E3A50u; /* 0x007783F4: mov eax, 0x7e3a50 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007783F9: jmp 0x75bf0e */

}

void sub_00778400(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778400u);

L_00778400:
    ecx = ebp + (-0x14); /* 0x00778400: lea ecx, [ebp - 0x14] */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00778403: jmp 0x5cde60 */

}

void sub_00778408(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778408u);

L_00778408:
    PUSH32(esp, 0); /* 0x00778408: push 0 */
    PUSH32(esp, 0x0079D7A0u); /* 0x0077840A: push 0x79d7a0 */
    eax = MEM32(ebp + (-0x18)); /* 0x0077840F: mov eax, dword ptr [ebp - 0x18] */
    PUSH32(esp, eax); /* 0x00778412: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00778413: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00778418: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077841B: ret  */

}

void sub_0077841C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077841Cu);

    goto L_0077841C;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077841C:
    eax = 0x007E3A2Cu; /* 0x0077841C: mov eax, 0x7e3a2c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778421: jmp 0x75bf0e */

}

void sub_00778430(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778430u);

L_00778430:
    ecx = ebp + (-0x20); /* 0x00778430: lea ecx, [ebp - 0x20] */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00778433: jmp 0x5cde60 */

}

void sub_00778438(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778438u);

L_00778438:
    ecx = ebp + (-0x18); /* 0x00778438: lea ecx, [ebp - 0x18] */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x0077843B: jmp 0x5cde60 */

}

void sub_00778440(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778440u);

    goto L_00778440;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778440:
    eax = 0x007E3A7Cu; /* 0x00778440: mov eax, 0x7e3a7c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778445: jmp 0x75bf0e */

}

void sub_00778450(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778450u);

L_00778450:
    ecx = MEM32(ebp + (-0x904)); /* 0x00778450: mov ecx, dword ptr [ebp - 0x904] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00778456: jmp 0x553a80 */

}

void sub_0077845B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077845Bu);

L_0077845B:
    ecx = ebp + (-0x8F0); /* 0x0077845B: lea ecx, [ebp - 0x8f0] */
    RECOMP_ITAIL(0x00401830u); RECOMP_RETURN(); /* 0x00778461: jmp 0x401830 */

}

void sub_00778466(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778466u);

L_00778466:
    ecx = ebp + (-0x900); /* 0x00778466: lea ecx, [ebp - 0x900] */
    RECOMP_ITAIL(0x0040BE20u); RECOMP_RETURN(); /* 0x0077846C: jmp 0x40be20 */

}

void sub_00778471(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778471u);

    goto L_00778471;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778471:
    eax = 0x007E3AB0u; /* 0x00778471: mov eax, 0x7e3ab0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778476: jmp 0x75bf0e */

}

void sub_00778480(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778480u);

L_00778480:
    PUSH32(esp, 0); /* 0x00778480: push 0 */
    PUSH32(esp, 0x0079D860u); /* 0x00778482: push 0x79d860 */
    eax = MEM32(ebp + (-0x10)); /* 0x00778487: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077848A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077848B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00778490: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778493: ret  */

}

void sub_00778494(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778494u);

    goto L_00778494;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778494:
    eax = 0x007E3AD4u; /* 0x00778494: mov eax, 0x7e3ad4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778499: jmp 0x75bf0e */

}

void sub_007784A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007784A0u);

L_007784A0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007784A0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004DEF50u); RECOMP_RETURN(); /* 0x007784A3: jmp 0x4def50 */

}

void sub_007784A8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007784A8u);

L_007784A8:
    ecx = MEM32(ebp + (-0x10)); /* 0x007784A8: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x150u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x150u; /* 0x007784AB: add ecx, 0x150 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0052E930u); RECOMP_RETURN(); /* 0x007784B1: jmp 0x52e930 */

}

void sub_007784B6(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007784B6u);

    goto L_007784B6;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007784B6:
    eax = 0x007E3B24u; /* 0x007784B6: mov eax, 0x7e3b24 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007784BB: jmp 0x75bf0e */

}

void sub_007784C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007784C0u);

L_007784C0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007784C0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004CBB50u); RECOMP_RETURN(); /* 0x007784C3: jmp 0x4cbb50 */

}

void sub_007784C8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007784C8u);

L_007784C8:
    ecx = MEM32(ebp + (-0x10)); /* 0x007784C8: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x14Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x14Cu; /* 0x007784CB: add ecx, 0x14c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004FF410u); RECOMP_RETURN(); /* 0x007784D1: jmp 0x4ff410 */

}

void sub_007784D6(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007784D6u);

L_007784D6:
    ecx = MEM32(ebp + (-0x10)); /* 0x007784D6: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x198u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x198u; /* 0x007784D9: add ecx, 0x198 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004FF410u); RECOMP_RETURN(); /* 0x007784DF: jmp 0x4ff410 */

}

void sub_007784E4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007784E4u);

    goto L_007784E4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007784E4:
    eax = 0x007E3B7Cu; /* 0x007784E4: mov eax, 0x7e3b7c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007784E9: jmp 0x75bf0e */

}

void sub_007784F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007784F0u);

L_007784F0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007784F0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004DEF50u); RECOMP_RETURN(); /* 0x007784F3: jmp 0x4def50 */

}

void sub_007784F8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007784F8u);

L_007784F8:
    ecx = MEM32(ebp + (-0x10)); /* 0x007784F8: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x158u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x158u; /* 0x007784FB: add ecx, 0x158 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00778501: jmp 0x5cde60 */

}

void sub_00778506(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778506u);

L_00778506:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778506: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x160u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x160u; /* 0x00778509: add ecx, 0x160 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x0077850F: jmp 0x5cde60 */

}

void sub_00778514(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778514u);

    goto L_00778514;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778514:
    eax = 0x007E3BB0u; /* 0x00778514: mov eax, 0x7e3bb0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778519: jmp 0x75bf0e */

}

void sub_00778520(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778520u);

L_00778520:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778520: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004DEF50u); RECOMP_RETURN(); /* 0x00778523: jmp 0x4def50 */

}

void sub_00778528(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778528u);

L_00778528:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778528: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x158u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x158u; /* 0x0077852B: add ecx, 0x158 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00778531: jmp 0x5cde60 */

}

void sub_00778536(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778536u);

    goto L_00778536;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778536:
    eax = 0x007E3BDCu; /* 0x00778536: mov eax, 0x7e3bdc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077853B: jmp 0x75bf0e */

}

void sub_00778540(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778540u);

L_00778540:
    PUSH32(esp, 0); /* 0x00778540: push 0 */
    PUSH32(esp, 0x0079D908u); /* 0x00778542: push 0x79d908 */
    eax = MEM32(ebp + (-0x10)); /* 0x00778547: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077854A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077854B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00778550: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778553: ret  */

}

void sub_00778554(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778554u);

    goto L_00778554;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778554:
    eax = 0x007E3C00u; /* 0x00778554: mov eax, 0x7e3c00 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778559: jmp 0x75bf0e */

}

void sub_00778560(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778560u);

L_00778560:
    PUSH32(esp, 0); /* 0x00778560: push 0 */
    PUSH32(esp, 0x0079D91Cu); /* 0x00778562: push 0x79d91c */
    eax = MEM32(ebp + (-0x10)); /* 0x00778567: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077856A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077856B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00778570: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778573: ret  */

}

void sub_00778574(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778574u);

    goto L_00778574;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778574:
    eax = 0x007E3C24u; /* 0x00778574: mov eax, 0x7e3c24 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778579: jmp 0x75bf0e */

}

void sub_00778580(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778580u);

L_00778580:
    PUSH32(esp, 0); /* 0x00778580: push 0 */
    PUSH32(esp, 0x0079D928u); /* 0x00778582: push 0x79d928 */
    eax = MEM32(ebp + (-0x10)); /* 0x00778587: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077858A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077858B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00778590: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778593: ret  */

}

void sub_00778594(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778594u);

    goto L_00778594;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778594:
    eax = 0x007E3C48u; /* 0x00778594: mov eax, 0x7e3c48 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778599: jmp 0x75bf0e */

}

void sub_007785A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007785A0u);

L_007785A0:
    PUSH32(esp, 0); /* 0x007785A0: push 0 */
    PUSH32(esp, 0x0079D93Cu); /* 0x007785A2: push 0x79d93c */
    eax = MEM32(ebp + (-0x10)); /* 0x007785A7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007785AA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007785AB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007785B0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007785B3: ret  */

}

void sub_007785B4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007785B4u);

    goto L_007785B4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007785B4:
    eax = 0x007E3C6Cu; /* 0x007785B4: mov eax, 0x7e3c6c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007785B9: jmp 0x75bf0e */

}

void sub_007785C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007785C0u);

L_007785C0:
    PUSH32(esp, 0); /* 0x007785C0: push 0 */
    PUSH32(esp, 0x0079D950u); /* 0x007785C2: push 0x79d950 */
    eax = MEM32(ebp + (-0x10)); /* 0x007785C7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007785CA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007785CB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007785D0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007785D3: ret  */

}

void sub_007785D4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007785D4u);

    goto L_007785D4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007785D4:
    eax = 0x007E3C90u; /* 0x007785D4: mov eax, 0x7e3c90 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007785D9: jmp 0x75bf0e */

}

void sub_007785E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007785E0u);

L_007785E0:
    PUSH32(esp, 0); /* 0x007785E0: push 0 */
    PUSH32(esp, 0x0079D964u); /* 0x007785E2: push 0x79d964 */
    eax = MEM32(ebp + (-0x10)); /* 0x007785E7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007785EA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007785EB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007785F0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007785F3: ret  */

}

void sub_007785F4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007785F4u);

    goto L_007785F4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007785F4:
    eax = 0x007E3CB4u; /* 0x007785F4: mov eax, 0x7e3cb4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007785F9: jmp 0x75bf0e */

}

void sub_00778600(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778600u);

L_00778600:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778600: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00532640u); RECOMP_RETURN(); /* 0x00778603: jmp 0x532640 */

}

void sub_00778608(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778608u);

    goto L_00778608;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778608:
    eax = 0x007E3CD8u; /* 0x00778608: mov eax, 0x7e3cd8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077860D: jmp 0x75bf0e */

}

void sub_00778620(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778620u);

L_00778620:
    PUSH32(esp, 0); /* 0x00778620: push 0 */
    PUSH32(esp, 0x0079D988u); /* 0x00778622: push 0x79d988 */
    eax = MEM32(ebp + (-0x10)); /* 0x00778627: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077862A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077862B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00778630: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778633: ret  */

}

void sub_00778634(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778634u);

    goto L_00778634;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778634:
    eax = 0x007E3D20u; /* 0x00778634: mov eax, 0x7e3d20 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778639: jmp 0x75bf0e */

}

void sub_00778640(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778640u);

L_00778640:
    PUSH32(esp, 0); /* 0x00778640: push 0 */
    PUSH32(esp, 0x0079D998u); /* 0x00778642: push 0x79d998 */
    eax = MEM32(ebp + (-0x10)); /* 0x00778647: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077864A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077864B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00778650: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778653: ret  */

}

void sub_00778654(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778654u);

    goto L_00778654;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778654:
    eax = 0x007E3D44u; /* 0x00778654: mov eax, 0x7e3d44 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778659: jmp 0x75bf0e */

}

void sub_00778660(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778660u);

L_00778660:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778660: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0xCu; /* 0x00778663: add ecx, 0xc */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00576850u); RECOMP_RETURN(); /* 0x00778666: jmp 0x576850 */

}

void sub_0077866B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077866Bu);

    goto L_0077866B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077866B:
    eax = 0x007E3D94u; /* 0x0077866B: mov eax, 0x7e3d94 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778670: jmp 0x75bf0e */

}

void sub_00778680(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778680u);

L_00778680:
    ecx = ebp + (-0x8F0); /* 0x00778680: lea ecx, [ebp - 0x8f0] */
    RECOMP_ITAIL(0x00401830u); RECOMP_RETURN(); /* 0x00778686: jmp 0x401830 */

}

void sub_0077868B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077868Bu);

L_0077868B:
    ecx = ebp + (-0x900); /* 0x0077868B: lea ecx, [ebp - 0x900] */
    RECOMP_ITAIL(0x0040BE20u); RECOMP_RETURN(); /* 0x00778691: jmp 0x40be20 */

}

void sub_00778696(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778696u);

    goto L_00778696;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778696:
    eax = 0x007E3D70u; /* 0x00778696: mov eax, 0x7e3d70 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077869B: jmp 0x75bf0e */

}

void sub_007786A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007786A0u);

L_007786A0:
    eax = MEM32(ebp + (-0x10)); /* 0x007786A0: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007786A3: push eax */
    RECOMP_CALL(sub_0056C3E0); /* 0x007786A4: call 0x56c3e0 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x007786A9: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007786AA: ret  */

}

void sub_007786AB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007786ABu);

    goto L_007786AB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007786AB:
    eax = 0x007E3DB8u; /* 0x007786AB: mov eax, 0x7e3db8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007786B0: jmp 0x75bf0e */

}

void sub_007786C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007786C0u);

L_007786C0:
    ecx = ebp + (-0x14); /* 0x007786C0: lea ecx, [ebp - 0x14] */
    RECOMP_ITAIL(0x0056FC00u); RECOMP_RETURN(); /* 0x007786C3: jmp 0x56fc00 */

}

void sub_007786C8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007786C8u);

    goto L_007786C8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007786C8:
    eax = 0x007E3DDCu; /* 0x007786C8: mov eax, 0x7e3ddc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007786CD: jmp 0x75bf0e */

}

void sub_007786E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007786E0u);

L_007786E0:
    eax = MEM32(0x866634); /* 0x007786E0: mov eax, dword ptr [0x866634] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0xFFFFFFFEu);
    eax = eax & 0xFFFFFFFEu; /* 0x007786E5: and eax, 0xfffffffe */
    _cf = 0;
    _flag_k = FK_TEST;
    MEM32(0x866634) = eax; /* 0x007786E8: mov dword ptr [0x866634], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007786ED: ret  */

}

void sub_007786EE(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007786EEu);

    goto L_007786EE;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007786EE:
    eax = 0x007E3E00u; /* 0x007786EE: mov eax, 0x7e3e00 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007786F3: jmp 0x75bf0e */

}

void sub_00778700(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778700u);

L_00778700:
    eax = MEM32(ebp + 0x4); /* 0x00778700: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00778703: push eax */
    RECOMP_CALL(sub_005752F0); /* 0x00778704: call 0x5752f0 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00778709: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077870A: ret  */

}

void sub_0077870B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077870Bu);

    goto L_0077870B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077870B:
    eax = 0x007E3E24u; /* 0x0077870B: mov eax, 0x7e3e24 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778710: jmp 0x75bf0e */

}

void sub_00778720(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778720u);

L_00778720:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778720: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x90u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x90u; /* 0x00778723: add ecx, 0x90 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0057CCF0u); RECOMP_RETURN(); /* 0x00778729: jmp 0x57ccf0 */

}

void sub_0077872E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077872Eu);

L_0077872E:
    ecx = MEM32(ebp + (-0x10)); /* 0x0077872E: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x98u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x98u; /* 0x00778731: add ecx, 0x98 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0057CCF0u); RECOMP_RETURN(); /* 0x00778737: jmp 0x57ccf0 */

}

void sub_0077873C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077873Cu);

    goto L_0077873C;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077873C:
    eax = 0x007E3E50u; /* 0x0077873C: mov eax, 0x7e3e50 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778741: jmp 0x75bf0e */

}

void sub_00778750(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778750u);

L_00778750:
    ecx = ebp + (-0x18); /* 0x00778750: lea ecx, [ebp - 0x18] */
    RECOMP_ITAIL(0x0057CCF0u); RECOMP_RETURN(); /* 0x00778753: jmp 0x57ccf0 */

}

void sub_00778758(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778758u);

    goto L_00778758;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778758:
    eax = 0x007E3E74u; /* 0x00778758: mov eax, 0x7e3e74 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077875D: jmp 0x75bf0e */

}

void sub_00778770(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778770u);

L_00778770:
    eax = MEM32(ebp + (-0x10)); /* 0x00778770: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00778773: push eax */
    RECOMP_CALL(sub_005734F0); /* 0x00778774: call 0x5734f0 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00778779: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077877A: ret  */

}

void sub_0077877B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077877Bu);

    goto L_0077877B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077877B:
    eax = 0x007E3E98u; /* 0x0077877B: mov eax, 0x7e3e98 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778780: jmp 0x75bf0e */

}

void sub_00778790(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778790u);

L_00778790:
    eax = MEM32(ebp + (-0x10)); /* 0x00778790: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00778793: push eax */
    RECOMP_CALL(sub_00575590); /* 0x00778794: call 0x575590 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00778799: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077879A: ret  */

}

void sub_0077879B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077879Bu);

    goto L_0077879B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077879B:
    eax = 0x007E3EBCu; /* 0x0077879B: mov eax, 0x7e3ebc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007787A0: jmp 0x75bf0e */

}

void sub_007787B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007787B0u);

L_007787B0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007787B0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x0057BB50u); RECOMP_RETURN(); /* 0x007787B3: jmp 0x57bb50 */

}

void sub_007787B8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007787B8u);

    goto L_007787B8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007787B8:
    eax = 0x007E3EE0u; /* 0x007787B8: mov eax, 0x7e3ee0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007787BD: jmp 0x75bf0e */

}

void sub_007787D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007787D0u);

L_007787D0:
    eax = MEM32(ebp + (-0x10)); /* 0x007787D0: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007787D3: push eax */
    RECOMP_CALL(sub_005752F0); /* 0x007787D4: call 0x5752f0 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x007787D9: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007787DA: ret  */

}

void sub_007787DB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007787DBu);

    goto L_007787DB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007787DB:
    eax = 0x007E3F04u; /* 0x007787DB: mov eax, 0x7e3f04 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007787E0: jmp 0x75bf0e */

}

void sub_007787F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007787F0u);

L_007787F0:
    eax = MEM32(ebp + (-0x10)); /* 0x007787F0: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007787F3: push eax */
    RECOMP_CALL(sub_00570A00); /* 0x007787F4: call 0x570a00 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x007787F9: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007787FA: ret  */

}

void sub_007787FB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007787FBu);

    goto L_007787FB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007787FB:
    eax = 0x007E3F28u; /* 0x007787FB: mov eax, 0x7e3f28 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778800: jmp 0x75bf0e */

}

void sub_00778810(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778810u);

L_00778810:
    PUSH32(esp, 0); /* 0x00778810: push 0 */
    PUSH32(esp, 0x007A09A4u); /* 0x00778812: push 0x7a09a4 */
    eax = MEM32(ebp + (-0x114)); /* 0x00778817: mov eax, dword ptr [ebp - 0x114] */
    PUSH32(esp, eax); /* 0x0077881D: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077881E: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00778823: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778826: ret  */

}

void sub_00778827(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778827u);

L_00778827:
    PUSH32(esp, 0); /* 0x00778827: push 0 */
    PUSH32(esp, 0x007A0994u); /* 0x00778829: push 0x7a0994 */
    eax = MEM32(ebp + (-0x114)); /* 0x0077882E: mov eax, dword ptr [ebp - 0x114] */
    PUSH32(esp, eax); /* 0x00778834: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00778835: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077883A: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077883D: ret  */

}

void sub_0077883E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077883Eu);

    goto L_0077883E;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077883E:
    eax = 0x007E3F54u; /* 0x0077883E: mov eax, 0x7e3f54 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778843: jmp 0x75bf0e */

}

void sub_00778850(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778850u);

L_00778850:
    PUSH32(esp, 0); /* 0x00778850: push 0 */
    PUSH32(esp, 0x007A0AECu); /* 0x00778852: push 0x7a0aec */
    eax = MEM32(ebp + (-0x10)); /* 0x00778857: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077885A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077885B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00778860: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778863: ret  */

}

void sub_00778864(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778864u);

    goto L_00778864;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778864:
    eax = 0x007E3F78u; /* 0x00778864: mov eax, 0x7e3f78 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778869: jmp 0x75bf0e */

}

void sub_00778870(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778870u);

L_00778870:
    PUSH32(esp, 3); /* 0x00778870: push 3 */
    PUSH32(esp, 0x4B1u); /* 0x00778872: push 0x4b1 */
    PUSH32(esp, 0x007A134Cu); /* 0x00778877: push 0x7a134c */
    eax = MEM32(ebp + (-0x10)); /* 0x0077887C: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077887F: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00778880: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x10u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x10u; /* 0x00778885: add esp, 0x10 */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778888: ret  */

}

void sub_00778889(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778889u);

    goto L_00778889;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778889:
    eax = 0x007E3F9Cu; /* 0x00778889: mov eax, 0x7e3f9c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077888E: jmp 0x75bf0e */

}

void sub_007788A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007788A0u);

L_007788A0:
    PUSH32(esp, 0x005CDE60u); /* 0x007788A0: push 0x5cde60 */
    PUSH32(esp, 6); /* 0x007788A5: push 6 */
    PUSH32(esp, 8); /* 0x007788A7: push 8 */
    eax = MEM32(ebp + (-0x10)); /* 0x007788A9: mov eax, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 4; /* 0x007788AC: add eax, 4 */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x007788AF: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x007788B0: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007788B5: ret  */

}

void sub_007788B6(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007788B6u);

L_007788B6:
    ecx = MEM32(ebp + (-0x10)); /* 0x007788B6: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x34u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x34u; /* 0x007788B9: add ecx, 0x34 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x007788BC: jmp 0x5cde60 */

}

void sub_007788C1(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007788C1u);

L_007788C1:
    ecx = MEM32(ebp + (-0x10)); /* 0x007788C1: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x3Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x3Cu; /* 0x007788C4: add ecx, 0x3c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00586590u); RECOMP_RETURN(); /* 0x007788C7: jmp 0x586590 */

}

void sub_007788CC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007788CCu);

    goto L_007788CC;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007788CC:
    eax = 0x007E3FD0u; /* 0x007788CC: mov eax, 0x7e3fd0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007788D1: jmp 0x75bf0e */

}

void sub_007788E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007788E0u);

L_007788E0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007788E0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x007788E3: jmp 0x5cde60 */

}

void sub_007788E8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007788E8u);

L_007788E8:
    ecx = MEM32(ebp + (-0x10)); /* 0x007788E8: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(8);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 8; /* 0x007788EB: add ecx, 8 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004CBA10u); RECOMP_RETURN(); /* 0x007788EE: jmp 0x4cba10 */

}

void sub_007788F3(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007788F3u);

    goto L_007788F3;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007788F3:
    eax = 0x007E3FFCu; /* 0x007788F3: mov eax, 0x7e3ffc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007788F8: jmp 0x75bf0e */

}

void sub_00778900(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778900u);

L_00778900:
    PUSH32(esp, 3); /* 0x00778900: push 3 */
    PUSH32(esp, 0x21Fu); /* 0x00778902: push 0x21f */
    PUSH32(esp, 0x007A134Cu); /* 0x00778907: push 0x7a134c */
    eax = MEM32(ebp + 0x4); /* 0x0077890C: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x0077890F: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00778910: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x10u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x10u; /* 0x00778915: add esp, 0x10 */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778918: ret  */

}

void sub_00778919(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778919u);

    goto L_00778919;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778919:
    eax = 0x007E4020u; /* 0x00778919: mov eax, 0x7e4020 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077891E: jmp 0x75bf0e */

}

void sub_00778930(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778930u);

L_00778930:
    ecx = ebp + (-0x428); /* 0x00778930: lea ecx, [ebp - 0x428] */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00778936: jmp 0x5cde60 */

}

void sub_0077893B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077893Bu);

    goto L_0077893B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077893B:
    eax = 0x007E408Cu; /* 0x0077893B: mov eax, 0x7e408c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778940: jmp 0x75bf0e */

}

void sub_00778950(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778950u);

L_00778950:
    ecx = ebp + (-0x18); /* 0x00778950: lea ecx, [ebp - 0x18] */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00778953: jmp 0x5cde60 */

}

void sub_00778958(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778958u);

    goto L_00778958;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778958:
    eax = 0x007E4044u; /* 0x00778958: mov eax, 0x7e4044 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077895D: jmp 0x75bf0e */

}

void sub_00778970(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778970u);

L_00778970:
    ecx = ebp + (-0x14); /* 0x00778970: lea ecx, [ebp - 0x14] */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00778973: jmp 0x5cde60 */

}

void sub_00778978(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778978u);

    goto L_00778978;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778978:
    eax = 0x007E4068u; /* 0x00778978: mov eax, 0x7e4068 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077897D: jmp 0x75bf0e */

}

void sub_00778990(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778990u);

L_00778990:
    eax = MEM32(0x86A450); /* 0x00778990: mov eax, dword ptr [0x86a450] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0xFFFFFFFEu);
    eax = eax & 0xFFFFFFFEu; /* 0x00778995: and eax, 0xfffffffe */
    _cf = 0;
    _flag_k = FK_TEST;
    MEM32(0x86A450) = eax; /* 0x00778998: mov dword ptr [0x86a450], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077899D: ret  */

}

void sub_0077899E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077899Eu);

    goto L_0077899E;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077899E:
    eax = 0x007E40B0u; /* 0x0077899E: mov eax, 0x7e40b0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007789A3: jmp 0x75bf0e */

}

void sub_007789B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007789B0u);

L_007789B0:
    eax = MEM32(0x86A5E4); /* 0x007789B0: mov eax, dword ptr [0x86a5e4] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0xFFFFFFFEu);
    eax = eax & 0xFFFFFFFEu; /* 0x007789B5: and eax, 0xfffffffe */
    _cf = 0;
    _flag_k = FK_TEST;
    MEM32(0x86A5E4) = eax; /* 0x007789B8: mov dword ptr [0x86a5e4], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007789BD: ret  */

}

void sub_007789BE(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007789BEu);

    goto L_007789BE;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007789BE:
    eax = 0x007E40D4u; /* 0x007789BE: mov eax, 0x7e40d4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007789C3: jmp 0x75bf0e */

}

void sub_007789D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007789D0u);

L_007789D0:
    ecx = ebp + (-0x424); /* 0x007789D0: lea ecx, [ebp - 0x424] */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x007789D6: jmp 0x5cde60 */

}

void sub_007789DB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007789DBu);

    goto L_007789DB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007789DB:
    eax = 0x007E40F8u; /* 0x007789DB: mov eax, 0x7e40f8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007789E0: jmp 0x75bf0e */

}

void sub_007789F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007789F0u);

L_007789F0:
    ecx = ebp + (-0x294); /* 0x007789F0: lea ecx, [ebp - 0x294] */
    RECOMP_ITAIL(0x004CBA10u); RECOMP_RETURN(); /* 0x007789F6: jmp 0x4cba10 */

}

void sub_007789FB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007789FBu);

L_007789FB:
    ecx = ebp + (-0x150); /* 0x007789FB: lea ecx, [ebp - 0x150] */
    RECOMP_ITAIL(0x004CBA10u); RECOMP_RETURN(); /* 0x00778A01: jmp 0x4cba10 */

}

void sub_00778A06(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778A06u);

    goto L_00778A06;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778A06:
    eax = 0x007E4124u; /* 0x00778A06: mov eax, 0x7e4124 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778A0B: jmp 0x75bf0e */

}

void sub_00778A10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778A10u);

L_00778A10:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778A10: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(8);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 8; /* 0x00778A13: add ecx, 8 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00588410u); RECOMP_RETURN(); /* 0x00778A16: jmp 0x588410 */

}

void sub_00778A1B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778A1Bu);

L_00778A1B:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778A1B: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x10u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x10u; /* 0x00778A1E: add ecx, 0x10 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00588410u); RECOMP_RETURN(); /* 0x00778A21: jmp 0x588410 */

}

void sub_00778A26(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778A26u);

    goto L_00778A26;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778A26:
    eax = 0x007E4150u; /* 0x00778A26: mov eax, 0x7e4150 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778A2B: jmp 0x75bf0e */

}

void sub_00778A30(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778A30u);

L_00778A30:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778A30: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00778A33: jmp 0x5cde60 */

}

void sub_00778A38(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778A38u);

    goto L_00778A38;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778A38:
    eax = 0x007E4174u; /* 0x00778A38: mov eax, 0x7e4174 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778A3D: jmp 0x75bf0e */

}

void sub_00778A50(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778A50u);

L_00778A50:
    PUSH32(esp, 0); /* 0x00778A50: push 0 */
    PUSH32(esp, 0x007A16F0u); /* 0x00778A52: push 0x7a16f0 */
    eax = MEM32(ebp + (-0x214)); /* 0x00778A57: mov eax, dword ptr [ebp - 0x214] */
    PUSH32(esp, eax); /* 0x00778A5D: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00778A5E: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00778A63: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778A66: ret  */

}

void sub_00778A67(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778A67u);

    goto L_00778A67;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778A67:
    eax = 0x007E4198u; /* 0x00778A67: mov eax, 0x7e4198 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778A6C: jmp 0x75bf0e */

}

void sub_00778A80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778A80u);

L_00778A80:
    PUSH32(esp, 0); /* 0x00778A80: push 0 */
    PUSH32(esp, 0x007A1708u); /* 0x00778A82: push 0x7a1708 */
    eax = MEM32(ebp + (-0x94)); /* 0x00778A87: mov eax, dword ptr [ebp - 0x94] */
    PUSH32(esp, eax); /* 0x00778A8D: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00778A8E: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00778A93: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778A96: ret  */

}

void sub_00778A97(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778A97u);

    goto L_00778A97;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778A97:
    eax = 0x007E41BCu; /* 0x00778A97: mov eax, 0x7e41bc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778A9C: jmp 0x75bf0e */

}

void sub_00778AB0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778AB0u);

L_00778AB0:
    PUSH32(esp, 0); /* 0x00778AB0: push 0 */
    PUSH32(esp, 0x007A1F3Cu); /* 0x00778AB2: push 0x7a1f3c */
    eax = MEM32(ebp + (-0x10)); /* 0x00778AB7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00778ABA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00778ABB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00778AC0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778AC3: ret  */

}

void sub_00778AC4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778AC4u);

    goto L_00778AC4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778AC4:
    eax = 0x007E41E0u; /* 0x00778AC4: mov eax, 0x7e41e0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778AC9: jmp 0x75bf0e */

}

void sub_00778AD0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778AD0u);

L_00778AD0:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778AD0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x005AFAE0u); RECOMP_RETURN(); /* 0x00778AD3: jmp 0x5afae0 */

}

void sub_00778AD8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778AD8u);

L_00778AD8:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778AD8: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x198u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x198u; /* 0x00778ADB: add ecx, 0x198 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00591310u); RECOMP_RETURN(); /* 0x00778AE1: jmp 0x591310 */

}

void sub_00778AE6(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778AE6u);

    goto L_00778AE6;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778AE6:
    eax = 0x007E420Cu; /* 0x00778AE6: mov eax, 0x7e420c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778AEB: jmp 0x75bf0e */

}

void sub_00778AF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778AF0u);

L_00778AF0:
    ecx = MEM32(ebp + (-0x28)); /* 0x00778AF0: mov ecx, dword ptr [ebp - 0x28] */
    RECOMP_ITAIL(0x005EA1F0u); RECOMP_RETURN(); /* 0x00778AF3: jmp 0x5ea1f0 */

}

void sub_00778AF8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778AF8u);

L_00778AF8:
    eax = MEM32(ebp + 0x4); /* 0x00778AF8: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00778AFB: push eax */
    RECOMP_CALL(sub_00575590); /* 0x00778AFC: call 0x575590 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00778B01: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778B02: ret  */

}

void sub_00778B03(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778B03u);

L_00778B03:
    eax = MEM32(ebp + 0x4); /* 0x00778B03: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00778B06: push eax */
    RECOMP_CALL(sub_00575590); /* 0x00778B07: call 0x575590 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00778B0C: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778B0D: ret  */

}

void sub_00778B0E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778B0Eu);

L_00778B0E:
    eax = MEM32(ebp + (-0x24)); /* 0x00778B0E: mov eax, dword ptr [ebp - 0x24] */
    PUSH32(esp, eax); /* 0x00778B11: push eax */
    RECOMP_CALL(sub_00591320); /* 0x00778B12: call 0x591320 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00778B17: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778B18: ret  */

}

void sub_00778B19(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778B19u);

    goto L_00778B19;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778B19:
    eax = 0x007E4248u; /* 0x00778B19: mov eax, 0x7e4248 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778B1E: jmp 0x75bf0e */

}

void sub_00778B30(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778B30u);

L_00778B30:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778B30: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x005EA1F0u); RECOMP_RETURN(); /* 0x00778B33: jmp 0x5ea1f0 */

}

void sub_00778B38(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778B38u);

    goto L_00778B38;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778B38:
    eax = 0x007E426Cu; /* 0x00778B38: mov eax, 0x7e426c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778B3D: jmp 0x75bf0e */

}

void sub_00778B50(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778B50u);

L_00778B50:
    eax = MEM32(ebp + (-0x10)); /* 0x00778B50: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00778B53: push eax */
    RECOMP_CALL(sub_005929D0); /* 0x00778B54: call 0x5929d0 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00778B59: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778B5A: ret  */

}

void sub_00778B5B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778B5Bu);

    goto L_00778B5B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778B5B:
    eax = 0x007E4290u; /* 0x00778B5B: mov eax, 0x7e4290 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778B60: jmp 0x75bf0e */

}

void sub_00778B70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778B70u);

L_00778B70:
    ecx = MEM32(ebp + (-0x84)); /* 0x00778B70: mov ecx, dword ptr [ebp - 0x84] */
    RECOMP_ITAIL(0x005A9FF0u); RECOMP_RETURN(); /* 0x00778B76: jmp 0x5a9ff0 */

}

void sub_00778B7B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778B7Bu);

L_00778B7B:
    ecx = MEM32(ebp + (-0x84)); /* 0x00778B7B: mov ecx, dword ptr [ebp - 0x84] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x70u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x70u; /* 0x00778B81: add ecx, 0x70 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005A19A0u); RECOMP_RETURN(); /* 0x00778B84: jmp 0x5a19a0 */

}

void sub_00778B89(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778B89u);

    goto L_00778B89;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778B89:
    eax = 0x007E42BCu; /* 0x00778B89: mov eax, 0x7e42bc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778B8E: jmp 0x75bf0e */

}

void sub_00778BA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778BA0u);

L_00778BA0:
    eax = MEM32(ebp + (-0x10)); /* 0x00778BA0: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00778BA3: push eax */
    RECOMP_CALL(sub_00592960); /* 0x00778BA4: call 0x592960 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00778BA9: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778BAA: ret  */

}

void sub_00778BAB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778BABu);

    goto L_00778BAB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778BAB:
    eax = 0x007E42E0u; /* 0x00778BAB: mov eax, 0x7e42e0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778BB0: jmp 0x75bf0e */

}

void sub_00778BC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778BC0u);

L_00778BC0:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778BC0: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0xCu; /* 0x00778BC3: add ecx, 0xc */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00490340u); RECOMP_RETURN(); /* 0x00778BC6: jmp 0x490340 */

}

void sub_00778BCB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778BCBu);

    goto L_00778BCB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778BCB:
    eax = 0x007E4304u; /* 0x00778BCB: mov eax, 0x7e4304 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778BD0: jmp 0x75bf0e */

}

void sub_00778BE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778BE0u);

L_00778BE0:
    ecx = ebp + (-0x18); /* 0x00778BE0: lea ecx, [ebp - 0x18] */
    RECOMP_ITAIL(0x00490340u); RECOMP_RETURN(); /* 0x00778BE3: jmp 0x490340 */

}

void sub_00778BE8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778BE8u);

    goto L_00778BE8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778BE8:
    eax = 0x007E4328u; /* 0x00778BE8: mov eax, 0x7e4328 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778BED: jmp 0x75bf0e */

}

void sub_00778C00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778C00u);

L_00778C00:
    ecx = MEM32(ebp + (-0x84)); /* 0x00778C00: mov ecx, dword ptr [ebp - 0x84] */
    RECOMP_ITAIL(0x005A9FF0u); RECOMP_RETURN(); /* 0x00778C06: jmp 0x5a9ff0 */

}

void sub_00778C0B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778C0Bu);

    goto L_00778C0B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778C0B:
    eax = 0x007E434Cu; /* 0x00778C0B: mov eax, 0x7e434c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778C10: jmp 0x75bf0e */

}

void sub_00778C20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778C20u);

L_00778C20:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778C20: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x005A9FF0u); RECOMP_RETURN(); /* 0x00778C23: jmp 0x5a9ff0 */

}

void sub_00778C28(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778C28u);

    goto L_00778C28;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778C28:
    eax = 0x007E4370u; /* 0x00778C28: mov eax, 0x7e4370 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778C2D: jmp 0x75bf0e */

}

void sub_00778C40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778C40u);

L_00778C40:
    eax = MEM32(ebp + (-0x10)); /* 0x00778C40: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00778C43: push eax */
    RECOMP_CALL(sub_00592A30); /* 0x00778C44: call 0x592a30 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00778C49: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778C4A: ret  */

}

void sub_00778C4B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778C4Bu);

    goto L_00778C4B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778C4B:
    eax = 0x007E4540u; /* 0x00778C4B: mov eax, 0x7e4540 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778C50: jmp 0x75bf0e */

}

void sub_00778C60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778C60u);

L_00778C60:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778C60: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0xF0u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0xF0u; /* 0x00778C63: add ecx, 0xf0 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00436820u); RECOMP_RETURN(); /* 0x00778C69: jmp 0x436820 */

}

void sub_00778C6E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778C6Eu);

    goto L_00778C6E;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778C6E:
    eax = 0x007E4394u; /* 0x00778C6E: mov eax, 0x7e4394 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778C73: jmp 0x75bf0e */

}

void sub_00778C80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778C80u);

L_00778C80:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778C80: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x00778C83: jmp 0x5ce0f0 */

}

void sub_00778C88(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778C88u);

    goto L_00778C88;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778C88:
    eax = 0x007E43B8u; /* 0x00778C88: mov eax, 0x7e43b8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778C8D: jmp 0x75bf0e */

}

void sub_00778CA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778CA0u);

L_00778CA0:
    eax = MEM32(ebp + (-0x10)); /* 0x00778CA0: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00778CA3: push eax */
    RECOMP_CALL(sub_00592940); /* 0x00778CA4: call 0x592940 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00778CA9: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778CAA: ret  */

}

void sub_00778CAB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778CABu);

    goto L_00778CAB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778CAB:
    eax = 0x007E461Cu; /* 0x00778CAB: mov eax, 0x7e461c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778CB0: jmp 0x75bf0e */

}

void sub_00778CC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778CC0u);

L_00778CC0:
    eax = MEM32(ebp + (-0xD4)); /* 0x00778CC0: mov eax, dword ptr [ebp - 0xd4] */
    PUSH32(esp, eax); /* 0x00778CC6: push eax */
    RECOMP_CALL(sub_00592960); /* 0x00778CC7: call 0x592960 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00778CCC: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778CCD: ret  */

}

void sub_00778CCE(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778CCEu);

    goto L_00778CCE;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778CCE:
    eax = 0x007E43DCu; /* 0x00778CCE: mov eax, 0x7e43dc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778CD3: jmp 0x75bf0e */

}

void sub_00778CE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778CE0u);

L_00778CE0:
    ecx = MEM32(ebp + (-0x3C)); /* 0x00778CE0: mov ecx, dword ptr [ebp - 0x3c] */
    RECOMP_ITAIL(0x005A9D30u); RECOMP_RETURN(); /* 0x00778CE3: jmp 0x5a9d30 */

}

void sub_00778CE8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778CE8u);

    goto L_00778CE8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778CE8:
    eax = 0x007E4400u; /* 0x00778CE8: mov eax, 0x7e4400 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778CED: jmp 0x75bf0e */

}

void sub_00778D00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778D00u);

L_00778D00:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778D00: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x005A9D30u); RECOMP_RETURN(); /* 0x00778D03: jmp 0x5a9d30 */

}

void sub_00778D08(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778D08u);

    goto L_00778D08;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778D08:
    eax = 0x007E4424u; /* 0x00778D08: mov eax, 0x7e4424 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778D0D: jmp 0x75bf0e */

}

void sub_00778D20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778D20u);

L_00778D20:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778D20: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x005A9FF0u); RECOMP_RETURN(); /* 0x00778D23: jmp 0x5a9ff0 */

}

void sub_00778D28(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778D28u);

L_00778D28:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778D28: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x70u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x70u; /* 0x00778D2B: add ecx, 0x70 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005A19A0u); RECOMP_RETURN(); /* 0x00778D2E: jmp 0x5a19a0 */

}

void sub_00778D33(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778D33u);

    goto L_00778D33;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778D33:
    eax = 0x007E4450u; /* 0x00778D33: mov eax, 0x7e4450 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778D38: jmp 0x75bf0e */

}

void sub_00778D40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778D40u);

L_00778D40:
    ecx = ebp + (-0x28); /* 0x00778D40: lea ecx, [ebp - 0x28] */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00778D43: jmp 0x5cde60 */

}

void sub_00778D48(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778D48u);

    goto L_00778D48;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778D48:
    eax = 0x007E4474u; /* 0x00778D48: mov eax, 0x7e4474 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778D4D: jmp 0x75bf0e */

}

void sub_00778D60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778D60u);

L_00778D60:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778D60: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x005EA1F0u); RECOMP_RETURN(); /* 0x00778D63: jmp 0x5ea1f0 */

}

void sub_00778D68(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778D68u);

L_00778D68:
    /* cmp MEM32(ebp + (-0x10)), 0 */ /* 0x00778D68: cmp dword ptr [ebp - 0x10], 0 */
    _flag_a = (uint32_t)(MEM32(ebp + (-0x10))); _flag_b = (uint32_t)(0);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    _flag_k = FK_CMP;
    if (CMP_EQ(_flag_a, _flag_b)) goto L_00778D80; /* 0x00778D6C: je 0x778d80 */

L_00778D72:
    eax = MEM32(ebp + (-0x10)); /* 0x00778D72: mov eax, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(8);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 8; /* 0x00778D75: add eax, 8 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x1C)) = eax; /* 0x00778D78: mov dword ptr [ebp - 0x1c], eax */
    goto L_00778D87; /* 0x00778D7B: jmp 0x778d87 */

L_00778D80:
    MEM32(ebp + (-0x1C)) = 0; /* 0x00778D80: mov dword ptr [ebp - 0x1c], 0 */

L_00778D87:
    ecx = MEM32(ebp + (-0x1C)); /* 0x00778D87: mov ecx, dword ptr [ebp - 0x1c] */
    RECOMP_ITAIL(0x005AE160u); RECOMP_RETURN(); /* 0x00778D8A: jmp 0x5ae160 */

}

void sub_00778D87(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778D87u);

L_00778D87:
    ecx = MEM32(ebp + (-0x1C)); /* 0x00778D87: mov ecx, dword ptr [ebp - 0x1c] */
    RECOMP_ITAIL(0x005AE160u); RECOMP_RETURN(); /* 0x00778D8A: jmp 0x5ae160 */

}

void sub_00778D8F(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778D8Fu);

    goto L_00778D8F;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778D8F:
    eax = 0x007E44A0u; /* 0x00778D8F: mov eax, 0x7e44a0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778D94: jmp 0x75bf0e */

}

void sub_00778DA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778DA0u);

L_00778DA0:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778DA0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x005AFAE0u); RECOMP_RETURN(); /* 0x00778DA3: jmp 0x5afae0 */

}

void sub_00778DA8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778DA8u);

    goto L_00778DA8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778DA8:
    eax = 0x007E44C4u; /* 0x00778DA8: mov eax, 0x7e44c4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778DAD: jmp 0x75bf0e */

}

void sub_00778DC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778DC0u);

L_00778DC0:
    ecx = MEM32(ebp + (-0x24)); /* 0x00778DC0: mov ecx, dword ptr [ebp - 0x24] */
    RECOMP_ITAIL(0x005EA1F0u); RECOMP_RETURN(); /* 0x00778DC3: jmp 0x5ea1f0 */

}

void sub_00778DC8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778DC8u);

L_00778DC8:
    /* cmp MEM32(ebp + (-0x24)), 0 */ /* 0x00778DC8: cmp dword ptr [ebp - 0x24], 0 */
    _flag_a = (uint32_t)(MEM32(ebp + (-0x24))); _flag_b = (uint32_t)(0);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    _flag_k = FK_CMP;
    if (CMP_EQ(_flag_a, _flag_b)) goto L_00778DE3; /* 0x00778DCC: je 0x778de3 */

L_00778DD2:
    eax = MEM32(ebp + (-0x24)); /* 0x00778DD2: mov eax, dword ptr [ebp - 0x24] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(8);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 8; /* 0x00778DD5: add eax, 8 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0xA8)) = eax; /* 0x00778DD8: mov dword ptr [ebp - 0xa8], eax */
    goto L_00778DED; /* 0x00778DDE: jmp 0x778ded */

L_00778DE3:
    MEM32(ebp + (-0xA8)) = 0; /* 0x00778DE3: mov dword ptr [ebp - 0xa8], 0 */

L_00778DED:
    ecx = MEM32(ebp + (-0xA8)); /* 0x00778DED: mov ecx, dword ptr [ebp - 0xa8] */
    RECOMP_ITAIL(0x005AE160u); RECOMP_RETURN(); /* 0x00778DF3: jmp 0x5ae160 */

}

void sub_00778DED(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778DEDu);

L_00778DED:
    ecx = MEM32(ebp + (-0xA8)); /* 0x00778DED: mov ecx, dword ptr [ebp - 0xa8] */
    RECOMP_ITAIL(0x005AE160u); RECOMP_RETURN(); /* 0x00778DF3: jmp 0x5ae160 */

}

void sub_00778DF8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778DF8u);

    goto L_00778DF8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778DF8:
    eax = 0x007E44F0u; /* 0x00778DF8: mov eax, 0x7e44f0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778DFD: jmp 0x75bf0e */

}

void sub_00778E10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778E10u);

L_00778E10:
    eax = MEM32(ebp + (-0x2C)); /* 0x00778E10: mov eax, dword ptr [ebp - 0x2c] */
    PUSH32(esp, eax); /* 0x00778E13: push eax */
    RECOMP_CALL(sub_00592A30); /* 0x00778E14: call 0x592a30 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00778E19: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778E1A: ret  */

}

void sub_00778E1B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778E1Bu);

L_00778E1B:
    eax = MEM32(ebp + (-0x10)); /* 0x00778E1B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00778E1E: push eax */
    RECOMP_CALL(sub_00592A30); /* 0x00778E1F: call 0x592a30 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00778E24: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778E25: ret  */

}

void sub_00778E26(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778E26u);

    goto L_00778E26;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778E26:
    eax = 0x007E451Cu; /* 0x00778E26: mov eax, 0x7e451c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778E2B: jmp 0x75bf0e */

}

void sub_00778E30(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778E30u);

L_00778E30:
    ecx = ebp + (-0x328); /* 0x00778E30: lea ecx, [ebp - 0x328] */
    RECOMP_ITAIL(0x005E0BE0u); RECOMP_RETURN(); /* 0x00778E36: jmp 0x5e0be0 */

}

void sub_00778E3B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778E3Bu);

    goto L_00778E3B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778E3B:
    eax = 0x007E4564u; /* 0x00778E3B: mov eax, 0x7e4564 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778E40: jmp 0x75bf0e */

}

void sub_00778E50(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778E50u);

L_00778E50:
    eax = MEM32(ebp + (-0x94)); /* 0x00778E50: mov eax, dword ptr [ebp - 0x94] */
    PUSH32(esp, eax); /* 0x00778E56: push eax */
    RECOMP_CALL(sub_005912D0); /* 0x00778E57: call 0x5912d0 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00778E5C: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778E5D: ret  */

}

void sub_00778E5E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778E5Eu);

    goto L_00778E5E;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778E5E:
    eax = 0x007E4588u; /* 0x00778E5E: mov eax, 0x7e4588 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778E63: jmp 0x75bf0e */

}

void sub_00778E70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778E70u);

L_00778E70:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778E70: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x005A9D30u); RECOMP_RETURN(); /* 0x00778E73: jmp 0x5a9d30 */

}

void sub_00778E78(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778E78u);

L_00778E78:
    /* cmp MEM32(ebp + (-0x10)), 0 */ /* 0x00778E78: cmp dword ptr [ebp - 0x10], 0 */
    _flag_a = (uint32_t)(MEM32(ebp + (-0x10))); _flag_b = (uint32_t)(0);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    _flag_k = FK_CMP;
    if (CMP_EQ(_flag_a, _flag_b)) goto L_00778E92; /* 0x00778E7C: je 0x778e92 */

L_00778E82:
    eax = MEM32(ebp + (-0x10)); /* 0x00778E82: mov eax, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x130u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x130u; /* 0x00778E85: add eax, 0x130 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x14)) = eax; /* 0x00778E8A: mov dword ptr [ebp - 0x14], eax */
    goto L_00778E99; /* 0x00778E8D: jmp 0x778e99 */

L_00778E92:
    MEM32(ebp + (-0x14)) = 0; /* 0x00778E92: mov dword ptr [ebp - 0x14], 0 */

L_00778E99:
    ecx = MEM32(ebp + (-0x14)); /* 0x00778E99: mov ecx, dword ptr [ebp - 0x14] */
    RECOMP_ITAIL(0x005AA370u); RECOMP_RETURN(); /* 0x00778E9C: jmp 0x5aa370 */

}

void sub_00778E99(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778E99u);

L_00778E99:
    ecx = MEM32(ebp + (-0x14)); /* 0x00778E99: mov ecx, dword ptr [ebp - 0x14] */
    RECOMP_ITAIL(0x005AA370u); RECOMP_RETURN(); /* 0x00778E9C: jmp 0x5aa370 */

}

void sub_00778EA1(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778EA1u);

L_00778EA1:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778EA1: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x16Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x16Cu; /* 0x00778EA4: add ecx, 0x16c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005E0BE0u); RECOMP_RETURN(); /* 0x00778EAA: jmp 0x5e0be0 */

}

void sub_00778EAF(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778EAFu);

L_00778EAF:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778EAF: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x480u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x480u; /* 0x00778EB2: add ecx, 0x480 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00633FD0u); RECOMP_RETURN(); /* 0x00778EB8: jmp 0x633fd0 */

}

void sub_00778EBD(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778EBDu);

L_00778EBD:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778EBD: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4F4u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4F4u; /* 0x00778EC0: add ecx, 0x4f4 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x00778EC6: jmp 0x5ce0f0 */

}

void sub_00778ECB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778ECBu);

L_00778ECB:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778ECB: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4FCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4FCu; /* 0x00778ECE: add ecx, 0x4fc */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x00778ED4: jmp 0x5ce0f0 */

}

void sub_00778ED9(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778ED9u);

    goto L_00778ED9;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778ED9:
    eax = 0x007E45D4u; /* 0x00778ED9: mov eax, 0x7e45d4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778EDE: jmp 0x75bf0e */

}

void sub_00778EF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778EF0u);

L_00778EF0:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778EF0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00598080u); RECOMP_RETURN(); /* 0x00778EF3: jmp 0x598080 */

}

void sub_00778EF8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778EF8u);

    goto L_00778EF8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778EF8:
    eax = 0x007E45F8u; /* 0x00778EF8: mov eax, 0x7e45f8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778EFD: jmp 0x75bf0e */

}

void sub_00778F10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778F10u);

L_00778F10:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778F10: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x005A9D30u); RECOMP_RETURN(); /* 0x00778F13: jmp 0x5a9d30 */

}

void sub_00778F18(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778F18u);

L_00778F18:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778F18: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x130u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x130u; /* 0x00778F1B: add ecx, 0x130 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005AA370u); RECOMP_RETURN(); /* 0x00778F21: jmp 0x5aa370 */

}

void sub_00778F26(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778F26u);

L_00778F26:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778F26: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x16Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x16Cu; /* 0x00778F29: add ecx, 0x16c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005E0BE0u); RECOMP_RETURN(); /* 0x00778F2F: jmp 0x5e0be0 */

}

void sub_00778F34(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778F34u);

L_00778F34:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778F34: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x480u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x480u; /* 0x00778F37: add ecx, 0x480 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00633FD0u); RECOMP_RETURN(); /* 0x00778F3D: jmp 0x633fd0 */

}

void sub_00778F42(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778F42u);

L_00778F42:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778F42: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4F4u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4F4u; /* 0x00778F45: add ecx, 0x4f4 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x00778F4B: jmp 0x5ce0f0 */

}

void sub_00778F50(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778F50u);

L_00778F50:
    ecx = MEM32(ebp + (-0x10)); /* 0x00778F50: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4FCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4FCu; /* 0x00778F53: add ecx, 0x4fc */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x00778F59: jmp 0x5ce0f0 */

}

void sub_00778F5E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778F5Eu);

    goto L_00778F5E;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778F5E:
    eax = 0x007E4668u; /* 0x00778F5E: mov eax, 0x7e4668 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778F63: jmp 0x75bf0e */

}

void sub_00778F70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778F70u);

L_00778F70:
    eax = MEM32(ebp + (-0x10)); /* 0x00778F70: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00778F73: push eax */
    RECOMP_CALL(sub_00592A50); /* 0x00778F74: call 0x592a50 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00778F79: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778F7A: ret  */

}

void sub_00778F7B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778F7Bu);

    goto L_00778F7B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778F7B:
    eax = 0x007E468Cu; /* 0x00778F7B: mov eax, 0x7e468c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778F80: jmp 0x75bf0e */

}

void sub_00778F90(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778F90u);

L_00778F90:
    eax = MEM32(ebp + (-0x10)); /* 0x00778F90: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00778F93: push eax */
    RECOMP_CALL(sub_00592D40); /* 0x00778F94: call 0x592d40 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00778F99: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778F9A: ret  */

}

void sub_00778F9B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778F9Bu);

    goto L_00778F9B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778F9B:
    eax = 0x007E46B0u; /* 0x00778F9B: mov eax, 0x7e46b0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778FA0: jmp 0x75bf0e */

}

void sub_00778FB0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778FB0u);

L_00778FB0:
    ecx = MEM32(ebp + (-0x14)); /* 0x00778FB0: mov ecx, dword ptr [ebp - 0x14] */
    RECOMP_ITAIL(0x005EA1F0u); RECOMP_RETURN(); /* 0x00778FB3: jmp 0x5ea1f0 */

}

void sub_00778FB8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778FB8u);

L_00778FB8:
    ecx = MEM32(ebp + (-0x14)); /* 0x00778FB8: mov ecx, dword ptr [ebp - 0x14] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(8);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 8; /* 0x00778FBB: add ecx, 8 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005AE160u); RECOMP_RETURN(); /* 0x00778FBE: jmp 0x5ae160 */

}

void sub_00778FC3(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778FC3u);

L_00778FC3:
    eax = MEM32(ebp + 0x4); /* 0x00778FC3: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00778FC6: push eax */
    RECOMP_CALL(sub_005912D0); /* 0x00778FC7: call 0x5912d0 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00778FCC: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778FCD: ret  */

}

void sub_00778FCE(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778FCEu);

L_00778FCE:
    eax = MEM32(ebp + 0xC); /* 0x00778FCE: mov eax, dword ptr [ebp + 0xc] */
    PUSH32(esp, eax); /* 0x00778FD1: push eax */
    RECOMP_CALL(sub_00591320); /* 0x00778FD2: call 0x591320 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00778FD7: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778FD8: ret  */

}

void sub_00778FD9(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778FD9u);

L_00778FD9:
    eax = MEM32(ebp + (-0x10)); /* 0x00778FD9: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00778FDC: push eax */
    RECOMP_CALL(sub_00598E30); /* 0x00778FDD: call 0x598e30 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00778FE2: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778FE3: ret  */

}

void sub_00778FE4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778FE4u);

L_00778FE4:
    eax = MEM32(ebp + 0x4); /* 0x00778FE4: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00778FE7: push eax */
    RECOMP_CALL(sub_005929F0); /* 0x00778FE8: call 0x5929f0 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00778FED: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778FEE: ret  */

}

void sub_00778FEF(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778FEFu);

L_00778FEF:
    eax = MEM32(ebp + 0x8); /* 0x00778FEF: mov eax, dword ptr [ebp + 8] */
    PUSH32(esp, eax); /* 0x00778FF2: push eax */
    RECOMP_CALL(sub_00592A10); /* 0x00778FF3: call 0x592a10 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00778FF8: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00778FF9: ret  */

}

void sub_00778FFA(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00778FFAu);

    goto L_00778FFA;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00778FFA:
    eax = 0x007E4704u; /* 0x00778FFA: mov eax, 0x7e4704 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00778FFF: jmp 0x75bf0e */

}

void sub_00779010(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779010u);

L_00779010:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779010: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x005EA1F0u); RECOMP_RETURN(); /* 0x00779013: jmp 0x5ea1f0 */

}

void sub_00779018(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779018u);

L_00779018:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779018: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(8);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 8; /* 0x0077901B: add ecx, 8 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005AE160u); RECOMP_RETURN(); /* 0x0077901E: jmp 0x5ae160 */

}

void sub_00779023(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779023u);

L_00779023:
    eax = MEM32(ebp + 0x8); /* 0x00779023: mov eax, dword ptr [ebp + 8] */
    PUSH32(esp, eax); /* 0x00779026: push eax */
    RECOMP_CALL(sub_005912D0); /* 0x00779027: call 0x5912d0 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077902C: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077902D: ret  */

}

void sub_0077902E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077902Eu);

L_0077902E:
    eax = MEM32(ebp + 0x8); /* 0x0077902E: mov eax, dword ptr [ebp + 8] */
    PUSH32(esp, eax); /* 0x00779031: push eax */
    RECOMP_CALL(sub_00592D20); /* 0x00779032: call 0x592d20 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00779037: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779038: ret  */

}

void sub_00779039(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779039u);

L_00779039:
    eax = MEM32(ebp + 0x8); /* 0x00779039: mov eax, dword ptr [ebp + 8] */
    PUSH32(esp, eax); /* 0x0077903C: push eax */
    RECOMP_CALL(sub_00591320); /* 0x0077903D: call 0x591320 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00779042: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779043: ret  */

}

void sub_00779044(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779044u);

    goto L_00779044;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779044:
    eax = 0x007E4748u; /* 0x00779044: mov eax, 0x7e4748 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779049: jmp 0x75bf0e */

}

void sub_00779050(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779050u);

L_00779050:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779050: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x005AFEF0u); RECOMP_RETURN(); /* 0x00779053: jmp 0x5afef0 */

}

void sub_00779058(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779058u);

L_00779058:
    eax = MEM32(ebp + 0xC); /* 0x00779058: mov eax, dword ptr [ebp + 0xc] */
    PUSH32(esp, eax); /* 0x0077905B: push eax */
    RECOMP_CALL(sub_005912D0); /* 0x0077905C: call 0x5912d0 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00779061: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779062: ret  */

}

void sub_00779063(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779063u);

L_00779063:
    eax = MEM32(ebp + 0xC); /* 0x00779063: mov eax, dword ptr [ebp + 0xc] */
    PUSH32(esp, eax); /* 0x00779066: push eax */
    RECOMP_CALL(sub_00583260); /* 0x00779067: call 0x583260 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077906C: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077906D: ret  */

}

void sub_0077906E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077906Eu);

L_0077906E:
    eax = MEM32(ebp + 0x10); /* 0x0077906E: mov eax, dword ptr [ebp + 0x10] */
    PUSH32(esp, eax); /* 0x00779071: push eax */
    RECOMP_CALL(sub_00591320); /* 0x00779072: call 0x591320 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00779077: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779078: ret  */

}

void sub_00779079(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779079u);

    goto L_00779079;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779079:
    eax = 0x007E4784u; /* 0x00779079: mov eax, 0x7e4784 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077907E: jmp 0x75bf0e */

}

void sub_00779090(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779090u);

L_00779090:
    eax = MEM32(ebp + (-0x10)); /* 0x00779090: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00779093: push eax */
    RECOMP_CALL(sub_00575590); /* 0x00779094: call 0x575590 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00779099: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077909A: ret  */

}

void sub_0077909B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077909Bu);

L_0077909B:
    eax = MEM32(ebp + (-0x10)); /* 0x0077909B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077909E: push eax */
    RECOMP_CALL(sub_00575590); /* 0x0077909F: call 0x575590 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x007790A4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007790A5: ret  */

}

void sub_007790A6(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007790A6u);

L_007790A6:
    eax = MEM32(ebp + (-0x10)); /* 0x007790A6: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007790A9: push eax */
    RECOMP_CALL(sub_00575590); /* 0x007790AA: call 0x575590 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x007790AF: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007790B0: ret  */

}

void sub_007790B1(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007790B1u);

L_007790B1:
    eax = MEM32(ebp + (-0x10)); /* 0x007790B1: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007790B4: push eax */
    RECOMP_CALL(sub_00575590); /* 0x007790B5: call 0x575590 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x007790BA: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007790BB: ret  */

}

void sub_007790BC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007790BCu);

    goto L_007790BC;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007790BC:
    eax = 0x007E47C0u; /* 0x007790BC: mov eax, 0x7e47c0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007790C1: jmp 0x75bf0e */

}

void sub_007790D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007790D0u);

L_007790D0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007790D0: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x2224u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x2224u; /* 0x007790D3: add ecx, 0x2224 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005C85A0u); RECOMP_RETURN(); /* 0x007790D9: jmp 0x5c85a0 */

}

void sub_007790DE(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007790DEu);

L_007790DE:
    ecx = MEM32(ebp + (-0x10)); /* 0x007790DE: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x2448u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x2448u; /* 0x007790E1: add ecx, 0x2448 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CA3F0u); RECOMP_RETURN(); /* 0x007790E7: jmp 0x5ca3f0 */

}

void sub_007790EC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007790ECu);

L_007790EC:
    ecx = MEM32(ebp + (-0x10)); /* 0x007790EC: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x2498u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x2498u; /* 0x007790EF: add ecx, 0x2498 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CA3F0u); RECOMP_RETURN(); /* 0x007790F5: jmp 0x5ca3f0 */

}

void sub_007790FA(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007790FAu);

L_007790FA:
    ecx = MEM32(ebp + (-0x10)); /* 0x007790FA: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x24E8u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x24E8u; /* 0x007790FD: add ecx, 0x24e8 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CA3F0u); RECOMP_RETURN(); /* 0x00779103: jmp 0x5ca3f0 */

}

void sub_00779108(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779108u);

L_00779108:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779108: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x2538u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x2538u; /* 0x0077910B: add ecx, 0x2538 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CA3F0u); RECOMP_RETURN(); /* 0x00779111: jmp 0x5ca3f0 */

}

void sub_00779116(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779116u);

L_00779116:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779116: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x2588u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x2588u; /* 0x00779119: add ecx, 0x2588 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CA3F0u); RECOMP_RETURN(); /* 0x0077911F: jmp 0x5ca3f0 */

}

void sub_00779124(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779124u);

    goto L_00779124;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779124:
    eax = 0x007E480Cu; /* 0x00779124: mov eax, 0x7e480c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779129: jmp 0x75bf0e */

}

void sub_00779130(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779130u);

    goto L_00779130;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779130:
    eax = 0x007E4890u; /* 0x00779130: mov eax, 0x7e4890 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779135: jmp 0x75bf0e */

}

void sub_00779140(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779140u);

    goto L_00779140;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779140:
    eax = 0x007E48E0u; /* 0x00779140: mov eax, 0x7e48e0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779145: jmp 0x75bf0e */

}

void sub_00779150(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779150u);

L_00779150:
    eax = MEM32(ebp + (-0x10)); /* 0x00779150: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00779153: push eax */
    RECOMP_CALL(sub_00575590); /* 0x00779154: call 0x575590 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00779159: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077915A: ret  */

}

void sub_0077915B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077915Bu);

    goto L_0077915B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077915B:
    eax = 0x007E4A68u; /* 0x0077915B: mov eax, 0x7e4a68 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779160: jmp 0x75bf0e */

}

void sub_00779170(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779170u);

    goto L_00779170;

L_0075D8C4:
    /* cmp MEM32(ecx + 0x8), 0 */ /* 0x0075D8C4: cmp dword ptr [ecx + 8], 0 */
    _flag_a = (uint32_t)(MEM32(ecx + 0x8)); _flag_b = (uint32_t)(0);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    _flag_k = FK_CMP;
    MEM32(ecx) = 0x007D3A80u; /* 0x0075D8C8: mov dword ptr [ecx], 0x7d3a80 */
    if (CMP_EQ(_flag_a, _flag_b)) goto L_0075D8D9; /* 0x0075D8CE: je 0x75d8d9 */

L_0075D8D0:
    PUSH32(esp, MEM32(ecx + 0x4)); /* 0x0075D8D0: push dword ptr [ecx + 4] */
    RECOMP_CALL(sub_0075C60A); /* 0x0075D8D3: call 0x75c60a */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0075D8D8: pop ecx */

L_0075D8D9:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075D8D9: ret  */

L_00779170:
    ecx = MEM32(ebp + (-0x10)); /* 0x00779170: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_BACKEDGE();
    goto L_0075D8C4; /* 0x00779173: jmp 0x75d8c4 */

}

void sub_00779178(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779178u);

    goto L_00779178;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779178:
    eax = 0x007E4978u; /* 0x00779178: mov eax, 0x7e4978 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077917D: jmp 0x75bf0e */

}

void sub_00779190(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779190u);

L_00779190:
    ecx = ebp + (-0x50); /* 0x00779190: lea ecx, [ebp - 0x50] */
    RECOMP_ITAIL(0x005CEFB0u); RECOMP_RETURN(); /* 0x00779193: jmp 0x5cefb0 */

}

void sub_00779198(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779198u);

    goto L_00779198;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779198:
    eax = 0x007E499Cu; /* 0x00779198: mov eax, 0x7e499c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077919D: jmp 0x75bf0e */

}

void sub_007791B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007791B0u);

    goto L_007791B0;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007791B0:
    eax = 0x007E4A20u; /* 0x007791B0: mov eax, 0x7e4a20 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007791B5: jmp 0x75bf0e */

}

void sub_007791C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007791C0u);

L_007791C0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007791C0: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 4; /* 0x007791C3: add ecx, 4 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x005CFA70u); RECOMP_RETURN(); /* 0x007791C6: jmp 0x5cfa70 */

}

void sub_007791CB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007791CBu);

    goto L_007791CB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007791CB:
    eax = 0x007E4A44u; /* 0x007791CB: mov eax, 0x7e4a44 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007791D0: jmp 0x75bf0e */

}

void sub_007791E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007791E0u);

L_007791E0:
    eax = MEM32(ebp + (-0x10)); /* 0x007791E0: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007791E3: push eax */
    RECOMP_CALL(sub_00575590); /* 0x007791E4: call 0x575590 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x007791E9: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007791EA: ret  */

}

void sub_007791EB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007791EBu);

L_007791EB:
    eax = MEM32(ebp + (-0x10)); /* 0x007791EB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007791EE: push eax */
    RECOMP_CALL(sub_00575590); /* 0x007791EF: call 0x575590 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x007791F4: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007791F5: ret  */

}

void sub_007791F6(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007791F6u);

L_007791F6:
    eax = MEM32(ebp + (-0x10)); /* 0x007791F6: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007791F9: push eax */
    RECOMP_CALL(sub_00575590); /* 0x007791FA: call 0x575590 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x007791FF: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779200: ret  */

}

void sub_00779201(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779201u);

L_00779201:
    eax = MEM32(ebp + (-0x10)); /* 0x00779201: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00779204: push eax */
    RECOMP_CALL(sub_00575590); /* 0x00779205: call 0x575590 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077920A: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077920B: ret  */

}

void sub_0077920C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077920Cu);

L_0077920C:
    eax = MEM32(ebp + (-0x10)); /* 0x0077920C: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077920F: push eax */
    RECOMP_CALL(sub_00575590); /* 0x00779210: call 0x575590 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00779215: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779216: ret  */

}

void sub_00779217(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779217u);

L_00779217:
    eax = MEM32(ebp + (-0x10)); /* 0x00779217: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077921A: push eax */
    RECOMP_CALL(sub_00575590); /* 0x0077921B: call 0x575590 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00779220: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779221: ret  */

}

void sub_00779222(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779222u);

L_00779222:
    eax = MEM32(ebp + (-0x10)); /* 0x00779222: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00779225: push eax */
    RECOMP_CALL(sub_00575590); /* 0x00779226: call 0x575590 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077922B: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077922C: ret  */

}

void sub_0077922D(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077922Du);

L_0077922D:
    eax = MEM32(ebp + (-0x10)); /* 0x0077922D: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00779230: push eax */
    RECOMP_CALL(sub_00575590); /* 0x00779231: call 0x575590 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00779236: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779237: ret  */

}

void sub_00779238(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779238u);

    goto L_00779238;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779238:
    eax = 0x007E4AC4u; /* 0x00779238: mov eax, 0x7e4ac4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077923D: jmp 0x75bf0e */

}

void sub_00779250(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779250u);

L_00779250:
    eax = MEM32(ebp + (-0x34)); /* 0x00779250: mov eax, dword ptr [ebp - 0x34] */
    PUSH32(esp, eax); /* 0x00779253: push eax */
    RECOMP_CALL(sub_00575590); /* 0x00779254: call 0x575590 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00779259: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077925A: ret  */

}

void sub_0077925B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077925Bu);

    goto L_0077925B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077925B:
    eax = 0x007E4AE8u; /* 0x0077925B: mov eax, 0x7e4ae8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779260: jmp 0x75bf0e */

}

void sub_00779270(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779270u);

L_00779270:
    PUSH32(esp, 0); /* 0x00779270: push 0 */
    PUSH32(esp, 0x007A521Cu); /* 0x00779272: push 0x7a521c */
    eax = MEM32(ebp + 0x4); /* 0x00779277: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x0077927A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077927B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00779280: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00779283: ret  */

}

void sub_00779284(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779284u);

    goto L_00779284;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00779284:
    eax = 0x007E4B0Cu; /* 0x00779284: mov eax, 0x7e4b0c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00779289: jmp 0x75bf0e */

}

void sub_00779290(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00779290u);

L_00779290:
    ecx = ebp + (-0x278); /* 0x00779290: lea ecx, [ebp - 0x278] */
    RECOMP_ITAIL(0x0043E0D0u); RECOMP_RETURN(); /* 0x00779296: jmp 0x43e0d0 */

}

void sub_0077929B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077929Bu);

    goto L_0077929B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077929B:
    eax = 0x007E4B30u; /* 0x0077929B: mov eax, 0x7e4b30 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007792A0: jmp 0x75bf0e */

}

void sub_007792B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007792B0u);

L_007792B0:
    PUSH32(esp, 0x00490370u); /* 0x007792B0: push 0x490370 */
    PUSH32(esp, 4); /* 0x007792B5: push 4 */
    PUSH32(esp, 0x18u); /* 0x007792B7: push 0x18 */
    eax = MEM32(ebp + (-0x10)); /* 0x007792B9: mov eax, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x2084u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x2084u; /* 0x007792BC: add eax, 0x2084 */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x007792C1: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x007792C2: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007792C7: ret  */

}

void sub_007792C8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007792C8u);

    goto L_007792C8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007792C8:
    eax = 0x007E4B54u; /* 0x007792C8: mov eax, 0x7e4b54 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007792CD: jmp 0x75bf0e */

}

void sub_007792E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007792E0u);

L_007792E0:
    eax = MEM32(ebp + (-0x10)); /* 0x007792E0: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007792E3: push eax */
    RECOMP_CALL(sub_00486E80); /* 0x007792E4: call 0x486e80 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x007792E9: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007792EA: ret  */

}

void sub_007792EB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007792EBu);

    goto L_007792EB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007792EB:
    eax = 0x007E4B78u; /* 0x007792EB: mov eax, 0x7e4b78 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007792F0: jmp 0x75bf0e */

}