/* AUTO-GENERATED from SPEED2.analysis.exe by run_lift.py (pcrecomp lift32). DO NOT EDIT, DO NOT COMMIT. */
#define RECOMP_GENERATED_CODE
#include "recomp_types.h"
#include "recomp_funcs.h"
#include "guest_render_probe.h"
#include <math.h>
#include <string.h>

void sub_00772DF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00772DF0u);

L_00772DF0:
    PUSH32(esp, 0); /* 0x00772DF0: push 0 */
    PUSH32(esp, 0x00790FB0u); /* 0x00772DF2: push 0x790fb0 */
    eax = MEM32(ebp + (-0x10)); /* 0x00772DF7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00772DFA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00772DFB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00772E00: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00772E03: ret  */

}

void sub_00772E00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00772E00u);

L_00772E00:
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00772E00: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00772E03: ret  */

}

void sub_00772E04(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00772E04u);

    goto L_00772E04;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00772E04:
    eax = 0x007DF438u; /* 0x00772E04: mov eax, 0x7df438 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00772E09: jmp 0x75bf0e */

}

void sub_00772E10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00772E10u);

L_00772E10:
    PUSH32(esp, 0); /* 0x00772E10: push 0 */
    PUSH32(esp, 0x00791060u); /* 0x00772E12: push 0x791060 */
    eax = MEM32(ebp + (-0x10)); /* 0x00772E17: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00772E1A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00772E1B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00772E20: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00772E23: ret  */

}

void sub_00772E24(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00772E24u);

L_00772E24:
    PUSH32(esp, 0); /* 0x00772E24: push 0 */
    PUSH32(esp, 0x00791054u); /* 0x00772E26: push 0x791054 */
    eax = MEM32(ebp + (-0x10)); /* 0x00772E2B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00772E2E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00772E2F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00772E34: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00772E37: ret  */

}

void sub_00772E38(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00772E38u);

L_00772E38:
    PUSH32(esp, 0); /* 0x00772E38: push 0 */
    PUSH32(esp, 0x0079104Cu); /* 0x00772E3A: push 0x79104c */
    eax = MEM32(ebp + (-0x10)); /* 0x00772E3F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00772E42: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00772E43: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00772E48: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00772E4B: ret  */

}

void sub_00772E4C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00772E4Cu);

L_00772E4C:
    PUSH32(esp, 0); /* 0x00772E4C: push 0 */
    PUSH32(esp, 0x00791044u); /* 0x00772E4E: push 0x791044 */
    eax = MEM32(ebp + (-0x10)); /* 0x00772E53: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00772E56: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00772E57: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00772E5C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00772E5F: ret  */

}

void sub_00772E60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00772E60u);

L_00772E60:
    PUSH32(esp, 0); /* 0x00772E60: push 0 */
    PUSH32(esp, 0x00791034u); /* 0x00772E62: push 0x791034 */
    eax = MEM32(ebp + (-0x10)); /* 0x00772E67: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00772E6A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00772E6B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00772E70: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00772E73: ret  */

}

void sub_00772E74(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00772E74u);

L_00772E74:
    PUSH32(esp, 0); /* 0x00772E74: push 0 */
    PUSH32(esp, 0x0079102Cu); /* 0x00772E76: push 0x79102c */
    eax = MEM32(ebp + (-0x10)); /* 0x00772E7B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00772E7E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00772E7F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00772E84: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00772E87: ret  */

}

void sub_00772E88(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00772E88u);

L_00772E88:
    PUSH32(esp, 0); /* 0x00772E88: push 0 */
    PUSH32(esp, 0x00791020u); /* 0x00772E8A: push 0x791020 */
    eax = MEM32(ebp + (-0x10)); /* 0x00772E8F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00772E92: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00772E93: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00772E98: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00772E9B: ret  */

}

void sub_00772E9C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00772E9Cu);

L_00772E9C:
    PUSH32(esp, 0); /* 0x00772E9C: push 0 */
    PUSH32(esp, 0x00791014u); /* 0x00772E9E: push 0x791014 */
    eax = MEM32(ebp + (-0x10)); /* 0x00772EA3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00772EA6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00772EA7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00772EAC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00772EAF: ret  */

}

void sub_00772EB0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00772EB0u);

    goto L_00772EB0;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00772EB0:
    eax = 0x007DF494u; /* 0x00772EB0: mov eax, 0x7df494 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00772EB5: jmp 0x75bf0e */

}

void sub_00772EC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00772EC0u);

L_00772EC0:
    PUSH32(esp, 0); /* 0x00772EC0: push 0 */
    PUSH32(esp, 0x00791744u); /* 0x00772EC2: push 0x791744 */
    eax = MEM32(ebp + (-0x10)); /* 0x00772EC7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00772ECA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00772ECB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00772ED0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00772ED3: ret  */

}

void sub_00772ED4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00772ED4u);

L_00772ED4:
    PUSH32(esp, 0); /* 0x00772ED4: push 0 */
    PUSH32(esp, 0x00791730u); /* 0x00772ED6: push 0x791730 */
    eax = MEM32(ebp + (-0x10)); /* 0x00772EDB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00772EDE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00772EDF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00772EE4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00772EE7: ret  */

}

void sub_00772EE8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00772EE8u);

L_00772EE8:
    PUSH32(esp, 0); /* 0x00772EE8: push 0 */
    PUSH32(esp, 0x00791718u); /* 0x00772EEA: push 0x791718 */
    eax = MEM32(ebp + (-0x10)); /* 0x00772EEF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00772EF2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00772EF3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00772EF8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00772EFB: ret  */

}

void sub_00772EFC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00772EFCu);

L_00772EFC:
    PUSH32(esp, 0); /* 0x00772EFC: push 0 */
    PUSH32(esp, 0x00791704u); /* 0x00772EFE: push 0x791704 */
    eax = MEM32(ebp + (-0x10)); /* 0x00772F03: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00772F06: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00772F07: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00772F0C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00772F0F: ret  */

}

void sub_00772F10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00772F10u);

L_00772F10:
    PUSH32(esp, 0); /* 0x00772F10: push 0 */
    PUSH32(esp, 0x007916F4u); /* 0x00772F12: push 0x7916f4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00772F17: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00772F1A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00772F1B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00772F20: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00772F23: ret  */

}

void sub_00772F24(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00772F24u);

L_00772F24:
    PUSH32(esp, 0); /* 0x00772F24: push 0 */
    PUSH32(esp, 0x007916E0u); /* 0x00772F26: push 0x7916e0 */
    eax = MEM32(ebp + (-0x10)); /* 0x00772F2B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00772F2E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00772F2F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00772F34: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00772F37: ret  */

}

void sub_00772F38(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00772F38u);

L_00772F38:
    PUSH32(esp, 0); /* 0x00772F38: push 0 */
    PUSH32(esp, 0x007916D0u); /* 0x00772F3A: push 0x7916d0 */
    eax = MEM32(ebp + (-0x10)); /* 0x00772F3F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00772F42: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00772F43: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00772F48: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00772F4B: ret  */

}

void sub_00772F4C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00772F4Cu);

L_00772F4C:
    PUSH32(esp, 0); /* 0x00772F4C: push 0 */
    PUSH32(esp, 0x007916C0u); /* 0x00772F4E: push 0x7916c0 */
    eax = MEM32(ebp + (-0x10)); /* 0x00772F53: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00772F56: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00772F57: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00772F5C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00772F5F: ret  */

}

void sub_00772F60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00772F60u);

L_00772F60:
    PUSH32(esp, 0); /* 0x00772F60: push 0 */
    PUSH32(esp, 0x007916ACu); /* 0x00772F62: push 0x7916ac */
    eax = MEM32(ebp + (-0x10)); /* 0x00772F67: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00772F6A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00772F6B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00772F70: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00772F73: ret  */

}

void sub_00772F74(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00772F74u);

L_00772F74:
    PUSH32(esp, 0); /* 0x00772F74: push 0 */
    PUSH32(esp, 0x00791690u); /* 0x00772F76: push 0x791690 */
    eax = MEM32(ebp + (-0x10)); /* 0x00772F7B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00772F7E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00772F7F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00772F84: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00772F87: ret  */

}

void sub_00772F88(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00772F88u);

L_00772F88:
    PUSH32(esp, 0); /* 0x00772F88: push 0 */
    PUSH32(esp, 0x00791674u); /* 0x00772F8A: push 0x791674 */
    eax = MEM32(ebp + (-0x10)); /* 0x00772F8F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00772F92: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00772F93: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00772F98: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00772F9B: ret  */

}

void sub_00772F9C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00772F9Cu);

L_00772F9C:
    PUSH32(esp, 0); /* 0x00772F9C: push 0 */
    PUSH32(esp, 0x00791660u); /* 0x00772F9E: push 0x791660 */
    eax = MEM32(ebp + (-0x10)); /* 0x00772FA3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00772FA6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00772FA7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00772FAC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00772FAF: ret  */

}

void sub_00772FB0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00772FB0u);

L_00772FB0:
    PUSH32(esp, 0); /* 0x00772FB0: push 0 */
    PUSH32(esp, 0x0079164Cu); /* 0x00772FB2: push 0x79164c */
    eax = MEM32(ebp + (-0x10)); /* 0x00772FB7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00772FBA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00772FBB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00772FC0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00772FC3: ret  */

}

void sub_00772FC4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00772FC4u);

    goto L_00772FC4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00772FC4:
    eax = 0x007DF53Cu; /* 0x00772FC4: mov eax, 0x7df53c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00772FC9: jmp 0x75bf0e */

}

void sub_00772FD0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00772FD0u);

L_00772FD0:
    PUSH32(esp, 0); /* 0x00772FD0: push 0 */
    PUSH32(esp, 0x007916E0u); /* 0x00772FD2: push 0x7916e0 */
    eax = MEM32(ebp + (-0x10)); /* 0x00772FD7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00772FDA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00772FDB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00772FE0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00772FE3: ret  */

}

void sub_00772FE4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00772FE4u);

L_00772FE4:
    PUSH32(esp, 0); /* 0x00772FE4: push 0 */
    PUSH32(esp, 0x00791790u); /* 0x00772FE6: push 0x791790 */
    eax = MEM32(ebp + (-0x10)); /* 0x00772FEB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00772FEE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00772FEF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00772FF4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00772FF7: ret  */

}

void sub_00772FF8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00772FF8u);

    goto L_00772FF8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00772FF8:
    eax = 0x007DF5ACu; /* 0x00772FF8: mov eax, 0x7df5ac */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00772FFD: jmp 0x75bf0e */

}

void sub_00773010(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773010u);

L_00773010:
    PUSH32(esp, 0); /* 0x00773010: push 0 */
    PUSH32(esp, 0x00793E44u); /* 0x00773012: push 0x793e44 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773017: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077301A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077301B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773020: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773023: ret  */

}

void sub_00773024(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773024u);

L_00773024:
    PUSH32(esp, 0); /* 0x00773024: push 0 */
    PUSH32(esp, 0x00793E38u); /* 0x00773026: push 0x793e38 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077302B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077302E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077302F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773034: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773037: ret  */

}

void sub_00773038(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773038u);

L_00773038:
    PUSH32(esp, 0); /* 0x00773038: push 0 */
    PUSH32(esp, 0x00793E2Cu); /* 0x0077303A: push 0x793e2c */
    eax = MEM32(ebp + (-0x10)); /* 0x0077303F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773042: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773043: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773048: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077304B: ret  */

}

void sub_0077304C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077304Cu);

L_0077304C:
    PUSH32(esp, 0); /* 0x0077304C: push 0 */
    PUSH32(esp, 0x00793E20u); /* 0x0077304E: push 0x793e20 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773053: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773056: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773057: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077305C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077305F: ret  */

}

void sub_00773060(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773060u);

L_00773060:
    PUSH32(esp, 0); /* 0x00773060: push 0 */
    PUSH32(esp, 0x00793E10u); /* 0x00773062: push 0x793e10 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773067: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077306A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077306B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773070: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773073: ret  */

}

void sub_00773074(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773074u);

L_00773074:
    PUSH32(esp, 0); /* 0x00773074: push 0 */
    PUSH32(esp, 0x00793E04u); /* 0x00773076: push 0x793e04 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077307B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077307E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077307F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773084: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773087: ret  */

}

void sub_00773088(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773088u);

L_00773088:
    PUSH32(esp, 0); /* 0x00773088: push 0 */
    PUSH32(esp, 0x00793DF8u); /* 0x0077308A: push 0x793df8 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077308F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773092: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773093: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773098: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077309B: ret  */

}

void sub_0077309C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077309Cu);

L_0077309C:
    PUSH32(esp, 0); /* 0x0077309C: push 0 */
    PUSH32(esp, 0x00793DECu); /* 0x0077309E: push 0x793dec */
    eax = MEM32(ebp + (-0x10)); /* 0x007730A3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007730A6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007730A7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007730AC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007730AF: ret  */

}

void sub_007730B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007730B0u);

L_007730B0:
    PUSH32(esp, 0); /* 0x007730B0: push 0 */
    PUSH32(esp, 0x00793DECu); /* 0x007730B2: push 0x793dec */
    eax = MEM32(ebp + (-0x10)); /* 0x007730B7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007730BA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007730BB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007730C0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007730C3: ret  */

}

void sub_007730C4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007730C4u);

    goto L_007730C4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007730C4:
    eax = 0x007DF610u; /* 0x007730C4: mov eax, 0x7df610 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007730C9: jmp 0x75bf0e */

}

void sub_007730D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007730D0u);

L_007730D0:
    PUSH32(esp, 0); /* 0x007730D0: push 0 */
    PUSH32(esp, 0x00793FACu); /* 0x007730D2: push 0x793fac */
    eax = MEM32(ebp + (-0x10)); /* 0x007730D7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007730DA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007730DB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007730E0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007730E3: ret  */

}

void sub_007730E4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007730E4u);

L_007730E4:
    PUSH32(esp, 0); /* 0x007730E4: push 0 */
    PUSH32(esp, 0x00793F9Cu); /* 0x007730E6: push 0x793f9c */
    eax = MEM32(ebp + (-0x10)); /* 0x007730EB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007730EE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007730EF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007730F4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007730F7: ret  */

}

void sub_007730F8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007730F8u);

L_007730F8:
    PUSH32(esp, 0); /* 0x007730F8: push 0 */
    PUSH32(esp, 0x00793F88u); /* 0x007730FA: push 0x793f88 */
    eax = MEM32(ebp + (-0x10)); /* 0x007730FF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773102: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773103: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773108: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077310B: ret  */

}

void sub_0077310C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077310Cu);

L_0077310C:
    PUSH32(esp, 0); /* 0x0077310C: push 0 */
    PUSH32(esp, 0x00793F78u); /* 0x0077310E: push 0x793f78 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773113: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773116: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773117: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077311C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077311F: ret  */

}

void sub_00773120(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773120u);

L_00773120:
    PUSH32(esp, 0); /* 0x00773120: push 0 */
    PUSH32(esp, 0x00793F68u); /* 0x00773122: push 0x793f68 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773127: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077312A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077312B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773130: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773133: ret  */

}

void sub_00773134(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773134u);

L_00773134:
    PUSH32(esp, 0); /* 0x00773134: push 0 */
    PUSH32(esp, 0x00793F54u); /* 0x00773136: push 0x793f54 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077313B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077313E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077313F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773144: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773147: ret  */

}

void sub_00773148(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773148u);

L_00773148:
    PUSH32(esp, 0); /* 0x00773148: push 0 */
    PUSH32(esp, 0x00793F44u); /* 0x0077314A: push 0x793f44 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077314F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773152: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773153: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773158: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077315B: ret  */

}

void sub_0077315C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077315Cu);

L_0077315C:
    PUSH32(esp, 0); /* 0x0077315C: push 0 */
    PUSH32(esp, 0x00793F34u); /* 0x0077315E: push 0x793f34 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773163: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773166: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773167: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077316C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077316F: ret  */

}

void sub_00773170(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773170u);

L_00773170:
    PUSH32(esp, 0); /* 0x00773170: push 0 */
    PUSH32(esp, 0x00793F1Cu); /* 0x00773172: push 0x793f1c */
    eax = MEM32(ebp + (-0x10)); /* 0x00773177: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077317A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077317B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773180: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773183: ret  */

}

void sub_00773184(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773184u);

L_00773184:
    PUSH32(esp, 0); /* 0x00773184: push 0 */
    PUSH32(esp, 0x00793F0Cu); /* 0x00773186: push 0x793f0c */
    eax = MEM32(ebp + (-0x10)); /* 0x0077318B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077318E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077318F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773194: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773197: ret  */

}

void sub_00773198(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773198u);

L_00773198:
    PUSH32(esp, 0); /* 0x00773198: push 0 */
    PUSH32(esp, 0x00793EFCu); /* 0x0077319A: push 0x793efc */
    eax = MEM32(ebp + (-0x10)); /* 0x0077319F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007731A2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007731A3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007731A8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007731AB: ret  */

}

void sub_007731AC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007731ACu);

L_007731AC:
    PUSH32(esp, 0); /* 0x007731AC: push 0 */
    PUSH32(esp, 0x00793EE8u); /* 0x007731AE: push 0x793ee8 */
    eax = MEM32(ebp + (-0x10)); /* 0x007731B3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007731B6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007731B7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007731BC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007731BF: ret  */

}

void sub_007731C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007731C0u);

L_007731C0:
    PUSH32(esp, 0); /* 0x007731C0: push 0 */
    PUSH32(esp, 0x00793ED8u); /* 0x007731C2: push 0x793ed8 */
    eax = MEM32(ebp + (-0x10)); /* 0x007731C7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007731CA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007731CB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007731D0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007731D3: ret  */

}

void sub_007731D4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007731D4u);

L_007731D4:
    PUSH32(esp, 0); /* 0x007731D4: push 0 */
    PUSH32(esp, 0x00793EC8u); /* 0x007731D6: push 0x793ec8 */
    eax = MEM32(ebp + (-0x10)); /* 0x007731DB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007731DE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007731DF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007731E4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007731E7: ret  */

}

void sub_007731E8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007731E8u);

L_007731E8:
    PUSH32(esp, 0); /* 0x007731E8: push 0 */
    PUSH32(esp, 0x00793EB8u); /* 0x007731EA: push 0x793eb8 */
    eax = MEM32(ebp + (-0x10)); /* 0x007731EF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007731F2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007731F3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007731F8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007731FB: ret  */

}

void sub_007731FC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007731FCu);

L_007731FC:
    PUSH32(esp, 0); /* 0x007731FC: push 0 */
    PUSH32(esp, 0x00793EB0u); /* 0x007731FE: push 0x793eb0 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773203: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773206: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773207: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077320C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077320F: ret  */

}

void sub_00773210(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773210u);

L_00773210:
    PUSH32(esp, 0); /* 0x00773210: push 0 */
    PUSH32(esp, 0x00793EA4u); /* 0x00773212: push 0x793ea4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773217: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077321A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077321B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773220: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773223: ret  */

}

void sub_00773224(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773224u);

L_00773224:
    PUSH32(esp, 0); /* 0x00773224: push 0 */
    PUSH32(esp, 0x00793E94u); /* 0x00773226: push 0x793e94 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077322B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077322E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077322F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773234: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773237: ret  */

}

void sub_00773238(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773238u);

L_00773238:
    PUSH32(esp, 0); /* 0x00773238: push 0 */
    PUSH32(esp, 0x00793E84u); /* 0x0077323A: push 0x793e84 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077323F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773242: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773243: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773248: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077324B: ret  */

}

void sub_0077324C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077324Cu);

L_0077324C:
    PUSH32(esp, 0); /* 0x0077324C: push 0 */
    PUSH32(esp, 0x00793E74u); /* 0x0077324E: push 0x793e74 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773253: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773256: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773257: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077325C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077325F: ret  */

}

void sub_00773260(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773260u);

L_00773260:
    PUSH32(esp, 0); /* 0x00773260: push 0 */
    PUSH32(esp, 0x00793E6Cu); /* 0x00773262: push 0x793e6c */
    eax = MEM32(ebp + (-0x10)); /* 0x00773267: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077326A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077326B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773270: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773273: ret  */

}

void sub_00773274(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773274u);

L_00773274:
    PUSH32(esp, 0); /* 0x00773274: push 0 */
    PUSH32(esp, 0x00793E58u); /* 0x00773276: push 0x793e58 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077327B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077327E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077327F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773284: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773287: ret  */

}

void sub_00773288(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773288u);

L_00773288:
    PUSH32(esp, 0); /* 0x00773288: push 0 */
    PUSH32(esp, 0x00793E4Cu); /* 0x0077328A: push 0x793e4c */
    eax = MEM32(ebp + (-0x10)); /* 0x0077328F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773292: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773293: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773298: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077329B: ret  */

}

void sub_0077329C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077329Cu);

    goto L_0077329C;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077329C:
    eax = 0x007DF6E4u; /* 0x0077329C: mov eax, 0x7df6e4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007732A1: jmp 0x75bf0e */

}

void sub_007732B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007732B0u);

L_007732B0:
    PUSH32(esp, 0); /* 0x007732B0: push 0 */
    PUSH32(esp, 0x00794028u); /* 0x007732B2: push 0x794028 */
    eax = MEM32(ebp + (-0x10)); /* 0x007732B7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007732BA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007732BB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007732C0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007732C3: ret  */

}

void sub_007732C4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007732C4u);

L_007732C4:
    PUSH32(esp, 0); /* 0x007732C4: push 0 */
    PUSH32(esp, 0x00794018u); /* 0x007732C6: push 0x794018 */
    eax = MEM32(ebp + (-0x10)); /* 0x007732CB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007732CE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007732CF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007732D4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007732D7: ret  */

}

void sub_007732D8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007732D8u);

L_007732D8:
    PUSH32(esp, 0); /* 0x007732D8: push 0 */
    PUSH32(esp, 0x00794008u); /* 0x007732DA: push 0x794008 */
    eax = MEM32(ebp + (-0x10)); /* 0x007732DF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007732E2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007732E3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007732E8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007732EB: ret  */

}

void sub_007732EC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007732ECu);

L_007732EC:
    PUSH32(esp, 0); /* 0x007732EC: push 0 */
    PUSH32(esp, 0x00793FFCu); /* 0x007732EE: push 0x793ffc */
    eax = MEM32(ebp + (-0x10)); /* 0x007732F3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007732F6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007732F7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007732FC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007732FF: ret  */

}

void sub_00773300(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773300u);

L_00773300:
    PUSH32(esp, 0); /* 0x00773300: push 0 */
    PUSH32(esp, 0x00793FECu); /* 0x00773302: push 0x793fec */
    eax = MEM32(ebp + (-0x10)); /* 0x00773307: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077330A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077330B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773310: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773313: ret  */

}

void sub_00773314(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773314u);

L_00773314:
    PUSH32(esp, 0); /* 0x00773314: push 0 */
    PUSH32(esp, 0x00793FE0u); /* 0x00773316: push 0x793fe0 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077331B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077331E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077331F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773324: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773327: ret  */

}

void sub_00773328(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773328u);

L_00773328:
    PUSH32(esp, 0); /* 0x00773328: push 0 */
    PUSH32(esp, 0x00793FD4u); /* 0x0077332A: push 0x793fd4 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077332F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773332: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773333: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773338: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077333B: ret  */

}

void sub_0077333C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077333Cu);

L_0077333C:
    PUSH32(esp, 0); /* 0x0077333C: push 0 */
    PUSH32(esp, 0x00793FC8u); /* 0x0077333E: push 0x793fc8 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773343: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773346: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773347: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077334C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077334F: ret  */

}

void sub_00773350(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773350u);

    goto L_00773350;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00773350:
    eax = 0x007DF740u; /* 0x00773350: mov eax, 0x7df740 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00773355: jmp 0x75bf0e */

}

void sub_00773360(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773360u);

L_00773360:
    PUSH32(esp, 0); /* 0x00773360: push 0 */
    PUSH32(esp, 0x007940E4u); /* 0x00773362: push 0x7940e4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773367: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077336A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077336B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773370: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773373: ret  */

}

void sub_00773374(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773374u);

L_00773374:
    PUSH32(esp, 0); /* 0x00773374: push 0 */
    PUSH32(esp, 0x007940D8u); /* 0x00773376: push 0x7940d8 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077337B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077337E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077337F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773384: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773387: ret  */

}

void sub_00773388(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773388u);

L_00773388:
    PUSH32(esp, 0); /* 0x00773388: push 0 */
    PUSH32(esp, 0x007940C8u); /* 0x0077338A: push 0x7940c8 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077338F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773392: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773393: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773398: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077339B: ret  */

}

void sub_0077339C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077339Cu);

L_0077339C:
    PUSH32(esp, 0); /* 0x0077339C: push 0 */
    PUSH32(esp, 0x007940B4u); /* 0x0077339E: push 0x7940b4 */
    eax = MEM32(ebp + (-0x10)); /* 0x007733A3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007733A6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007733A7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007733AC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007733AF: ret  */

}

void sub_007733B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007733B0u);

L_007733B0:
    PUSH32(esp, 0); /* 0x007733B0: push 0 */
    PUSH32(esp, 0x007940A0u); /* 0x007733B2: push 0x7940a0 */
    eax = MEM32(ebp + (-0x10)); /* 0x007733B7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007733BA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007733BB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007733C0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007733C3: ret  */

}

void sub_007733C4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007733C4u);

L_007733C4:
    PUSH32(esp, 0); /* 0x007733C4: push 0 */
    PUSH32(esp, 0x00794090u); /* 0x007733C6: push 0x794090 */
    eax = MEM32(ebp + (-0x10)); /* 0x007733CB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007733CE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007733CF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007733D4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007733D7: ret  */

}

void sub_007733D8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007733D8u);

L_007733D8:
    PUSH32(esp, 0); /* 0x007733D8: push 0 */
    PUSH32(esp, 0x00794084u); /* 0x007733DA: push 0x794084 */
    eax = MEM32(ebp + (-0x10)); /* 0x007733DF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007733E2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007733E3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007733E8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007733EB: ret  */

}

void sub_007733EC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007733ECu);

    goto L_007733EC;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007733EC:
    eax = 0x007DF7D0u; /* 0x007733EC: mov eax, 0x7df7d0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007733F1: jmp 0x75bf0e */

}

void sub_00773400(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773400u);

L_00773400:
    PUSH32(esp, 0); /* 0x00773400: push 0 */
    PUSH32(esp, 0x00794448u); /* 0x00773402: push 0x794448 */
    eax = MEM32(ebp + (-0x14)); /* 0x00773407: mov eax, dword ptr [ebp - 0x14] */
    PUSH32(esp, eax); /* 0x0077340A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077340B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773410: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773413: ret  */

}

void sub_00773414(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773414u);

L_00773414:
    PUSH32(esp, 0); /* 0x00773414: push 0 */
    PUSH32(esp, 0x0079443Cu); /* 0x00773416: push 0x79443c */
    eax = MEM32(ebp + (-0x14)); /* 0x0077341B: mov eax, dword ptr [ebp - 0x14] */
    PUSH32(esp, eax); /* 0x0077341E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077341F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773424: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773427: ret  */

}

void sub_00773428(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773428u);

L_00773428:
    PUSH32(esp, 0); /* 0x00773428: push 0 */
    PUSH32(esp, 0x00794430u); /* 0x0077342A: push 0x794430 */
    eax = MEM32(ebp + (-0x14)); /* 0x0077342F: mov eax, dword ptr [ebp - 0x14] */
    PUSH32(esp, eax); /* 0x00773432: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773433: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773438: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077343B: ret  */

}

void sub_0077343C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077343Cu);

L_0077343C:
    PUSH32(esp, 0); /* 0x0077343C: push 0 */
    PUSH32(esp, 0x00794424u); /* 0x0077343E: push 0x794424 */
    eax = MEM32(ebp + (-0x14)); /* 0x00773443: mov eax, dword ptr [ebp - 0x14] */
    PUSH32(esp, eax); /* 0x00773446: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773447: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077344C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077344F: ret  */

}

void sub_00773450(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773450u);

L_00773450:
    PUSH32(esp, 0); /* 0x00773450: push 0 */
    PUSH32(esp, 0x00794418u); /* 0x00773452: push 0x794418 */
    eax = MEM32(ebp + (-0x14)); /* 0x00773457: mov eax, dword ptr [ebp - 0x14] */
    PUSH32(esp, eax); /* 0x0077345A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077345B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773460: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773463: ret  */

}

void sub_00773464(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773464u);

L_00773464:
    PUSH32(esp, 0); /* 0x00773464: push 0 */
    PUSH32(esp, 0x0079440Cu); /* 0x00773466: push 0x79440c */
    eax = MEM32(ebp + (-0x14)); /* 0x0077346B: mov eax, dword ptr [ebp - 0x14] */
    PUSH32(esp, eax); /* 0x0077346E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077346F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773474: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773477: ret  */

}

void sub_00773478(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773478u);

L_00773478:
    PUSH32(esp, 0); /* 0x00773478: push 0 */
    PUSH32(esp, 0x00794400u); /* 0x0077347A: push 0x794400 */
    eax = MEM32(ebp + (-0x14)); /* 0x0077347F: mov eax, dword ptr [ebp - 0x14] */
    PUSH32(esp, eax); /* 0x00773482: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773483: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773488: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077348B: ret  */

}

void sub_0077348C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077348Cu);

L_0077348C:
    PUSH32(esp, 0); /* 0x0077348C: push 0 */
    PUSH32(esp, 0x007943F8u); /* 0x0077348E: push 0x7943f8 */
    eax = MEM32(ebp + (-0x14)); /* 0x00773493: mov eax, dword ptr [ebp - 0x14] */
    PUSH32(esp, eax); /* 0x00773496: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773497: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077349C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077349F: ret  */

}

void sub_007734A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007734A0u);

L_007734A0:
    PUSH32(esp, 0); /* 0x007734A0: push 0 */
    PUSH32(esp, 0x007943E8u); /* 0x007734A2: push 0x7943e8 */
    eax = MEM32(ebp + (-0x14)); /* 0x007734A7: mov eax, dword ptr [ebp - 0x14] */
    PUSH32(esp, eax); /* 0x007734AA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007734AB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007734B0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007734B3: ret  */

}

void sub_007734B4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007734B4u);

L_007734B4:
    PUSH32(esp, 0); /* 0x007734B4: push 0 */
    PUSH32(esp, 0x007943D8u); /* 0x007734B6: push 0x7943d8 */
    eax = MEM32(ebp + (-0x14)); /* 0x007734BB: mov eax, dword ptr [ebp - 0x14] */
    PUSH32(esp, eax); /* 0x007734BE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007734BF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007734C4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007734C7: ret  */

}

void sub_007734C8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007734C8u);

L_007734C8:
    PUSH32(esp, 0); /* 0x007734C8: push 0 */
    PUSH32(esp, 0x007943CCu); /* 0x007734CA: push 0x7943cc */
    eax = MEM32(ebp + (-0x10)); /* 0x007734CF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007734D2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007734D3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007734D8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007734DB: ret  */

}

void sub_007734DC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007734DCu);

L_007734DC:
    PUSH32(esp, 0); /* 0x007734DC: push 0 */
    PUSH32(esp, 0x007943BCu); /* 0x007734DE: push 0x7943bc */
    eax = MEM32(ebp + (-0x10)); /* 0x007734E3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007734E6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007734E7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007734EC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007734EF: ret  */

}

void sub_007734F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007734F0u);

    goto L_007734F0;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007734F0:
    eax = 0x007DF84Cu; /* 0x007734F0: mov eax, 0x7df84c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007734F5: jmp 0x75bf0e */

}

void sub_00773500(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773500u);

L_00773500:
    PUSH32(esp, 0); /* 0x00773500: push 0 */
    PUSH32(esp, 0x00794470u); /* 0x00773502: push 0x794470 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773507: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077350A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077350B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773510: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773513: ret  */

}

void sub_00773514(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773514u);

L_00773514:
    PUSH32(esp, 0); /* 0x00773514: push 0 */
    PUSH32(esp, 0x00794458u); /* 0x00773516: push 0x794458 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077351B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077351E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077351F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773524: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773527: ret  */

}

void sub_00773528(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773528u);

    goto L_00773528;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00773528:
    eax = 0x007DF878u; /* 0x00773528: mov eax, 0x7df878 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077352D: jmp 0x75bf0e */

}

void sub_00773540(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773540u);

L_00773540:
    PUSH32(esp, 0); /* 0x00773540: push 0 */
    PUSH32(esp, 0x00794580u); /* 0x00773542: push 0x794580 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773547: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077354A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077354B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773550: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773553: ret  */

}

void sub_00773554(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773554u);

L_00773554:
    PUSH32(esp, 0); /* 0x00773554: push 0 */
    PUSH32(esp, 0x00794574u); /* 0x00773556: push 0x794574 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077355B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077355E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077355F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773564: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773567: ret  */

}

void sub_00773568(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773568u);

L_00773568:
    PUSH32(esp, 0); /* 0x00773568: push 0 */
    PUSH32(esp, 0x00794568u); /* 0x0077356A: push 0x794568 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077356F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773572: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773573: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773578: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077357B: ret  */

}

void sub_0077357C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077357Cu);

    goto L_0077357C;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077357C:
    eax = 0x007DF8ACu; /* 0x0077357C: mov eax, 0x7df8ac */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00773581: jmp 0x75bf0e */

}

void sub_00773590(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773590u);

L_00773590:
    PUSH32(esp, 0); /* 0x00773590: push 0 */
    PUSH32(esp, 0x007945D4u); /* 0x00773592: push 0x7945d4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773597: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077359A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077359B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007735A0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007735A3: ret  */

}

void sub_007735A4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007735A4u);

    goto L_007735A4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007735A4:
    eax = 0x007DF8D0u; /* 0x007735A4: mov eax, 0x7df8d0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007735A9: jmp 0x75bf0e */

}

void sub_007735B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007735B0u);

L_007735B0:
    PUSH32(esp, 0); /* 0x007735B0: push 0 */
    PUSH32(esp, 0x00794620u); /* 0x007735B2: push 0x794620 */
    eax = MEM32(ebp + (-0x10)); /* 0x007735B7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007735BA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007735BB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007735C0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007735C3: ret  */

}

void sub_007735C4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007735C4u);

    goto L_007735C4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007735C4:
    eax = 0x007DF8F4u; /* 0x007735C4: mov eax, 0x7df8f4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007735C9: jmp 0x75bf0e */

}

void sub_007735D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007735D0u);

L_007735D0:
    PUSH32(esp, 0); /* 0x007735D0: push 0 */
    PUSH32(esp, 0x00794658u); /* 0x007735D2: push 0x794658 */
    eax = MEM32(ebp + (-0x10)); /* 0x007735D7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007735DA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007735DB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007735E0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007735E3: ret  */

}

void sub_007735E4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007735E4u);

L_007735E4:
    PUSH32(esp, 0); /* 0x007735E4: push 0 */
    PUSH32(esp, 0x00794644u); /* 0x007735E6: push 0x794644 */
    eax = MEM32(ebp + (-0x10)); /* 0x007735EB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007735EE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007735EF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007735F4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007735F7: ret  */

}

void sub_007735F8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007735F8u);

L_007735F8:
    PUSH32(esp, 0); /* 0x007735F8: push 0 */
    PUSH32(esp, 0x0079462Cu); /* 0x007735FA: push 0x79462c */
    eax = MEM32(ebp + (-0x10)); /* 0x007735FF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773602: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773603: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773608: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077360B: ret  */

}

void sub_0077360C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077360Cu);

    goto L_0077360C;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077360C:
    eax = 0x007DF928u; /* 0x0077360C: mov eax, 0x7df928 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00773611: jmp 0x75bf0e */

}

void sub_00773620(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773620u);

L_00773620:
    ecx = MEM32(ebp + (-0x10)); /* 0x00773620: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00773623: jmp 0x553a80 */

}

void sub_00773628(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773628u);

L_00773628:
    ecx = MEM32(ebp + (-0x10)); /* 0x00773628: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x50u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x50u; /* 0x0077362B: add ecx, 0x50 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0049D820u); RECOMP_RETURN(); /* 0x0077362E: jmp 0x49d820 */

}

void sub_00773633(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773633u);

    goto L_00773633;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00773633:
    eax = 0x007DF954u; /* 0x00773633: mov eax, 0x7df954 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00773638: jmp 0x75bf0e */

}

void sub_00773640(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773640u);

L_00773640:
    PUSH32(esp, 0); /* 0x00773640: push 0 */
    PUSH32(esp, 0x00794678u); /* 0x00773642: push 0x794678 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773647: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077364A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077364B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773650: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773653: ret  */

}

void sub_00773654(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773654u);

    goto L_00773654;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00773654:
    eax = 0x007DF978u; /* 0x00773654: mov eax, 0x7df978 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00773659: jmp 0x75bf0e */

}

void sub_00773660(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773660u);

L_00773660:
    PUSH32(esp, 0); /* 0x00773660: push 0 */
    PUSH32(esp, 0x00794800u); /* 0x00773662: push 0x794800 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773667: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077366A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077366B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773670: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773673: ret  */

}

void sub_00773674(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773674u);

L_00773674:
    PUSH32(esp, 0); /* 0x00773674: push 0 */
    PUSH32(esp, 0x007947E8u); /* 0x00773676: push 0x7947e8 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077367B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077367E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077367F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773684: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773687: ret  */

}

void sub_00773688(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773688u);

L_00773688:
    PUSH32(esp, 0); /* 0x00773688: push 0 */
    PUSH32(esp, 0x007947D0u); /* 0x0077368A: push 0x7947d0 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077368F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773692: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773693: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773698: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077369B: ret  */

}

void sub_0077369C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077369Cu);

    goto L_0077369C;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077369C:
    eax = 0x007DF9ACu; /* 0x0077369C: mov eax, 0x7df9ac */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007736A1: jmp 0x75bf0e */

}

void sub_007736B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007736B0u);

L_007736B0:
    PUSH32(esp, 0); /* 0x007736B0: push 0 */
    PUSH32(esp, 0x00794814u); /* 0x007736B2: push 0x794814 */
    eax = MEM32(ebp + (-0x10)); /* 0x007736B7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007736BA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007736BB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007736C0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007736C3: ret  */

}

void sub_007736C4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007736C4u);

    goto L_007736C4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007736C4:
    eax = 0x007DF9D0u; /* 0x007736C4: mov eax, 0x7df9d0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007736C9: jmp 0x75bf0e */

}

void sub_007736D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007736D0u);

L_007736D0:
    PUSH32(esp, 0); /* 0x007736D0: push 0 */
    PUSH32(esp, 0x00794884u); /* 0x007736D2: push 0x794884 */
    eax = MEM32(ebp + (-0x10)); /* 0x007736D7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007736DA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007736DB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007736E0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007736E3: ret  */

}

void sub_007736E4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007736E4u);

L_007736E4:
    PUSH32(esp, 0); /* 0x007736E4: push 0 */
    PUSH32(esp, 0x00794884u); /* 0x007736E6: push 0x794884 */
    eax = MEM32(ebp + (-0x10)); /* 0x007736EB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007736EE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007736EF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007736F4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007736F7: ret  */

}

void sub_007736F8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007736F8u);

    goto L_007736F8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007736F8:
    eax = 0x007DF9FCu; /* 0x007736F8: mov eax, 0x7df9fc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007736FD: jmp 0x75bf0e */

}

void sub_00773710(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773710u);

L_00773710:
    PUSH32(esp, 0); /* 0x00773710: push 0 */
    PUSH32(esp, 0x00794AF8u); /* 0x00773712: push 0x794af8 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773717: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077371A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077371B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773720: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773723: ret  */

}

void sub_00773724(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773724u);

    goto L_00773724;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00773724:
    eax = 0x007DFA20u; /* 0x00773724: mov eax, 0x7dfa20 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00773729: jmp 0x75bf0e */

}

void sub_00773730(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773730u);

L_00773730:
    PUSH32(esp, 0); /* 0x00773730: push 0 */
    PUSH32(esp, 0x00794B14u); /* 0x00773732: push 0x794b14 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773737: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077373A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077373B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773740: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773743: ret  */

}

void sub_00773744(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773744u);

    goto L_00773744;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00773744:
    eax = 0x007DFA44u; /* 0x00773744: mov eax, 0x7dfa44 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00773749: jmp 0x75bf0e */

}

void sub_00773750(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773750u);

L_00773750:
    ecx = MEM32(ebp + (-0x10)); /* 0x00773750: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004CF610u); RECOMP_RETURN(); /* 0x00773753: jmp 0x4cf610 */

}

void sub_00773758(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773758u);

    goto L_00773758;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00773758:
    eax = 0x007DF4B8u; /* 0x00773758: mov eax, 0x7df4b8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077375D: jmp 0x75bf0e */

}

void sub_00773770(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773770u);

L_00773770:
    PUSH32(esp, 0); /* 0x00773770: push 0 */
    PUSH32(esp, 0x00794C88u); /* 0x00773772: push 0x794c88 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773777: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077377A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077377B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773780: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773783: ret  */

}

void sub_00773784(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773784u);

L_00773784:
    PUSH32(esp, 0); /* 0x00773784: push 0 */
    PUSH32(esp, 0x00794C70u); /* 0x00773786: push 0x794c70 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077378B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077378E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077378F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773794: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773797: ret  */

}

void sub_00773798(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773798u);

L_00773798:
    PUSH32(esp, 0); /* 0x00773798: push 0 */
    PUSH32(esp, 0x00794C5Cu); /* 0x0077379A: push 0x794c5c */
    eax = MEM32(ebp + (-0x10)); /* 0x0077379F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007737A2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007737A3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007737A8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007737AB: ret  */

}

void sub_007737AC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007737ACu);

L_007737AC:
    PUSH32(esp, 0); /* 0x007737AC: push 0 */
    PUSH32(esp, 0x00794C44u); /* 0x007737AE: push 0x794c44 */
    eax = MEM32(ebp + (-0x10)); /* 0x007737B3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007737B6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007737B7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007737BC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007737BF: ret  */

}

void sub_007737C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007737C0u);

    goto L_007737C0;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007737C0:
    eax = 0x007DFA80u; /* 0x007737C0: mov eax, 0x7dfa80 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007737C5: jmp 0x75bf0e */

}

void sub_007737D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007737D0u);

L_007737D0:
    ecx = ebp + (-0x900); /* 0x007737D0: lea ecx, [ebp - 0x900] */
    RECOMP_ITAIL(0x0040BE20u); RECOMP_RETURN(); /* 0x007737D6: jmp 0x40be20 */

}

void sub_007737DB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007737DBu);

    goto L_007737DB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007737DB:
    eax = 0x007DFAA4u; /* 0x007737DB: mov eax, 0x7dfaa4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007737E0: jmp 0x75bf0e */

}

void sub_007737F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007737F0u);

L_007737F0:
    PUSH32(esp, 0); /* 0x007737F0: push 0 */
    PUSH32(esp, 0x00794E58u); /* 0x007737F2: push 0x794e58 */
    eax = MEM32(ebp + (-0x10)); /* 0x007737F7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007737FA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007737FB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773800: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773803: ret  */

}

void sub_00773804(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773804u);

L_00773804:
    PUSH32(esp, 0); /* 0x00773804: push 0 */
    PUSH32(esp, 0x00794E48u); /* 0x00773806: push 0x794e48 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077380B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077380E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077380F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773814: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773817: ret  */

}

void sub_00773818(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773818u);

L_00773818:
    PUSH32(esp, 0); /* 0x00773818: push 0 */
    PUSH32(esp, 0x00794E34u); /* 0x0077381A: push 0x794e34 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077381F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773822: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773823: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773828: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077382B: ret  */

}

void sub_0077382C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077382Cu);

L_0077382C:
    PUSH32(esp, 0); /* 0x0077382C: push 0 */
    PUSH32(esp, 0x00794E24u); /* 0x0077382E: push 0x794e24 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773833: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773836: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773837: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077383C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077383F: ret  */

}

void sub_00773840(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773840u);

L_00773840:
    PUSH32(esp, 0); /* 0x00773840: push 0 */
    PUSH32(esp, 0x00794E14u); /* 0x00773842: push 0x794e14 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773847: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077384A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077384B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773850: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773853: ret  */

}

void sub_00773854(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773854u);

    goto L_00773854;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00773854:
    eax = 0x007DFB0Cu; /* 0x00773854: mov eax, 0x7dfb0c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00773859: jmp 0x75bf0e */

}

void sub_00773860(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773860u);

L_00773860:
    PUSH32(esp, 0); /* 0x00773860: push 0 */
    PUSH32(esp, 0x00794F88u); /* 0x00773862: push 0x794f88 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773867: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077386A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077386B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773870: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773873: ret  */

}

void sub_00773874(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773874u);

L_00773874:
    PUSH32(esp, 0); /* 0x00773874: push 0 */
    PUSH32(esp, 0x00794F74u); /* 0x00773876: push 0x794f74 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077387B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077387E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077387F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773884: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773887: ret  */

}

void sub_00773888(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773888u);

L_00773888:
    PUSH32(esp, 0); /* 0x00773888: push 0 */
    PUSH32(esp, 0x00794F60u); /* 0x0077388A: push 0x794f60 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077388F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773892: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773893: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773898: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077389B: ret  */

}

void sub_0077389C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077389Cu);

    goto L_0077389C;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077389C:
    eax = 0x007DFB40u; /* 0x0077389C: mov eax, 0x7dfb40 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007738A1: jmp 0x75bf0e */

}

void sub_007738B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007738B0u);

L_007738B0:
    PUSH32(esp, 0); /* 0x007738B0: push 0 */
    PUSH32(esp, 0x007950A0u); /* 0x007738B2: push 0x7950a0 */
    eax = MEM32(ebp + (-0x10)); /* 0x007738B7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007738BA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007738BB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007738C0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007738C3: ret  */

}

void sub_007738C4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007738C4u);

L_007738C4:
    PUSH32(esp, 0); /* 0x007738C4: push 0 */
    PUSH32(esp, 0x00795094u); /* 0x007738C6: push 0x795094 */
    eax = MEM32(ebp + (-0x10)); /* 0x007738CB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007738CE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007738CF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007738D4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007738D7: ret  */

}

void sub_007738D8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007738D8u);

L_007738D8:
    PUSH32(esp, 0); /* 0x007738D8: push 0 */
    PUSH32(esp, 0x00795080u); /* 0x007738DA: push 0x795080 */
    eax = MEM32(ebp + (-0x10)); /* 0x007738DF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007738E2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007738E3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007738E8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007738EB: ret  */

}

void sub_007738EC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007738ECu);

L_007738EC:
    PUSH32(esp, 0); /* 0x007738EC: push 0 */
    PUSH32(esp, 0x00795070u); /* 0x007738EE: push 0x795070 */
    eax = MEM32(ebp + (-0x10)); /* 0x007738F3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007738F6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007738F7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007738FC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007738FF: ret  */

}

void sub_00773900(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773900u);

L_00773900:
    PUSH32(esp, 0); /* 0x00773900: push 0 */
    PUSH32(esp, 0x00795060u); /* 0x00773902: push 0x795060 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773907: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077390A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077390B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773910: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773913: ret  */

}

void sub_00773914(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773914u);

L_00773914:
    PUSH32(esp, 0); /* 0x00773914: push 0 */
    PUSH32(esp, 0x00795054u); /* 0x00773916: push 0x795054 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077391B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077391E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077391F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773924: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773927: ret  */

}

void sub_00773928(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773928u);

L_00773928:
    PUSH32(esp, 0); /* 0x00773928: push 0 */
    PUSH32(esp, 0x00795044u); /* 0x0077392A: push 0x795044 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077392F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773932: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773933: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773938: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077393B: ret  */

}

void sub_0077393C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077393Cu);

    goto L_0077393C;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077393C:
    eax = 0x007DFB94u; /* 0x0077393C: mov eax, 0x7dfb94 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00773941: jmp 0x75bf0e */

}

void sub_00773950(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773950u);

L_00773950:
    eax = MEM32(ebp + (-0x90)); /* 0x00773950: mov eax, dword ptr [ebp - 0x90] */
    PUSH32(esp, eax); /* 0x00773956: push eax */
    RECOMP_CALL(sub_00575590); /* 0x00773957: call 0x575590 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x0077395C: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077395D: ret  */

}

void sub_0077395E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077395Eu);

    goto L_0077395E;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077395E:
    eax = 0x007DFBB8u; /* 0x0077395E: mov eax, 0x7dfbb8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00773963: jmp 0x75bf0e */

}

void sub_00773970(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773970u);

L_00773970:
    ecx = MEM32(ebp + (-0x30)); /* 0x00773970: mov ecx, dword ptr [ebp - 0x30] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00773973: jmp 0x553a80 */

}

void sub_00773978(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773978u);

    goto L_00773978;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00773978:
    eax = 0x007DFAC8u; /* 0x00773978: mov eax, 0x7dfac8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077397D: jmp 0x75bf0e */

}

void sub_00773990(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773990u);

L_00773990:
    PUSH32(esp, 0); /* 0x00773990: push 0 */
    PUSH32(esp, 0x0079546Cu); /* 0x00773992: push 0x79546c */
    eax = MEM32(ebp + (-0x10)); /* 0x00773997: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077399A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077399B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007739A0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007739A3: ret  */

}

void sub_007739A4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007739A4u);

    goto L_007739A4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007739A4:
    eax = 0x007DFBDCu; /* 0x007739A4: mov eax, 0x7dfbdc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007739A9: jmp 0x75bf0e */

}

void sub_007739B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007739B0u);

L_007739B0:
    PUSH32(esp, 0); /* 0x007739B0: push 0 */
    PUSH32(esp, 0x007954A0u); /* 0x007739B2: push 0x7954a0 */
    eax = MEM32(ebp + (-0x30)); /* 0x007739B7: mov eax, dword ptr [ebp - 0x30] */
    PUSH32(esp, eax); /* 0x007739BA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007739BB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007739C0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007739C3: ret  */

}

void sub_007739C4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007739C4u);

    goto L_007739C4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007739C4:
    eax = 0x007DFC00u; /* 0x007739C4: mov eax, 0x7dfc00 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007739C9: jmp 0x75bf0e */

}

void sub_007739D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007739D0u);

L_007739D0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007739D0: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 4; /* 0x007739D3: add ecx, 4 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00490370u); RECOMP_RETURN(); /* 0x007739D6: jmp 0x490370 */

}

void sub_007739DB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007739DBu);

L_007739DB:
    ecx = MEM32(ebp + (-0x10)); /* 0x007739DB: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x1Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x1Cu; /* 0x007739DE: add ecx, 0x1c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00490370u); RECOMP_RETURN(); /* 0x007739E1: jmp 0x490370 */

}

void sub_007739E6(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007739E6u);

    goto L_007739E6;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007739E6:
    eax = 0x007DFC2Cu; /* 0x007739E6: mov eax, 0x7dfc2c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007739EB: jmp 0x75bf0e */

}

void sub_007739F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007739F0u);

L_007739F0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007739F0: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 4; /* 0x007739F3: add ecx, 4 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00490370u); RECOMP_RETURN(); /* 0x007739F6: jmp 0x490370 */

}

void sub_007739FB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007739FBu);

L_007739FB:
    ecx = MEM32(ebp + (-0x10)); /* 0x007739FB: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x1Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x1Cu; /* 0x007739FE: add ecx, 0x1c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00490370u); RECOMP_RETURN(); /* 0x00773A01: jmp 0x490370 */

}

void sub_00773A06(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773A06u);

L_00773A06:
    PUSH32(esp, 0x00490370u); /* 0x00773A06: push 0x490370 */
    PUSH32(esp, 3); /* 0x00773A0B: push 3 */
    PUSH32(esp, 0x18u); /* 0x00773A0D: push 0x18 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773A0F: mov eax, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(0x34u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    eax = eax + 0x34u; /* 0x00773A12: add eax, 0x34 */
    _flag_k = FK_ADD;
    PUSH32(esp, eax); /* 0x00773A15: push eax */
    RECOMP_CALL(sub_0075C33D); /* 0x00773A16: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773A1B: ret  */

}

void sub_00773A1C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773A1Cu);

L_00773A1C:
    ecx = MEM32(ebp + (-0x10)); /* 0x00773A1C: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x7Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x7Cu; /* 0x00773A1F: add ecx, 0x7c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00490370u); RECOMP_RETURN(); /* 0x00773A22: jmp 0x490370 */

}

void sub_00773A27(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773A27u);

    goto L_00773A27;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00773A27:
    eax = 0x007DFC68u; /* 0x00773A27: mov eax, 0x7dfc68 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00773A2C: jmp 0x75bf0e */

}

void sub_00773A40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773A40u);

L_00773A40:
    ecx = MEM32(ebp + (-0x10)); /* 0x00773A40: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00773A43: jmp 0x553a80 */

}

void sub_00773A48(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773A48u);

L_00773A48:
    ecx = MEM32(ebp + (-0x10)); /* 0x00773A48: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x6Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x6Cu; /* 0x00773A4B: add ecx, 0x6c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004C1940u); RECOMP_RETURN(); /* 0x00773A4E: jmp 0x4c1940 */

}

void sub_00773A53(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773A53u);

L_00773A53:
    ecx = MEM32(ebp + (-0x10)); /* 0x00773A53: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x23Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x23Cu; /* 0x00773A56: add ecx, 0x23c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004C1680u); RECOMP_RETURN(); /* 0x00773A5C: jmp 0x4c1680 */

}

void sub_00773A61(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773A61u);

    goto L_00773A61;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00773A61:
    eax = 0x007DFC9Cu; /* 0x00773A61: mov eax, 0x7dfc9c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00773A66: jmp 0x75bf0e */

}

void sub_00773A70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773A70u);

L_00773A70:
    PUSH32(esp, 0); /* 0x00773A70: push 0 */
    PUSH32(esp, 0x00795574u); /* 0x00773A72: push 0x795574 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773A77: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773A7A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773A7B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773A80: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773A83: ret  */

}

void sub_00773A84(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773A84u);

L_00773A84:
    PUSH32(esp, 0); /* 0x00773A84: push 0 */
    PUSH32(esp, 0x00795574u); /* 0x00773A86: push 0x795574 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773A8B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773A8E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773A8F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773A94: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773A97: ret  */

}

void sub_00773A98(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773A98u);

L_00773A98:
    PUSH32(esp, 0); /* 0x00773A98: push 0 */
    PUSH32(esp, 0x00795564u); /* 0x00773A9A: push 0x795564 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773A9F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773AA2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773AA3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773AA8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773AAB: ret  */

}

void sub_00773AAC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773AACu);

L_00773AAC:
    PUSH32(esp, 0); /* 0x00773AAC: push 0 */
    PUSH32(esp, 0x00795550u); /* 0x00773AAE: push 0x795550 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773AB3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773AB6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773AB7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773ABC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773ABF: ret  */

}

void sub_00773AC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773AC0u);

L_00773AC0:
    PUSH32(esp, 0); /* 0x00773AC0: push 0 */
    PUSH32(esp, 0x00795544u); /* 0x00773AC2: push 0x795544 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773AC7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773ACA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773ACB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773AD0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773AD3: ret  */

}

void sub_00773AD4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773AD4u);

L_00773AD4:
    PUSH32(esp, 0); /* 0x00773AD4: push 0 */
    PUSH32(esp, 0x00795530u); /* 0x00773AD6: push 0x795530 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773ADB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773ADE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773ADF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773AE4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773AE7: ret  */

}

void sub_00773AE8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773AE8u);

L_00773AE8:
    PUSH32(esp, 0); /* 0x00773AE8: push 0 */
    PUSH32(esp, 0x00795530u); /* 0x00773AEA: push 0x795530 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773AEF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773AF2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773AF3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773AF8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773AFB: ret  */

}

void sub_00773AFC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773AFCu);

L_00773AFC:
    PUSH32(esp, 0); /* 0x00773AFC: push 0 */
    PUSH32(esp, 0x00795530u); /* 0x00773AFE: push 0x795530 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773B03: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773B06: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773B07: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773B0C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773B0F: ret  */

}

void sub_00773B10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773B10u);

    goto L_00773B10;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00773B10:
    eax = 0x007DFCF8u; /* 0x00773B10: mov eax, 0x7dfcf8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00773B15: jmp 0x75bf0e */

}

void sub_00773B20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773B20u);

L_00773B20:
    PUSH32(esp, 0); /* 0x00773B20: push 0 */
    PUSH32(esp, 0x007955C0u); /* 0x00773B22: push 0x7955c0 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773B27: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773B2A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773B2B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773B30: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773B33: ret  */

}

void sub_00773B34(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773B34u);

L_00773B34:
    PUSH32(esp, 0); /* 0x00773B34: push 0 */
    PUSH32(esp, 0x007955B0u); /* 0x00773B36: push 0x7955b0 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773B3B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773B3E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773B3F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773B44: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773B47: ret  */

}

void sub_00773B48(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773B48u);

L_00773B48:
    PUSH32(esp, 0); /* 0x00773B48: push 0 */
    PUSH32(esp, 0x007955A0u); /* 0x00773B4A: push 0x7955a0 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773B4F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773B52: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773B53: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773B58: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773B5B: ret  */

}

void sub_00773B5C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773B5Cu);

L_00773B5C:
    PUSH32(esp, 0); /* 0x00773B5C: push 0 */
    PUSH32(esp, 0x00795588u); /* 0x00773B5E: push 0x795588 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773B63: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773B66: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773B67: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773B6C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773B6F: ret  */

}

void sub_00773B70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773B70u);

L_00773B70:
    PUSH32(esp, 0); /* 0x00773B70: push 0 */
    PUSH32(esp, 0x00795550u); /* 0x00773B72: push 0x795550 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773B77: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773B7A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773B7B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773B80: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773B83: ret  */

}

void sub_00773B84(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773B84u);

L_00773B84:
    PUSH32(esp, 0); /* 0x00773B84: push 0 */
    PUSH32(esp, 0x00795544u); /* 0x00773B86: push 0x795544 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773B8B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773B8E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773B8F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773B94: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773B97: ret  */

}

void sub_00773B98(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773B98u);

L_00773B98:
    PUSH32(esp, 0); /* 0x00773B98: push 0 */
    PUSH32(esp, 0x00795530u); /* 0x00773B9A: push 0x795530 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773B9F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773BA2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773BA3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773BA8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773BAB: ret  */

}

void sub_00773BAC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773BACu);

L_00773BAC:
    PUSH32(esp, 0); /* 0x00773BAC: push 0 */
    PUSH32(esp, 0x00795530u); /* 0x00773BAE: push 0x795530 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773BB3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773BB6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773BB7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773BBC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773BBF: ret  */

}

void sub_00773BC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773BC0u);

L_00773BC0:
    PUSH32(esp, 0); /* 0x00773BC0: push 0 */
    PUSH32(esp, 0x00795530u); /* 0x00773BC2: push 0x795530 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773BC7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773BCA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773BCB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773BD0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773BD3: ret  */

}

void sub_00773BD4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773BD4u);

L_00773BD4:
    PUSH32(esp, 0); /* 0x00773BD4: push 0 */
    PUSH32(esp, 0x00795530u); /* 0x00773BD6: push 0x795530 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773BDB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773BDE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773BDF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773BE4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773BE7: ret  */

}

void sub_00773BE8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773BE8u);

L_00773BE8:
    PUSH32(esp, 0); /* 0x00773BE8: push 0 */
    PUSH32(esp, 0x00795530u); /* 0x00773BEA: push 0x795530 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773BEF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773BF2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773BF3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773BF8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773BFB: ret  */

}

void sub_00773BFC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773BFCu);

L_00773BFC:
    PUSH32(esp, 0); /* 0x00773BFC: push 0 */
    PUSH32(esp, 0x00795530u); /* 0x00773BFE: push 0x795530 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773C03: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773C06: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773C07: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773C0C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773C0F: ret  */

}

void sub_00773C10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773C10u);

    goto L_00773C10;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00773C10:
    eax = 0x007DFD74u; /* 0x00773C10: mov eax, 0x7dfd74 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00773C15: jmp 0x75bf0e */

}

void sub_00773C20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773C20u);

L_00773C20:
    PUSH32(esp, 0); /* 0x00773C20: push 0 */
    PUSH32(esp, 0x00793E44u); /* 0x00773C22: push 0x793e44 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773C27: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773C2A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773C2B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773C30: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773C33: ret  */

}

void sub_00773C34(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773C34u);

L_00773C34:
    PUSH32(esp, 0); /* 0x00773C34: push 0 */
    PUSH32(esp, 0x00793E38u); /* 0x00773C36: push 0x793e38 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773C3B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773C3E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773C3F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773C44: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773C47: ret  */

}

void sub_00773C48(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773C48u);

L_00773C48:
    PUSH32(esp, 0); /* 0x00773C48: push 0 */
    PUSH32(esp, 0x00793E2Cu); /* 0x00773C4A: push 0x793e2c */
    eax = MEM32(ebp + (-0x10)); /* 0x00773C4F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773C52: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773C53: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773C58: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773C5B: ret  */

}

void sub_00773C5C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773C5Cu);

L_00773C5C:
    PUSH32(esp, 0); /* 0x00773C5C: push 0 */
    PUSH32(esp, 0x00793E20u); /* 0x00773C5E: push 0x793e20 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773C63: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773C66: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773C67: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773C6C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773C6F: ret  */

}

void sub_00773C70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773C70u);

    goto L_00773C70;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00773C70:
    eax = 0x007DFDB0u; /* 0x00773C70: mov eax, 0x7dfdb0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00773C75: jmp 0x75bf0e */

}

void sub_00773C80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773C80u);

L_00773C80:
    PUSH32(esp, 0); /* 0x00773C80: push 0 */
    PUSH32(esp, 0x00794028u); /* 0x00773C82: push 0x794028 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773C87: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773C8A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773C8B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773C90: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773C93: ret  */

}

void sub_00773C94(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773C94u);

L_00773C94:
    PUSH32(esp, 0); /* 0x00773C94: push 0 */
    PUSH32(esp, 0x00794018u); /* 0x00773C96: push 0x794018 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773C9B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773C9E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773C9F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773CA4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773CA7: ret  */

}

void sub_00773CA8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773CA8u);

L_00773CA8:
    PUSH32(esp, 0); /* 0x00773CA8: push 0 */
    PUSH32(esp, 0x00794008u); /* 0x00773CAA: push 0x794008 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773CAF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773CB2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773CB3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773CB8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773CBB: ret  */

}

void sub_00773CBC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773CBCu);

L_00773CBC:
    PUSH32(esp, 0); /* 0x00773CBC: push 0 */
    PUSH32(esp, 0x00793FFCu); /* 0x00773CBE: push 0x793ffc */
    eax = MEM32(ebp + (-0x10)); /* 0x00773CC3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773CC6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773CC7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773CCC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773CCF: ret  */

}

void sub_00773CD0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773CD0u);

L_00773CD0:
    PUSH32(esp, 0); /* 0x00773CD0: push 0 */
    PUSH32(esp, 0x00793FECu); /* 0x00773CD2: push 0x793fec */
    eax = MEM32(ebp + (-0x10)); /* 0x00773CD7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773CDA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773CDB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773CE0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773CE3: ret  */

}

void sub_00773CE4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773CE4u);

L_00773CE4:
    PUSH32(esp, 0); /* 0x00773CE4: push 0 */
    PUSH32(esp, 0x00795634u); /* 0x00773CE6: push 0x795634 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773CEB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773CEE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773CEF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773CF4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773CF7: ret  */

}

void sub_00773CF8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773CF8u);

L_00773CF8:
    PUSH32(esp, 0); /* 0x00773CF8: push 0 */
    PUSH32(esp, 0x00793FD4u); /* 0x00773CFA: push 0x793fd4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773CFF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773D02: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773D03: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773D08: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773D0B: ret  */

}

void sub_00773D0C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773D0Cu);

    goto L_00773D0C;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00773D0C:
    eax = 0x007DFE04u; /* 0x00773D0C: mov eax, 0x7dfe04 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00773D11: jmp 0x75bf0e */

}

void sub_00773D20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773D20u);

L_00773D20:
    PUSH32(esp, 0); /* 0x00773D20: push 0 */
    PUSH32(esp, 0x00794074u); /* 0x00773D22: push 0x794074 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773D27: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773D2A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773D2B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773D30: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773D33: ret  */

}

void sub_00773D34(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773D34u);

L_00773D34:
    PUSH32(esp, 0); /* 0x00773D34: push 0 */
    PUSH32(esp, 0x00794060u); /* 0x00773D36: push 0x794060 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773D3B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773D3E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773D3F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773D44: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773D47: ret  */

}

void sub_00773D48(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773D48u);

L_00773D48:
    PUSH32(esp, 0); /* 0x00773D48: push 0 */
    PUSH32(esp, 0x00794048u); /* 0x00773D4A: push 0x794048 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773D4F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773D52: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773D53: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773D58: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773D5B: ret  */

}

void sub_00773D5C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773D5Cu);

L_00773D5C:
    PUSH32(esp, 0); /* 0x00773D5C: push 0 */
    PUSH32(esp, 0x00794034u); /* 0x00773D5E: push 0x794034 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773D63: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773D66: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773D67: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773D6C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773D6F: ret  */

}

void sub_00773D70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773D70u);

    goto L_00773D70;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00773D70:
    eax = 0x007DF77Cu; /* 0x00773D70: mov eax, 0x7df77c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00773D75: jmp 0x75bf0e */

}

void sub_00773D80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773D80u);

L_00773D80:
    PUSH32(esp, 0); /* 0x00773D80: push 0 */
    PUSH32(esp, 0x007940B4u); /* 0x00773D82: push 0x7940b4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773D87: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773D8A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773D8B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773D90: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773D93: ret  */

}

void sub_00773D94(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773D94u);

L_00773D94:
    PUSH32(esp, 0); /* 0x00773D94: push 0 */
    PUSH32(esp, 0x007940E4u); /* 0x00773D96: push 0x7940e4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773D9B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773D9E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773D9F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773DA4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773DA7: ret  */

}

void sub_00773DA8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773DA8u);

L_00773DA8:
    PUSH32(esp, 0); /* 0x00773DA8: push 0 */
    PUSH32(esp, 0x007940D8u); /* 0x00773DAA: push 0x7940d8 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773DAF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773DB2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773DB3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773DB8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773DBB: ret  */

}

void sub_00773DBC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773DBCu);

L_00773DBC:
    PUSH32(esp, 0); /* 0x00773DBC: push 0 */
    PUSH32(esp, 0x007940C8u); /* 0x00773DBE: push 0x7940c8 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773DC3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773DC6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773DC7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773DCC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773DCF: ret  */

}

void sub_00773DD0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773DD0u);

L_00773DD0:
    PUSH32(esp, 0); /* 0x00773DD0: push 0 */
    PUSH32(esp, 0x007940A0u); /* 0x00773DD2: push 0x7940a0 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773DD7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773DDA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773DDB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773DE0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773DE3: ret  */

}

void sub_00773DE4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773DE4u);

L_00773DE4:
    PUSH32(esp, 0); /* 0x00773DE4: push 0 */
    PUSH32(esp, 0x00794090u); /* 0x00773DE6: push 0x794090 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773DEB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773DEE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773DEF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773DF4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773DF7: ret  */

}

void sub_00773DF8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773DF8u);

L_00773DF8:
    PUSH32(esp, 0); /* 0x00773DF8: push 0 */
    PUSH32(esp, 0x00795650u); /* 0x00773DFA: push 0x795650 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773DFF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773E02: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773E03: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773E08: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773E0B: ret  */

}

void sub_00773E0C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773E0Cu);

    goto L_00773E0C;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00773E0C:
    eax = 0x007DFE58u; /* 0x00773E0C: mov eax, 0x7dfe58 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00773E11: jmp 0x75bf0e */

}

void sub_00773E20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773E20u);

L_00773E20:
    PUSH32(esp, 0); /* 0x00773E20: push 0 */
    PUSH32(esp, 0x00795904u); /* 0x00773E22: push 0x795904 */
    eax = MEM32(ebp + (-0x14)); /* 0x00773E27: mov eax, dword ptr [ebp - 0x14] */
    PUSH32(esp, eax); /* 0x00773E2A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773E2B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773E30: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773E33: ret  */

}

void sub_00773E34(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773E34u);

L_00773E34:
    PUSH32(esp, 0); /* 0x00773E34: push 0 */
    PUSH32(esp, 0x007958F8u); /* 0x00773E36: push 0x7958f8 */
    eax = MEM32(ebp + (-0x14)); /* 0x00773E3B: mov eax, dword ptr [ebp - 0x14] */
    PUSH32(esp, eax); /* 0x00773E3E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773E3F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773E44: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773E47: ret  */

}

void sub_00773E48(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773E48u);

L_00773E48:
    PUSH32(esp, 0); /* 0x00773E48: push 0 */
    PUSH32(esp, 0x007958ECu); /* 0x00773E4A: push 0x7958ec */
    eax = MEM32(ebp + (-0x14)); /* 0x00773E4F: mov eax, dword ptr [ebp - 0x14] */
    PUSH32(esp, eax); /* 0x00773E52: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773E53: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773E58: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773E5B: ret  */

}

void sub_00773E5C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773E5Cu);

L_00773E5C:
    PUSH32(esp, 0); /* 0x00773E5C: push 0 */
    PUSH32(esp, 0x007943CCu); /* 0x00773E5E: push 0x7943cc */
    eax = MEM32(ebp + (-0x10)); /* 0x00773E63: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773E66: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773E67: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773E6C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773E6F: ret  */

}

void sub_00773E70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773E70u);

L_00773E70:
    PUSH32(esp, 0); /* 0x00773E70: push 0 */
    PUSH32(esp, 0x007958E0u); /* 0x00773E72: push 0x7958e0 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773E77: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773E7A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773E7B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773E80: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773E83: ret  */

}

void sub_00773E84(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773E84u);

L_00773E84:
    PUSH32(esp, 0); /* 0x00773E84: push 0 */
    PUSH32(esp, 0x007958D4u); /* 0x00773E86: push 0x7958d4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773E8B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773E8E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773E8F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773E94: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773E97: ret  */

}

void sub_00773E98(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773E98u);

L_00773E98:
    PUSH32(esp, 0); /* 0x00773E98: push 0 */
    PUSH32(esp, 0x007958C8u); /* 0x00773E9A: push 0x7958c8 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773E9F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773EA2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773EA3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773EA8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773EAB: ret  */

}

void sub_00773EAC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773EACu);

L_00773EAC:
    PUSH32(esp, 0); /* 0x00773EAC: push 0 */
    PUSH32(esp, 0x007958B8u); /* 0x00773EAE: push 0x7958b8 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773EB3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773EB6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773EB7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773EBC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773EBF: ret  */

}

void sub_00773EC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773EC0u);

L_00773EC0:
    PUSH32(esp, 0); /* 0x00773EC0: push 0 */
    PUSH32(esp, 0x007958A8u); /* 0x00773EC2: push 0x7958a8 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773EC7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773ECA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773ECB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773ED0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773ED3: ret  */

}

void sub_00773ED4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773ED4u);

L_00773ED4:
    PUSH32(esp, 0); /* 0x00773ED4: push 0 */
    PUSH32(esp, 0x0079589Cu); /* 0x00773ED6: push 0x79589c */
    eax = MEM32(ebp + (-0x10)); /* 0x00773EDB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773EDE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773EDF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773EE4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773EE7: ret  */

}

void sub_00773EE8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773EE8u);

    goto L_00773EE8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00773EE8:
    eax = 0x007DFEC4u; /* 0x00773EE8: mov eax, 0x7dfec4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00773EED: jmp 0x75bf0e */

}

void sub_00773F00(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773F00u);

L_00773F00:
    PUSH32(esp, 0); /* 0x00773F00: push 0 */
    PUSH32(esp, 0x00795918u); /* 0x00773F02: push 0x795918 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773F07: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773F0A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773F0B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773F10: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773F13: ret  */

}

void sub_00773F14(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773F14u);

    goto L_00773F14;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00773F14:
    eax = 0x007DFEE8u; /* 0x00773F14: mov eax, 0x7dfee8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00773F19: jmp 0x75bf0e */

}

void sub_00773F20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773F20u);

L_00773F20:
    PUSH32(esp, 0); /* 0x00773F20: push 0 */
    PUSH32(esp, 0x00795954u); /* 0x00773F22: push 0x795954 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773F27: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773F2A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773F2B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773F30: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773F33: ret  */

}

void sub_00773F34(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773F34u);

    goto L_00773F34;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00773F34:
    eax = 0x007DFF0Cu; /* 0x00773F34: mov eax, 0x7dff0c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00773F39: jmp 0x75bf0e */

}

void sub_00773F40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773F40u);

L_00773F40:
    PUSH32(esp, 0); /* 0x00773F40: push 0 */
    PUSH32(esp, 0x00795974u); /* 0x00773F42: push 0x795974 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773F47: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773F4A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773F4B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773F50: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773F53: ret  */

}

void sub_00773F54(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773F54u);

    goto L_00773F54;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00773F54:
    eax = 0x007DFF30u; /* 0x00773F54: mov eax, 0x7dff30 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00773F59: jmp 0x75bf0e */

}

void sub_00773F60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773F60u);

L_00773F60:
    PUSH32(esp, 0); /* 0x00773F60: push 0 */
    PUSH32(esp, 0x00795A14u); /* 0x00773F62: push 0x795a14 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773F67: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773F6A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773F6B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773F70: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773F73: ret  */

}

void sub_00773F74(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773F74u);

L_00773F74:
    PUSH32(esp, 0); /* 0x00773F74: push 0 */
    PUSH32(esp, 0x00795A08u); /* 0x00773F76: push 0x795a08 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773F7B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773F7E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773F7F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773F84: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773F87: ret  */

}

void sub_00773F88(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773F88u);

L_00773F88:
    PUSH32(esp, 0); /* 0x00773F88: push 0 */
    PUSH32(esp, 0x00795A00u); /* 0x00773F8A: push 0x795a00 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773F8F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773F92: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773F93: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773F98: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773F9B: ret  */

}

void sub_00773F9C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773F9Cu);

L_00773F9C:
    PUSH32(esp, 0); /* 0x00773F9C: push 0 */
    PUSH32(esp, 0x007959F4u); /* 0x00773F9E: push 0x7959f4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773FA3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773FA6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773FA7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773FAC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773FAF: ret  */

}

void sub_00773FB0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773FB0u);

    goto L_00773FB0;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00773FB0:
    eax = 0x007DFF74u; /* 0x00773FB0: mov eax, 0x7dff74 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00773FB5: jmp 0x75bf0e */

}

void sub_00773FC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773FC0u);

L_00773FC0:
    PUSH32(esp, 0); /* 0x00773FC0: push 0 */
    PUSH32(esp, 0x00795A08u); /* 0x00773FC2: push 0x795a08 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773FC7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773FCA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773FCB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773FD0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773FD3: ret  */

}

void sub_00773FD4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773FD4u);

L_00773FD4:
    PUSH32(esp, 0); /* 0x00773FD4: push 0 */
    PUSH32(esp, 0x007959F4u); /* 0x00773FD6: push 0x7959f4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00773FDB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00773FDE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00773FDF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00773FE4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00773FE7: ret  */

}

void sub_00773FE8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00773FE8u);

    goto L_00773FE8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00773FE8:
    eax = 0x007DFFA0u; /* 0x00773FE8: mov eax, 0x7dffa0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00773FED: jmp 0x75bf0e */

}

void sub_00774000(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774000u);

L_00774000:
    PUSH32(esp, 0); /* 0x00774000: push 0 */
    PUSH32(esp, 0x00795A34u); /* 0x00774002: push 0x795a34 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774007: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077400A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077400B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774010: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774013: ret  */

}

void sub_00774014(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774014u);

    goto L_00774014;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774014:
    eax = 0x007DFFC4u; /* 0x00774014: mov eax, 0x7dffc4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774019: jmp 0x75bf0e */

}

void sub_00774020(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774020u);

L_00774020:
    PUSH32(esp, 0); /* 0x00774020: push 0 */
    PUSH32(esp, 0x00795A68u); /* 0x00774022: push 0x795a68 */
    eax = MEM32(ebp + (-0x54)); /* 0x00774027: mov eax, dword ptr [ebp - 0x54] */
    PUSH32(esp, eax); /* 0x0077402A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077402B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774030: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774033: ret  */

}

void sub_00774034(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774034u);

    goto L_00774034;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774034:
    eax = 0x007DFFE8u; /* 0x00774034: mov eax, 0x7dffe8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774039: jmp 0x75bf0e */

}

void sub_00774040(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774040u);

L_00774040:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774040: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004C9C30u); RECOMP_RETURN(); /* 0x00774043: jmp 0x4c9c30 */

}

void sub_00774048(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774048u);

    goto L_00774048;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774048:
    eax = 0x007E000Cu; /* 0x00774048: mov eax, 0x7e000c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077404D: jmp 0x75bf0e */

}

void sub_00774060(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774060u);

L_00774060:
    eax = MEM32(ebp + (-0x10)); /* 0x00774060: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774063: push eax */
    RECOMP_CALL(sub_004022D0); /* 0x00774064: call 0x4022d0 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x00774069: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077406A: ret  */

}

void sub_0077406B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077406Bu);

    goto L_0077406B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077406B:
    eax = 0x007E0030u; /* 0x0077406B: mov eax, 0x7e0030 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774070: jmp 0x75bf0e */

}

void sub_00774080(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774080u);

L_00774080:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774080: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(8);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 8; /* 0x00774083: add ecx, 8 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00490340u); RECOMP_RETURN(); /* 0x00774086: jmp 0x490340 */

}

void sub_0077408B(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077408Bu);

    goto L_0077408B;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077408B:
    eax = 0x007E0054u; /* 0x0077408B: mov eax, 0x7e0054 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774090: jmp 0x75bf0e */

}

void sub_007740A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007740A0u);

L_007740A0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007740A0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x007740A3: jmp 0x553a80 */

}

void sub_007740A8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007740A8u);

L_007740A8:
    ecx = MEM32(ebp + (-0x10)); /* 0x007740A8: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4Cu; /* 0x007740AB: add ecx, 0x4c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00479130u); RECOMP_RETURN(); /* 0x007740AE: jmp 0x479130 */

}

void sub_007740B3(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007740B3u);

L_007740B3:
    ecx = MEM32(ebp + (-0x10)); /* 0x007740B3: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0xC8u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0xC8u; /* 0x007740B6: add ecx, 0xc8 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004FF410u); RECOMP_RETURN(); /* 0x007740BC: jmp 0x4ff410 */

}

void sub_007740C1(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007740C1u);

L_007740C1:
    ecx = MEM32(ebp + (-0x10)); /* 0x007740C1: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x10Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x10Cu; /* 0x007740C4: add ecx, 0x10c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004FF410u); RECOMP_RETURN(); /* 0x007740CA: jmp 0x4ff410 */

}

void sub_007740CF(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007740CFu);

L_007740CF:
    ecx = MEM32(ebp + (-0x10)); /* 0x007740CF: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x150u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x150u; /* 0x007740D2: add ecx, 0x150 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004FF410u); RECOMP_RETURN(); /* 0x007740D8: jmp 0x4ff410 */

}

void sub_007740DD(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007740DDu);

    goto L_007740DD;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007740DD:
    eax = 0x007E20FCu; /* 0x007740DD: mov eax, 0x7e20fc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007740E2: jmp 0x75bf0e */

}

void sub_007740F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007740F0u);

L_007740F0:
    ecx = MEM32(ebp + (-0x110)); /* 0x007740F0: mov ecx, dword ptr [ebp - 0x110] */
    RECOMP_ITAIL(0x004E89F0u); RECOMP_RETURN(); /* 0x007740F6: jmp 0x4e89f0 */

}

void sub_007740FB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007740FBu);

    goto L_007740FB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007740FB:
    eax = 0x007E0078u; /* 0x007740FB: mov eax, 0x7e0078 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774100: jmp 0x75bf0e */

}

void sub_00774110(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774110u);

L_00774110:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774110: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00774113: jmp 0x553a80 */

}

void sub_00774118(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774118u);

L_00774118:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774118: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x50u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x50u; /* 0x0077411B: add ecx, 0x50 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004CBAA0u); RECOMP_RETURN(); /* 0x0077411E: jmp 0x4cbaa0 */

}

void sub_00774123(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774123u);

L_00774123:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774123: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0xFCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0xFCu; /* 0x00774126: add ecx, 0xfc */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004CBAA0u); RECOMP_RETURN(); /* 0x0077412C: jmp 0x4cbaa0 */

}

void sub_00774131(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774131u);

    goto L_00774131;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774131:
    eax = 0x007E00ACu; /* 0x00774131: mov eax, 0x7e00ac */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774136: jmp 0x75bf0e */

}

void sub_00774140(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774140u);

L_00774140:
    PUSH32(esp, 0); /* 0x00774140: push 0 */
    PUSH32(esp, 0x00795D58u); /* 0x00774142: push 0x795d58 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774147: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077414A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077414B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774150: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774153: ret  */

}

void sub_00774154(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774154u);

    goto L_00774154;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774154:
    eax = 0x007E00D0u; /* 0x00774154: mov eax, 0x7e00d0 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774159: jmp 0x75bf0e */

}

void sub_00774160(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774160u);

L_00774160:
    PUSH32(esp, 0); /* 0x00774160: push 0 */
    PUSH32(esp, 0x00795D70u); /* 0x00774162: push 0x795d70 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774167: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077416A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077416B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774170: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774173: ret  */

}

void sub_00774174(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774174u);

    goto L_00774174;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774174:
    eax = 0x007E00F4u; /* 0x00774174: mov eax, 0x7e00f4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774179: jmp 0x75bf0e */

}

void sub_00774180(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774180u);

L_00774180:
    PUSH32(esp, 0); /* 0x00774180: push 0 */
    PUSH32(esp, 0x007916E0u); /* 0x00774182: push 0x7916e0 */
    eax = MEM32(ebp + (-0x14)); /* 0x00774187: mov eax, dword ptr [ebp - 0x14] */
    PUSH32(esp, eax); /* 0x0077418A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077418B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774190: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774193: ret  */

}

void sub_00774194(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774194u);

L_00774194:
    PUSH32(esp, 0); /* 0x00774194: push 0 */
    PUSH32(esp, 0x00795D84u); /* 0x00774196: push 0x795d84 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077419B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077419E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077419F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007741A4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007741A7: ret  */

}

void sub_007741A8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007741A8u);

L_007741A8:
    PUSH32(esp, 0); /* 0x007741A8: push 0 */
    PUSH32(esp, 0x00791784u); /* 0x007741AA: push 0x791784 */
    eax = MEM32(ebp + (-0x10)); /* 0x007741AF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007741B2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007741B3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007741B8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007741BB: ret  */

}

void sub_007741BC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007741BCu);

L_007741BC:
    PUSH32(esp, 0); /* 0x007741BC: push 0 */
    PUSH32(esp, 0x00791784u); /* 0x007741BE: push 0x791784 */
    eax = MEM32(ebp + (-0x10)); /* 0x007741C3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007741C6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007741C7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007741CC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007741CF: ret  */

}

void sub_007741D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007741D0u);

L_007741D0:
    PUSH32(esp, 0); /* 0x007741D0: push 0 */
    PUSH32(esp, 0x00791790u); /* 0x007741D2: push 0x791790 */
    eax = MEM32(ebp + (-0x10)); /* 0x007741D7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007741DA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007741DB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007741E0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007741E3: ret  */

}

void sub_007741E4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007741E4u);

L_007741E4:
    PUSH32(esp, 0); /* 0x007741E4: push 0 */
    PUSH32(esp, 0x00791770u); /* 0x007741E6: push 0x791770 */
    eax = MEM32(ebp + (-0x10)); /* 0x007741EB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007741EE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007741EF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007741F4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007741F7: ret  */

}

void sub_007741F8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007741F8u);

L_007741F8:
    PUSH32(esp, 0); /* 0x007741F8: push 0 */
    PUSH32(esp, 0x00791764u); /* 0x007741FA: push 0x791764 */
    eax = MEM32(ebp + (-0x10)); /* 0x007741FF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774202: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774203: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774208: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077420B: ret  */

}

void sub_0077420C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077420Cu);

L_0077420C:
    PUSH32(esp, 0); /* 0x0077420C: push 0 */
    PUSH32(esp, 0x00791758u); /* 0x0077420E: push 0x791758 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774213: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774216: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774217: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077421C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077421F: ret  */

}

void sub_00774220(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774220u);

    goto L_00774220;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774220:
    eax = 0x007E0150u; /* 0x00774220: mov eax, 0x7e0150 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774225: jmp 0x75bf0e */

}

void sub_00774230(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774230u);

L_00774230:
    PUSH32(esp, 0); /* 0x00774230: push 0 */
    PUSH32(esp, 0x007916E0u); /* 0x00774232: push 0x7916e0 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774237: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077423A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077423B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774240: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774243: ret  */

}

void sub_00774244(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774244u);

L_00774244:
    PUSH32(esp, 0); /* 0x00774244: push 0 */
    PUSH32(esp, 0x00791790u); /* 0x00774246: push 0x791790 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077424B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077424E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077424F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774254: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774257: ret  */

}

void sub_00774258(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774258u);

L_00774258:
    PUSH32(esp, 0); /* 0x00774258: push 0 */
    PUSH32(esp, 0x00791770u); /* 0x0077425A: push 0x791770 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077425F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774262: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774263: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774268: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077426B: ret  */

}

void sub_0077426C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077426Cu);

L_0077426C:
    PUSH32(esp, 0); /* 0x0077426C: push 0 */
    PUSH32(esp, 0x00791764u); /* 0x0077426E: push 0x791764 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774273: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774276: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774277: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077427C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077427F: ret  */

}

void sub_00774280(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774280u);

L_00774280:
    PUSH32(esp, 0); /* 0x00774280: push 0 */
    PUSH32(esp, 0x00791758u); /* 0x00774282: push 0x791758 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774287: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077428A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077428B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774290: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774293: ret  */

}

void sub_00774294(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774294u);

    goto L_00774294;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774294:
    eax = 0x007E0194u; /* 0x00774294: mov eax, 0x7e0194 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774299: jmp 0x75bf0e */

}

void sub_007742A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007742A0u);

L_007742A0:
    PUSH32(esp, 0); /* 0x007742A0: push 0 */
    PUSH32(esp, 0x007916E0u); /* 0x007742A2: push 0x7916e0 */
    eax = MEM32(ebp + (-0x10)); /* 0x007742A7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007742AA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007742AB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007742B0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007742B3: ret  */

}

void sub_007742B4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007742B4u);

L_007742B4:
    PUSH32(esp, 0); /* 0x007742B4: push 0 */
    PUSH32(esp, 0x00791784u); /* 0x007742B6: push 0x791784 */
    eax = MEM32(ebp + (-0x10)); /* 0x007742BB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007742BE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007742BF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007742C4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007742C7: ret  */

}

void sub_007742C8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007742C8u);

L_007742C8:
    PUSH32(esp, 0); /* 0x007742C8: push 0 */
    PUSH32(esp, 0x00791770u); /* 0x007742CA: push 0x791770 */
    eax = MEM32(ebp + (-0x10)); /* 0x007742CF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007742D2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007742D3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007742D8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007742DB: ret  */

}

void sub_007742DC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007742DCu);

L_007742DC:
    PUSH32(esp, 0); /* 0x007742DC: push 0 */
    PUSH32(esp, 0x00791764u); /* 0x007742DE: push 0x791764 */
    eax = MEM32(ebp + (-0x10)); /* 0x007742E3: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007742E6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007742E7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007742EC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007742EF: ret  */

}

void sub_007742F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007742F0u);

L_007742F0:
    PUSH32(esp, 0); /* 0x007742F0: push 0 */
    PUSH32(esp, 0x00791790u); /* 0x007742F2: push 0x791790 */
    eax = MEM32(ebp + (-0x10)); /* 0x007742F7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007742FA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007742FB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774300: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774303: ret  */

}

void sub_00774304(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774304u);

    goto L_00774304;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774304:
    eax = 0x007E01D8u; /* 0x00774304: mov eax, 0x7e01d8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774309: jmp 0x75bf0e */

}

void sub_00774310(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774310u);

L_00774310:
    PUSH32(esp, 0); /* 0x00774310: push 0 */
    PUSH32(esp, 0x007916E0u); /* 0x00774312: push 0x7916e0 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774317: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077431A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077431B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774320: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774323: ret  */

}

void sub_00774324(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774324u);

L_00774324:
    PUSH32(esp, 0); /* 0x00774324: push 0 */
    PUSH32(esp, 0x00791784u); /* 0x00774326: push 0x791784 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077432B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077432E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077432F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774334: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774337: ret  */

}

void sub_00774338(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774338u);

L_00774338:
    PUSH32(esp, 0); /* 0x00774338: push 0 */
    PUSH32(esp, 0x00791770u); /* 0x0077433A: push 0x791770 */
    eax = MEM32(ebp + (-0x10)); /* 0x0077433F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774342: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774343: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774348: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077434B: ret  */

}

void sub_0077434C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077434Cu);

L_0077434C:
    PUSH32(esp, 0); /* 0x0077434C: push 0 */
    PUSH32(esp, 0x00791764u); /* 0x0077434E: push 0x791764 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774353: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774356: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774357: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077435C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077435F: ret  */

}

void sub_00774360(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774360u);

L_00774360:
    PUSH32(esp, 0); /* 0x00774360: push 0 */
    PUSH32(esp, 0x00791758u); /* 0x00774362: push 0x791758 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774367: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077436A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077436B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774370: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774373: ret  */

}

void sub_00774374(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774374u);

    goto L_00774374;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774374:
    eax = 0x007DF580u; /* 0x00774374: mov eax, 0x7df580 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774379: jmp 0x75bf0e */

}

void sub_00774380(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774380u);

L_00774380:
    PUSH32(esp, 0); /* 0x00774380: push 0 */
    PUSH32(esp, 0x00795D98u); /* 0x00774382: push 0x795d98 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774387: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077438A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077438B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774390: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774393: ret  */

}

void sub_00774394(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774394u);

L_00774394:
    PUSH32(esp, 0); /* 0x00774394: push 0 */
    PUSH32(esp, 0x00795D8Cu); /* 0x00774396: push 0x795d8c */
    eax = MEM32(ebp + (-0x10)); /* 0x0077439B: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077439E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077439F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007743A4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007743A7: ret  */

}

void sub_007743A8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007743A8u);

    goto L_007743A8;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007743A8:
    eax = 0x007E0204u; /* 0x007743A8: mov eax, 0x7e0204 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007743AD: jmp 0x75bf0e */

}

void sub_007743C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007743C0u);

L_007743C0:
    PUSH32(esp, 0); /* 0x007743C0: push 0 */
    PUSH32(esp, 0x007916E0u); /* 0x007743C2: push 0x7916e0 */
    eax = MEM32(ebp + (-0x10)); /* 0x007743C7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007743CA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007743CB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007743D0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007743D3: ret  */

}

void sub_007743D4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007743D4u);

L_007743D4:
    PUSH32(esp, 0); /* 0x007743D4: push 0 */
    PUSH32(esp, 0x00791770u); /* 0x007743D6: push 0x791770 */
    eax = MEM32(ebp + (-0x10)); /* 0x007743DB: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007743DE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007743DF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007743E4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007743E7: ret  */

}

void sub_007743E8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007743E8u);

L_007743E8:
    PUSH32(esp, 0); /* 0x007743E8: push 0 */
    PUSH32(esp, 0x00791764u); /* 0x007743EA: push 0x791764 */
    eax = MEM32(ebp + (-0x10)); /* 0x007743EF: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007743F2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007743F3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007743F8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007743FB: ret  */

}

void sub_007743FC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007743FCu);

L_007743FC:
    PUSH32(esp, 0); /* 0x007743FC: push 0 */
    PUSH32(esp, 0x00791758u); /* 0x007743FE: push 0x791758 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774403: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774406: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774407: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077440C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077440F: ret  */

}

void sub_00774410(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774410u);

    goto L_00774410;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774410:
    eax = 0x007E0240u; /* 0x00774410: mov eax, 0x7e0240 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774415: jmp 0x75bf0e */

}

void sub_00774420(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774420u);

L_00774420:
    PUSH32(esp, 0); /* 0x00774420: push 0 */
    PUSH32(esp, 0x00795DC4u); /* 0x00774422: push 0x795dc4 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774427: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077442A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077442B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774430: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774433: ret  */

}

void sub_00774434(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774434u);

    goto L_00774434;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774434:
    eax = 0x007E0264u; /* 0x00774434: mov eax, 0x7e0264 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774439: jmp 0x75bf0e */

}

void sub_00774440(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774440u);

L_00774440:
    PUSH32(esp, 0); /* 0x00774440: push 0 */
    PUSH32(esp, 0x00795DD8u); /* 0x00774442: push 0x795dd8 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774447: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077444A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077444B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774450: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774453: ret  */

}

void sub_00774454(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774454u);

    goto L_00774454;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774454:
    eax = 0x007E0288u; /* 0x00774454: mov eax, 0x7e0288 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774459: jmp 0x75bf0e */

}

void sub_00774460(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774460u);

L_00774460:
    PUSH32(esp, 0); /* 0x00774460: push 0 */
    PUSH32(esp, 0x00795DECu); /* 0x00774462: push 0x795dec */
    eax = MEM32(ebp + (-0x10)); /* 0x00774467: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077446A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077446B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774470: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774473: ret  */

}

void sub_00774474(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774474u);

    goto L_00774474;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774474:
    eax = 0x007E02ACu; /* 0x00774474: mov eax, 0x7e02ac */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774479: jmp 0x75bf0e */

}

void sub_00774480(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774480u);

L_00774480:
    PUSH32(esp, 0); /* 0x00774480: push 0 */
    PUSH32(esp, 0x00795E3Cu); /* 0x00774482: push 0x795e3c */
    eax = MEM32(ebp + (-0x10)); /* 0x00774487: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077448A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077448B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774490: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774493: ret  */

}

void sub_00774494(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774494u);

    goto L_00774494;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774494:
    eax = 0x007E02F4u; /* 0x00774494: mov eax, 0x7e02f4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774499: jmp 0x75bf0e */

}

void sub_007744A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007744A0u);

L_007744A0:
    ecx = ebp + (-0x158); /* 0x007744A0: lea ecx, [ebp - 0x158] */
    RECOMP_ITAIL(0x004CBA10u); RECOMP_RETURN(); /* 0x007744A6: jmp 0x4cba10 */

}

void sub_007744AB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007744ABu);

    goto L_007744AB;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007744AB:
    eax = 0x007E0318u; /* 0x007744AB: mov eax, 0x7e0318 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007744B0: jmp 0x75bf0e */

}

void sub_007744C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007744C0u);

L_007744C0:
    PUSH32(esp, 0); /* 0x007744C0: push 0 */
    PUSH32(esp, 0x00795E60u); /* 0x007744C2: push 0x795e60 */
    eax = MEM32(ebp + (-0x10)); /* 0x007744C7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007744CA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007744CB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007744D0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007744D3: ret  */

}

void sub_007744D4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007744D4u);

    goto L_007744D4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007744D4:
    eax = 0x007E033Cu; /* 0x007744D4: mov eax, 0x7e033c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007744D9: jmp 0x75bf0e */

}

void sub_007744E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007744E0u);

L_007744E0:
    PUSH32(esp, 0); /* 0x007744E0: push 0 */
    PUSH32(esp, 0x00795E74u); /* 0x007744E2: push 0x795e74 */
    eax = MEM32(ebp + (-0x10)); /* 0x007744E7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007744EA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007744EB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007744F0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007744F3: ret  */

}

void sub_007744F4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007744F4u);

    goto L_007744F4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007744F4:
    eax = 0x007E0360u; /* 0x007744F4: mov eax, 0x7e0360 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007744F9: jmp 0x75bf0e */

}

void sub_00774500(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774500u);

L_00774500:
    ecx = MEM32(ebp + (-0x14)); /* 0x00774500: mov ecx, dword ptr [ebp - 0x14] */
    RECOMP_ITAIL(0x004CBB50u); RECOMP_RETURN(); /* 0x00774503: jmp 0x4cbb50 */

}

void sub_00774508(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774508u);

L_00774508:
    PUSH32(esp, 0); /* 0x00774508: push 0 */
    PUSH32(esp, 0x00795E8Cu); /* 0x0077450A: push 0x795e8c */
    eax = MEM32(ebp + (-0x10)); /* 0x0077450F: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x00774512: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774513: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774518: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077451B: ret  */

}

void sub_0077451C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077451Cu);

    goto L_0077451C;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077451C:
    eax = 0x007E038Cu; /* 0x0077451C: mov eax, 0x7e038c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774521: jmp 0x75bf0e */

}

void sub_00774530(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774530u);

L_00774530:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774530: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004CBB50u); RECOMP_RETURN(); /* 0x00774533: jmp 0x4cbb50 */

}

void sub_00774538(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774538u);

L_00774538:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774538: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x154u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x154u; /* 0x0077453B: add ecx, 0x154 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0049D820u); RECOMP_RETURN(); /* 0x00774541: jmp 0x49d820 */

}

void sub_00774546(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774546u);

    goto L_00774546;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774546:
    eax = 0x007E03B8u; /* 0x00774546: mov eax, 0x7e03b8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077454B: jmp 0x75bf0e */

}

void sub_00774550(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774550u);

L_00774550:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774550: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004CBB50u); RECOMP_RETURN(); /* 0x00774553: jmp 0x4cbb50 */

}

void sub_00774558(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774558u);

L_00774558:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774558: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x150u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x150u; /* 0x0077455B: add ecx, 0x150 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0049D820u); RECOMP_RETURN(); /* 0x00774561: jmp 0x49d820 */

}

void sub_00774566(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774566u);

    goto L_00774566;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774566:
    eax = 0x007E03E4u; /* 0x00774566: mov eax, 0x7e03e4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077456B: jmp 0x75bf0e */

}

void sub_00774570(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774570u);

L_00774570:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774570: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004CBB50u); RECOMP_RETURN(); /* 0x00774573: jmp 0x4cbb50 */

}

void sub_00774578(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774578u);

L_00774578:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774578: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x188u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x188u; /* 0x0077457B: add ecx, 0x188 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0049D820u); RECOMP_RETURN(); /* 0x00774581: jmp 0x49d820 */

}

void sub_00774586(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774586u);

L_00774586:
    PUSH32(esp, 0); /* 0x00774586: push 0 */
    PUSH32(esp, 0x00795F80u); /* 0x00774588: push 0x795f80 */
    eax = MEM32(ebp + 0x4); /* 0x0077458D: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00774590: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774591: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774596: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774599: ret  */

}

void sub_0077459A(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077459Au);

L_0077459A:
    PUSH32(esp, 0); /* 0x0077459A: push 0 */
    PUSH32(esp, 0x00795F6Cu); /* 0x0077459C: push 0x795f6c */
    eax = MEM32(ebp + 0x4); /* 0x007745A1: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x007745A4: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007745A5: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007745AA: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007745AD: ret  */

}

void sub_007745AE(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007745AEu);

L_007745AE:
    PUSH32(esp, 0); /* 0x007745AE: push 0 */
    PUSH32(esp, 0x00795F54u); /* 0x007745B0: push 0x795f54 */
    eax = MEM32(ebp + 0x4); /* 0x007745B5: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x007745B8: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007745B9: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007745BE: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007745C1: ret  */

}

void sub_007745C2(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007745C2u);

L_007745C2:
    PUSH32(esp, 0); /* 0x007745C2: push 0 */
    PUSH32(esp, 0x00795F40u); /* 0x007745C4: push 0x795f40 */
    eax = MEM32(ebp + 0x4); /* 0x007745C9: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x007745CC: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007745CD: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007745D2: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007745D5: ret  */

}

void sub_007745D6(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007745D6u);

L_007745D6:
    PUSH32(esp, 0); /* 0x007745D6: push 0 */
    PUSH32(esp, 0x00795F2Cu); /* 0x007745D8: push 0x795f2c */
    eax = MEM32(ebp + 0x4); /* 0x007745DD: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x007745E0: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007745E1: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007745E6: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007745E9: ret  */

}

void sub_007745EA(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007745EAu);

L_007745EA:
    PUSH32(esp, 0); /* 0x007745EA: push 0 */
    PUSH32(esp, 0x00795F1Cu); /* 0x007745EC: push 0x795f1c */
    eax = MEM32(ebp + 0x4); /* 0x007745F1: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x007745F4: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007745F5: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007745FA: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007745FD: ret  */

}

void sub_007745FE(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007745FEu);

L_007745FE:
    PUSH32(esp, 0); /* 0x007745FE: push 0 */
    PUSH32(esp, 0x00793F9Cu); /* 0x00774600: push 0x793f9c */
    eax = MEM32(ebp + 0x4); /* 0x00774605: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00774608: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774609: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077460E: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774611: ret  */

}

void sub_00774612(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774612u);

L_00774612:
    PUSH32(esp, 0); /* 0x00774612: push 0 */
    PUSH32(esp, 0x00793F9Cu); /* 0x00774614: push 0x793f9c */
    eax = MEM32(ebp + 0x4); /* 0x00774619: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x0077461C: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077461D: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774622: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774625: ret  */

}

void sub_00774626(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774626u);

L_00774626:
    PUSH32(esp, 0); /* 0x00774626: push 0 */
    PUSH32(esp, 0x00795F0Cu); /* 0x00774628: push 0x795f0c */
    eax = MEM32(ebp + 0x4); /* 0x0077462D: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00774630: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774631: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774636: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774639: ret  */

}

void sub_0077463A(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077463Au);

L_0077463A:
    PUSH32(esp, 0); /* 0x0077463A: push 0 */
    PUSH32(esp, 0x00793F9Cu); /* 0x0077463C: push 0x793f9c */
    eax = MEM32(ebp + 0x4); /* 0x00774641: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00774644: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774645: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077464A: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077464D: ret  */

}

void sub_0077464E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077464Eu);

L_0077464E:
    PUSH32(esp, 0); /* 0x0077464E: push 0 */
    PUSH32(esp, 0x00793F9Cu); /* 0x00774650: push 0x793f9c */
    eax = MEM32(ebp + 0x4); /* 0x00774655: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00774658: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774659: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077465E: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774661: ret  */

}

void sub_00774662(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774662u);

L_00774662:
    PUSH32(esp, 0); /* 0x00774662: push 0 */
    PUSH32(esp, 0x00795EFCu); /* 0x00774664: push 0x795efc */
    eax = MEM32(ebp + 0x4); /* 0x00774669: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x0077466C: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077466D: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774672: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774675: ret  */

}

void sub_00774676(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774676u);

    goto L_00774676;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774676:
    eax = 0x007E0470u; /* 0x00774676: mov eax, 0x7e0470 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077467B: jmp 0x75bf0e */

}

void sub_00774680(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774680u);

L_00774680:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774680: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004CBB50u); RECOMP_RETURN(); /* 0x00774683: jmp 0x4cbb50 */

}

void sub_00774688(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774688u);

L_00774688:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774688: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x188u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x188u; /* 0x0077468B: add ecx, 0x188 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0049D820u); RECOMP_RETURN(); /* 0x00774691: jmp 0x49d820 */

}

void sub_00774696(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774696u);

    goto L_00774696;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774696:
    eax = 0x007E049Cu; /* 0x00774696: mov eax, 0x7e049c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077469B: jmp 0x75bf0e */

}

void sub_007746A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007746A0u);

L_007746A0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007746A0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004CBB50u); RECOMP_RETURN(); /* 0x007746A3: jmp 0x4cbb50 */

}

void sub_007746A8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007746A8u);

L_007746A8:
    ecx = MEM32(ebp + (-0x10)); /* 0x007746A8: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x184u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x184u; /* 0x007746AB: add ecx, 0x184 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0049D820u); RECOMP_RETURN(); /* 0x007746B1: jmp 0x49d820 */

}

void sub_007746B6(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007746B6u);

    goto L_007746B6;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007746B6:
    eax = 0x007E04C8u; /* 0x007746B6: mov eax, 0x7e04c8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007746BB: jmp 0x75bf0e */

}

void sub_007746C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007746C0u);

L_007746C0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007746C0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x007746C3: jmp 0x553a80 */

}

void sub_007746C8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007746C8u);

L_007746C8:
    ecx = MEM32(ebp + (-0x10)); /* 0x007746C8: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4Cu; /* 0x007746CB: add ecx, 0x4c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004CBAA0u); RECOMP_RETURN(); /* 0x007746CE: jmp 0x4cbaa0 */

}

void sub_007746D3(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007746D3u);

L_007746D3:
    ecx = MEM32(ebp + (-0x10)); /* 0x007746D3: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x120u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x120u; /* 0x007746D6: add ecx, 0x120 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x0049D820u); RECOMP_RETURN(); /* 0x007746DC: jmp 0x49d820 */

}

void sub_007746E1(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007746E1u);

    goto L_007746E1;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007746E1:
    eax = 0x007E04FCu; /* 0x007746E1: mov eax, 0x7e04fc */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007746E6: jmp 0x75bf0e */

}

void sub_007746F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007746F0u);

L_007746F0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007746F0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004CBB50u); RECOMP_RETURN(); /* 0x007746F3: jmp 0x4cbb50 */

}

void sub_007746F8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007746F8u);

L_007746F8:
    PUSH32(esp, 0); /* 0x007746F8: push 0 */
    PUSH32(esp, 0x00795FF4u); /* 0x007746FA: push 0x795ff4 */
    eax = MEM32(ebp + 0x4); /* 0x007746FF: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00774702: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774703: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774708: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077470B: ret  */

}

void sub_0077470C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077470Cu);

    goto L_0077470C;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077470C:
    eax = 0x007E0528u; /* 0x0077470C: mov eax, 0x7e0528 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774711: jmp 0x75bf0e */

}

void sub_00774720(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774720u);

L_00774720:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774720: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004E89F0u); RECOMP_RETURN(); /* 0x00774723: jmp 0x4e89f0 */

}

void sub_00774728(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774728u);

    goto L_00774728;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774728:
    eax = 0x007E054Cu; /* 0x00774728: mov eax, 0x7e054c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x0077472D: jmp 0x75bf0e */

}

void sub_00774740(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774740u);

L_00774740:
    ecx = MEM32(ebp + (-0x14)); /* 0x00774740: mov ecx, dword ptr [ebp - 0x14] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00774743: jmp 0x553a80 */

}

void sub_00774748(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774748u);

L_00774748:
    ecx = MEM32(ebp + (-0x14)); /* 0x00774748: mov ecx, dword ptr [ebp - 0x14] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4Cu; /* 0x0077474B: add ecx, 0x4c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004CBAA0u); RECOMP_RETURN(); /* 0x0077474E: jmp 0x4cbaa0 */

}

void sub_00774753(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774753u);

L_00774753:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774753: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(8);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 8; /* 0x00774756: add ecx, 8 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x00490340u); RECOMP_RETURN(); /* 0x00774759: jmp 0x490340 */

}

void sub_0077475E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077475Eu);

    goto L_0077475E;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077475E:
    eax = 0x007E0580u; /* 0x0077475E: mov eax, 0x7e0580 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774763: jmp 0x75bf0e */

}

void sub_00774770(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774770u);

L_00774770:
    PUSH32(esp, 0); /* 0x00774770: push 0 */
    PUSH32(esp, 0x0079604Cu); /* 0x00774772: push 0x79604c */
    eax = MEM32(ebp + (-0x34)); /* 0x00774777: mov eax, dword ptr [ebp - 0x34] */
    PUSH32(esp, eax); /* 0x0077477A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077477B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774780: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774783: ret  */

}

void sub_00774784(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774784u);

L_00774784:
    PUSH32(esp, 0); /* 0x00774784: push 0 */
    PUSH32(esp, 0x0079604Cu); /* 0x00774786: push 0x79604c */
    eax = MEM32(ebp + (-0x34)); /* 0x0077478B: mov eax, dword ptr [ebp - 0x34] */
    PUSH32(esp, eax); /* 0x0077478E: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077478F: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774794: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774797: ret  */

}

void sub_00774798(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774798u);

L_00774798:
    PUSH32(esp, 0); /* 0x00774798: push 0 */
    PUSH32(esp, 0x0079604Cu); /* 0x0077479A: push 0x79604c */
    eax = MEM32(ebp + (-0x34)); /* 0x0077479F: mov eax, dword ptr [ebp - 0x34] */
    PUSH32(esp, eax); /* 0x007747A2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007747A3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007747A8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007747AB: ret  */

}

void sub_007747AC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007747ACu);

L_007747AC:
    PUSH32(esp, 0); /* 0x007747AC: push 0 */
    PUSH32(esp, 0x0079604Cu); /* 0x007747AE: push 0x79604c */
    eax = MEM32(ebp + 0x4); /* 0x007747B3: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x007747B6: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007747B7: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007747BC: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007747BF: ret  */

}

void sub_007747C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007747C0u);

L_007747C0:
    PUSH32(esp, 0); /* 0x007747C0: push 0 */
    PUSH32(esp, 0x0079604Cu); /* 0x007747C2: push 0x79604c */
    eax = MEM32(ebp + 0x4); /* 0x007747C7: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x007747CA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007747CB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007747D0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007747D3: ret  */

}

void sub_007747D4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007747D4u);

    goto L_007747D4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007747D4:
    eax = 0x007E05C4u; /* 0x007747D4: mov eax, 0x7e05c4 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007747D9: jmp 0x75bf0e */

}

void sub_007747E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007747E0u);

L_007747E0:
    ecx = MEM32(ebp + (-0x10)); /* 0x007747E0: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x007747E3: jmp 0x553a80 */

}

void sub_007747E8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007747E8u);

L_007747E8:
    ecx = MEM32(ebp + (-0x10)); /* 0x007747E8: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x4Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x4Cu; /* 0x007747EB: add ecx, 0x4c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004CBAA0u); RECOMP_RETURN(); /* 0x007747EE: jmp 0x4cbaa0 */

}

void sub_007747F3(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007747F3u);

    goto L_007747F3;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007747F3:
    eax = 0x007E138Cu; /* 0x007747F3: mov eax, 0x7e138c */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007747F8: jmp 0x75bf0e */

}

void sub_00774800(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774800u);

L_00774800:
    PUSH32(esp, 0); /* 0x00774800: push 0 */
    PUSH32(esp, 0x00796110u); /* 0x00774802: push 0x796110 */
    eax = MEM32(ebp + (-0x10)); /* 0x00774807: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077480A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077480B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774810: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774813: ret  */

}

void sub_00774814(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774814u);

    goto L_00774814;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774814:
    eax = 0x007E05E8u; /* 0x00774814: mov eax, 0x7e05e8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774819: jmp 0x75bf0e */

}

void sub_00774820(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774820u);

L_00774820:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774820: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00774823: jmp 0x553a80 */

}

void sub_00774828(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774828u);

L_00774828:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774828: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x5Cu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x5Cu; /* 0x0077482B: add ecx, 0x5c */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004CBA10u); RECOMP_RETURN(); /* 0x0077482E: jmp 0x4cba10 */

}

void sub_00774833(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774833u);

L_00774833:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774833: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x1A4u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x1A4u; /* 0x00774836: add ecx, 0x1a4 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004CBAA0u); RECOMP_RETURN(); /* 0x0077483C: jmp 0x4cbaa0 */

}

void sub_00774841(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774841u);

L_00774841:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774841: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x380u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x380u; /* 0x00774844: add ecx, 0x380 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004FF410u); RECOMP_RETURN(); /* 0x0077484A: jmp 0x4ff410 */

}

void sub_0077484F(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077484Fu);

    goto L_0077484F;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_0077484F:
    eax = 0x007E0624u; /* 0x0077484F: mov eax, 0x7e0624 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774854: jmp 0x75bf0e */

}

void sub_00774860(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774860u);

L_00774860:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774860: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x004CBB50u); RECOMP_RETURN(); /* 0x00774863: jmp 0x4cbb50 */

}

void sub_00774868(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774868u);

L_00774868:
    PUSH32(esp, 0); /* 0x00774868: push 0 */
    PUSH32(esp, 0x007961DCu); /* 0x0077486A: push 0x7961dc */
    eax = MEM32(ebp + 0x4); /* 0x0077486F: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00774872: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774873: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774878: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077487B: ret  */

}

void sub_0077487C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0077487Cu);

L_0077487C:
    PUSH32(esp, 0); /* 0x0077487C: push 0 */
    PUSH32(esp, 0x00791674u); /* 0x0077487E: push 0x791674 */
    eax = MEM32(ebp + 0x4); /* 0x00774883: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x00774886: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x00774887: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x0077488C: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0077488F: ret  */

}

void sub_00774890(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774890u);

L_00774890:
    PUSH32(esp, 0); /* 0x00774890: push 0 */
    PUSH32(esp, 0x007916C0u); /* 0x00774892: push 0x7916c0 */
    eax = MEM32(ebp + 0x4); /* 0x00774897: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x0077489A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077489B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007748A0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007748A3: ret  */

}

void sub_007748A4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007748A4u);

L_007748A4:
    PUSH32(esp, 0); /* 0x007748A4: push 0 */
    PUSH32(esp, 0x00791660u); /* 0x007748A6: push 0x791660 */
    eax = MEM32(ebp + 0x4); /* 0x007748AB: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x007748AE: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007748AF: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007748B4: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007748B7: ret  */

}

void sub_007748B8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007748B8u);

L_007748B8:
    PUSH32(esp, 0); /* 0x007748B8: push 0 */
    PUSH32(esp, 0x00791690u); /* 0x007748BA: push 0x791690 */
    eax = MEM32(ebp + 0x4); /* 0x007748BF: mov eax, dword ptr [ebp + 4] */
    PUSH32(esp, eax); /* 0x007748C2: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007748C3: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007748C8: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007748CB: ret  */

}

void sub_007748CC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007748CCu);

    goto L_007748CC;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007748CC:
    eax = 0x007E0670u; /* 0x007748CC: mov eax, 0x7e0670 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007748D1: jmp 0x75bf0e */

}

void sub_007748E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007748E0u);

L_007748E0:
    PUSH32(esp, 0); /* 0x007748E0: push 0 */
    PUSH32(esp, 0x00796298u); /* 0x007748E2: push 0x796298 */
    eax = MEM32(ebp + (-0x10)); /* 0x007748E7: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x007748EA: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x007748EB: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x007748F0: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007748F3: ret  */

}

void sub_007748F4(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007748F4u);

    goto L_007748F4;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_007748F4:
    eax = 0x007E06C8u; /* 0x007748F4: mov eax, 0x7e06c8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x007748F9: jmp 0x75bf0e */

}

void sub_00774900(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774900u);

L_00774900:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774900: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00774903: jmp 0x553a80 */

}

void sub_00774908(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774908u);

L_00774908:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774908: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x54u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x54u; /* 0x0077490B: add ecx, 0x54 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004CBAA0u); RECOMP_RETURN(); /* 0x0077490E: jmp 0x4cbaa0 */

}

void sub_00774913(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774913u);

    goto L_00774913;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774913:
    eax = 0x007E1BB8u; /* 0x00774913: mov eax, 0x7e1bb8 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774918: jmp 0x75bf0e */

}

void sub_00774920(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774920u);

L_00774920:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774920: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00774923: jmp 0x553a80 */

}

void sub_00774928(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774928u);

L_00774928:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774928: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x64u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x64u; /* 0x0077492B: add ecx, 0x64 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004CBAA0u); RECOMP_RETURN(); /* 0x0077492E: jmp 0x4cbaa0 */

}

void sub_00774933(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774933u);

    goto L_00774933;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774933:
    eax = 0x007E1494u; /* 0x00774933: mov eax, 0x7e1494 */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774938: jmp 0x75bf0e */

}

void sub_00774940(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774940u);

L_00774940:
    PUSH32(esp, 0); /* 0x00774940: push 0 */
    PUSH32(esp, 0x007963ECu); /* 0x00774942: push 0x7963ec */
    eax = MEM32(ebp + (-0x10)); /* 0x00774947: mov eax, dword ptr [ebp - 0x10] */
    PUSH32(esp, eax); /* 0x0077494A: push eax */
    RECOMP_CALL(sub_005755A0); /* 0x0077494B: call 0x5755a0 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0xCu);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0xCu; /* 0x00774950: add esp, 0xc */
    _flag_k = FK_ADD;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00774953: ret  */

}

void sub_00774954(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774954u);

    goto L_00774954;

L_0075BF0E:
    PUSH32(esp, ebp); /* 0x0075BF0E: push ebp */
    ebp = esp; /* 0x0075BF0F: mov ebp, esp */
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(4);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    esp = esp - 4; /* 0x0075BF11: sub esp, 4 */
    _flag_k = FK_CMP;
    PUSH32(esp, ebx); /* 0x0075BF14: push ebx */
    PUSH32(esp, esi); /* 0x0075BF15: push esi */
    PUSH32(esp, edi); /* 0x0075BF16: push edi */
    _df = 1; /* 0x0075BF17: cld  */
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF18: mov dword ptr [ebp - 4], eax */
    _flag_a = (uint32_t)(0); _flag_b = (uint32_t)(0);
    eax = 0; /* 0x0075BF1B: xor eax, eax */
    _cf = 0;
    _flag_k = FK_TEST;
    PUSH32(esp, eax); /* 0x0075BF1D: push eax */
    PUSH32(esp, eax); /* 0x0075BF1E: push eax */
    PUSH32(esp, eax); /* 0x0075BF1F: push eax */
    PUSH32(esp, MEM32(ebp + (-0x4))); /* 0x0075BF20: push dword ptr [ebp - 4] */
    PUSH32(esp, MEM32(ebp + 0x14)); /* 0x0075BF23: push dword ptr [ebp + 0x14] */
    PUSH32(esp, MEM32(ebp + 0x10)); /* 0x0075BF26: push dword ptr [ebp + 0x10] */
    PUSH32(esp, MEM32(ebp + 0xC)); /* 0x0075BF29: push dword ptr [ebp + 0xc] */
    PUSH32(esp, MEM32(ebp + 0x8)); /* 0x0075BF2C: push dword ptr [ebp + 8] */
    RECOMP_CALL(sub_00762C89); /* 0x0075BF2F: call 0x762c89 */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(0x20u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 0x20u; /* 0x0075BF34: add esp, 0x20 */
    _flag_k = FK_ADD;
    MEM32(ebp + (-0x4)) = eax; /* 0x0075BF37: mov dword ptr [ebp - 4], eax */
    edi = POP32_VAL(esp); /* 0x0075BF3A: pop edi */
    esi = POP32_VAL(esp); /* 0x0075BF3B: pop esi */
    ebx = POP32_VAL(esp); /* 0x0075BF3C: pop ebx */
    eax = MEM32(ebp + (-0x4)); /* 0x0075BF3D: mov eax, dword ptr [ebp - 4] */
    esp = ebp; /* 0x0075BF40: mov esp, ebp */
    ebp = POP32_VAL(esp); /* 0x0075BF42: pop ebp */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0075BF43: ret  */

L_00774954:
    eax = 0x007E06ECu; /* 0x00774954: mov eax, 0x7e06ec */
    RECOMP_BACKEDGE();
    goto L_0075BF0E; /* 0x00774959: jmp 0x75bf0e */

}

void sub_00774960(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774960u);

L_00774960:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774960: mov ecx, dword ptr [ebp - 0x10] */
    RECOMP_ITAIL(0x00553A80u); RECOMP_RETURN(); /* 0x00774963: jmp 0x553a80 */

}

void sub_00774968(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774968u);

L_00774968:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774968: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x50u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x50u; /* 0x0077496B: add ecx, 0x50 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004FF410u); RECOMP_RETURN(); /* 0x0077496E: jmp 0x4ff410 */

}

void sub_00774973(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00774973u);

L_00774973:
    ecx = MEM32(ebp + (-0x10)); /* 0x00774973: mov ecx, dword ptr [ebp - 0x10] */
    _flag_a = (uint32_t)(ecx); _flag_b = (uint32_t)(0x98u);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    ecx = ecx + 0x98u; /* 0x00774976: add ecx, 0x98 */
    _flag_k = FK_ADD;
    RECOMP_ITAIL(0x004CBA10u); RECOMP_RETURN(); /* 0x0077497C: jmp 0x4cba10 */

}