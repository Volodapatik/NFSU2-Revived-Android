/* AUTO-GENERATED from SPEED2.analysis.exe by run_lift.py (pcrecomp lift32). DO NOT EDIT, DO NOT COMMIT. */
#define RECOMP_GENERATED_CODE
#include "recomp_types.h"
#include "recomp_funcs.h"
#include "guest_render_probe.h"
#include <math.h>
#include <string.h>

void sub_00781EE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781EE0u);

L_00781EE0:
    ecx = 0x0085AD40u; /* 0x00781EE0: mov ecx, 0x85ad40 */
    RECOMP_ITAIL(0x00512DA0u); RECOMP_RETURN(); /* 0x00781EE5: jmp 0x512da0 */

}

void sub_00781EF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781EF0u);

L_00781EF0:
    PUSH32(esp, 0x00525BE0u); /* 0x00781EF0: push 0x525be0 */
    PUSH32(esp, 0x100u); /* 0x00781EF5: push 0x100 */
    PUSH32(esp, 8); /* 0x00781EFA: push 8 */
    PUSH32(esp, 0x008639A0u); /* 0x00781EFC: push 0x8639a0 */
    RECOMP_CALL(sub_0075C33D); /* 0x00781F01: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781F06: ret  */

}

void sub_00781F10(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781F10u);

L_00781F10:
    ecx = 0x008637B0u; /* 0x00781F10: mov ecx, 0x8637b0 */
    RECOMP_ITAIL(0x0052CBC0u); RECOMP_RETURN(); /* 0x00781F15: jmp 0x52cbc0 */

}

void sub_00781F20(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781F20u);

L_00781F20:
    ecx = 0x0083A9D0u; /* 0x00781F20: mov ecx, 0x83a9d0 */
    RECOMP_ITAIL(0x00531C20u); RECOMP_RETURN(); /* 0x00781F25: jmp 0x531c20 */

}

void sub_00781F30(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781F30u);

L_00781F30:
    ecx = 0x008637A0u; /* 0x00781F30: mov ecx, 0x8637a0 */
    RECOMP_ITAIL(0x00525C10u); RECOMP_RETURN(); /* 0x00781F35: jmp 0x525c10 */

}

void sub_00781F40(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781F40u);

L_00781F40:
    ecx = 0x00863770u; /* 0x00781F40: mov ecx, 0x863770 */
    RECOMP_ITAIL(0x00525C10u); RECOMP_RETURN(); /* 0x00781F45: jmp 0x525c10 */

}

void sub_00781F50(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781F50u);

L_00781F50:
    ecx = 0x00839C30u; /* 0x00781F50: mov ecx, 0x839c30 */
    RECOMP_ITAIL(0x00525C10u); RECOMP_RETURN(); /* 0x00781F55: jmp 0x525c10 */

}

void sub_00781F60(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781F60u);

L_00781F60:
    ecx = 0x00839BD0u; /* 0x00781F60: mov ecx, 0x839bd0 */
    RECOMP_ITAIL(0x00525C10u); RECOMP_RETURN(); /* 0x00781F65: jmp 0x525c10 */

}

void sub_00781F70(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781F70u);

L_00781F70:
    ecx = 0x00863768u; /* 0x00781F70: mov ecx, 0x863768 */
    RECOMP_ITAIL(0x005318A0u); RECOMP_RETURN(); /* 0x00781F75: jmp 0x5318a0 */

}

void sub_00781F80(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781F80u);

L_00781F80:
    ecx = 0x00838980u; /* 0x00781F80: mov ecx, 0x838980 */
    RECOMP_ITAIL(0x00539840u); RECOMP_RETURN(); /* 0x00781F85: jmp 0x539840 */

}

void sub_00781F90(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781F90u);

L_00781F90:
    ecx = 0x008637BCu; /* 0x00781F90: mov ecx, 0x8637bc */
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x00781F95: jmp 0x5ce0f0 */

}

void sub_00781FA0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781FA0u);

L_00781FA0:
    PUSH32(esp, 0x004022D0u); /* 0x00781FA0: push 0x4022d0 */
    PUSH32(esp, 6); /* 0x00781FA5: push 6 */
    PUSH32(esp, 0x20u); /* 0x00781FA7: push 0x20 */
    PUSH32(esp, 0x00864640u); /* 0x00781FA9: push 0x864640 */
    RECOMP_CALL(sub_0075C33D); /* 0x00781FAE: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781FB3: ret  */

}

void sub_00781FC0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781FC0u);

L_00781FC0:
    ecx = 0x00864630u; /* 0x00781FC0: mov ecx, 0x864630 */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00781FC5: jmp 0x5cde60 */

}

void sub_00781FD0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781FD0u);

L_00781FD0:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781FD0: ret  */

}

void sub_00781FE0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781FE0u);

L_00781FE0:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781FE0: ret  */

}

void sub_00781FF0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00781FF0u);

L_00781FF0:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00781FF0: ret  */

}

void sub_00782000(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782000u);

L_00782000:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782000: ret  */

}

void sub_00782010(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782010u);

L_00782010:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782010: ret  */

}

void sub_00782020(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782020u);

L_00782020:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782020: ret  */

}

void sub_00782030(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782030u);

L_00782030:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782030: ret  */

}

void sub_00782040(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782040u);

L_00782040:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782040: ret  */

}

void sub_00782050(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782050u);

L_00782050:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782050: ret  */

}

void sub_00782060(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782060u);

L_00782060:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782060: ret  */

}

void sub_00782070(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782070u);

L_00782070:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782070: ret  */

}

void sub_00782080(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782080u);

L_00782080:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782080: ret  */

}

void sub_00782090(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782090u);

L_00782090:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782090: ret  */

}

void sub_007820A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007820A0u);

L_007820A0:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007820A0: ret  */

}

void sub_007820B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007820B0u);

L_007820B0:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007820B0: ret  */

}

void sub_007820C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007820C0u);

L_007820C0:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007820C0: ret  */

}

void sub_007820D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007820D0u);

L_007820D0:
    PUSH32(esp, 0x004022D0u); /* 0x007820D0: push 0x4022d0 */
    PUSH32(esp, 4); /* 0x007820D5: push 4 */
    PUSH32(esp, 0x30u); /* 0x007820D7: push 0x30 */
    PUSH32(esp, 0x008653B0u); /* 0x007820D9: push 0x8653b0 */
    RECOMP_CALL(sub_0075C33D); /* 0x007820DE: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007820E3: ret  */

}

void sub_007820F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007820F0u);

L_007820F0:
    PUSH32(esp, 0x004022D0u); /* 0x007820F0: push 0x4022d0 */
    PUSH32(esp, 2); /* 0x007820F5: push 2 */
    PUSH32(esp, 0x20u); /* 0x007820F7: push 0x20 */
    PUSH32(esp, 0x00865360u); /* 0x007820F9: push 0x865360 */
    RECOMP_CALL(sub_0075C33D); /* 0x007820FE: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782103: ret  */

}

void sub_00782110(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782110u);

L_00782110:
    MEM32(0x865930) = 0x007A0608u; /* 0x00782110: mov dword ptr [0x865930], 0x7a0608 */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078211A: ret  */

}

void sub_00782120(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782120u);

L_00782120:
    ecx = 0x008652F8u; /* 0x00782120: mov ecx, 0x8652f8 */
    RECOMP_ITAIL(0x005779E0u); RECOMP_RETURN(); /* 0x00782125: jmp 0x5779e0 */

}

void sub_00782130(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782130u);

L_00782130:
    ecx = 0x008651A4u; /* 0x00782130: mov ecx, 0x8651a4 */
    RECOMP_ITAIL(0x0057A1C0u); RECOMP_RETURN(); /* 0x00782135: jmp 0x57a1c0 */

}

void sub_00782140(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782140u);

L_00782140:
    ecx = 0x0086519Cu; /* 0x00782140: mov ecx, 0x86519c */
    RECOMP_ITAIL(0x0057CCF0u); RECOMP_RETURN(); /* 0x00782145: jmp 0x57ccf0 */

}

void sub_00782150(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782150u);

L_00782150:
    ecx = 0x00866584u; /* 0x00782150: mov ecx, 0x866584 */
    RECOMP_ITAIL(0x0057A200u); RECOMP_RETURN(); /* 0x00782155: jmp 0x57a200 */

}

void sub_00782160(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782160u);

L_00782160:
    ecx = 0x0086555Cu; /* 0x00782160: mov ecx, 0x86555c */
    RECOMP_ITAIL(0x0057CCF0u); RECOMP_RETURN(); /* 0x00782165: jmp 0x57ccf0 */

}

void sub_00782170(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782170u);

L_00782170:
    ecx = 0x00865564u; /* 0x00782170: mov ecx, 0x865564 */
    RECOMP_ITAIL(0x0057AEB0u); RECOMP_RETURN(); /* 0x00782175: jmp 0x57aeb0 */

}

void sub_00782180(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782180u);

L_00782180:
    ecx = 0x00865220u; /* 0x00782180: mov ecx, 0x865220 */
    RECOMP_ITAIL(0x0057BB90u); RECOMP_RETURN(); /* 0x00782185: jmp 0x57bb90 */

}

void sub_00782190(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782190u);

L_00782190:
    ecx = 0x00865550u; /* 0x00782190: mov ecx, 0x865550 */
    RECOMP_ITAIL(0x0057BB90u); RECOMP_RETURN(); /* 0x00782195: jmp 0x57bb90 */

}

void sub_007821A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007821A0u);

L_007821A0:
    ecx = 0x008652F0u; /* 0x007821A0: mov ecx, 0x8652f0 */
    RECOMP_ITAIL(0x0057BBD0u); RECOMP_RETURN(); /* 0x007821A5: jmp 0x57bbd0 */

}

void sub_007821B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007821B0u);

L_007821B0:
    ecx = 0x00865190u; /* 0x007821B0: mov ecx, 0x865190 */
    RECOMP_ITAIL(0x0057BBD0u); RECOMP_RETURN(); /* 0x007821B5: jmp 0x57bbd0 */

}

void sub_007821C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007821C0u);

L_007821C0:
    ecx = 0x00865210u; /* 0x007821C0: mov ecx, 0x865210 */
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x007821C5: jmp 0x5ce0f0 */

}

void sub_007821D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007821D0u);

L_007821D0:
    PUSH32(esp, 0x0057C250u); /* 0x007821D0: push 0x57c250 */
    PUSH32(esp, 2); /* 0x007821D5: push 2 */
    PUSH32(esp, 0x1C8u); /* 0x007821D7: push 0x1c8 */
    PUSH32(esp, 0x008655A0u); /* 0x007821DC: push 0x8655a0 */
    RECOMP_CALL(sub_0075C33D); /* 0x007821E1: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007821E6: ret  */

}

void sub_007821F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007821F0u);

L_007821F0:
    ecx = 0x00865218u; /* 0x007821F0: mov ecx, 0x865218 */
    RECOMP_ITAIL(0x0057CCF0u); RECOMP_RETURN(); /* 0x007821F5: jmp 0x57ccf0 */

}

void sub_00782200(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782200u);

L_00782200:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782200: ret  */

}

void sub_00782210(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782210u);

L_00782210:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782210: ret  */

}

void sub_00782220(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782220u);

L_00782220:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782220: ret  */

}

void sub_00782230(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782230u);

L_00782230:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782230: ret  */

}

void sub_00782240(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782240u);

L_00782240:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782240: ret  */

}

void sub_00782250(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782250u);

L_00782250:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782250: ret  */

}

void sub_00782260(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782260u);

L_00782260:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782260: ret  */

}

void sub_00782270(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782270u);

L_00782270:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782270: ret  */

}

void sub_00782280(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782280u);

L_00782280:
    PUSH32(esp, 0x004022D0u); /* 0x00782280: push 0x4022d0 */
    PUSH32(esp, 5); /* 0x00782285: push 5 */
    PUSH32(esp, 0x20u); /* 0x00782287: push 0x20 */
    PUSH32(esp, 0x008693C8u); /* 0x00782289: push 0x8693c8 */
    RECOMP_CALL(sub_0075C33D); /* 0x0078228E: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782293: ret  */

}

void sub_007822A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007822A0u);

L_007822A0:
    ecx = 0x0086A454u; /* 0x007822A0: mov ecx, 0x86a454 */
    RECOMP_ITAIL(0x005846A0u); RECOMP_RETURN(); /* 0x007822A5: jmp 0x5846a0 */

}

void sub_007822B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007822B0u);

L_007822B0:
    ecx = 0x0086A388u; /* 0x007822B0: mov ecx, 0x86a388 */
    RECOMP_ITAIL(0x00588450u); RECOMP_RETURN(); /* 0x007822B5: jmp 0x588450 */

}

void sub_007822C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007822C0u);

L_007822C0:
    ecx = 0x0086A490u; /* 0x007822C0: mov ecx, 0x86a490 */
    RECOMP_ITAIL(0x005884F0u); RECOMP_RETURN(); /* 0x007822C5: jmp 0x5884f0 */

}

void sub_007822D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007822D0u);

L_007822D0:
    ecx = 0x0086A5E8u; /* 0x007822D0: mov ecx, 0x86a5e8 */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x007822D5: jmp 0x5cde60 */

}

void sub_007822E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007822E0u);

L_007822E0:
    ecx = 0x0086A5F4u; /* 0x007822E0: mov ecx, 0x86a5f4 */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x007822E5: jmp 0x5cde60 */

}

void sub_007822F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007822F0u);

L_007822F0:
    ecx = 0x0086A758u; /* 0x007822F0: mov ecx, 0x86a758 */
    RECOMP_ITAIL(0x0058A140u); RECOMP_RETURN(); /* 0x007822F5: jmp 0x58a140 */

}

void sub_00782300(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782300u);

L_00782300:
    ecx = 0x0086A834u; /* 0x00782300: mov ecx, 0x86a834 */
    RECOMP_ITAIL(0x0058F4D0u); RECOMP_RETURN(); /* 0x00782305: jmp 0x58f4d0 */

}

void sub_00782310(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782310u);

L_00782310:
    ecx = 0x0086A858u; /* 0x00782310: mov ecx, 0x86a858 */
    RECOMP_ITAIL(0x0058F530u); RECOMP_RETURN(); /* 0x00782315: jmp 0x58f530 */

}

void sub_00782320(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782320u);

L_00782320:
    ecx = 0x0086B4C8u; /* 0x00782320: mov ecx, 0x86b4c8 */
    RECOMP_ITAIL(0x00490340u); RECOMP_RETURN(); /* 0x00782325: jmp 0x490340 */

}

void sub_00782330(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782330u);

L_00782330:
    ecx = 0x0086B490u; /* 0x00782330: mov ecx, 0x86b490 */
    RECOMP_ITAIL(0x005A8F00u); RECOMP_RETURN(); /* 0x00782335: jmp 0x5a8f00 */

}

void sub_00782340(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782340u);

L_00782340:
    ecx = 0x0086B598u; /* 0x00782340: mov ecx, 0x86b598 */
    RECOMP_ITAIL(0x005E07F0u); RECOMP_RETURN(); /* 0x00782345: jmp 0x5e07f0 */

}

void sub_00782350(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782350u);

L_00782350:
    ecx = 0x0086B5A0u; /* 0x00782350: mov ecx, 0x86b5a0 */
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x00782355: jmp 0x5ce0f0 */

}

void sub_00782360(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782360u);

L_00782360:
    ecx = 0x0086B4C0u; /* 0x00782360: mov ecx, 0x86b4c0 */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00782365: jmp 0x5cde60 */

}

void sub_00782370(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782370u);

L_00782370:
    ecx = 0x0086B5A8u; /* 0x00782370: mov ecx, 0x86b5a8 */
    RECOMP_ITAIL(0x005B32C0u); RECOMP_RETURN(); /* 0x00782375: jmp 0x5b32c0 */

}

void sub_00782380(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782380u);

L_00782380:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782380: ret  */

}

void sub_00782390(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782390u);

L_00782390:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782390: ret  */

}

void sub_007823A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007823A0u);

L_007823A0:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007823A0: ret  */

}

void sub_007823B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007823B0u);

L_007823B0:
    PUSH32(esp, 0x005B7FA0u); /* 0x007823B0: push 0x5b7fa0 */
    PUSH32(esp, 6); /* 0x007823B5: push 6 */
    PUSH32(esp, 0x370u); /* 0x007823B7: push 0x370 */
    PUSH32(esp, 0x00874C40u); /* 0x007823BC: push 0x874c40 */
    RECOMP_CALL(sub_0075C33D); /* 0x007823C1: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007823C6: ret  */

}

void sub_007823D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007823D0u);

L_007823D0:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007823D0: ret  */

}

void sub_007823E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007823E0u);

L_007823E0:
    ecx = 0x00872B4Cu; /* 0x007823E0: mov ecx, 0x872b4c */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x007823E5: jmp 0x5cde60 */

}

void sub_007823F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007823F0u);

L_007823F0:
    ecx = 0x008763B0u; /* 0x007823F0: mov ecx, 0x8763b0 */
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x007823F5: jmp 0x5ce0f0 */

}

void sub_00782400(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782400u);

L_00782400:
    ecx = 0x00872ED0u; /* 0x00782400: mov ecx, 0x872ed0 */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00782405: jmp 0x5cde60 */

}

void sub_00782410(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782410u);

L_00782410:
    ecx = 0x00872B44u; /* 0x00782410: mov ecx, 0x872b44 */
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x00782415: jmp 0x5ce0f0 */

}

void sub_00782420(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782420u);

L_00782420:
    ecx = 0x00870D28u; /* 0x00782420: mov ecx, 0x870d28 */
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x00782425: jmp 0x5ce0f0 */

}

void sub_00782430(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782430u);

L_00782430:
    PUSH32(esp, 0x005CF3C0u); /* 0x00782430: push 0x5cf3c0 */
    PUSH32(esp, 0x10u); /* 0x00782435: push 0x10 */
    PUSH32(esp, 0xB8u); /* 0x00782437: push 0xb8 */
    PUSH32(esp, 0x00870D30u); /* 0x0078243C: push 0x870d30 */
    RECOMP_CALL(sub_0075C33D); /* 0x00782441: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782446: ret  */

}

void sub_00782450(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782450u);

L_00782450:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782450: ret  */

}

void sub_00782460(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782460u);

L_00782460:
    PUSH32(esp, 0x00605400u); /* 0x00782460: push 0x605400 */
    PUSH32(esp, 2); /* 0x00782465: push 2 */
    PUSH32(esp, 0x30u); /* 0x00782467: push 0x30 */
    PUSH32(esp, 0x0088A2C0u); /* 0x00782469: push 0x88a2c0 */
    RECOMP_CALL(sub_0075C33D); /* 0x0078246E: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782473: ret  */

}

void sub_00782480(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782480u);

L_00782480:
    PUSH32(esp, 0x00605400u); /* 0x00782480: push 0x605400 */
    PUSH32(esp, 2); /* 0x00782485: push 2 */
    PUSH32(esp, 0x30u); /* 0x00782487: push 0x30 */
    PUSH32(esp, 0x0088EA08u); /* 0x00782489: push 0x88ea08 */
    RECOMP_CALL(sub_0075C33D); /* 0x0078248E: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782493: ret  */

}

void sub_007824A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007824A0u);

L_007824A0:
    PUSH32(esp, 0x00605400u); /* 0x007824A0: push 0x605400 */
    PUSH32(esp, 2); /* 0x007824A5: push 2 */
    PUSH32(esp, 0x30u); /* 0x007824A7: push 0x30 */
    PUSH32(esp, 0x0088F210u); /* 0x007824A9: push 0x88f210 */
    RECOMP_CALL(sub_0075C33D); /* 0x007824AE: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007824B3: ret  */

}

void sub_007824C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007824C0u);

L_007824C0:
    ecx = 0x0088EA68u; /* 0x007824C0: mov ecx, 0x88ea68 */
    RECOMP_ITAIL(0x00436820u); RECOMP_RETURN(); /* 0x007824C5: jmp 0x436820 */

}

void sub_007824D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007824D0u);

L_007824D0:
    ecx = 0x0088EA8Cu; /* 0x007824D0: mov ecx, 0x88ea8c */
    RECOMP_ITAIL(0x005DC580u); RECOMP_RETURN(); /* 0x007824D5: jmp 0x5dc580 */

}

void sub_007824E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007824E0u);

L_007824E0:
    ecx = 0x0088E9FCu; /* 0x007824E0: mov ecx, 0x88e9fc */
    RECOMP_ITAIL(0x005DC5B0u); RECOMP_RETURN(); /* 0x007824E5: jmp 0x5dc5b0 */

}

void sub_007824F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007824F0u);

L_007824F0:
    ecx = 0x0088EA84u; /* 0x007824F0: mov ecx, 0x88ea84 */
    RECOMP_ITAIL(0x005DC5F0u); RECOMP_RETURN(); /* 0x007824F5: jmp 0x5dc5f0 */

}

void sub_00782500(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782500u);

L_00782500:
    ecx = 0x0088EADCu; /* 0x00782500: mov ecx, 0x88eadc */
    RECOMP_ITAIL(0x005DC630u); RECOMP_RETURN(); /* 0x00782505: jmp 0x5dc630 */

}

void sub_00782510(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782510u);

L_00782510:
    ecx = 0x0088F760u; /* 0x00782510: mov ecx, 0x88f760 */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00782515: jmp 0x5cde60 */

}

void sub_00782520(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782520u);

L_00782520:
    ecx = 0x0088E9C4u; /* 0x00782520: mov ecx, 0x88e9c4 */
    RECOMP_ITAIL(0x005E0820u); RECOMP_RETURN(); /* 0x00782525: jmp 0x5e0820 */

}

void sub_00782530(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782530u);

L_00782530:
    ecx = 0x0088F208u; /* 0x00782530: mov ecx, 0x88f208 */
    RECOMP_ITAIL(0x005E0860u); RECOMP_RETURN(); /* 0x00782535: jmp 0x5e0860 */

}

void sub_00782540(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782540u);

L_00782540:
    ecx = 0x0088FF98u; /* 0x00782540: mov ecx, 0x88ff98 */
    RECOMP_ITAIL(0x005CE0F0u); RECOMP_RETURN(); /* 0x00782545: jmp 0x5ce0f0 */

}

void sub_00782550(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782550u);

L_00782550:
    ecx = 0x0088F270u; /* 0x00782550: mov ecx, 0x88f270 */
    RECOMP_ITAIL(0x005E57D0u); RECOMP_RETURN(); /* 0x00782555: jmp 0x5e57d0 */

}

void sub_00782560(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782560u);

L_00782560:
    ecx = 0x0088F740u; /* 0x00782560: mov ecx, 0x88f740 */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00782565: jmp 0x5cde60 */

}

void sub_00782570(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782570u);

L_00782570:
    ecx = 0x0088F298u; /* 0x00782570: mov ecx, 0x88f298 */
    RECOMP_ITAIL(0x005E4890u); RECOMP_RETURN(); /* 0x00782575: jmp 0x5e4890 */

}

void sub_00782580(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782580u);

L_00782580:
    ecx = 0x0088EAD4u; /* 0x00782580: mov ecx, 0x88ead4 */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00782585: jmp 0x5cde60 */

}

void sub_00782590(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782590u);

L_00782590:
    PUSH32(esp, 0x005CDE60u); /* 0x00782590: push 0x5cde60 */
    PUSH32(esp, 8); /* 0x00782595: push 8 */
    PUSH32(esp, 8); /* 0x00782597: push 8 */
    PUSH32(esp, 0x0088F1C8u); /* 0x00782599: push 0x88f1c8 */
    RECOMP_CALL(sub_0075C33D); /* 0x0078259E: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007825A3: ret  */

}

void sub_007825B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007825B0u);

L_007825B0:
    ecx = 0x0088F28Cu; /* 0x007825B0: mov ecx, 0x88f28c */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x007825B5: jmp 0x5cde60 */

}

void sub_007825C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007825C0u);

L_007825C0:
    ecx = 0x0088FFA0u; /* 0x007825C0: mov ecx, 0x88ffa0 */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x007825C5: jmp 0x5cde60 */

}

void sub_007825D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007825D0u);

L_007825D0:
    ecx = 0x0088F1BCu; /* 0x007825D0: mov ecx, 0x88f1bc */
    RECOMP_ITAIL(0x005E6690u); RECOMP_RETURN(); /* 0x007825D5: jmp 0x5e6690 */

}

void sub_007825E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007825E0u);

L_007825E0:
    ecx = 0x0088A320u; /* 0x007825E0: mov ecx, 0x88a320 */
    RECOMP_ITAIL(0x005E5B00u); RECOMP_RETURN(); /* 0x007825E5: jmp 0x5e5b00 */

}

void sub_007825F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007825F0u);

L_007825F0:
    ecx = 0x00883E70u; /* 0x007825F0: mov ecx, 0x883e70 */
    RECOMP_ITAIL(0x005E6480u); RECOMP_RETURN(); /* 0x007825F5: jmp 0x5e6480 */

}

void sub_00782600(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782600u);

L_00782600:
    ecx = 0x0088F768u; /* 0x00782600: mov ecx, 0x88f768 */
    RECOMP_ITAIL(0x005E81F0u); RECOMP_RETURN(); /* 0x00782605: jmp 0x5e81f0 */

}

void sub_00782610(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782610u);

L_00782610:
    PUSH32(esp, 0x0050F700u); /* 0x00782610: push 0x50f700 */
    PUSH32(esp, 0x16u); /* 0x00782615: push 0x16 */
    PUSH32(esp, 0x940u); /* 0x00782617: push 0x940 */
    PUSH32(esp, 0x00890160u); /* 0x0078261C: push 0x890160 */
    RECOMP_CALL(sub_0075C33D); /* 0x00782621: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782626: ret  */

}

void sub_00782630(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782630u);

L_00782630:
    ecx = 0x0089CF48u; /* 0x00782630: mov ecx, 0x89cf48 */
    RECOMP_ITAIL(0x005EFCB0u); RECOMP_RETURN(); /* 0x00782635: jmp 0x5efcb0 */

}

void sub_00782640(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782640u);

L_00782640:
    ecx = 0x0089E838u; /* 0x00782640: mov ecx, 0x89e838 */
    RECOMP_ITAIL(0x00490340u); RECOMP_RETURN(); /* 0x00782645: jmp 0x490340 */

}

void sub_00782650(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782650u);

L_00782650:
    ecx = 0x0089E844u; /* 0x00782650: mov ecx, 0x89e844 */
    RECOMP_ITAIL(0x0060B2F0u); RECOMP_RETURN(); /* 0x00782655: jmp 0x60b2f0 */

}

void sub_00782660(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782660u);

L_00782660:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782660: ret  */

}

void sub_00782670(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782670u);

L_00782670:
    ecx = 0x008A1F28u; /* 0x00782670: mov ecx, 0x8a1f28 */
    RECOMP_ITAIL(0x00605390u); RECOMP_RETURN(); /* 0x00782675: jmp 0x605390 */

}

void sub_00782680(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782680u);

L_00782680:
    PUSH32(esp, 0x00605400u); /* 0x00782680: push 0x605400 */
    PUSH32(esp, 2); /* 0x00782685: push 2 */
    PUSH32(esp, 0x30u); /* 0x00782687: push 0x30 */
    PUSH32(esp, 0x008A3180u); /* 0x00782689: push 0x8a3180 */
    RECOMP_CALL(sub_0075C33D); /* 0x0078268E: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782693: ret  */

}

void sub_007826A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007826A0u);

L_007826A0:
    PUSH32(esp, 0x00605400u); /* 0x007826A0: push 0x605400 */
    PUSH32(esp, 2); /* 0x007826A5: push 2 */
    PUSH32(esp, 0x30u); /* 0x007826A7: push 0x30 */
    PUSH32(esp, 0x008A1E90u); /* 0x007826A9: push 0x8a1e90 */
    RECOMP_CALL(sub_0075C33D); /* 0x007826AE: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007826B3: ret  */

}

void sub_007826C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007826C0u);

L_007826C0:
    PUSH32(esp, 0x00605400u); /* 0x007826C0: push 0x605400 */
    PUSH32(esp, 2); /* 0x007826C5: push 2 */
    PUSH32(esp, 0x30u); /* 0x007826C7: push 0x30 */
    PUSH32(esp, 0x008A31F0u); /* 0x007826C9: push 0x8a31f0 */
    RECOMP_CALL(sub_0075C33D); /* 0x007826CE: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007826D3: ret  */

}

void sub_007826E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007826E0u);

L_007826E0:
    PUSH32(esp, 0x00605400u); /* 0x007826E0: push 0x605400 */
    PUSH32(esp, 2); /* 0x007826E5: push 2 */
    PUSH32(esp, 0x30u); /* 0x007826E7: push 0x30 */
    PUSH32(esp, 0x008A1E30u); /* 0x007826E9: push 0x8a1e30 */
    RECOMP_CALL(sub_0075C33D); /* 0x007826EE: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007826F3: ret  */

}

void sub_00782700(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782700u);

L_00782700:
    PUSH32(esp, 0x00605390u); /* 0x00782700: push 0x605390 */
    PUSH32(esp, 2); /* 0x00782705: push 2 */
    PUSH32(esp, 0x1Cu); /* 0x00782707: push 0x1c */
    PUSH32(esp, 0x008A3250u); /* 0x00782709: push 0x8a3250 */
    RECOMP_CALL(sub_0075C33D); /* 0x0078270E: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782713: ret  */

}

void sub_00782720(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782720u);

L_00782720:
    ecx = 0x008A1DE4u; /* 0x00782720: mov ecx, 0x8a1de4 */
    RECOMP_ITAIL(0x00490370u); RECOMP_RETURN(); /* 0x00782725: jmp 0x490370 */

}

void sub_00782730(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782730u);

L_00782730:
    ecx = 0x008A3168u; /* 0x00782730: mov ecx, 0x8a3168 */
    RECOMP_ITAIL(0x00490370u); RECOMP_RETURN(); /* 0x00782735: jmp 0x490370 */

}

void sub_00782740(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782740u);

L_00782740:
    ecx = 0x008A1DFCu; /* 0x00782740: mov ecx, 0x8a1dfc */
    RECOMP_ITAIL(0x00490370u); RECOMP_RETURN(); /* 0x00782745: jmp 0x490370 */

}

void sub_00782750(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782750u);

L_00782750:
    ecx = 0x008A1F10u; /* 0x00782750: mov ecx, 0x8a1f10 */
    RECOMP_ITAIL(0x00490370u); RECOMP_RETURN(); /* 0x00782755: jmp 0x490370 */

}

void sub_00782760(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782760u);

L_00782760:
    PUSH32(esp, 0x004022D0u); /* 0x00782760: push 0x4022d0 */
    PUSH32(esp, 1); /* 0x00782765: push 1 */
    PUSH32(esp, 0x64u); /* 0x00782767: push 0x64 */
    PUSH32(esp, 0x008A42C0u); /* 0x00782769: push 0x8a42c0 */
    RECOMP_CALL(sub_0075C33D); /* 0x0078276E: call 0x75c33d */
    RECOMP_FLAGS_IN();
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782773: ret  */

}

void sub_00782780(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782780u);

L_00782780:
    ecx = 0x008A2B50u; /* 0x00782780: mov ecx, 0x8a2b50 */
    RECOMP_ITAIL(0x00637ED0u); RECOMP_RETURN(); /* 0x00782785: jmp 0x637ed0 */

}

void sub_00782790(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782790u);

L_00782790:
    ecx = 0x008A2B68u; /* 0x00782790: mov ecx, 0x8a2b68 */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x00782795: jmp 0x5cde60 */

}

void sub_007827A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007827A0u);

L_007827A0:
    ecx = 0x008A31E4u; /* 0x007827A0: mov ecx, 0x8a31e4 */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x007827A5: jmp 0x5cde60 */

}

void sub_007827B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007827B0u);

L_007827B0:
    ecx = 0x008A3288u; /* 0x007827B0: mov ecx, 0x8a3288 */
    RECOMP_ITAIL(0x006379B0u); RECOMP_RETURN(); /* 0x007827B5: jmp 0x6379b0 */

}

void sub_007827C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007827C0u);

L_007827C0:
    ecx = 0x008A3148u; /* 0x007827C0: mov ecx, 0x8a3148 */
    RECOMP_ITAIL(0x005CDE60u); RECOMP_RETURN(); /* 0x007827C5: jmp 0x5cde60 */

}

void sub_007827D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007827D0u);

L_007827D0:
    ecx = 0x008A4260u; /* 0x007827D0: mov ecx, 0x8a4260 */
    RECOMP_ITAIL(0x00637F10u); RECOMP_RETURN(); /* 0x007827D5: jmp 0x637f10 */

}

void sub_007827E0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007827E0u);

L_007827E0:
    ecx = 0x008A2CA4u; /* 0x007827E0: mov ecx, 0x8a2ca4 */
    RECOMP_ITAIL(0x0063B4D0u); RECOMP_RETURN(); /* 0x007827E5: jmp 0x63b4d0 */

}

void sub_007827F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007827F0u);

L_007827F0:
    ecx = 0x008A30F0u; /* 0x007827F0: mov ecx, 0x8a30f0 */
    RECOMP_ITAIL(0x0063B510u); RECOMP_RETURN(); /* 0x007827F5: jmp 0x63b510 */

}

void sub_00782800(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782800u);

L_00782800:
    ecx = 0x008A2C9Cu; /* 0x00782800: mov ecx, 0x8a2c9c */
    RECOMP_ITAIL(0x0063B550u); RECOMP_RETURN(); /* 0x00782805: jmp 0x63b550 */

}

void sub_00782810(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782810u);

    goto L_00782810;

L_006D86C0:
    PUSH32(esp, esi); /* 0x006D86C0: push esi */
    esi = ecx; /* 0x006D86C1: mov esi, ecx */
    RECOMP_CALL(sub_006D8630); /* 0x006D86C3: call 0x6d8630 */
    RECOMP_FLAGS_IN();
    eax = MEM32(esi + 0x8); /* 0x006D86C8: mov eax, dword ptr [esi + 8] */
    /* test eax, eax */ /* 0x006D86CB: test eax, eax */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(eax);
    _cf = 0;
    _flag_k = FK_TEST;
    if (TEST_Z(_flag_a, _flag_b)) goto L_006D86E7; /* 0x006D86CD: je 0x6d86e7 */

L_006D86CF:
    ecx = MEM32(esi + 0x4); /* 0x006D86CF: mov ecx, dword ptr [esi + 4] */
    if (2u) _cf = (((ecx) >> 30) & 1u); /* 0x006D86D2: shl ecx, 2 */
    if (2u) { _flag_a = recomp_flags_pack((ecx << 2u), _cf, 0, 0); _flag_b = 0; _flag_k = FK_EFLAGS; }
    ecx = ecx << 2u; /* 0x006D86D2: shl ecx, 2 */
    PUSH32(esp, ecx); /* 0x006D86D5: push ecx */
    PUSH32(esp, eax); /* 0x006D86D6: push eax */
    RECOMP_ICALL(MEM32(0x80BFDC)); /* 0x006D86D7: call dword ptr [0x80bfdc] */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(8);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 8; /* 0x006D86DD: add esp, 8 */
    _flag_k = FK_ADD;
    MEM32(esi + 0x8) = 0; /* 0x006D86E0: mov dword ptr [esi + 8], 0 */

L_006D86E7:
    esi = POP32_VAL(esp); /* 0x006D86E7: pop esi */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x006D86E8: ret  */

L_00782810:
    ecx = 0x008A7114u; /* 0x00782810: mov ecx, 0x8a7114 */
    RECOMP_BACKEDGE();
    goto L_006D86C0; /* 0x00782815: jmp 0x6d86c0 */

}

void sub_00782820(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782820u);

    goto L_00782820;

L_006D86C0:
    PUSH32(esp, esi); /* 0x006D86C0: push esi */
    esi = ecx; /* 0x006D86C1: mov esi, ecx */
    RECOMP_CALL(sub_006D8630); /* 0x006D86C3: call 0x6d8630 */
    RECOMP_FLAGS_IN();
    eax = MEM32(esi + 0x8); /* 0x006D86C8: mov eax, dword ptr [esi + 8] */
    /* test eax, eax */ /* 0x006D86CB: test eax, eax */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(eax);
    _cf = 0;
    _flag_k = FK_TEST;
    if (TEST_Z(_flag_a, _flag_b)) goto L_006D86E7; /* 0x006D86CD: je 0x6d86e7 */

L_006D86CF:
    ecx = MEM32(esi + 0x4); /* 0x006D86CF: mov ecx, dword ptr [esi + 4] */
    if (2u) _cf = (((ecx) >> 30) & 1u); /* 0x006D86D2: shl ecx, 2 */
    if (2u) { _flag_a = recomp_flags_pack((ecx << 2u), _cf, 0, 0); _flag_b = 0; _flag_k = FK_EFLAGS; }
    ecx = ecx << 2u; /* 0x006D86D2: shl ecx, 2 */
    PUSH32(esp, ecx); /* 0x006D86D5: push ecx */
    PUSH32(esp, eax); /* 0x006D86D6: push eax */
    RECOMP_ICALL(MEM32(0x80BFDC)); /* 0x006D86D7: call dword ptr [0x80bfdc] */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(8);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 8; /* 0x006D86DD: add esp, 8 */
    _flag_k = FK_ADD;
    MEM32(esi + 0x8) = 0; /* 0x006D86E0: mov dword ptr [esi + 8], 0 */

L_006D86E7:
    esi = POP32_VAL(esp); /* 0x006D86E7: pop esi */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x006D86E8: ret  */

L_006D87A0:
    PUSH32(esp, esi); /* 0x006D87A0: push esi */
    PUSH32(esp, edi); /* 0x006D87A1: push edi */
    esi = ecx; /* 0x006D87A2: mov esi, ecx */
    RECOMP_CALL(sub_006D86C0); /* 0x006D87A4: call 0x6d86c0 */
    RECOMP_FLAGS_IN();
    edi = esi + 0x14; /* 0x006D87A9: lea edi, [esi + 0x14] */
    ecx = edi; /* 0x006D87AC: mov ecx, edi */
    RECOMP_CALL(sub_006D86C0); /* 0x006D87AE: call 0x6d86c0 */
    RECOMP_FLAGS_IN();
    ecx = edi; /* 0x006D87B3: mov ecx, edi */
    RECOMP_CALL(sub_006D86C0); /* 0x006D87B5: call 0x6d86c0 */
    RECOMP_FLAGS_IN();
    edi = POP32_VAL(esp); /* 0x006D87BA: pop edi */
    ecx = esi; /* 0x006D87BB: mov ecx, esi */
    esi = POP32_VAL(esp); /* 0x006D87BD: pop esi */
    RECOMP_BACKEDGE();
    goto L_006D86C0; /* 0x006D87BE: jmp 0x6d86c0 */

L_00782820:
    ecx = 0x008A7168u; /* 0x00782820: mov ecx, 0x8a7168 */
    RECOMP_BACKEDGE();
    goto L_006D87A0; /* 0x00782825: jmp 0x6d87a0 */

}

void sub_00782830(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782830u);

    goto L_00782830;

L_006D86C0:
    PUSH32(esp, esi); /* 0x006D86C0: push esi */
    esi = ecx; /* 0x006D86C1: mov esi, ecx */
    RECOMP_CALL(sub_006D8630); /* 0x006D86C3: call 0x6d8630 */
    RECOMP_FLAGS_IN();
    eax = MEM32(esi + 0x8); /* 0x006D86C8: mov eax, dword ptr [esi + 8] */
    /* test eax, eax */ /* 0x006D86CB: test eax, eax */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(eax);
    _cf = 0;
    _flag_k = FK_TEST;
    if (TEST_Z(_flag_a, _flag_b)) goto L_006D86E7; /* 0x006D86CD: je 0x6d86e7 */

L_006D86CF:
    ecx = MEM32(esi + 0x4); /* 0x006D86CF: mov ecx, dword ptr [esi + 4] */
    if (2u) _cf = (((ecx) >> 30) & 1u); /* 0x006D86D2: shl ecx, 2 */
    if (2u) { _flag_a = recomp_flags_pack((ecx << 2u), _cf, 0, 0); _flag_b = 0; _flag_k = FK_EFLAGS; }
    ecx = ecx << 2u; /* 0x006D86D2: shl ecx, 2 */
    PUSH32(esp, ecx); /* 0x006D86D5: push ecx */
    PUSH32(esp, eax); /* 0x006D86D6: push eax */
    RECOMP_ICALL(MEM32(0x80BFDC)); /* 0x006D86D7: call dword ptr [0x80bfdc] */
    RECOMP_FLAGS_IN();
    _flag_a = (uint32_t)(esp); _flag_b = (uint32_t)(8);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    esp = esp + 8; /* 0x006D86DD: add esp, 8 */
    _flag_k = FK_ADD;
    MEM32(esi + 0x8) = 0; /* 0x006D86E0: mov dword ptr [esi + 8], 0 */

L_006D86E7:
    esi = POP32_VAL(esp); /* 0x006D86E7: pop esi */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x006D86E8: ret  */

L_006D87A0:
    PUSH32(esp, esi); /* 0x006D87A0: push esi */
    PUSH32(esp, edi); /* 0x006D87A1: push edi */
    esi = ecx; /* 0x006D87A2: mov esi, ecx */
    RECOMP_CALL(sub_006D86C0); /* 0x006D87A4: call 0x6d86c0 */
    RECOMP_FLAGS_IN();
    edi = esi + 0x14; /* 0x006D87A9: lea edi, [esi + 0x14] */
    ecx = edi; /* 0x006D87AC: mov ecx, edi */
    RECOMP_CALL(sub_006D86C0); /* 0x006D87AE: call 0x6d86c0 */
    RECOMP_FLAGS_IN();
    ecx = edi; /* 0x006D87B3: mov ecx, edi */
    RECOMP_CALL(sub_006D86C0); /* 0x006D87B5: call 0x6d86c0 */
    RECOMP_FLAGS_IN();
    edi = POP32_VAL(esp); /* 0x006D87BA: pop edi */
    ecx = esi; /* 0x006D87BB: mov ecx, esi */
    esi = POP32_VAL(esp); /* 0x006D87BD: pop esi */
    RECOMP_BACKEDGE();
    goto L_006D86C0; /* 0x006D87BE: jmp 0x6d86c0 */

L_00782830:
    ecx = 0x008A7140u; /* 0x00782830: mov ecx, 0x8a7140 */
    RECOMP_BACKEDGE();
    goto L_006D87A0; /* 0x00782835: jmp 0x6d87a0 */

}

void sub_00782840(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782840u);

L_00782840:
    ecx = 0x008A7BF8u; /* 0x00782840: mov ecx, 0x8a7bf8 */
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x00782845: jmp 0x4022d0 */

}

void sub_00782850(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782850u);

L_00782850:
    ecx = 0x008A7E38u; /* 0x00782850: mov ecx, 0x8a7e38 */
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x00782855: jmp 0x4022d0 */

}

void sub_00782860(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782860u);

L_00782860:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782860: ret  */

}

void sub_00782870(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782870u);

    goto L_00782870;

L_006DE380:
    eax = MEM32(0x8A85CC); /* 0x006DE380: mov eax, dword ptr [0x8a85cc] */
    /* cmp eax, ecx */ /* 0x006DE385: cmp eax, ecx */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(ecx);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    _flag_k = FK_CMP;
    if (CMP_NE(_flag_a, _flag_b)) goto L_006DE395; /* 0x006DE387: jne 0x6de395 */

L_006DE389:
    eax = MEM32(ecx + 0x124); /* 0x006DE389: mov eax, dword ptr [ecx + 0x124] */
    MEM32(0x8A85CC) = eax; /* 0x006DE38F: mov dword ptr [0x8a85cc], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x006DE394: ret  */

L_006DE395:
    /* cmp MEM32(eax + 0x124), ecx */ /* 0x006DE395: cmp dword ptr [eax + 0x124], ecx */
    _flag_a = (uint32_t)(MEM32(eax + 0x124)); _flag_b = (uint32_t)(ecx);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    _flag_k = FK_CMP;
    if (CMP_EQ(_flag_a, _flag_b)) goto L_006DE3BC; /* 0x006DE39B: je 0x6de3bc */

L_006DE39D:
    ecx = ecx; /* 0x006DE39D: lea ecx, [ecx] */

L_006DE3A0:
    edx = MEM32(eax + 0x124); /* 0x006DE3A0: mov edx, dword ptr [eax + 0x124] */
    /* test edx, edx */ /* 0x006DE3A6: test edx, edx */
    _flag_a = (uint32_t)(edx); _flag_b = (uint32_t)(edx);
    _cf = 0;
    _flag_k = FK_TEST;
    if (TEST_Z(_flag_a, _flag_b)) goto L_006DE3B4; /* 0x006DE3A8: je 0x6de3b4 */

L_006DE3AA:
    eax = edx; /* 0x006DE3AA: mov eax, edx */
    /* cmp MEM32(eax + 0x124), ecx */ /* 0x006DE3AC: cmp dword ptr [eax + 0x124], ecx */
    _flag_a = (uint32_t)(MEM32(eax + 0x124)); _flag_b = (uint32_t)(ecx);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    _flag_k = FK_CMP;
    RECOMP_BACKEDGE();
    if (CMP_NE(_flag_a, _flag_b)) goto L_006DE3A0; /* 0x006DE3B2: jne 0x6de3a0 */

L_006DE3B4:
    /* cmp MEM32(eax + 0x124), ecx */ /* 0x006DE3B4: cmp dword ptr [eax + 0x124], ecx */
    _flag_a = (uint32_t)(MEM32(eax + 0x124)); _flag_b = (uint32_t)(ecx);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    _flag_k = FK_CMP;
    if (CMP_NE(_flag_a, _flag_b)) goto L_006DE3C8; /* 0x006DE3BA: jne 0x6de3c8 */

L_006DE3BC:
    ecx = MEM32(ecx + 0x124); /* 0x006DE3BC: mov ecx, dword ptr [ecx + 0x124] */
    MEM32(eax + 0x124) = ecx; /* 0x006DE3C2: mov dword ptr [eax + 0x124], ecx */

L_006DE3C8:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x006DE3C8: ret  */

L_00782870:
    ecx = 0x008A85F0u; /* 0x00782870: mov ecx, 0x8a85f0 */
    RECOMP_BACKEDGE();
    goto L_006DE380; /* 0x00782875: jmp 0x6de380 */

}

void sub_00782880(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782880u);

    goto L_00782880;

L_006DE380:
    eax = MEM32(0x8A85CC); /* 0x006DE380: mov eax, dword ptr [0x8a85cc] */
    /* cmp eax, ecx */ /* 0x006DE385: cmp eax, ecx */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(ecx);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    _flag_k = FK_CMP;
    if (CMP_NE(_flag_a, _flag_b)) goto L_006DE395; /* 0x006DE387: jne 0x6de395 */

L_006DE389:
    eax = MEM32(ecx + 0x124); /* 0x006DE389: mov eax, dword ptr [ecx + 0x124] */
    MEM32(0x8A85CC) = eax; /* 0x006DE38F: mov dword ptr [0x8a85cc], eax */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x006DE394: ret  */

L_006DE395:
    /* cmp MEM32(eax + 0x124), ecx */ /* 0x006DE395: cmp dword ptr [eax + 0x124], ecx */
    _flag_a = (uint32_t)(MEM32(eax + 0x124)); _flag_b = (uint32_t)(ecx);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    _flag_k = FK_CMP;
    if (CMP_EQ(_flag_a, _flag_b)) goto L_006DE3BC; /* 0x006DE39B: je 0x6de3bc */

L_006DE39D:
    ecx = ecx; /* 0x006DE39D: lea ecx, [ecx] */

L_006DE3A0:
    edx = MEM32(eax + 0x124); /* 0x006DE3A0: mov edx, dword ptr [eax + 0x124] */
    /* test edx, edx */ /* 0x006DE3A6: test edx, edx */
    _flag_a = (uint32_t)(edx); _flag_b = (uint32_t)(edx);
    _cf = 0;
    _flag_k = FK_TEST;
    if (TEST_Z(_flag_a, _flag_b)) goto L_006DE3B4; /* 0x006DE3A8: je 0x6de3b4 */

L_006DE3AA:
    eax = edx; /* 0x006DE3AA: mov eax, edx */
    /* cmp MEM32(eax + 0x124), ecx */ /* 0x006DE3AC: cmp dword ptr [eax + 0x124], ecx */
    _flag_a = (uint32_t)(MEM32(eax + 0x124)); _flag_b = (uint32_t)(ecx);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    _flag_k = FK_CMP;
    RECOMP_BACKEDGE();
    if (CMP_NE(_flag_a, _flag_b)) goto L_006DE3A0; /* 0x006DE3B2: jne 0x6de3a0 */

L_006DE3B4:
    /* cmp MEM32(eax + 0x124), ecx */ /* 0x006DE3B4: cmp dword ptr [eax + 0x124], ecx */
    _flag_a = (uint32_t)(MEM32(eax + 0x124)); _flag_b = (uint32_t)(ecx);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    _flag_k = FK_CMP;
    if (CMP_NE(_flag_a, _flag_b)) goto L_006DE3C8; /* 0x006DE3BA: jne 0x6de3c8 */

L_006DE3BC:
    ecx = MEM32(ecx + 0x124); /* 0x006DE3BC: mov ecx, dword ptr [ecx + 0x124] */
    MEM32(eax + 0x124) = ecx; /* 0x006DE3C2: mov dword ptr [eax + 0x124], ecx */

L_006DE3C8:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x006DE3C8: ret  */

L_00782880:
    ecx = 0x008A8738u; /* 0x00782880: mov ecx, 0x8a8738 */
    RECOMP_BACKEDGE();
    goto L_006DE380; /* 0x00782885: jmp 0x6de380 */

}

void sub_00782890(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782890u);

    goto L_00782890;

L_006DE630:
    PUSH32(esp, ecx); /* 0x006DE630: push ecx */
    MEM32(esp) = ecx; /* 0x006DE631: mov dword ptr [esp], ecx */
    SET_LO8(eax, MEM8(ecx + 0x10)); /* 0x006DE635: mov al, byte ptr [ecx + 0x10] */
    /* test LO8(eax), LO8(eax) */ /* 0x006DE638: test al, al */
    _flag_a = (uint32_t)(LO8(eax)) << 24; _flag_b = (uint32_t)(LO8(eax)) << 24;
    _cf = 0;
    _flag_k = FK_NARROW(FK_TEST, 24);
    if (TEST_Z(_flag_a, _flag_b)) goto L_006DE680; /* 0x006DE63A: je 0x6de680 */

L_006DE63C:
    PUSH32(esp, esi); /* 0x006DE63C: push esi */
    { uint64_t _t = __rdtsc(); eax = (uint32_t)_t; edx = (uint32_t)(_t >> 32); } /* 0x006DE63D: rdtsc  */
    edx = MEM32(esp + 0x4); /* 0x006DE63F: mov edx, dword ptr [esp + 4] */
    esi = MEM32(edx + 0xC); /* 0x006DE643: mov esi, dword ptr [edx + 0xc] */
    ecx = MEM32(edx); /* 0x006DE646: mov ecx, dword ptr [edx] */
    edx = MEM32(ecx + 0x110); /* 0x006DE648: mov edx, dword ptr [ecx + 0x110] */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(esi);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    eax = eax - esi; /* 0x006DE64E: sub eax, esi */
    _flag_k = FK_CMP;
    _flag_a = (uint32_t)(edx); _flag_b = (uint32_t)(eax);
    _cf = (uint32_t)((uint32_t)(_flag_a + _flag_b) < (uint32_t)_flag_a);
    edx = edx + eax; /* 0x006DE650: add edx, eax */
    _flag_k = FK_ADD;
    MEM32(ecx + 0x110) = edx; /* 0x006DE652: mov dword ptr [ecx + 0x110], edx */
    eax = MEM32(esp + 0x4); /* 0x006DE658: mov eax, dword ptr [esp + 4] */
    MEM8(eax + 0x10) = (uint8_t)(0); /* 0x006DE65C: mov byte ptr [eax + 0x10], 0 */
    ecx = MEM32(esp + 0x4); /* 0x006DE660: mov ecx, dword ptr [esp + 4] */
    ecx = MEM32(ecx + 0x4); /* 0x006DE664: mov ecx, dword ptr [ecx + 4] */
    SET_LO8(eax, MEM8(ecx + 0x10)); /* 0x006DE667: mov al, byte ptr [ecx + 0x10] */
    /* test LO8(eax), LO8(eax) */ /* 0x006DE66A: test al, al */
    _flag_a = (uint32_t)(LO8(eax)) << 24; _flag_b = (uint32_t)(LO8(eax)) << 24;
    _cf = 0;
    _flag_k = FK_NARROW(FK_TEST, 24);
    esi = POP32_VAL(esp); /* 0x006DE66C: pop esi */
    if (TEST_NZ(_flag_a, _flag_b)) goto L_006DE68D; /* 0x006DE66D: jne 0x6de68d */

L_006DE66F:
    MEM32(0x80F09C) = ecx; /* 0x006DE66F: mov dword ptr [0x80f09c], ecx */
    { uint64_t _t = __rdtsc(); eax = (uint32_t)_t; edx = (uint32_t)(_t >> 32); } /* 0x006DE675: rdtsc  */
    MEM32(ecx + 0xC) = eax; /* 0x006DE677: mov dword ptr [ecx + 0xc], eax */
    MEM8(ecx + 0x10) = (uint8_t)(1); /* 0x006DE67A: mov byte ptr [ecx + 0x10], 1 */
    ecx = POP32_VAL(esp); /* 0x006DE67E: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x006DE67F: ret  */

L_006DE680:
    eax = MEM32(ecx + 0x8); /* 0x006DE680: mov eax, dword ptr [ecx + 8] */
    /* test eax, eax */ /* 0x006DE683: test eax, eax */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(eax);
    _cf = 0;
    _flag_k = FK_TEST;
    if (TEST_Z(_flag_a, _flag_b)) goto L_006DE68D; /* 0x006DE685: je 0x6de68d */

L_006DE687:
    edx = MEM32(ecx + 0x4); /* 0x006DE687: mov edx, dword ptr [ecx + 4] */
    MEM32(eax + 0x4) = edx; /* 0x006DE68A: mov dword ptr [eax + 4], edx */

L_006DE68D:
    ecx = POP32_VAL(esp); /* 0x006DE68D: pop ecx */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x006DE68E: ret  */

L_00782890:
    ecx = 0x008A8718u; /* 0x00782890: mov ecx, 0x8a8718 */
    RECOMP_BACKEDGE();
    goto L_006DE630; /* 0x00782895: jmp 0x6de630 */

}

void sub_007828A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007828A0u);

L_007828A0:
    ecx = 0x008AAAD8u; /* 0x007828A0: mov ecx, 0x8aaad8 */
    RECOMP_ITAIL(0x004022D0u); RECOMP_RETURN(); /* 0x007828A5: jmp 0x4022d0 */

}

void sub_007828B0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007828B0u);

    goto L_007828B0;

L_006DAE50:
    eax = MEM32(ecx + 0x1C); /* 0x006DAE50: mov eax, dword ptr [ecx + 0x1c] */
    /* test eax, eax */ /* 0x006DAE53: test eax, eax */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(eax);
    _cf = 0;
    _flag_k = FK_TEST;
    if (TEST_Z(_flag_a, _flag_b)) goto L_006DAE63; /* 0x006DAE55: je 0x6dae63 */

L_006DAE57:
    /* cmp MEM32(ecx), 0 */ /* 0x006DAE57: cmp dword ptr [ecx], 0 */
    _flag_a = (uint32_t)(MEM32(ecx)); _flag_b = (uint32_t)(0);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    _flag_k = FK_CMP;
    if (CMP_EQ(_flag_a, _flag_b)) goto L_006DAE63; /* 0x006DAE5A: je 0x6dae63 */

L_006DAE5C:
    PUSH32(esp, ecx); /* 0x006DAE5C: push ecx */
    RECOMP_CALL(sub_006DABC0); /* 0x006DAE5D: call 0x6dabc0 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x006DAE62: pop ecx */

L_006DAE63:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x006DAE63: ret  */

L_007828B0:
    ecx = 0x008AB668u; /* 0x007828B0: mov ecx, 0x8ab668 */
    RECOMP_BACKEDGE();
    goto L_006DAE50; /* 0x007828B5: jmp 0x6dae50 */

}

void sub_007828C0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007828C0u);

    goto L_007828C0;

L_006DAE50:
    eax = MEM32(ecx + 0x1C); /* 0x006DAE50: mov eax, dword ptr [ecx + 0x1c] */
    /* test eax, eax */ /* 0x006DAE53: test eax, eax */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(eax);
    _cf = 0;
    _flag_k = FK_TEST;
    if (TEST_Z(_flag_a, _flag_b)) goto L_006DAE63; /* 0x006DAE55: je 0x6dae63 */

L_006DAE57:
    /* cmp MEM32(ecx), 0 */ /* 0x006DAE57: cmp dword ptr [ecx], 0 */
    _flag_a = (uint32_t)(MEM32(ecx)); _flag_b = (uint32_t)(0);
    _cf = (uint32_t)CMP_B(_flag_a, _flag_b);
    _flag_k = FK_CMP;
    if (CMP_EQ(_flag_a, _flag_b)) goto L_006DAE63; /* 0x006DAE5A: je 0x6dae63 */

L_006DAE5C:
    PUSH32(esp, ecx); /* 0x006DAE5C: push ecx */
    RECOMP_CALL(sub_006DABC0); /* 0x006DAE5D: call 0x6dabc0 */
    RECOMP_FLAGS_IN();
    ecx = POP32_VAL(esp); /* 0x006DAE62: pop ecx */

L_006DAE63:
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x006DAE63: ret  */

L_007828C0:
    ecx = 0x008AB6B8u; /* 0x007828C0: mov ecx, 0x8ab6b8 */
    RECOMP_BACKEDGE();
    goto L_006DAE50; /* 0x007828C5: jmp 0x6dae50 */

}

void sub_007828D0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007828D0u);

L_007828D0:
    MEM32(0x8AD618) = 0x007A035Cu; /* 0x007828D0: mov dword ptr [0x8ad618], 0x7a035c */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007828DA: ret  */

}

void sub_007828DB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007828DBu);

    goto L_007828DB;

L_006FA7C1:
    eax = MEM32(ecx); /* 0x006FA7C1: mov eax, dword ptr [ecx] */
    /* test eax, eax */ /* 0x006FA7C3: test eax, eax */
    _flag_a = (uint32_t)(eax); _flag_b = (uint32_t)(eax);
    _cf = 0;
    _flag_k = FK_TEST;
    if (TEST_Z(_flag_a, _flag_b)) goto L_006FA7D6; /* 0x006FA7C5: je 0x6fa7d6 */

L_006FA7C7:
    edx = MEM32(eax); /* 0x006FA7C7: mov edx, dword ptr [eax] */
    /* test edx, edx */ /* 0x006FA7C9: test edx, edx */
    _flag_a = (uint32_t)(edx); _flag_b = (uint32_t)(edx);
    _cf = 0;
    _flag_k = FK_TEST;
    if (TEST_Z(_flag_a, _flag_b)) goto L_006FA7D6; /* 0x006FA7CB: je 0x6fa7d6 */

L_006FA7CD:
    _flag_a = (uint32_t)(MEM32(eax)); _flag_b = (uint32_t)(0);
    MEM32(eax) = MEM32(eax) & 0; /* 0x006FA7CD: and dword ptr [eax], 0 */
    _cf = 0;
    _flag_k = FK_TEST;
    /* test edx, edx */ /* 0x006FA7D0: test edx, edx */
    _flag_a = (uint32_t)(edx); _flag_b = (uint32_t)(edx);
    _cf = 0;
    _flag_k = FK_TEST;
    eax = edx; /* 0x006FA7D2: mov eax, edx */
    RECOMP_BACKEDGE();
    if (TEST_NZ(_flag_a, _flag_b)) goto L_006FA7C7; /* 0x006FA7D4: jne 0x6fa7c7 */

L_006FA7D6:
    _flag_a = (uint32_t)(MEM32(ecx + 0x4)); _flag_b = (uint32_t)(0);
    MEM32(ecx + 0x4) = MEM32(ecx + 0x4) & 0; /* 0x006FA7D6: and dword ptr [ecx + 4], 0 */
    _cf = 0;
    _flag_k = FK_TEST;
    _flag_a = (uint32_t)(MEM32(ecx)); _flag_b = (uint32_t)(0);
    MEM32(ecx) = MEM32(ecx) & 0; /* 0x006FA7DA: and dword ptr [ecx], 0 */
    _cf = 0;
    _flag_k = FK_TEST;
    _flag_a = (uint32_t)(MEM32(ecx + 0x8)); _flag_b = (uint32_t)(0);
    MEM32(ecx + 0x8) = MEM32(ecx + 0x8) & 0; /* 0x006FA7DD: and dword ptr [ecx + 8], 0 */
    _cf = 0;
    _flag_k = FK_TEST;
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x006FA7E1: ret  */

L_007828DB:
    ecx = 0x008AD69Cu; /* 0x007828DB: mov ecx, 0x8ad69c */
    RECOMP_BACKEDGE();
    goto L_006FA7C1; /* 0x007828E0: jmp 0x6fa7c1 */

}

void sub_007828E5(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007828E5u);

L_007828E5:
    MEM32(0x8AD74C) = 0x007A035Cu; /* 0x007828E5: mov dword ptr [0x8ad74c], 0x7a035c */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007828EF: ret  */

}

void sub_007828F0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007828F0u);

L_007828F0:
    MEM32(0x8AD7B0) = 0x007A035Cu; /* 0x007828F0: mov dword ptr [0x8ad7b0], 0x7a035c */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007828FA: ret  */

}

void sub_007828FB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007828FBu);

L_007828FB:
    MEM32(0x8AD7D8) = 0x007A035Cu; /* 0x007828FB: mov dword ptr [0x8ad7d8], 0x7a035c */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782905: ret  */

}

void sub_00782906(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782906u);

L_00782906:
    MEM32(0x8AD710) = 0x007A035Cu; /* 0x00782906: mov dword ptr [0x8ad710], 0x7a035c */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782910: ret  */

}

void sub_00782911(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782911u);

L_00782911:
    MEM32(0x8AD800) = 0x007A035Cu; /* 0x00782911: mov dword ptr [0x8ad800], 0x7a035c */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078291B: ret  */

}

void sub_0078291C(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0078291Cu);

L_0078291C:
    MEM32(0x8AD760) = 0x007A035Cu; /* 0x0078291C: mov dword ptr [0x8ad760], 0x7a035c */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782926: ret  */

}

void sub_00782927(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782927u);

L_00782927:
    MEM32(0x8AD850) = 0x007A035Cu; /* 0x00782927: mov dword ptr [0x8ad850], 0x7a035c */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782931: ret  */

}

void sub_00782932(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782932u);

L_00782932:
    MEM32(0x8AD724) = 0x007A035Cu; /* 0x00782932: mov dword ptr [0x8ad724], 0x7a035c */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078293C: ret  */

}

void sub_0078293D(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0078293Du);

L_0078293D:
    MEM32(0x8AD83C) = 0x007A035Cu; /* 0x0078293D: mov dword ptr [0x8ad83c], 0x7a035c */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782947: ret  */

}

void sub_00782948(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782948u);

L_00782948:
    MEM32(0x8AD788) = 0x007A035Cu; /* 0x00782948: mov dword ptr [0x8ad788], 0x7a035c */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782952: ret  */

}

void sub_00782953(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782953u);

L_00782953:
    MEM32(0x8AD814) = 0x007A035Cu; /* 0x00782953: mov dword ptr [0x8ad814], 0x7a035c */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078295D: ret  */

}

void sub_0078295E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0078295Eu);

L_0078295E:
    MEM32(0x8AD8B4) = 0x007A035Cu; /* 0x0078295E: mov dword ptr [0x8ad8b4], 0x7a035c */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782968: ret  */

}

void sub_00782969(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782969u);

L_00782969:
    MEM32(0x8AD904) = 0x007A035Cu; /* 0x00782969: mov dword ptr [0x8ad904], 0x7a035c */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782973: ret  */

}

void sub_00782974(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782974u);

L_00782974:
    MEM32(0x8AD878) = 0x007A035Cu; /* 0x00782974: mov dword ptr [0x8ad878], 0x7a035c */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078297E: ret  */

}

void sub_0078297F(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0078297Fu);

L_0078297F:
    MEM32(0x8AD864) = 0x007A035Cu; /* 0x0078297F: mov dword ptr [0x8ad864], 0x7a035c */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782989: ret  */

}

void sub_0078298A(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x0078298Au);

L_0078298A:
    MEM32(0x8AD8C8) = 0x007A035Cu; /* 0x0078298A: mov dword ptr [0x8ad8c8], 0x7a035c */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782994: ret  */

}

void sub_00782995(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782995u);

L_00782995:
    MEM32(0x8AD738) = 0x007A035Cu; /* 0x00782995: mov dword ptr [0x8ad738], 0x7a035c */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x0078299F: ret  */

}

void sub_007829A0(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007829A0u);

L_007829A0:
    MEM32(0x8AD828) = 0x007A035Cu; /* 0x007829A0: mov dword ptr [0x8ad828], 0x7a035c */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007829AA: ret  */

}

void sub_007829AB(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007829ABu);

L_007829AB:
    MEM32(0x8AD774) = 0x007A035Cu; /* 0x007829AB: mov dword ptr [0x8ad774], 0x7a035c */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007829B5: ret  */

}

void sub_007829B6(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007829B6u);

L_007829B6:
    MEM32(0x8AD8A0) = 0x007A035Cu; /* 0x007829B6: mov dword ptr [0x8ad8a0], 0x7a035c */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007829C0: ret  */

}

void sub_007829C1(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007829C1u);

L_007829C1:
    MEM32(0x8AD8DC) = 0x007A035Cu; /* 0x007829C1: mov dword ptr [0x8ad8dc], 0x7a035c */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007829CB: ret  */

}

void sub_007829CC(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007829CCu);

L_007829CC:
    MEM32(0x8AD8F0) = 0x007A035Cu; /* 0x007829CC: mov dword ptr [0x8ad8f0], 0x7a035c */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007829D6: ret  */

}

void sub_007829D7(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007829D7u);

L_007829D7:
    MEM32(0x8AD7C4) = 0x007A035Cu; /* 0x007829D7: mov dword ptr [0x8ad7c4], 0x7a035c */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007829E1: ret  */

}

void sub_007829E2(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007829E2u);

L_007829E2:
    MEM32(0x8AD88C) = 0x007A035Cu; /* 0x007829E2: mov dword ptr [0x8ad88c], 0x7a035c */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007829EC: ret  */

}

void sub_007829ED(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007829EDu);

L_007829ED:
    MEM32(0x8AD79C) = 0x007A035Cu; /* 0x007829ED: mov dword ptr [0x8ad79c], 0x7a035c */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x007829F7: ret  */

}

void sub_007829F8(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x007829F8u);

L_007829F8:
    MEM32(0x8AD7EC) = 0x007A035Cu; /* 0x007829F8: mov dword ptr [0x8ad7ec], 0x7a035c */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782A02: ret  */

}

void sub_00782A03(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782A03u);

L_00782A03:
    MEM32(0x8161E8) = 0x007C3518u; /* 0x00782A03: mov dword ptr [0x8161e8], 0x7c3518 */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782A0D: ret  */

}

void sub_00782A0E(void) {
    int _fpu_cmp = 0;
    uint32_t _cf = 0;  /* carry flag */
    int _df = 1;  /* direction flag (1=forward, -1=backward) */
    uint32_t _flag_a = 0, _flag_b = 0;  /* flag-operand snapshots */
    uint32_t _flag_k = FK_NONE;  /* which instruction wrote them */
    /* _st[8]/_fp_top/_fpu_cw are GLOBAL (shared x87 stack) */
    RECOMP_REGS_LOCALS
    RECOMP_ENTER(0x00782A0Eu);

L_00782A0E:
    MEM32(0x8161F8) = 0x00786DBCu; /* 0x00782A0E: mov dword ptr [0x8161f8], 0x786dbc */
    RECOMP_FLAGS_OUT(); esp += 4; RECOMP_RETURN(); /* 0x00782A18: ret  */

}